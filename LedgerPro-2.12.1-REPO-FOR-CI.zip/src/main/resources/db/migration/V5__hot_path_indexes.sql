-- 2.7.0 performance migration: the hot query paths the worksheet, the trial
-- balance, the dashboard's recent entries and the closing/cash-flow services
-- all filter journal_entries by period (and posted state) or join lines to
-- entries; the period_id index was missing entirely, so every stage query
-- scanned the entries table. ledger_balances is read per period on every
-- dashboard refresh — indexed here too.
CREATE INDEX idx_journal_entries_period_posted
    ON journal_entries(period_id, posted);
CREATE INDEX idx_journal_entries_period_type
    ON journal_entries(period_id, type);
CREATE INDEX idx_ledger_balances_period
    ON ledger_balances(period_id);
