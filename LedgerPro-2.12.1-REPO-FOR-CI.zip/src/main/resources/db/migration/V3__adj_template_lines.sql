-- ============================================================================
-- LedgerPro - V3: multi-line recurring adjustment templates
-- ============================================================================
-- V1 shipped adj_templates with a SINGLE debit/credit account pair
-- (debit_account_id / credit_account_id / params_json). Those columns stay
-- unused and NULL for compatibility; a recurring adjustment is often bigger
-- than one pair, so templates now carry full line lists.
--
-- Lines reference ACCOUNT CODES, not account ids: a template then survives
-- chart rebuilds and can be shared across clients (client_id NULL = shared
-- by every client of the firm).
--
-- Structural guards mirror journal_lines: exactly one side per line, and a
-- positive amount. The full debits = credits rule is enforced in
-- AdjTemplateService, where the accounting rules live.
-- ============================================================================

CREATE TABLE adj_template_lines (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    template_id  INTEGER NOT NULL REFERENCES adj_templates(id),
    line_no      INTEGER NOT NULL,
    account_code TEXT    NOT NULL,
    debit_cents  INTEGER,
    credit_cents INTEGER,
    memo         TEXT,
    UNIQUE (template_id, line_no),
    CHECK ((debit_cents IS NULL) <> (credit_cents IS NULL)),
    CHECK (debit_cents  IS NULL OR debit_cents  > 0),
    CHECK (credit_cents IS NULL OR credit_cents > 0)
);

CREATE INDEX idx_adj_template_lines_template ON adj_template_lines(template_id);
