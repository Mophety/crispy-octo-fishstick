-- ============================================================================
-- LedgerPro - V1: initial schema
-- ============================================================================
-- Database : SQLite
-- Money    : INTEGER cents (never floating point)
-- Dates    : TEXT in ISO-8601 ('YYYY-MM-DD', 'YYYY-MM-DD HH:MM:SS') so plain
--            string comparison == chronological comparison
-- No users table: LedgerPro has NO login system; audit_log.actor defaults to
-- the fixed identity 'local-user'.
--
-- Golden rule of Flyway: once this file has been applied to a database, it is
-- IMMUTABLE. Any future change becomes V2__..., V3__..., never an edit here.
-- ============================================================================

-- 1) CLIENTS - the accounting firm's corporate customers --------------------
CREATE TABLE clients (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    code          TEXT    NOT NULL UNIQUE,          -- short code, e.g. 'ACME'
    name          TEXT    NOT NULL,
    base_currency TEXT    NOT NULL DEFAULT 'PHP',   -- ISO 4217 reporting currency
    active        INTEGER NOT NULL DEFAULT 1,       -- 0 = archived, never deleted
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- 2) PERIODS - accounting periods per client --------------------------------
-- A period is the unit that gets locked at the end of the cycle (step 9).
CREATE TABLE periods (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id  INTEGER NOT NULL REFERENCES clients(id),
    name       TEXT    NOT NULL,                    -- e.g. 'FY2026' or '2026-10'
    start_date TEXT    NOT NULL,                    -- inclusive
    end_date   TEXT    NOT NULL,                    -- inclusive
    status     TEXT    NOT NULL DEFAULT 'OPEN'
               CHECK (status IN ('OPEN', 'CLOSED')),
    UNIQUE (client_id, name),
    CHECK (end_date >= start_date)
);

-- 3) ACCOUNTS - chart of accounts per client --------------------------------
-- normal_side is stored explicitly (not derived from type) so contra accounts
-- work naturally: 'Accumulated Depreciation' is an ASSET with CREDIT normal
-- side, 'Allowance for Doubtful Accounts' likewise.
CREATE TABLE accounts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES clients(id),
    code        TEXT    NOT NULL,                   -- e.g. '1010'
    name        TEXT    NOT NULL,
    type        TEXT    NOT NULL
                CHECK (type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE')),
    normal_side TEXT    NOT NULL CHECK (normal_side IN ('DEBIT','CREDIT')),
    active      INTEGER NOT NULL DEFAULT 1,
    UNIQUE (client_id, code)
);

-- 4) JOURNAL ENTRIES --------------------------------------------------------
-- type reflects where in the cycle the entry belongs:
--   NORMAL    - day-to-day transactions (step 1)
--   ADJUSTING - end-of-period adjustments (step 4)
--   CLOSING   - zeroing temporary accounts (step 7)
--   REVERSING - optional reversals on the first day of the next period
-- void_of_id: entries are NEVER deleted; voiding = recording a mirrored
-- reversing entry that points back here.
CREATE TABLE journal_entries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES clients(id),
    period_id   INTEGER NOT NULL REFERENCES periods(id),
    entry_no    INTEGER NOT NULL,                   -- sequential per client
    entry_date  TEXT    NOT NULL,
    type        TEXT    NOT NULL DEFAULT 'NORMAL'
                CHECK (type IN ('NORMAL','ADJUSTING','CLOSING','REVERSING')),
    memo        TEXT,
    currency    TEXT,                               -- NULL = client base currency
    fx_rate     REAL,                               -- base-currency units per 1
                                                   -- 'currency' at entry date;
                                                   -- NULL/1 = base currency
    void_of_id  INTEGER REFERENCES journal_entries(id),
    posted      INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE (client_id, entry_no)
);

-- 4b) JOURNAL LINES - the Dr/Cr lines of each entry ------------------------
-- Structural guards (the FULL 'debits = credits' rule is per-entry and is
-- enforced in the service layer, where all accounting rules live):
--   * exactly one side may be filled
--   * the filled side must be a positive amount
CREATE TABLE journal_lines (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id     INTEGER NOT NULL REFERENCES journal_entries(id),
    account_id   INTEGER NOT NULL REFERENCES accounts(id),
    debit_cents  INTEGER,
    credit_cents INTEGER,
    memo         TEXT,
    CHECK ((debit_cents IS NULL) <> (credit_cents IS NULL)),
    CHECK (debit_cents  IS NULL OR debit_cents  > 0),
    CHECK (credit_cents IS NULL OR credit_cents > 0)
);

CREATE INDEX idx_journal_lines_entry   ON journal_lines(entry_id);
CREATE INDEX idx_journal_lines_account ON journal_lines(account_id);
CREATE INDEX idx_journal_entries_client_date ON journal_entries(client_id, entry_date);

-- 5) LEDGER BALANCES - cache of per-period account totals ------------------
-- Always recomputable from journal_lines; kept so the trial balance and
-- worksheets render instantly without replaying the whole journal.
CREATE TABLE ledger_balances (
    period_id          INTEGER NOT NULL REFERENCES periods(id),
    account_id         INTEGER NOT NULL REFERENCES accounts(id),
    debit_total_cents  INTEGER NOT NULL DEFAULT 0,
    credit_total_cents INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (period_id, account_id)
);

-- 6) SNAPSHOTS - immutable point-in-time reports ----------------------------
-- TB snapshots for the three checkpoints (steps 3, 5, 8) and generated
-- statements, stored as JSON payloads - the audit trail of every report
-- the firm ever produced.
CREATE TABLE tb_snapshots (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    period_id INTEGER NOT NULL REFERENCES periods(id),
    stage     TEXT    NOT NULL
              CHECK (stage IN ('UNADJUSTED','ADJUSTED','POST_CLOSING')),
    as_of     TEXT    NOT NULL,
    payload   TEXT    NOT NULL                      -- JSON
);

CREATE TABLE report_snapshots (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    period_id INTEGER NOT NULL REFERENCES periods(id),
    kind      TEXT    NOT NULL
              CHECK (kind IN ('WORKSHEET','INCOME_STATEMENT','SOCE','BALANCE_SHEET')),
    as_of     TEXT    NOT NULL,
    payload   TEXT    NOT NULL                      -- JSON
);

-- 7) ADJUSTMENT TEMPLATES (step 4 machinery) --------------------------------
-- client_id NULL = global template shared by all clients.
-- The UNIQUE expression index makes codes unique per client AND globally
-- (SQLite treats NULLs as distinct in plain UNIQUE constraints, so we fold
-- NULL into the sentinel -1 first).
CREATE TABLE adj_templates (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id         INTEGER REFERENCES clients(id),
    code              TEXT    NOT NULL,             -- 'DEP_SL', 'ACC_SAL', ...
    name              TEXT    NOT NULL,
    debit_account_id  INTEGER REFERENCES accounts(id),
    credit_account_id INTEGER REFERENCES accounts(id),
    params_json       TEXT                          -- template parameters
);
CREATE UNIQUE INDEX idx_adj_templates_code
    ON adj_templates(COALESCE(client_id, -1), code);

-- 8) FX RATES - cache of rates used for multi-currency entries -------------
CREATE TABLE fx_rates (
    as_of_date TEXT NOT NULL,                       -- transaction date
    from_cur   TEXT NOT NULL,
    to_cur     TEXT NOT NULL,
    rate       REAL NOT NULL CHECK (rate > 0),
    source     TEXT NOT NULL DEFAULT 'MANUAL'
               CHECK (source IN ('FRANKFURTER','MANUAL')),
    fetched_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (as_of_date, from_cur, to_cur)
);

-- 9) AUDIT LOG - every mutation gets a row ----------------------------------
-- client_id deliberately has no FK: audit rows must outlive any client record.
CREATE TABLE audit_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER,
    action    TEXT NOT NULL,                        -- 'CREATE_ENTRY', 'VOID_ENTRY',
                                                   -- 'CLOSE_PERIOD', ...
    detail    TEXT,                                 -- free text / JSON
    actor     TEXT NOT NULL DEFAULT 'local-user',  -- no login system
    at        TEXT NOT NULL DEFAULT (datetime('now'))
);
