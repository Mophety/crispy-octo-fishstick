-- 2.10.0: the journal's hot paths read every entry's lines in one batched
-- pass (JournalService.linesForEntries), grouping by entry_id and reading in
-- line_no order; the per-entry detail dialog reads one entry's lines by
-- entry_id alone. journal_lines had NO index on entry_id (V5 indexed only
-- journal_entries and ledger_balances), so every such read scanned the table.
-- One composite index serves both access patterns. IF NOT EXISTS keeps the
-- migration idempotent on re-runs and safe on every existing 2.x database.
CREATE INDEX IF NOT EXISTS idx_journal_lines_entry
    ON journal_lines(entry_id, line_no);
