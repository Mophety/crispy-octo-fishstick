-- ============================================================================
-- LedgerPro - V4: schema alignment with the firm's target ER design
-- ============================================================================
-- Closes every gap between the shipped schema and the reviewed design:
--   clients          + tax_id, is_setup (onboarding state)
--   periods          + closed_at, locked_at timestamps
--   journal_entries  + reference (doc no.), adj_template_id (provenance),
--                     posted_at (when it became ledger fact)
--   journal_lines    + line_no + the full transaction-currency audit trail:
--                     txn_currency, txn_debit_cents, txn_credit_cents,
--                     fx_rate, fx_rate_id. The entry-level conversion
--                     machinery is unchanged; these columns freeze exactly
--                     what was typed in the original currency.
--   accounts         + is_permanent, is_retained_earnings, parent_id
--   ledger_balances  + opening/regular/adjusting/closing splits, updated_at
--   tb_snapshots     + total_debit_cents/total_credit_cents/is_balanced
--   report_snapshots + export_format, export_path
--   audit_log        + period_id, entity_type, entity_id, details_json
--   fx_rates         rebuilt as a currency-PAIR table with surrogate id,
--                     note column; legacy rows carried over
--   adj_templates    + description, is_active
--   adj_template_lines rebuilt with explicit side + amount_source
--                     (FIXED / FORMULA) + value
--
-- Everything is additive except the two rebuilds, which migrate their own
-- data. Golden rule respected: V1-V3 are untouched.
-- ============================================================================

-- 0) FX RATES: rebuild first, so journal_lines.fx_rate_id below can
--    reference the final table shape. Pair semantics stay "1 quote-currency
--    unit = rate base-currency units"; the old from_cur/to_cur columns map
--    onto quote_currency/base_currency respectively.
CREATE TABLE fx_rates_v4 (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    base_currency  TEXT NOT NULL,               -- reporting side ('PHP')
    quote_currency TEXT NOT NULL,               -- foreign side ('USD')
    rate_date      TEXT NOT NULL,
    rate           REAL NOT NULL CHECK (rate > 0),
    source         TEXT NOT NULL DEFAULT 'MANUAL'
                   CHECK (source IN ('FRANKFURTER','MANUAL')),
    fetched_at     TEXT NOT NULL DEFAULT (datetime('now')),
    note           TEXT NOT NULL DEFAULT '',
    UNIQUE (base_currency, quote_currency, rate_date)
);

INSERT INTO fx_rates_v4(base_currency, quote_currency, rate_date, rate,
                        source, fetched_at, note)
SELECT to_cur, from_cur, as_of_date, rate, source, fetched_at,
       'migrated from the V1 pair cache'
FROM fx_rates;

DROP TABLE fx_rates;
ALTER TABLE fx_rates_v4 RENAME TO fx_rates;
CREATE INDEX idx_fx_pair_date ON fx_rates(base_currency, quote_currency, rate_date);

-- 1) CLIENTS ---------------------------------------------------------------
ALTER TABLE clients ADD COLUMN tax_id TEXT NOT NULL DEFAULT '';
ALTER TABLE clients ADD COLUMN is_setup INTEGER NOT NULL DEFAULT 0;

-- a client that already has a chart and periods is de facto set up
UPDATE clients SET is_setup = 1
 WHERE EXISTS (SELECT 1 FROM accounts a WHERE a.client_id = clients.id)
   AND EXISTS (SELECT 1 FROM periods p WHERE p.client_id = clients.id);

-- 2) PERIODS ---------------------------------------------------------------
ALTER TABLE periods ADD COLUMN closed_at TEXT;
ALTER TABLE periods ADD COLUMN locked_at TEXT;

-- 3) JOURNAL ENTRIES -------------------------------------------------------
ALTER TABLE journal_entries ADD COLUMN reference TEXT;
ALTER TABLE journal_entries ADD COLUMN adj_template_id
    INTEGER REFERENCES adj_templates(id);
ALTER TABLE journal_entries ADD COLUMN posted_at TEXT;

-- best possible approximation for history: posted when last touched
UPDATE journal_entries SET posted_at = created_at WHERE posted = 1;

-- 4) JOURNAL LINES ---------------------------------------------------------
ALTER TABLE journal_lines ADD COLUMN line_no INTEGER;
ALTER TABLE journal_lines ADD COLUMN txn_currency TEXT;
ALTER TABLE journal_lines ADD COLUMN txn_debit_cents INTEGER;
ALTER TABLE journal_lines ADD COLUMN txn_credit_cents INTEGER;
ALTER TABLE journal_lines ADD COLUMN fx_rate REAL;
ALTER TABLE journal_lines ADD COLUMN fx_rate_id INTEGER REFERENCES fx_rates(id);

-- line_no backfill: 1-based per entry, in insertion order
UPDATE journal_lines SET line_no = (
    SELECT COUNT(*) FROM journal_lines earlier
    WHERE earlier.entry_id = journal_lines.entry_id
      AND earlier.id <= journal_lines.id);

-- transaction-currency trail backfilled from the entry-level snapshot
-- (division by the entry rate recovers the typed amount; base-currency
-- entries keep rate NULL/1 and simply copy their own amounts)
UPDATE journal_lines SET
    txn_currency = (SELECT e.currency FROM journal_entries e
                     WHERE e.id = journal_lines.entry_id),
    fx_rate      = (SELECT e.fx_rate FROM journal_entries e
                     WHERE e.id = journal_lines.entry_id),
    txn_debit_cents  = CASE WHEN debit_cents IS NOT NULL THEN CAST(ROUND(
        debit_cents / COALESCE(NULLIF(
          (SELECT e.fx_rate FROM journal_entries e
            WHERE e.id = journal_lines.entry_id), 1), 1)) AS INTEGER) END,
    txn_credit_cents = CASE WHEN credit_cents IS NOT NULL THEN CAST(ROUND(
        credit_cents / COALESCE(NULLIF(
          (SELECT e.fx_rate FROM journal_entries e
            WHERE e.id = journal_lines.entry_id), 1), 1)) AS INTEGER) END;

-- best-effort link to the cache row whose rate the entry snapshotted
UPDATE journal_lines SET fx_rate_id = (
    SELECT f.id FROM fx_rates f
    JOIN journal_entries e ON e.id = journal_lines.entry_id
    JOIN clients c ON c.id = e.client_id
    WHERE f.quote_currency = e.currency
      AND f.base_currency = c.base_currency
      AND f.rate_date <= e.entry_date
    ORDER BY f.rate_date DESC LIMIT 1)
WHERE txn_currency IS NOT NULL;

-- 5) ACCOUNTS --------------------------------------------------------------
ALTER TABLE accounts ADD COLUMN is_permanent INTEGER NOT NULL DEFAULT 1;
ALTER TABLE accounts ADD COLUMN is_retained_earnings INTEGER NOT NULL DEFAULT 0;
ALTER TABLE accounts ADD COLUMN parent_id INTEGER REFERENCES accounts(id);

UPDATE accounts SET is_permanent =
    CASE WHEN type IN ('REVENUE','EXPENSE') THEN 0 ELSE 1 END;
UPDATE accounts SET is_retained_earnings = 1
 WHERE lower(name) LIKE '%retained earnings%';

-- 6) LEDGER BALANCES -------------------------------------------------------
ALTER TABLE ledger_balances ADD COLUMN opening_cents  INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ledger_balances ADD COLUMN regular_dr     INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ledger_balances ADD COLUMN regular_cr     INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ledger_balances ADD COLUMN adjusting_dr   INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ledger_balances ADD COLUMN adjusting_cr   INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ledger_balances ADD COLUMN closing_dr     INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ledger_balances ADD COLUMN closing_cr     INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ledger_balances ADD COLUMN updated_at     TEXT NOT NULL DEFAULT '';
UPDATE ledger_balances SET updated_at = datetime('now');

-- split backfill from the posted journal (matches the worksheet's reading:
-- unadjusted = NORMAL + REVERSING mirrors; then ADJUSTING; then CLOSING).
-- SQLite UPDATE takes no table alias, so the target is correlated by name.
UPDATE ledger_balances SET
    regular_dr = COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l
        JOIN journal_entries e ON e.id = l.entry_id
        WHERE e.period_id = ledger_balances.period_id
          AND l.account_id = ledger_balances.account_id
          AND e.posted = 1 AND e.type IN ('NORMAL','REVERSING')), 0),
    regular_cr = COALESCE((SELECT SUM(l.credit_cents) FROM journal_lines l
        JOIN journal_entries e ON e.id = l.entry_id
        WHERE e.period_id = ledger_balances.period_id
          AND l.account_id = ledger_balances.account_id
          AND e.posted = 1 AND e.type IN ('NORMAL','REVERSING')), 0),
    adjusting_dr = COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l
        JOIN journal_entries e ON e.id = l.entry_id
        WHERE e.period_id = ledger_balances.period_id
          AND l.account_id = ledger_balances.account_id
          AND e.posted = 1 AND e.type = 'ADJUSTING'), 0),
    adjusting_cr = COALESCE((SELECT SUM(l.credit_cents) FROM journal_lines l
        JOIN journal_entries e ON e.id = l.entry_id
        WHERE e.period_id = ledger_balances.period_id
          AND l.account_id = ledger_balances.account_id
          AND e.posted = 1 AND e.type = 'ADJUSTING'), 0),
    closing_dr = COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l
        JOIN journal_entries e ON e.id = l.entry_id
        WHERE e.period_id = ledger_balances.period_id
          AND l.account_id = ledger_balances.account_id
          AND e.posted = 1 AND e.type = 'CLOSING'), 0),
    closing_cr = COALESCE((SELECT SUM(l.credit_cents) FROM journal_lines l
        JOIN journal_entries e ON e.id = l.entry_id
        WHERE e.period_id = ledger_balances.period_id
          AND l.account_id = ledger_balances.account_id
          AND e.posted = 1 AND e.type = 'CLOSING'), 0);

-- 7) TB SNAPSHOTS: summary columns (legacy rows stay NULL; new snapshots
--    fill them; the JSON payload remains the full record)
ALTER TABLE tb_snapshots ADD COLUMN total_debit_cents  INTEGER;
ALTER TABLE tb_snapshots ADD COLUMN total_credit_cents INTEGER;
ALTER TABLE tb_snapshots ADD COLUMN is_balanced        INTEGER;

-- 8) REPORT SNAPSHOTS: export provenance
ALTER TABLE report_snapshots ADD COLUMN export_format TEXT;
ALTER TABLE report_snapshots ADD COLUMN export_path    TEXT;

-- 9) AUDIT LOG: structured entity links
ALTER TABLE audit_log ADD COLUMN period_id    INTEGER;
ALTER TABLE audit_log ADD COLUMN entity_type  TEXT;
ALTER TABLE audit_log ADD COLUMN entity_id    INTEGER;
ALTER TABLE audit_log ADD COLUMN details_json TEXT NOT NULL DEFAULT '{}';

-- 10) ADJUSTMENT TEMPLATES --------------------------------------------------
ALTER TABLE adj_templates ADD COLUMN description TEXT NOT NULL DEFAULT '';
ALTER TABLE adj_templates ADD COLUMN is_active    INTEGER NOT NULL DEFAULT 1;

-- 11) ADJUSTMENT TEMPLATE LINES: rebuilt with explicit side + amount source
CREATE TABLE adj_template_lines_v4 (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    template_id   INTEGER NOT NULL REFERENCES adj_templates(id) ON DELETE CASCADE,
    line_no       INTEGER NOT NULL,
    account_code  TEXT    NOT NULL,
    side          TEXT    NOT NULL CHECK (side IN ('DR','CR')),
    amount_source TEXT    NOT NULL DEFAULT 'FIXED'
                  CHECK (amount_source IN ('FIXED','FORMULA')),
    value         TEXT    NOT NULL DEFAULT '',
    memo          TEXT,
    UNIQUE (template_id, line_no)
);

INSERT INTO adj_template_lines_v4(template_id, line_no, account_code, side,
                                  amount_source, value, memo)
SELECT template_id, line_no, account_code,
       CASE WHEN debit_cents IS NOT NULL THEN 'DR' ELSE 'CR' END,
       'FIXED',
       printf('%.2f', COALESCE(debit_cents, credit_cents) / 100.0),
       memo
FROM adj_template_lines;

DROP TABLE adj_template_lines;
ALTER TABLE adj_template_lines_v4 RENAME TO adj_template_lines;
CREATE INDEX idx_adj_template_lines_template ON adj_template_lines(template_id);
