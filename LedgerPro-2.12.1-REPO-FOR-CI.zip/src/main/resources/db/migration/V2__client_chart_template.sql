-- ============================================================================
-- LedgerPro - V2: chart-of-accounts template provenance
-- ============================================================================
-- Additive only (the golden rule: V1 is immutable once applied). New column
-- records which preset chart template a client's chart was seeded from, so
-- the Chart of Accounts view can say "seeded from STANDARD" and the New
-- Client dialog can preselect it next time. NULL = empty/custom chart.
-- The template CONTENT itself lives in code (com.ledgerpro.service.
-- ChartTemplates): firm presets are shipped with the app, not user data.
-- ============================================================================

ALTER TABLE clients ADD COLUMN chart_template TEXT;
