package com.ledgerpro;

import javafx.application.Application;

/**
 * Plain launcher main class for the PACKAGED application (jpackage builds).
 *
 * <p>Why {@link App} alone is not enough: the {@code java} launcher refuses to
 * boot a JavaFX {@code Application} class whose classes sit on the CLASSPATH
 * (the infamous "JavaFX runtime components are missing" error) — it only
 * auto-initializes the toolkit when {@code javafx.graphics} is on the MODULE
 * path. This class does not extend {@link Application}, so the packaged
 * launcher (which puts every jar next to us on the classpath) happily runs
 * this {@code main()}, and it hands control to
 * {@link Application#launch(Class, String[])}, which initializes JavaFX from
 * those same classpath jars, platform natives included.</p>
 *
 * <p>Development entry points are unchanged: {@code mvn javafx:run} keeps
 * using {@link App} (module path), and {@code mvn exec:java} still runs
 * {@code DbCli}.</p>
 */
public final class Launcher {

    public static void main(String[] args) {
        Application.launch(App.class, args);
    }

    private Launcher() {
    }
}
