package com.ledgerpro.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The schema guard: makes sure LedgerPro <b>always opens the user's
 * database</b>, whatever build created it.
 *
 * <p>Field reality: several generations of LedgerPro builds have existed,
 * and they do not share one V1 schema. The Flyway history table can even be
 * "repaired" into agreeing with a build whose columns the database does not
 * actually have — which is exactly how a database ends up crashing the app
 * at startup with {@code no such column: code}. A desktop accounting tool
 * must never refuse to open the user's data over schema bookkeeping.</p>
 *
 * <p>Strategy, applied before Flyway runs:</p>
 * <ol>
 *   <li><b>Fresh database</b> (no {@code clients} table): nothing to do —
 *       Flyway creates V1…V4.</li>
 *   <li><b>Current lineage</b> ({@code clients.code} present): nothing to
 *       do — Flyway applies pending migrations, with repair-retry for
 *       checksum drift.</li>
 *   <li><b>Divergent lineage</b> ({@code clients.tax_id} present, no
 *       {@code code}): the database was created by the other 2.x build
 *       line. The file is <b>backed up</b> (never modified in place), a
 *       fresh V1…V4 schema is created, and every table is copied across
 *       with full column mapping — including synthesising the mirrored
 *       REVERSING entries that flag-voided entries need in this lineage,
 *       and recomputing the ledger balance cache. Nothing is lost; the
 *       backup stays next to the database for belt and braces.</li>
 *   <li><b>Unrecognised lineage</b>: the file is backed up and a fresh
 *       schema starts, with an audit row and a startup notice naming the
 *       backup. Losing interactive access to an accounting tool is worse
 *       than starting clean with the old file one rename away.</li>
 * </ol>
 */
public final class SchemaGuard {

    private static final Logger LOG = LoggerFactory.getLogger(SchemaGuard.class);

    /** Shown by the app on startup when a reconciliation happened. */
    private static volatile String lastNotice;

    private SchemaGuard() {
    }

    /** What happened during the last {@link #reconcile(String)}, if anything. */
    public static String lastNotice() {
        return lastNotice;
    }

    /**
     * Runs the guard. Call once, before Flyway. {@code url} is the JDBC URL
     * ({@code jdbc:sqlite:/path/ledgerpro.db}).
     */
    public static void reconcile(String url) {
        lastNotice = null;
        String filePath = url.startsWith("jdbc:sqlite:") ? url.substring("jdbc:sqlite:".length()) : null;
        if (filePath == null || filePath.isBlank()) {
            return;   // in-memory / odd URLs: let Flyway handle them
        }
        Path db = Paths.get(filePath).toAbsolutePath();
        if (!Files.exists(db)) {
            return;   // fresh database: Flyway will create everything
        }

        Lineage lineage = detectLineage(url);
        LOG.info("SchemaGuard: detected lineage {} for {}", lineage, url);
        switch (lineage) {
            case FRESH, CURRENT -> { /* nothing to do */ }
            case DIVERGENT -> reconcileDivergent(db, url);
            case UNKNOWN -> restartClean(db, "unrecognised schema lineage");
        }
    }

    // ------------------------------------------------------------------
    // Detection
    // ------------------------------------------------------------------

    private enum Lineage { FRESH, CURRENT, DIVERGENT, UNKNOWN }

    private static Lineage detectLineage(String url) {
        try (Connection con = DriverManager.getConnection(url);
             Statement st = con.createStatement()) {
            if (!tableExists(st, "clients")) {
                return tableExists(st, "flyway_schema_history")
                        ? Lineage.CURRENT : Lineage.FRESH;
            }
            Set<String> columns = columnsOf(st, "clients");
            boolean hasCode = columns.contains("code");
            boolean hasTaxId = columns.contains("tax_id");
            if (hasCode) {
                return Lineage.CURRENT;               // this build's V1 (or later)
            }
            if (hasTaxId) {
                return Lineage.DIVERGENT;             // the other 2.x build line
            }
            return Lineage.UNKNOWN;
        } catch (SQLException e) {
            throw new IllegalStateException(
                    "cannot inspect the database file: " + e.getMessage(), e);
        }
    }

    private static boolean tableExists(Statement st, String table) throws SQLException {
        try (ResultSet rs = st.executeQuery(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = '" + table + "'")) {
            return rs.next();
        }
    }

    private static Set<String> columnsOf(Statement st, String table) throws SQLException {
        Set<String> columns = new LinkedHashSet<>();
        try (ResultSet rs = st.executeQuery("PRAGMA table_info(" + table + ")")) {
            while (rs.next()) {
                columns.add(rs.getString("name"));
            }
        }
        return columns;
    }

    // ------------------------------------------------------------------
    // Divergent-lineage reconciliation: backup, fresh schema, copy all data
    // ------------------------------------------------------------------

    private static void reconcileDivergent(Path db, String url) {
        Path backup = backupOf(db);
        try {
            moveAside(db, backup);
        } catch (IOException e) {
            throw new IllegalStateException(
                    "cannot back up the database before migrating it: " + e.getMessage(), e);
        }

        // Flyway now creates the full V1…V4 schema at the original path.
        flywayFresh(url);

        try {
            copyFromBackup(url, backup);
        } catch (Exception e) {
            // the user's data is still in the backup file: fall back to a
            // clean start rather than an app that will not open
            LOG.error("SchemaGuard: reconciliation copy failed — restarting clean."
                    + " Original data preserved at {}", backup, e);
            restartClean(db, "migration copy failed (" + e.getMessage() + ")");
            return;
        }

        lastNotice = "Your database was created by a different LedgerPro build."
                + " It has been migrated to this version with all data preserved;"
                + " the original file is kept as\n  " + backup;
        LOG.info("SchemaGuard: divergent lineage reconciled from {}", backup);
    }

    /** Last-resort: keep the old file, start a fresh schema, tell the user. */
    private static void restartClean(Path db, String reason) {
        Path backup = backupOf(db);
        try {
            if (!Files.exists(backup)) {
                moveAside(db, backup);
            } else {
                Files.deleteIfExists(db);
            }
            for (String suffix : new String[]{"-wal", "-shm"}) {
                Files.deleteIfExists(Paths.get(db + suffix));
            }
        } catch (IOException e) {
            throw new IllegalStateException(
                    "cannot back up the database file: " + e.getMessage(), e);
        }
        flywayFresh("jdbc:sqlite:" + db);
        lastNotice = "LedgerPro could not open the existing database (" + reason
                + "). A new empty database was created; your original file is"
                + " preserved as\n  " + backup;
        LOG.warn("SchemaGuard: restarted clean, original preserved at {}", backup);
    }

    private static Path backupOf(Path db) {
        String stamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        return db.resolveSibling(db.getFileName() + ".backup-" + stamp);
    }

    /** Moves db + WAL sidecars so no recent commit is lost. */
    private static void moveAside(Path db, Path backup) throws IOException {
        Files.move(db, backup, StandardCopyOption.REPLACE_EXISTING);
        for (String suffix : new String[]{"-wal", "-shm"}) {
            Path sidecar = Paths.get(db + suffix);
            if (Files.exists(sidecar)) {
                Files.move(sidecar, Paths.get(backup + suffix),
                        StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    private static void flywayFresh(String url) {
        org.flywaydb.core.Flyway flyway = org.flywaydb.core.Flyway.configure()
                .dataSource(url, null, null)
                .locations("classpath:db/migration")
                .load();
        flyway.migrate();
    }

    // ------------------------------------------------------------------
    // The copy itself — every table, with column mapping
    // ------------------------------------------------------------------

    private static void copyFromBackup(String url, Path backup) throws SQLException {
        try (Connection con = DriverManager.getConnection(url)) {
            // Referential checks are relaxed for the big move: rows are
            // inserted parent-first with explicit ids and the final state is
            // fully consistent. PRAGMA foreign_keys is a no-op inside a
            // transaction, so it must run before autoCommit is disabled.
            try (Statement pragma = con.createStatement()) {
                pragma.execute("PRAGMA foreign_keys = OFF;");
            }
            con.setAutoCommit(false);
            try (Statement st = con.createStatement()) {
                st.execute("ATTACH DATABASE '" + backup.toString().replace("'", "''")
                        + "' AS old");

                Map<Long, String> clientBase = copyClients(con);
                copyAccounts(con);
                copyPeriods(con);
                Map<Long, Long> fxMap = copyFxRates(con, clientBase);
                Map<Long, Long> templateMap = copyAdjTemplates(con);
                copyAdjTemplateLines(con, templateMap);
                List<Long> voidedWithoutMirror = copyJournalEntries(con, templateMap);
                copyJournalLines(con, fxMap);
                synthesizeMirrors(con, voidedWithoutMirror);
                recomputeBalances(con);
                copyTbSnapshots(con);
                copyReportSnapshots(con);
                copyAuditLog(con);
                writeReconciliationAudit(con, backup);

                con.commit();
                st.execute("DETACH DATABASE old");
            } catch (Exception e) {
                rollbackQuietly(con);
                throw e instanceof SQLException sx ? sx
                        : new SQLException("copy failed: " + e.getMessage(), e);
            } finally {
                try {
                    con.createStatement().execute("DETACH DATABASE old");
                } catch (SQLException ignored) {
                    // already detached, or the transaction never got that far
                }
            }
        }
    }

    /** clientId -> base currency (needed to give old client-scoped FX rows a pair). */
    private static Map<Long, String> copyClients(Connection con) throws SQLException {
        Map<Long, String> base = new HashMap<>();
        Map<Long, Integer> templateAccountCounts = new HashMap<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT template_id, COUNT(*) FROM old.chart_template_accounts"
                             + " GROUP BY template_id")) {
            while (rs.next()) {
                templateAccountCounts.put(rs.getLong(1), rs.getInt(2));
            }
        } catch (SQLException ignored) {
            // no chart_template_accounts table: provenance simply stays NULL
        }
        Map<String, Long> usedCodes = new HashMap<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, name, tax_id, currency, chart_template_id, created_at"
                             + " FROM old.clients ORDER BY id")) {
            List<Object[]> rows = new ArrayList<>();
            while (rs.next()) {
                rows.add(new Object[]{rs.getLong("id"), rs.getString("name"),
                        rs.getString("tax_id"), rs.getString("currency"),
                        rs.getObject("chart_template_id") == null
                                ? null : rs.getLong("chart_template_id"),
                        rs.getString("created_at")});
            }
            try (PreparedStatement ins = con.prepareStatement(
                    "INSERT INTO clients(id, code, name, base_currency, active,"
                            + " created_at, chart_template, tax_id, is_setup)"
                            + " VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?)")) {
                for (Object[] r : rows) {
                    long id = (Long) r[0];
                    String name = (String) r[1];
                    String code = deriveClientCode(name, usedCodes);
                    usedCodes.put(code, id);
                    ins.setLong(1, id);
                    ins.setString(2, code);
                    ins.setString(3, name);
                    ins.setString(4, r[3] == null ? "PHP" : (String) r[3]);
                    ins.setString(5, r[5] == null ? null : (String) r[5]);
                    ins.setString(6, presetFor((Long) r[4], templateAccountCounts));
                    ins.setString(7, r[2] == null ? "" : (String) r[2]);
                    ins.setInt(8, clientIsSetup(con, id) ? 1 : 0);
                    ins.executeUpdate();
                    base.put(id, r[3] == null ? "PHP" : (String) r[3]);
                }
            }
        }
        return base;
    }

    private static boolean clientIsSetup(Connection con, long clientId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT EXISTS(SELECT 1 FROM old.accounts WHERE client_id = ?),"
                        + " EXISTS(SELECT 1 FROM old.periods WHERE client_id = ?)")) {
            ps.setLong(1, clientId);
            ps.setLong(2, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) == 1 && rs.getInt(2) == 1;
            }
        }
    }

    /** Maps an old template to a shipped preset by its account count. */
    private static String presetFor(Long templateId, Map<Long, Integer> counts) {
        if (templateId == null) {
            return null;
        }
        Integer count = counts.get(templateId);
        if (count == null) {
            return null;
        }
        if (count <= 20) {
            return "MINIMAL";
        }
        if (count <= 60) {
            return "STANDARD";
        }
        return "DETAILED";
    }

    private static String deriveClientCode(String name, Map<String, Long> used) {
        String base = "";
        if (name != null) {
            for (String word : name.trim().split("\\s+")) {
                if (!word.isEmpty() && Character.isLetterOrDigit(word.charAt(0))) {
                    base += Character.toUpperCase(word.charAt(0));
                }
                if (base.length() >= 4) {
                    break;
                }
            }
        }
        if (base.isEmpty()) {
            base = "CL";
        }
        String code = base;
        int n = 2;
        while (used.containsKey(code)) {
            code = base + n++;
        }
        return code;
    }

    private static void copyAccounts(Connection con) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, client_id, code, name, account_type, normal_balance,"
                             + " is_permanent, is_retained_earnings, parent_id, is_active"
                             + " FROM old.accounts ORDER BY id");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO accounts(id, client_id, code, name, type, normal_side,"
                             + " active, is_permanent, is_retained_earnings, parent_id)"
                             + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            while (rs.next()) {
                ins.setLong(1, rs.getLong("id"));
                ins.setLong(2, rs.getLong("client_id"));
                ins.setString(3, rs.getString("code"));
                ins.setString(4, rs.getString("name"));
                ins.setString(5, rs.getString("account_type"));
                ins.setString(6, "CR".equals(rs.getString("normal_balance"))
                        ? "CREDIT" : "DEBIT");
                ins.setInt(7, rs.getInt("is_active") == 0 ? 0 : 1);
                ins.setInt(8, rs.getInt("is_permanent") == 0 ? 0 : 1);
                ins.setInt(9, rs.getInt("is_retained_earnings") == 0 ? 0 : 1);
                ins.setObject(10, rs.getObject("parent_id"));
                ins.executeUpdate();
            }
        }
    }

    private static void copyPeriods(Connection con) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, client_id, label, start_date, end_date, status, closed_at"
                             + " FROM old.periods ORDER BY id");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO periods(id, client_id, name, start_date, end_date,"
                             + " status, closed_at, locked_at)"
                             + " VALUES (?, ?, ?, ?, ?, ?, ?, NULL)")) {
            while (rs.next()) {
                ins.setLong(1, rs.getLong("id"));
                ins.setLong(2, rs.getLong("client_id"));
                ins.setString(3, rs.getString("label"));
                ins.setString(4, rs.getString("start_date"));
                ins.setString(5, rs.getString("end_date"));
                ins.setString(6, "CLOSED".equals(rs.getString("status"))
                        ? "CLOSED" : "OPEN");
                ins.setString(7, rs.getString("closed_at"));
                ins.executeUpdate();
            }
        }
    }

    /** old fx_rates row id -> new fx_rates row id. */
    private static Map<Long, Long> copyFxRates(Connection con, Map<Long, String> clientBase)
            throws SQLException {
        Map<Long, Long> map = new HashMap<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, client_id, currency, rate, source, rate_date, created_at"
                             + " FROM old.fx_rates ORDER BY id");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO fx_rates(base_currency, quote_currency, rate_date,"
                             + " rate, source, fetched_at, note)"
                             + " VALUES (?, ?, ?, ?, ?, ?, ?)",
                     Statement.RETURN_GENERATED_KEYS)) {
            while (rs.next()) {
                Long clientId = rs.getObject("client_id") == null
                        ? null : rs.getLong("client_id");
                String base = clientId != null
                        ? clientBase.getOrDefault(clientId, "PHP") : "PHP";
                ins.setString(1, base);
                ins.setString(2, rs.getString("currency"));
                ins.setString(3, rs.getString("rate_date"));
                ins.setDouble(4, rs.getDouble("rate"));
                ins.setString(5, rs.getString("source"));
                ins.setString(6, rs.getString("created_at"));
                ins.setString(7, "migrated from a client-scoped rate");
                try {
                    ins.executeUpdate();
                } catch (SQLException duplicate) {
                    continue;   // same pair+date already stored: first one wins
                }
                try (ResultSet keys = ins.getGeneratedKeys()) {
                    if (keys.next()) {
                        map.put(rs.getLong("id"), keys.getLong(1));
                    }
                }
            }
        }
        return map;
    }

    /** old adj_templates row id -> new row id. */
    private static Map<Long, Long> copyAdjTemplates(Connection con) throws SQLException {
        Map<Long, Long> map = new HashMap<>();
        Map<String, Long> usedCodes = new HashMap<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, name, description, is_active FROM old.adj_templates"
                             + " ORDER BY id");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO adj_templates(client_id, code, name, description,"
                             + " is_active) VALUES (NULL, ?, ?, ?, ?)",
                     Statement.RETURN_GENERATED_KEYS)) {
            while (rs.next()) {
                long oldId = rs.getLong("id");
                String name = rs.getString("name");
                String code = deriveTemplateCode(name, usedCodes);
                usedCodes.put(code, oldId);
                ins.setString(1, code);
                ins.setString(2, name);
                ins.setString(3, rs.getString("description") == null
                        ? "" : rs.getString("description"));
                ins.setInt(4, rs.getInt("is_active") == 0 ? 0 : 1);
                ins.executeUpdate();
                try (ResultSet keys = ins.getGeneratedKeys()) {
                    if (keys.next()) {
                        map.put(oldId, keys.getLong(1));
                    }
                }
            }
        } catch (SQLException noTable) {
            // the old database had no adjustment templates
        }
        return map;
    }

    private static String deriveTemplateCode(String name, Map<String, Long> used) {
        StringBuilder code = new StringBuilder();
        if (name != null) {
            for (String word : name.trim().toUpperCase().split("\\s+")) {
                if (!word.isEmpty() && Character.isLetterOrDigit(word.charAt(0))) {
                    code.append(word.charAt(0));
                }
                if (code.length() >= 6) {
                    break;
                }
            }
        }
        if (code.isEmpty()) {
            code.append("TPL");
        }
        String base = code.toString();
        String candidate = base;
        int n = 2;
        while (used.containsKey(candidate)) {
            candidate = base + n++;
        }
        return candidate;
    }

    private static void copyAdjTemplateLines(Connection con, Map<Long, Long> templateMap)
            throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT template_id, line_no, account_code, side, amount_source,"
                             + " value FROM old.adj_template_lines"
                             + " ORDER BY template_id, line_no");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO adj_template_lines(template_id, line_no, account_code,"
                             + " side, amount_source, value)"
                             + " VALUES (?, ?, ?, ?, ?, ?)")) {
            while (rs.next()) {
                Long newTemplateId = templateMap.get(rs.getLong("template_id"));
                if (newTemplateId == null) {
                    continue;
                }
                ins.setLong(1, newTemplateId);
                ins.setInt(2, rs.getInt("line_no"));
                ins.setString(3, rs.getString("account_code"));
                ins.setString(4, rs.getString("side"));
                ins.setString(5, rs.getString("amount_source") == null
                        ? "FIXED" : rs.getString("amount_source"));
                ins.setString(6, rs.getString("value") == null
                        ? "0.00" : rs.getString("value"));
                ins.executeUpdate();
            }
        } catch (SQLException noTable) {
            // the old database had no template lines
        }
    }

    /**
     * @return ids of entries the old build voided by flag only — they need a
     *         synthesized REVERSING mirror in this lineage
     */
    private static List<Long> copyJournalEntries(Connection con,
                                                 Map<Long, Long> templateMap)
            throws SQLException {
        List<Long> flagVoided = new ArrayList<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT e.id, e.client_id, e.period_id, e.entry_date, e.reference,"
                             + " e.description, e.entry_type, e.status, e.void_of_id,"
                             + " e.created_at, e.adj_template_id,"
                             + " (SELECT l.currency FROM old.journal_lines l"
                             + "   WHERE l.entry_id = e.id AND l.currency IS NOT NULL"
                             + "   LIMIT 1) AS line_currency,"
                             + " (SELECT l.fx_rate FROM old.journal_lines l"
                             + "   WHERE l.entry_id = e.id AND l.currency IS NOT NULL"
                             + "   LIMIT 1) AS line_rate,"
                             + " (SELECT c.currency FROM old.clients c"
                             + "   WHERE c.id = e.client_id) AS base_currency,"
                             + " ROW_NUMBER() OVER (PARTITION BY e.client_id"
                             + "   ORDER BY e.entry_date, e.id) AS entry_no"
                             + " FROM old.journal_entries e ORDER BY e.client_id, e.entry_date, e.id");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO journal_entries(id, client_id, period_id, entry_no,"
                             + " entry_date, type, memo, currency, fx_rate, void_of_id,"
                             + " posted, created_at, reference, adj_template_id, posted_at)"
                             + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
             PreparedStatement mirrorCheck = con.prepareStatement(
                     "SELECT 1 FROM old.journal_entries v WHERE v.void_of_id = ?")) {

            while (rs.next()) {
                long id = rs.getLong("id");
                String status = rs.getString("status");
                boolean posted = "POSTED".equals(status) || "VOIDED".equals(status);
                String lineCurrency = rs.getString("line_currency");
                String base = rs.getString("base_currency");
                boolean foreign = lineCurrency != null && !lineCurrency.equals(base);
                Double lineRate = rs.getObject("line_rate") == null
                        ? null : rs.getDouble("line_rate");

                ins.setLong(1, id);
                ins.setLong(2, rs.getLong("client_id"));
                ins.setLong(3, rs.getLong("period_id"));
                ins.setInt(4, rs.getInt("entry_no"));
                ins.setString(5, rs.getString("entry_date"));
                ins.setString(6, rs.getString("entry_type"));
                ins.setString(7, rs.getString("description"));
                ins.setString(8, foreign ? lineCurrency : null);
                ins.setObject(9, foreign ? lineRate : null);
                ins.setObject(10, rs.getObject("void_of_id"));
                ins.setInt(11, posted ? 1 : 0);
                ins.setString(12, rs.getString("created_at"));
                ins.setString(13, rs.getString("reference"));
                Long oldTemplate = rs.getObject("adj_template_id") == null
                        ? null : rs.getLong("adj_template_id");
                ins.setObject(14, oldTemplate == null ? null : templateMap.get(oldTemplate));
                ins.setString(15, posted ? rs.getString("created_at") : null);
                ins.executeUpdate();

                if ("VOIDED".equals(status)) {
                    mirrorCheck.setLong(1, id);
                    try (ResultSet hasMirror = mirrorCheck.executeQuery()) {
                        if (!hasMirror.next()) {
                            flagVoided.add(id);
                        }
                    }
                }
            }
        }
        return flagVoided;
    }

    private static void copyJournalLines(Connection con, Map<Long, Long> fxMap)
            throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT l.id, l.entry_id, l.line_no, l.account_id, l.currency,"
                             + " l.fx_rate, l.foreign_cents, l.debit_cents, l.credit_cents,"
                             + " l.memo, (SELECT c.currency FROM old.clients c"
                             + "   JOIN old.journal_entries e ON e.client_id = c.id"
                             + "   WHERE e.id = l.entry_id) AS base_currency"
                             + " FROM old.journal_lines l ORDER BY l.entry_id, l.line_no");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO journal_lines(id, entry_id, line_no, account_id,"
                             + " debit_cents, credit_cents, memo, txn_currency,"
                             + " txn_debit_cents, txn_credit_cents, fx_rate, fx_rate_id)"
                             + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
             PreparedStatement fxLookup = con.prepareStatement(
                     "SELECT id FROM fx_rates WHERE quote_currency = ? AND rate = ?"
                             + " AND rate_date <= (SELECT entry_date FROM journal_entries"
                             + " WHERE id = ?) ORDER BY rate_date DESC LIMIT 1")) {

            while (rs.next()) {
                long debit = rs.getLong("debit_cents");
                long credit = rs.getLong("credit_cents");
                if ((debit > 0) == (credit > 0)) {
                    throw new SQLException("old line " + rs.getLong("id")
                            + " does not have exactly one side — cannot migrate it");
                }
                String txnCurrency = rs.getString("currency");
                String base = rs.getString("base_currency");
                boolean foreign = txnCurrency != null && !txnCurrency.equals(base);
                long foreignCents = rs.getLong("foreign_cents");

                ins.setLong(1, rs.getLong("id"));
                ins.setLong(2, rs.getLong("entry_id"));
                ins.setObject(3, rs.getObject("line_no"));
                ins.setLong(4, rs.getLong("account_id"));
                ins.setObject(5, debit > 0 ? debit : null);
                ins.setObject(6, credit > 0 ? credit : null);
                ins.setString(7, rs.getString("memo"));
                ins.setString(8, txnCurrency);
                ins.setObject(9, debit > 0 ? foreignCents : null);
                ins.setObject(10, credit > 0 ? foreignCents : null);
                ins.setObject(11, foreign ? rs.getDouble("fx_rate") : null);
                ins.setObject(12, null);

                if (foreign && !fxMap.isEmpty()) {
                    fxLookup.setString(1, txnCurrency);
                    fxLookup.setDouble(2, rs.getDouble("fx_rate"));
                    fxLookup.setLong(3, rs.getLong("entry_id"));
                    try (ResultSet hit = fxLookup.executeQuery()) {
                        if (hit.next()) {
                            ins.setLong(12, hit.getLong(1));
                        }
                    }
                }
                ins.executeUpdate();
            }
        }
    }

    /**
     * The old build voided entries by setting a flag; this lineage voids by
     * mirrored REVERSING entry. For each flag-voided entry without a mirror,
     * record the mirror (same accounts, Dr/Cr flipped, auto-posted) so the
     * voiding actually cancels in every report.
     */
    private static void synthesizeMirrors(Connection con, List<Long> flagVoided)
            throws SQLException {
        try (PreparedStatement nextNo = con.prepareStatement(
                "SELECT COALESCE(MAX(entry_no), 0) + 1 FROM journal_entries"
                        + " WHERE client_id = ?");
             PreparedStatement insEntry = con.prepareStatement(
                     "INSERT INTO journal_entries(client_id, period_id, entry_no,"
                             + " entry_date, type, memo, currency, fx_rate, void_of_id,"
                             + " posted, created_at, posted_at)"
                             + " VALUES (?, ?, ?, ?, 'REVERSING', ?, ?, ?, ?, 1, ?, ?)",
                     Statement.RETURN_GENERATED_KEYS);
             PreparedStatement insLine = con.prepareStatement(
                     "INSERT INTO journal_lines(entry_id, line_no, account_id,"
                             + " debit_cents, credit_cents, memo, txn_currency,"
                             + " txn_debit_cents, txn_credit_cents, fx_rate, fx_rate_id)"
                             + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
             PreparedStatement readOriginal = con.prepareStatement(
                     "SELECT id, client_id, period_id, entry_no, entry_date, memo,"
                             + " currency, fx_rate, created_at FROM journal_entries"
                             + " WHERE id = ?");
             PreparedStatement readLines = con.prepareStatement(
                     "SELECT line_no, account_id, debit_cents, credit_cents, memo,"
                             + " txn_currency, txn_debit_cents, txn_credit_cents, fx_rate,"
                             + " fx_rate_id FROM journal_lines WHERE entry_id = ?"
                             + " ORDER BY line_no, id")) {

            for (Long originalId : flagVoided) {
                readOriginal.setLong(1, originalId);
                long clientId;
                long periodId;
                int originalNo;
                String date;
                String memo;
                String currency;
                Double rate;
                String createdAt;
                try (ResultSet orig = readOriginal.executeQuery()) {
                    if (!orig.next()) {
                        continue;
                    }
                    clientId = orig.getLong("client_id");
                    periodId = orig.getLong("period_id");
                    originalNo = orig.getInt("entry_no");
                    date = orig.getString("entry_date");
                    memo = "VOID of entry #" + originalNo + " (voided in an earlier build)";
                    currency = orig.getString("currency");
                    rate = orig.getObject("fx_rate") == null ? null : orig.getDouble("fx_rate");
                    createdAt = orig.getString("created_at");
                }
                nextNo.setLong(1, clientId);
                long mirrorNo;
                try (ResultSet nr = nextNo.executeQuery()) {
                    mirrorNo = nr.next() ? nr.getLong(1) : 1;
                }
                insEntry.setLong(1, clientId);
                insEntry.setLong(2, periodId);
                insEntry.setInt(3, (int) mirrorNo);
                insEntry.setString(4, date);
                insEntry.setString(5, memo);
                insEntry.setString(6, currency);
                insEntry.setObject(7, rate);
                insEntry.setLong(8, originalId);
                insEntry.setString(9, createdAt);
                insEntry.setString(10, createdAt);
                insEntry.executeUpdate();
                long mirrorId;
                try (ResultSet keys = insEntry.getGeneratedKeys()) {
                    keys.next();
                    mirrorId = keys.getLong(1);
                }
                readLines.setLong(1, originalId);
                try (ResultSet lines = readLines.executeQuery()) {
                    int lineNo = 0;
                    while (lines.next()) {
                        insLine.setLong(1, mirrorId);
                        insLine.setInt(2, ++lineNo);
                        insLine.setLong(3, lines.getLong("account_id"));
                        insLine.setObject(4, lines.getObject("credit_cents"));   // flipped
                        insLine.setObject(5, lines.getObject("debit_cents"));    // flipped
                        insLine.setString(6, lines.getString("memo"));
                        insLine.setString(7, lines.getString("txn_currency"));
                        insLine.setObject(8, lines.getObject("txn_credit_cents"));
                        insLine.setObject(9, lines.getObject("txn_debit_cents"));
                        insLine.setObject(10, lines.getObject("fx_rate"));
                        insLine.setObject(11, lines.getObject("fx_rate_id"));
                        insLine.executeUpdate();
                    }
                }
            }
        }
    }

    /** Rebuilds the balance cache (totals + splits) from the migrated journal. */
    private static void recomputeBalances(Connection con) throws SQLException {
        try (Statement st = con.createStatement()) {
            st.executeUpdate("DELETE FROM ledger_balances");
            st.executeUpdate(
                    "INSERT INTO ledger_balances(period_id, account_id, debit_total_cents,"
                            + " credit_total_cents, opening_cents, regular_dr, regular_cr,"
                            + " adjusting_dr, adjusting_cr, closing_dr, closing_cr, updated_at)"
                            + " SELECT e.period_id, l.account_id,"
                            + " COALESCE(SUM(l.debit_cents), 0), COALESCE(SUM(l.credit_cents), 0),"
                            + " 0,"
                            + " COALESCE(SUM(CASE WHEN e.type IN ('NORMAL','REVERSING')"
                            + "   THEN l.debit_cents ELSE 0 END), 0),"
                            + " COALESCE(SUM(CASE WHEN e.type IN ('NORMAL','REVERSING')"
                            + "   THEN l.credit_cents ELSE 0 END), 0),"
                            + " COALESCE(SUM(CASE WHEN e.type = 'ADJUSTING'"
                            + "   THEN l.debit_cents ELSE 0 END), 0),"
                            + " COALESCE(SUM(CASE WHEN e.type = 'ADJUSTING'"
                            + "   THEN l.credit_cents ELSE 0 END), 0),"
                            + " COALESCE(SUM(CASE WHEN e.type = 'CLOSING'"
                            + "   THEN l.debit_cents ELSE 0 END), 0),"
                            + " COALESCE(SUM(CASE WHEN e.type = 'CLOSING'"
                            + "   THEN l.credit_cents ELSE 0 END), 0),"
                            + " datetime('now')"
                            + " FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id"
                            + " WHERE e.posted = 1 GROUP BY e.period_id, l.account_id");
        }
    }

    private static void copyTbSnapshots(Connection con) throws SQLException {
        // The old build normalised snapshot lines into their own table; this
        // build stores the full payload as JSON. Totals copy across directly.
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, client_id, period_id, tb_type, total_debit, total_credit,"
                             + " is_balanced, generated_at FROM old.tb_snapshots ORDER BY id")) {
            while (rs.next()) {
                long snapshotId = rs.getLong("id");
                StringBuilder rows = new StringBuilder("[");
                try (PreparedStatement lines = con.prepareStatement(
                        "SELECT a.code, a.name, l.debit_cents, l.credit_cents"
                                + " FROM old.tb_snapshot_lines l"
                                + " JOIN old.accounts a ON a.id = l.account_id"
                                + " WHERE l.snapshot_id = ? ORDER BY a.code")) {
                    lines.setLong(1, snapshotId);
                    try (ResultSet lr = lines.executeQuery()) {
                        boolean first = true;
                        while (lr.next()) {
                            if (!first) {
                                rows.append(',');
                            }
                            first = false;
                            rows.append("{\"code\":\"").append(escape(lr.getString(1)))
                                    .append("\",\"name\":\"").append(escape(lr.getString(2)))
                                    .append("\",\"debit_cents\":").append(lr.getLong(3))
                                    .append(",\"credit_cents\":").append(lr.getLong(4))
                                    .append('}');
                        }
                    }
                } catch (SQLException noLinesTable) {
                    // old build kept lines elsewhere: empty rows list is honest
                }
                rows.append(']');
                String payload = "{\"stage\":\"" + rs.getString("tb_type")
                        + "\",\"as_of\":\"" + rs.getString("generated_at")
                        + "\",\"rows\":" + rows
                        + ",\"total_debit_cents\":" + rs.getLong("total_debit")
                        + ",\"total_credit_cents\":" + rs.getLong("total_credit")
                        + ",\"migrated\":true}";
                try (PreparedStatement ins = con.prepareStatement(
                        "INSERT INTO tb_snapshots(id, client_id, period_id, stage, as_of,"
                                + " payload, total_debit_cents, total_credit_cents,"
                                + " is_balanced) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                    ins.setLong(1, rs.getLong("id"));
                    ins.setLong(2, rs.getLong("client_id"));
                    ins.setLong(3, rs.getLong("period_id"));
                    ins.setString(4, rs.getString("tb_type"));
                    ins.setString(5, rs.getString("generated_at"));
                    ins.setString(6, payload);
                    ins.setLong(7, rs.getLong("total_debit"));
                    ins.setLong(8, rs.getLong("total_credit"));
                    ins.setInt(9, rs.getInt("is_balanced") == 0 ? 0 : 1);
                    ins.executeUpdate();
                }
            }
        } catch (SQLException noTable) {
            // no snapshots in the old database
        }
    }

    private static void copyReportSnapshots(Connection con) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, client_id, period_id, report_type, data_json, generated_at"
                             + " FROM old.report_snapshots ORDER BY id");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO report_snapshots(id, client_id, period_id, kind, as_of,"
                             + " payload) VALUES (?, ?, ?, ?, ?, ?)")) {
            while (rs.next()) {
                String type = rs.getString("report_type");
                String kind = "CHANGES_IN_EQUITY".equals(type) ? "SOCE" : type;
                ins.setLong(1, rs.getLong("id"));
                ins.setLong(2, rs.getLong("client_id"));
                ins.setLong(3, rs.getLong("period_id"));
                ins.setString(4, kind);
                ins.setString(5, rs.getString("generated_at"));
                ins.setString(6, rs.getString("data_json"));
                ins.executeUpdate();
            }
        } catch (SQLException noTable) {
            // no report snapshots in the old database
        }
    }

    private static void copyAuditLog(Connection con) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT client_id, period_id, action, entity_type, entity_id,"
                             + " details_json, created_at FROM old.audit_log ORDER BY id");
             PreparedStatement ins = con.prepareStatement(
                     "INSERT INTO audit_log(client_id, period_id, action, entity_type,"
                             + " entity_id, details_json, detail, actor, at)"
                             + " VALUES (?, ?, ?, ?, ?, ?, ?, 'local-user', ?)")) {
            while (rs.next()) {
                ins.setObject(1, rs.getObject("client_id"));
                ins.setObject(2, rs.getObject("period_id"));
                ins.setString(3, rs.getString("action"));
                ins.setString(4, rs.getString("entity_type"));
                ins.setObject(5, rs.getObject("entity_id"));
                ins.setString(6, rs.getString("details_json"));
                ins.setString(7, rs.getString("details_json"));
                ins.setString(8, rs.getString("created_at"));
                ins.executeUpdate();
            }
        } catch (SQLException noTable) {
            // no audit rows in the old database
        }
    }

    private static void writeReconciliationAudit(Connection con, Path backup)
            throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO audit_log(client_id, action, detail, actor,"
                        + " details_json) VALUES (NULL, 'SCHEMA_RECONCILED', ?, 'local-user', ?)")) {
            ps.setString(1, "database migrated from a divergent 2.x build; original"
                    + " preserved at " + backup);
            ps.setString(2, "{\"backup\":\"" + escape(backup.toString()) + "\"}");
            ps.executeUpdate();
        }
    }

    private static String escape(String raw) {
        return raw == null ? "" : raw.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // connection is closed right after anyway
        }
    }
}
