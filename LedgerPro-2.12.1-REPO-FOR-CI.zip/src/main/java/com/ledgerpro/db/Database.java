package com.ledgerpro.db;

import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.FlywayException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * The single source of truth for LedgerPro's SQLite connection.
 *
 * <p>Every other class obtains connections through here, so the pragmas below
 * are guaranteed on EVERY connection - in SQLite, pragmas like
 * {@code foreign_keys} are per-connection settings, and forgetting that is a
 * classic source of silent data corruption.</p>
 *
 * <p>Pragmas used and why:</p>
 * <ul>
 *   <li>{@code journal_mode = WAL} - Write-Ahead Logging: readers never block
 *       the writer and vice versa; a crash mid-write cannot corrupt the DB.
 *       (WAL is a property of the database file - it sticks after the first
 *       time it is set - but re-issuing it is free and keeps this class
 *       self-contained.)</li>
 *   <li>{@code foreign_keys = ON} - enforces the REFERENCES clauses of the
 *       schema; SQLite ships with this OFF for historical reasons.</li>
 *   <li>{@code synchronous = NORMAL} - the recommended durability setting
 *       for WAL mode: safe against application crashes, good performance.</li>
 *   <li>{@code busy_timeout = 5000} - wait up to 5 s for a lock instead of
 *       failing instantly with SQLITE_BUSY.</li>
 * </ul>
 */
public final class Database {

    private static final Logger LOG = LoggerFactory.getLogger(Database.class);

    private final String url;

    /** Uses the default database path (see {@link #defaultDbPath()}). */
    public Database() {
        this(defaultDbPath());
    }

    /**
     * @param filePath file path of the SQLite database; parent folders are
     *                 created automatically, the file itself is created by
     *                 SQLite on first write
     */
    public Database(String filePath) {
        Path absolute = Paths.get(filePath).toAbsolutePath();
        try {
            if (absolute.getParent() != null) {
                Files.createDirectories(absolute.getParent());
            }
        } catch (IOException e) {
            throw new IllegalStateException(
                    "Cannot create database folder: " + absolute.getParent(), e);
        }
        this.url = "jdbc:sqlite:" + absolute;
    }

    /**
     * Resolution order for the default DB location:
     * system property {@code ledgerpro.db} &gt; environment variable
     * {@code LEDGERPRO_DB} &gt; (development runs only) a writable
     * {@code data/ledgerpro.db} next to the working directory &gt;
     * {@code ~/.ledgerpro/ledgerpro.db}.
     *
     * <p>The packaged application (jpackage {@code .exe} / {@code .app}) always
     * uses {@code ~/.ledgerpro}: its working directory depends on how it was
     * started (the app folder, the Desktop, a shortcut's "Start in" folder), and
     * a writable one used to make the database silently appear in a different
     * place per launch - the books looked empty after launching from
     * somewhere else. Tests point at a temp directory through the property or
     * the explicit constructor.</p>
     */
    public static String defaultDbPath() {
        String fromProperty = System.getProperty("ledgerpro.db");
        if (fromProperty != null && !fromProperty.isBlank()) {
            return fromProperty;
        }
        String fromEnv = System.getenv("LEDGERPRO_DB");
        if (fromEnv != null && !fromEnv.isBlank()) {
            return fromEnv;
        }
        return pickWritableDefault();
    }

    /**
     * {@code data/ledgerpro.db} when the working directory lets us create and
     * write a {@code data} folder; otherwise the user-home fallback that
     * always works for the packaged app.
     */
    private static String pickWritableDefault() {
        // jpackage launchers set this property; a development run
        // (mvn javafx:run / java -cp) never does.
        if (System.getProperty("jpackage.app-path") != null) {
            return userHomeDefault();
        }
        Path local = Paths.get("data");
        try {
            Files.createDirectories(local);
            Path probe = Files.createTempFile(local, "probe-", ".tmp");
            Files.deleteIfExists(probe);
            return local.resolve("ledgerpro.db").toString();
        } catch (IOException | SecurityException e) {
            return userHomeDefault();
        }
    }

    /** The per-user location that is always writable: {@code ~/.ledgerpro}. */
    private static String userHomeDefault() {
        return Paths.get(System.getProperty("user.home"), ".ledgerpro",
                "ledgerpro.db").toString();
    }

    /**
     * The absolute path of the database file this instance points at
     * (2.12.0 — the backup/restore feature and the settings row need to
     * tell the user WHERE their books live).
     */
    public String filePath() {
        return url.substring("jdbc:sqlite:".length());
    }

    /**
     * Opens a new connection with all pragmas applied.
     * Callers MUST close it - use try-with-resources.
     */
    public Connection open() throws SQLException {
        Connection connection = DriverManager.getConnection(url);
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON;");
            st.execute("PRAGMA journal_mode = WAL;");
            st.execute("PRAGMA synchronous  = NORMAL;");
            st.execute("PRAGMA busy_timeout = 5000;");
        }
        return connection;
    }

    /**
     * Opens the schema: first the {@link SchemaGuard} (which makes sure a
     * database created by any earlier LedgerPro build is reconciled — never
     * crashed on), then Flyway with the repair-retry below.
     */
    public void migrate() {
        SchemaGuard.reconcile(url);
        Flyway flyway = Flyway.configure()
                .dataSource(url, null, null)
                .locations("classpath:db/migration")
                .load();
        try {
            flyway.migrate();
        } catch (FlywayException e) {
            LOG.warn("Flyway migration failed ({}); repairing schema history and"
                    + " retrying once", e.getMessage());
            flyway.repair();
            flyway.migrate();
        }
    }

    /** JDBC URL this instance points at (for diagnostics and the CLI). */
    public String url() {
        return url;
    }
}
