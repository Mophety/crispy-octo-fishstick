package com.ledgerpro.model;

/**
 * One row of the {@code audit_log} table: the trail of every mutation the
 * firm ever made. Since migration V4 each row also carries the structured
 * entity it touched ({@code entityType} + {@code entityId}) and the period
 * it belongs to, so the Audit view can link straight to the record.
 *
 * @param id         database id
 * @param clientId   owning client, null for firm-wide actions (FX rates)
 * @param periodId   period the action touched, when applicable
 * @param action     machine verb ('CREATE_ENTRY', 'POST_ENTRY', …)
 * @param entityType 'CLIENT', 'ACCOUNT', 'PERIOD', 'ENTRY', 'ADJ_TEMPLATE',
 *                   'FX_RATE', 'TB_SNAPSHOT', 'REPORT', … or null
 * @param entityId   id of the entity above, when applicable
 * @param detail     the human-readable story of the action
 * @param actor      who did it — 'local-user' (LedgerPro has no login system)
 * @param at         UTC timestamp, 'YYYY-MM-DD HH:MM:SS'
 */
public record AuditEntry(
        long id,
        Long clientId,
        Long periodId,
        String action,
        String entityType,
        Long entityId,
        String detail,
        String actor,
        String at) {
}
