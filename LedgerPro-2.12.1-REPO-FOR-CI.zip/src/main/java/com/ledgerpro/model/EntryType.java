package com.ledgerpro.model;

/**
 * Where in the accounting cycle a journal entry belongs.
 *
 * <ul>
 *   <li>{@code NORMAL} — day-to-day transactions (cycle step 1).</li>
 *   <li>{@code ADJUSTING} — end-of-period adjustments (step 4).</li>
 *   <li>{@code CLOSING} — zeroing the temporary accounts (step 7).</li>
 *   <li>{@code REVERSING} — created only by the journal's void machinery:
 *       the mirrored entry that negates a posted entry. Never typed by a
 *       user.</li>
 * </ul>
 */
public enum EntryType {

    NORMAL("Normal"),
    ADJUSTING("Adjusting"),
    CLOSING("Closing"),
    REVERSING("Reversing");

    /** Human-friendly label for combo boxes and table cells. */
    public final String label;

    EntryType(String label) {
        this.label = label;
    }

    /** True for the types an accountant can pick in the new-entry dialog. */
    public boolean userSelectable() {
        return this != REVERSING;
    }

    /** Parses the database spelling ('NORMAL', 'Adjusting', …). */
    public static EntryType parse(String raw) {
        return switch (raw == null ? "" : raw.trim().toUpperCase()) {
            case "NORMAL" -> NORMAL;
            case "ADJUSTING" -> ADJUSTING;
            case "CLOSING" -> CLOSING;
            case "REVERSING" -> REVERSING;
            default -> throw new IllegalArgumentException(
                    "entry type must be one of NORMAL, ADJUSTING, CLOSING,"
                            + " REVERSING — not '" + raw + "'");
        };
    }
}
