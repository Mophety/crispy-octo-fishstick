package com.ledgerpro.model;

import java.time.LocalDate;

/**
 * One row of the {@code periods} table: an accounting period of one client —
 * the unit that gets locked at the end of the accounting cycle.
 *
 * <p>Every journal entry belongs to exactly one period; a CLOSED period
 * accepts no new entries, no posting and no voiding, so its reported numbers
 * stay put. Closing is reversible ({@code reopen}) — corrections happen in
 * daylight, with an audit row, never by silent back-dated edits.</p>
 *
 * @param id       database id
 * @param clientId owning client
 * @param name      display name, unique per client ('FY2026', '2026-10')
 * @param start     inclusive first day
 * @param end       inclusive last day
 * @param closed    true once the period is locked
 * @param closedAt  when the period was closed, null while open (or unknown
 *                  for periods migrated from older builds)
 * @param lockedAt  when the period was additionally hard-locked, if ever
 */
public record Period(
        long id,
        long clientId,
        String name,
        LocalDate start,
        LocalDate end,
        boolean closed,
        String closedAt,
        String lockedAt) {

    /** True when {@code date} falls inside the period (both ends inclusive). */
    public boolean contains(LocalDate date) {
        return date != null && !date.isBefore(start) && !date.isAfter(end);
    }

    /** Compact form used by the journal's period picker. */
    @Override
    public String toString() {
        return name + "  (" + start + " … " + end + ")" + (closed ? "  · CLOSED" : "");
    }
}
