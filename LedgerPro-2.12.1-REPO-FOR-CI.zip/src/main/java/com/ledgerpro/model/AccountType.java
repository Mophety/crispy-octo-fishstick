package com.ledgerpro.model;

/**
 * The five account classifications of the accounting cycle.
 *
 * <p>Each type has a <b>normal side</b> — the side that increases the
 * balance: assets and expenses grow with debits, liabilities, equity and
 * revenue grow with credits. {@link #defaultSide()} drives the default in
 * the account dialog; the user may override it to register a <b>contra
 * account</b> (an account of one type carrying the opposite normal side,
 * e.g. 'Accumulated Depreciation', an ASSET increased by credits).</p>
 */
public enum AccountType {

    ASSET("Asset", Side.DEBIT),
    LIABILITY("Liability", Side.CREDIT),
    EQUITY("Equity", Side.CREDIT),
    REVENUE("Revenue", Side.CREDIT),
    EXPENSE("Expense", Side.DEBIT);

    /** Human-friendly label for combo boxes and table cells. */
    public final String label;

    /** The side that increases accounts of this type (before contra overrides). */
    private final Side defaultSide;

    AccountType(String label, Side defaultSide) {
        this.label = label;
        this.defaultSide = defaultSide;
    }

    public Side defaultSide() {
        return defaultSide;
    }

    /**
     * Whether accounts of this type are permanent (real) or temporary
     * (nominal): closing entries zero REVENUE and EXPENSE into income
     * summary and then into retained earnings, so only ASSET, LIABILITY and
     * EQUITY carry balances into the next period (migration V4 column
     * {@code accounts.is_permanent}).
     */
    public boolean isPermanent() {
        return this == ASSET || this == LIABILITY || this == EQUITY;
    }

    /** Parses the database spelling ('ASSET', 'Liability', …). */
    public static AccountType parse(String raw) {
        return switch (raw == null ? "" : raw.trim().toUpperCase()) {
            case "ASSET" -> ASSET;
            case "LIABILITY" -> LIABILITY;
            case "EQUITY" -> EQUITY;
            case "REVENUE" -> REVENUE;
            case "EXPENSE" -> EXPENSE;
            default -> throw new IllegalArgumentException(
                    "account type must be one of ASSET, LIABILITY, EQUITY,"
                            + " REVENUE, EXPENSE — not '" + raw + "'");
        };
    }
}
