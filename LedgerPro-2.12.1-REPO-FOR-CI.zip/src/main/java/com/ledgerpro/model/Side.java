package com.ledgerpro.model;

/**
 * The two sides of a double-entry line — and, at account level, the side that
 * increases the account's balance (its "normal" side).
 *
 * <p>Stored as plain TEXT in SQLite; {@code values()} order (DEBIT first)
 * is the order the UI combo boxes show.</p>
 */
public enum Side {
    DEBIT("Debit"), CREDIT("Credit");

    /** Human-friendly label for combo boxes, hints and dialogs. */
    public final String label;

    Side(String label) {
        this.label = label;
    }

    /** The other side. */
    public Side opposite() {
        return this == DEBIT ? CREDIT : DEBIT;
    }

    /** Parses the database / dialog spelling; blank input is rejected. */
    public static Side parse(String raw) {
        return switch (raw == null ? "" : raw.trim().toUpperCase()) {
            case "DEBIT" -> DEBIT;
            case "CREDIT" -> CREDIT;
            default -> throw new IllegalArgumentException(
                    "side must be DEBIT or CREDIT, not '" + raw + "'");
        };
    }
}
