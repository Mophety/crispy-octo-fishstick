package com.ledgerpro.model;

import java.util.Set;

/**
 * The three trial-balance checkpoints of the accounting cycle — the exact
 * stages the {@code tb_snapshots} table records.
 *
 * <p>Each stage reads the posted journal filtered by how far the cycle has
 * come:</p>
 * <ul>
 *   <li>{@code UNADJUSTED} — day-to-day entries only ({@code NORMAL}), plus
 *       any {@code REVERSING} mirrors: voiding an erroneous entry must remove
 *       its effect from every stage.</li>
 *   <li>{@code ADJUSTED} — the above plus {@code ADJUSTING} entries.</li>
 *   <li>{@code POST_CLOSING} — the above plus {@code CLOSING} entries;
 *       temporary accounts net to zero here.</li>
 * </ul>
 */
public enum TbStage {

    UNADJUSTED("Unadjusted", Set.of(EntryType.NORMAL, EntryType.REVERSING)),
    ADJUSTED("Adjusted", Set.of(EntryType.NORMAL, EntryType.REVERSING, EntryType.ADJUSTING)),
    POST_CLOSING("Post-closing", Set.of(EntryType.values()));

    /** Human-friendly label for combo boxes and table headers. */
    public final String label;

    /** Entry types that count toward this stage. */
    public final Set<EntryType> includes;

    TbStage(String label, Set<EntryType> includes) {
        this.label = label;
        this.includes = includes;
    }

    /** Parses the database spelling ('UNADJUSTED', 'Adjusted', …). */
    public static TbStage parse(String raw) {
        return switch (raw == null ? "" : raw.trim().toUpperCase()) {
            case "UNADJUSTED" -> UNADJUSTED;
            case "ADJUSTED" -> ADJUSTED;
            case "POST_CLOSING" -> POST_CLOSING;
            default -> throw new IllegalArgumentException(
                    "trial-balance stage must be one of UNADJUSTED, ADJUSTED,"
                            + " POST_CLOSING — not '" + raw + "'");
        };
    }
}
