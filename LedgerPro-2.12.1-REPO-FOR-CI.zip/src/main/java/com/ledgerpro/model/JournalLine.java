package com.ledgerpro.model;

/**
 * One row of the {@code journal_lines} table: one Dr-or-Cr line of a journal
 * entry.
 *
 * <p>Exactly one of {@code debitCents} / {@code creditCents} is non-null and
 * positive — the schema's CHECK guards enforce that structurally, the journal
 * service enforces the per-entry "debits = credits" rule on top. Amounts are
 * <b>base-currency cents</b>: for a multi-currency entry the typed amount was
 * converted with the entry's rate snapshot (half-up), with any rounding
 * residual absorbed by the largest line so the entry balances exactly.</p>
 *
 * <p>For multi-currency entries the transaction-currency side is kept too
 * (migration V4): what currency was typed, how much on which side, the rate
 * applied and — best effort — the cache row it came from. Base-currency
 * entries leave all of those null.</p>
 *
 * @param id             database id
 * @param entryId        owning entry
 * @param lineNo         position within the entry, 1-based
 * @param accountId      account hit by the line
 * @param debitCents     debit amount in base-currency cents, or null
 * @param creditCents    credit amount in base-currency cents, or null
 * @param memo           optional line description
 * @param txnCurrency    the currency the amount was typed in, null = base
 * @param txnDebitCents  typed debit amount in txn-currency cents, or null
 * @param txnCreditCents typed credit amount in txn-currency cents, or null
 * @param fxRate         rate applied to this line, null for base currency
 * @param fxRateId       cache row the rate came from, when identifiable
 */
public record JournalLine(
        long id,
        long entryId,
        int lineNo,
        long accountId,
        Long debitCents,
        Long creditCents,
        String memo,
        String txnCurrency,
        Long txnDebitCents,
        Long txnCreditCents,
        Double fxRate,
        Long fxRateId) {

    /** The side this line posts on (never null for a stored row). */
    public Side side() {
        return debitCents != null ? Side.DEBIT : Side.CREDIT;
    }

    /** The positive amount this line posts (never null for a stored row). */
    public long amount() {
        return debitCents != null ? debitCents : creditCents;
    }
}
