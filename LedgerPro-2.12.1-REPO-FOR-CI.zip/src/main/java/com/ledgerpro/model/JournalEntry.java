package com.ledgerpro.model;

import java.time.LocalDate;

/**
 * One row of the {@code journal_entries} table: a complete double-entry.
 *
 * <p>Immutable snapshot, like the other models. "Voided" is not a column on
 * purpose — an entry counts as voided exactly when another entry's
 * {@code voidOfId} points at it (see {@code JournalService}); no flag can
 * ever disagree with the mirror entry that does the actual negating.</p>
 *
 * <p>Multi-currency entries keep the original currency and the rate that was
 * applied; the <b>lines themselves always carry base-currency cents</b>, so
 * every trial balance and ledger reads in one currency. A {@code null}
 * currency means the entry was recorded straight in the client's base
 * currency (rate {@code null}).</p>
 *
 * @param id        database id
 * @param clientId  owning client
 * @param periodId  period the entry belongs to
 * @param entryNo    sequential number, unique per client
 * @param date       accounting date (within the period)
 * @param type       NORMAL / ADJUSTING / CLOSING / REVERSING
 * @param reference  optional document number ('OR-2026-114'), may be blank
 * @param memo       free-text description
 * @param currency   original entry currency, null = client base currency
 * @param fxRate     base-currency units per 1 unit of {@code currency} at
 *                   {@code date}; null for base-currency entries
 * @param voidOfId   id of the entry this one negates, null if none
 * @param posted     false = draft (no ledger effect yet), true = posted
 * @param postedAt   when the entry became ledger fact, null while a draft
 * @param adjTemplateId the recurring template this entry was prefilled
 *                   from, when known (provenance, never enforced)
 * @param createdAt  UTC creation timestamp
 */
public record JournalEntry(
        long id,
        long clientId,
        long periodId,
        int entryNo,
        LocalDate date,
        EntryType type,
        String reference,
        String memo,
        String currency,
        Double fxRate,
        Long voidOfId,
        boolean posted,
        String postedAt,
        Long adjTemplateId,
        String createdAt) {
}
