package com.ledgerpro.model;

import java.time.LocalDate;

/**
 * One row of the {@code fx_rates} cache: how many {@code to}-currency units
 * one {@code from}-currency unit was worth on {@code asOf}.
 *
 * <p>Rates are conversion <b>ratios</b>, not ledger amounts: the golden
 * "integer cents" rule protects posted money, while a rate is inherently an
 * approximation (an ECB reference rate with ~4 significant decimals). It is
 * therefore safe for a rate to be a {@code double} — the cents it produces
 * when multiplied into an amount still land in the journal as integers.</p>
 *
 * <p>Since migration V4 the table is a currency-pair table
 * ({@code base_currency}, {@code quote_currency}) with a surrogate {@code id}
 * journal lines can reference and a free-text {@code note}. This record keeps
 * the from/to vocabulary of the service API: {@code fromCur} is the quote
 * (foreign) side, {@code toCur} the base (reporting) side.</p>
 *
 * @param id        database id, 0 for synthesized (inverse) rows
 * @param asOf      the date the rate applies to (ISO-8601)
 * @param fromCur   ISO 4217 source currency ('USD') — the quote side
 * @param toCur     ISO 4217 target currency ('PHP') — the base side
 * @param rate      {@code toCur} units per 1 {@code fromCur}, always &gt; 0
 * @param source    FRANKFURTER (live API) or MANUAL (typed by the accountant)
 * @param fetchedAt UTC timestamp of when the row was written
 * @param note      free-text note ('year-end rate from the bank statement')
 */
public record FxRate(
        long id,
        LocalDate asOf,
        String fromCur,
        String toCur,
        double rate,
        Source source,
        String fetchedAt,
        String note) {

    /** Where a cached rate came from. */
    public enum Source {
        FRANKFURTER, MANUAL;

        public static Source parse(String raw) {
            return switch (raw == null ? "" : raw.trim().toUpperCase()) {
                case "FRANKFURTER" -> FRANKFURTER;
                case "MANUAL" -> MANUAL;
                default -> throw new IllegalArgumentException(
                        "rate source must be FRANKFURTER or MANUAL, not '" + raw + "'");
            };
        }
    }

    /** Display form for the table: 'USD → PHP'. */
    public String pair() {
        return fromCur + " → " + toCur;
    }
}
