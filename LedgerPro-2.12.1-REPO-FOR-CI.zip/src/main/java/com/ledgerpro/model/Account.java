package com.ledgerpro.model;

/**
 * One row of the {@code accounts} table: an account in a client's chart of
 * accounts.
 *
 * <p>{@code normalSide} is stored explicitly instead of being derived from
 * {@code type} so contra accounts work naturally: 'Accumulated Depreciation'
 * is an ASSET whose normal side is CREDIT. {@link #contra()} flags exactly
 * those rows for the UI.</p>
 *
 * <p>Immutable snapshot, like {@link Client}: services return fresh records.</p>
 *
 * @param id          database id
 * @param clientId    owning client (charts are per client)
 * @param code        short code, unique within the client's chart ('1010')
 * @param name        account name
 * @param type        one of the five classifications
 * @param normalSide  side that increases the balance
 * @param isPermanent false for temporary accounts (REVENUE/EXPENSE) that
 *                    closing entries zero out at the end of the cycle
 * @param isRetainedEarnings flags the single equity account closing entries
 *                    sweep net income into
 * @param parentId    optional parent for hierarchical reporting
 * @param active      false once deactivated; accounts are never deleted
 */
public record Account(
        long id,
        long clientId,
        String code,
        String name,
        AccountType type,
        Side normalSide,
        boolean isPermanent,
        boolean isRetainedEarnings,
        Long parentId,
        boolean active) {

    /** True when the normal side is the opposite of the type's default —
     *  the signature of a contra account. */
    public boolean contra() {
        return normalSide != type.defaultSide();
    }

    /** Compact form used by pickers from the journal on: '1010 — Cash in Bank'. */
    @Override
    public String toString() {
        return code + "  —  " + name;
    }
}
