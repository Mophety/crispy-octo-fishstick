package com.ledgerpro.model;

/**
 * One row of the {@code clients} table: a corporate customer of the firm.
 *
 * <p>This is an immutable snapshot, not a live object: services return fresh
 * records on every query, so the UI can never hold a stale copy for long.</p>
 *
 * @param id           database id
 * @param code         short uppercase code, unique across the firm ('NRTH')
 * @param name         legal / trading name
 * @param baseCurrency ISO 4217 reporting currency ('PHP')
 * @param taxId        tax identification number, may be blank
 * @param isSetup      true once the client has a chart and a period — the
 *                     dashboard's onboarding checklist turns off
 * @param active       false once archived; clients are never deleted
 * @param createdAt    UTC creation timestamp, 'YYYY-MM-DD HH:MM:SS'
 */
public record Client(
        long id,
        String code,
        String name,
        String baseCurrency,
        String taxId,
        boolean isSetup,
        boolean active,
        String createdAt) {

    /** Compact form used by the client switcher and dialogs. */
    @Override
    public String toString() {
        return code + "  —  " + name;
    }
}
