package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.model.TbStage;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.AdjTemplateService;
import com.ledgerpro.service.ChartTemplates;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.service.WorksheetService;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Seeds the demo the shipped bundles advertise: Northwind Retail Trading, a
 * full FY2026 cycle — capital, prepayments, a multi-currency equipment
 * purchase, payroll with Philippine statutory contributions, a voided
 * duplicate payment that is honestly cancelled by a mirrored reversal,
 * recurring adjustment templates (fixed AND formula), and the reports.
 *
 * <p>Runs only when the database has no clients AT ALL — archived rows
 * count as clients (they still own journal entries, FX snapshots and shared
 * adjustment templates), so the demo never mixes itself into real data.
 * Invoked by {@code --demo} (the LedgerPro-demo launchers), by the
 * Settings → Data section (2.11.2) and usable from tests.</p>
 */
public final class DemoData {

    private DemoData() {
    }

    /**
     * True when the database holds no client row at all — the exact
     * condition {@link #seedIfEmpty} seeds under. Archived clients count
     * as existing books: their entries stay in the tables, and the demo's
     * global FX rates / adjustment templates would write over real data,
     * so a client archive is NOT an empty database.
     */
    public static boolean canSeed(Database database) {
        return !hasAnyClient(database);
    }

    /**
     * Seeds the demo when (and only when) the database is still client-free.
     *
     * @return true when the demo was written; false when the database
     *         already holds clients (archived included) and the call was a
     *         no-op — callers owe the user an honest "skipped" message
     */
    public static boolean seedIfEmpty(Database database) {
        if (hasAnyClient(database)) {
            return false;
        }
        seed(database);
        return true;
    }

    private static boolean hasAnyClient(Database database) {
        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT EXISTS(SELECT 1 FROM clients)")) {
            return rs.next() && rs.getInt(1) == 1;
        } catch (SQLException e) {
            throw new IllegalStateException("cannot inspect the database: " + e.getMessage(), e);
        }
    }

    public static void seed(Database database) {
        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        FxRateService fx = new FxRateService(database);
        PeriodService periods = new PeriodService(database);
        JournalService journal = new JournalService(database, fx);
        WorksheetService worksheets = new WorksheetService(database);
        AdjTemplateService adj = new AdjTemplateService(database);

        seedFxRates(fx);
        seedAdjTemplates(adj);

        Client nrth = clients.create("NRTH", "Northwind Retail Trading", "PHP",
                "STANDARD", "123-456-789-000");
        accounts.applyChartTemplate(nrth.id(),
                ChartTemplates.byCode("STANDARD").orElseThrow());
        Period fy = periods.create(nrth.id(), "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));
        clients.refreshSetup(nrth.id());   // chart AND period now exist

        // codes of the STANDARD chart (StandardChart.java)
        long bank = account(accounts, nrth, "1010");         // Cash in Bank
        long petty = account(accounts, nrth, "1020");        // Petty Cash Fund
        long ar = account(accounts, nrth, "1100");           // Accounts Receivable
        long inventory = account(accounts, nrth, "1200");    // Inventory
        long prepaid = account(accounts, nrth, "1300");      // Prepaid Expenses
        long equipment = account(accounts, nrth, "1500");    // PP&E
        long accumDep = account(accounts, nrth, "1510");     // Accumulated Depreciation
        long ap = account(accounts, nrth, "2000");           // Accounts Payable
        long contributions = account(accounts, nrth, "2120");// SSS/Pag-IBIG/PhilHealth
        long capital = account(accounts, nrth, "3000");      // Ordinary Share Capital
        long dividends = account(accounts, nrth, "3900");    // Dividends Declared
        long serviceRev = account(accounts, nrth, "4000");   // Service Revenue
        long sales = account(accounts, nrth, "4010");        // Sales - Goods
        long cogs = account(accounts, nrth, "5000");         // Cost of Sales
        long salaries = account(accounts, nrth, "6000");     // Salaries and Wages
        long rentExp = account(accounts, nrth, "6100");      // Rent Expense
        long utilities = account(accounts, nrth, "6110");    // Utilities Expense
        long supplies = account(accounts, nrth, "6150");     // Supplies Expense
        long insurance = account(accounts, nrth, "6200");    // Insurance Expense
        long depreciation = account(accounts, nrth, "6400"); // Depreciation Expense
        long bankCharges = account(accounts, nrth, "6600");  // Bank Charges

        // 1. initial capital
        post(journal, nrth, fy, LocalDate.of(2026, 1, 5), "CAP-001",
                "Owner's initial investment",
                line(bank, 500_000_00), cr(capital, 500_000_00));
        // 2. petty cash fund
        post(journal, nrth, fy, LocalDate.of(2026, 1, 8), "TRF-001",
                "Establish petty cash fund",
                line(petty, 10_000_00), cr(bank, 10_000_00));
        // 3. annual rent prepayment
        post(journal, nrth, fy, LocalDate.of(2026, 1, 15), "CHK-1001",
                "Annual office rent, paid in advance",
                line(prepaid, 120_000_00), cr(bank, 120_000_00));
        // 4. equipment purchase in USD — typed in USD, converted at the
        //    cached rate snapshotted on the entry (58.25)
        postUsd(journal, nrth, fy, LocalDate.of(2026, 1, 20), "CHK-1002",
                "Equipment purchase (USD 5,000 @ 58.25)",
                usd(equipment, 5_000_00, "Bundled coffee machines"),
                usdCr(bank, 5_000_00));
        // 5. service invoice
        post(journal, nrth, fy, LocalDate.of(2026, 2, 10), "INV-1001",
                "Consulting services — Acme Corp",
                line(ar, 85_000_00), cr(serviceRev, 85_000_00));
        // 6. collection
        post(journal, nrth, fy, LocalDate.of(2026, 2, 15), "COL-1001",
                "Collection of INV-1001",
                line(bank, 60_000_00), cr(ar, 60_000_00));
        // 7. payroll with PH statutory contributions
        post(journal, nrth, fy, LocalDate.of(2026, 2, 28), "PAY-0228",
                "February payroll",
                line(salaries, 42_000_00), line(contributions, 3_430_00),
                cr(bank, 45_430_00));
        // 8. utilities
        post(journal, nrth, fy, LocalDate.of(2026, 3, 10), "CHK-1003",
                "February utilities",
                line(utilities, 9_600_00), cr(bank, 9_600_00));
        // 9. USD service invoice (58.10)
        postUsd(journal, nrth, fy, LocalDate.of(2026, 3, 15), "INV-1002",
                "Consulting services — Globex (USD 3,000 @ 58.10)",
                usd(ar, 3_000_00, "USD invoice"), usdCr(serviceRev, 3_000_00));
        // 10. bank charges
        post(journal, nrth, fy, LocalDate.of(2026, 3, 20), "BC-2026Q1",
                "Q1 bank charges",
                line(bankCharges, 350_00), cr(bank, 350_00));
        // 11. merchandise purchase on account
        post(journal, nrth, fy, LocalDate.of(2026, 4, 5), "PO-0042",
                "Merchandise purchase on 30-day terms",
                line(inventory, 95_000_00), cr(ap, 95_000_00));
        // 12. cash sale + COGS
        post(journal, nrth, fy, LocalDate.of(2026, 4, 12), "SALE-0130",
                "Cash merchandise sale",
                line(bank, 52_000_00), cr(sales, 52_000_00));
        post(journal, nrth, fy, LocalDate.of(2026, 4, 12), "COGS-0130",
                "Cost of the merchandise sold",
                line(cogs, 38_000_00), cr(inventory, 38_000_00));
        // 13. supplies
        post(journal, nrth, fy, LocalDate.of(2026, 4, 25), "PETTY-015",
                "Office supplies from petty cash",
                line(supplies, 6_500_00), cr(petty, 6_500_00));
        // 14. dividends declared and paid
        post(journal, nrth, fy, LocalDate.of(2026, 5, 2), "DRW-001",
                "Owner's drawings",
                line(dividends, 30_000_00), cr(bank, 30_000_00));
        // 15. a mistaken entry that gets voided by mirrored reversal
        long mistaken = post(journal, nrth, fy, LocalDate.of(2026, 5, 10), "CHK-1004",
                "Insurance premium — duplicate payment (to be voided)",
                line(insurance, 24_000_00), cr(bank, 24_000_00));
        journal.voidEntry(mistaken, "duplicate payment — see CHK-1004's replacement");

        // 16. manual adjustment: prepaid rent consumed Jan–Jun
        post(journal, nrth, fy, LocalDate.of(2026, 6, 30), "ADJ-001",
                "Prepaid rent consumed Jan–Jun", EntryType.ADJUSTING,
                line(rentExp, 60_000_00), cr(prepaid, 60_000_00));

        // 17. adjustments from the seeded templates: depreciation (formula),
        //     bad-debt allowance (formula)
        postTemplate(journal, adj, accounts, nrth, fy, "DEP_M",
                LocalDate.of(2026, 6, 30), "ADJ-002");
        postTemplate(journal, adj, accounts, nrth, fy, "BAD_DEBT",
                LocalDate.of(2026, 6, 30), "ADJ-003");

        journal.snapshotTrialBalance(fy.id(), TbStage.UNADJUSTED);
        journal.snapshotTrialBalance(fy.id(), TbStage.ADJUSTED);
        worksheets.snapshotStatement(fy.id(), WorksheetService.ReportKind.INCOME_STATEMENT);
        worksheets.snapshotStatement(fy.id(), WorksheetService.ReportKind.BALANCE_SHEET);
    }

    private static long account(AccountService accounts, Client client, String code) {
        return accounts.list(client.id(), false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "the STANDARD chart has no account " + code))
                .id();
    }

    private static void seedFxRates(FxRateService fx) {
        fx.putManual(LocalDate.of(2026, 1, 2), "USD", "PHP", 58.32,
                "opening reference for the demo year");
        fx.putManual(LocalDate.of(2026, 1, 20), "USD", "PHP", 58.25, "equipment purchase");
        fx.putManual(LocalDate.of(2026, 3, 15), "USD", "PHP", 58.10, "Globex invoice");
        fx.putManual(LocalDate.of(2026, 1, 2), "EUR", "PHP", 63.40, "");
        fx.putManual(LocalDate.of(2026, 1, 2), "GBP", "PHP", 74.15, "");
        fx.putManual(LocalDate.of(2026, 1, 2), "JPY", "PHP", 0.3852, "");
    }

    private static void seedAdjTemplates(AdjTemplateService adj) {
        adj.save(null, "DEP_M", "Monthly depreciation — equipment",
                "10% per annum straight line, one month of the equipment balance",
                List.of(
                        new AdjTemplateService.TemplateLine(1, "6400", "DR",
                                AdjTemplateService.FORMULA, "BAL(1500) * 10% / 12", null),
                        new AdjTemplateService.TemplateLine(2, "1510", "CR",
                                AdjTemplateService.FORMULA, "BAL(1500) * 10% / 12", null)));

        adj.save(null, "BAD_DEBT", "Bad debts allowance — 5% of AR",
                "Allowance at 5% of the accounts-receivable balance",
                List.of(
                        new AdjTemplateService.TemplateLine(1, "6500", "DR",
                                AdjTemplateService.FORMULA, "5% * BAL(1100)", null),
                        new AdjTemplateService.TemplateLine(2, "1110", "CR",
                                AdjTemplateService.FORMULA, "5% * BAL(1100)", null)));

        adj.save(null, "RENT_AM", "Monthly rent amortization",
                "Monthly portion of the annual rent prepayment",
                List.of(
                        new AdjTemplateService.TemplateLine(1, "6100", "DR",
                                AdjTemplateService.FIXED, "10000.00", null),
                        new AdjTemplateService.TemplateLine(2, "1300", "CR",
                                AdjTemplateService.FIXED, "10000.00", null)));
    }

    private static JournalService.NewLine line(long accountId, long cents) {
        return new JournalService.NewLine(accountId, cents, null, null);   // debit
    }

    private static JournalService.NewLine cr(long accountId, long cents) {
        return new JournalService.NewLine(accountId, null, cents, null);   // credit
    }

    private static JournalService.NewLine usd(long accountId, long cents, String memo) {
        return new JournalService.NewLine(accountId, cents, null, memo);   // debit
    }

    private static JournalService.NewLine usdCr(long accountId, long cents) {
        return new JournalService.NewLine(accountId, null, cents, null);   // credit
    }

    private static long post(JournalService journal, Client client, Period period,
                             LocalDate date, String reference, String description,
                             JournalService.NewLine... lines) {
        return post(journal, client, period, date, reference, description,
                EntryType.NORMAL, null, lines);
    }

    private static long post(JournalService journal, Client client, Period period,
                             LocalDate date, String reference, String description,
                             EntryType type, JournalService.NewLine... lines) {
        return post(journal, client, period, date, reference, description,
                type, null, lines);
    }

    /** All lines typed in the entry currency (USD) — the service converts. */
    private static long postUsd(JournalService journal, Client client, Period period,
                                LocalDate date, String reference, String description,
                                JournalService.NewLine... lines) {
        return post(journal, client, period, date, reference, description,
                EntryType.NORMAL, "USD", lines);
    }

    private static long post(JournalService journal, Client client, Period period,
                             LocalDate date, String reference, String description,
                             EntryType type, String currency,
                             JournalService.NewLine... lines) {
        long dr = 0;
        long cr = 0;
        for (JournalService.NewLine line : lines) {
            dr += line.debitCents() == null ? 0 : line.debitCents();
            cr += line.creditCents() == null ? 0 : line.creditCents();
        }
        if (dr != cr) {
            throw new IllegalStateException("demo entry '" + reference
                    + "' does not balance: " + dr + " ≠ " + cr);
        }
        JournalService.NewEntry command = new JournalService.NewEntry(
                client.id(), period.id(), date, type, reference, description,
                currency, null, List.of(lines));
        com.ledgerpro.model.JournalEntry entry = journal.createDraft(command);
        return journal.post(entry.id()).id();
    }

    /** Loads a template, evaluates its formulas, posts the ADJUSTING entry. */
    private static long postTemplate(JournalService journal, AdjTemplateService adj,
                                     AccountService accounts, Client client, Period period,
                                     String code, LocalDate date, String reference) {
        AdjTemplateService.Template template = adj.list(client.id(), client.code()).stream()
                .filter(t -> t.code().equals(code))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("missing seeded template " + code));
        List<com.ledgerpro.model.Account> chart = accounts.list(client.id(), false);
        var ctx = com.ledgerpro.service.JournalService.formulaContext(
                journal.trialBalance(period.id(), TbStage.ADJUSTED));
        List<AdjTemplateService.AppliedLine> applied =
                adj.instantiate(template.id(), chart, ctx);

        List<JournalService.NewLine> lines = new ArrayList<>();
        for (AdjTemplateService.AppliedLine line : applied) {
            lines.add(new JournalService.NewLine(line.account().id(),
                    line.debitCents(), line.creditCents(), line.memo()));
        }
        JournalService.NewEntry command = new JournalService.NewEntry(
                client.id(), period.id(), date, EntryType.ADJUSTING, reference,
                template.name(), null, template.id(), lines);
        com.ledgerpro.model.JournalEntry entry = journal.createDraft(command);
        return journal.post(entry.id()).id();
    }
}
