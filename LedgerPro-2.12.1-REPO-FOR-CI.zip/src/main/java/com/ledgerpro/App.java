package com.ledgerpro;

import com.ledgerpro.db.Database;
import com.ledgerpro.db.SchemaGuard;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.AdjTemplateService;
import com.ledgerpro.service.AuditService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.service.WorksheetService;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.Theme;
import com.ledgerpro.ui.ThemeManager;
import com.ledgerpro.ui.Prefs;
import com.ledgerpro.ui.UiIcons;
import com.ledgerpro.ui.UiSettings;
import com.ledgerpro.ui.UiStartup;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.Objects;

/**
 * JavaFX entry point (Phase 2: the application shell).
 *
 * <p>{@link #start(Stage)} does only what a launcher should: apply the theme,
 * migrate the database, build the scene through {@link #buildScene(Database)}
 * and show the stage. Everything else lives in the ui/service classes.</p>
 *
 * <p>Run it with {@code mvn javafx:run}.</p>
 */
public class App extends Application {

    /** User preferences node: window geometry + shortcuts survive restarts. */
    private static final String PREFS_NODE = "ledgerpro/app";

    @Override
    public void start(Stage stage) {
        Database database;
        try {
            database = new Database();
            database.migrate();
        } catch (Exception e) {
            stage.setScene(failureScene(e));
            stage.setTitle("LedgerPro - database problem");
            stage.getIcons().addAll(UiIcons.windowIcons());
            stage.show();
            return;
        }

        // --demo: seed a full example cycle when the database is still fresh
        // (the launcher scripts expose this as the separate LedgerPro-demo
        // entry point; the flag is harmless on a database that has data).
        if (getParameters().getUnnamed().contains("--demo")) {
            try {
                if (!com.ledgerpro.dev.DemoData.seedIfEmpty(database)) {
                    // not an error — but say so instead of letting the
                    // demo launcher look like it silently did nothing
                    Alert skip = new Alert(Alert.AlertType.INFORMATION,
                            "The demo was not loaded: this database already holds"
                                    + " clients (archived ones count), and the demo"
                                    + " never writes over real books.\n\n"
                                    + "To explore the demo, start a fresh database"
                                    + " (move or rename the current one first).",
                            ButtonType.OK);
                    skip.setHeaderText("Demo skipped");
                    skip.setTitle("Demo data");
                    skip.showAndWait();
                }
            } catch (RuntimeException e) {
                Alert warn = new Alert(Alert.AlertType.WARNING,
                        "The demo data could not be seeded:\n\n" + e.getMessage()
                                + "\n\nThe application continues with whatever the"
                                + " database already holds.",
                        ButtonType.OK);
                warn.setHeaderText(null);
                warn.setTitle("Demo data");
                warn.showAndWait();
            }
        }

        stage.setTitle("LedgerPro - Accounting Cycle Suite");
        stage.setMinWidth(1024);
        stage.setMinHeight(660);
        stage.getIcons().addAll(UiIcons.windowIcons());
        stage.setScene(buildScene(database));
        // window geometry restores only when the user keeps that setting on
        if (Prefs.getInstance().isGeometryRemembered()) {
            UiStartup.applyRememberedGeometry(stage, PREFS_NODE);
            UiStartup.attachGeometrySaver(stage, PREFS_NODE);
        }
        stage.show();
        // the settled window size lands in the responsive scale (one re-apply
        // after show covers a restored/maximized state)
        UiStartup.bindResponsiveTextToStage(stage);

        // The schema guard reconciled something this start: say so, once.
        String notice = SchemaGuard.lastNotice();
        if (notice != null) {
            Alert info = new Alert(Alert.AlertType.INFORMATION, notice, ButtonType.OK);
            info.setHeaderText("Database migrated");
            info.setTitle("LedgerPro");
            info.showAndWait();
        }
    }

    /**
     * Builds the full application scene: the remembered theme's AtlantaFX
     * user-agent stylesheet plus the LedgerPro stylesheet (and, when the
     * theme carries one, its palette overlay) on top of the {@link AppShell}.
     *
     * <p>Static and public because the headless UI smoke check
     * ({@code com.ledgerpro.dev.UiSnapshot}, test sources) reuses exactly this
     * code path to render screenshots without going through
     * {@link Application#launch launch()}.</p>
     */
    public static Scene buildScene(Database database) {
        return buildScene(database, 1280, 820);
    }

    /**
     * Same scene at a custom size — the headless snapshot tool asks for a
     * wider one when it captures the 13-column worksheet, a working paper
     * that is genuinely wide.
     */
    public static Scene buildScene(Database database, double width, double height) {
        // The remembered theme (Primer Light on a fresh install): one call
        // styles every standard JavaFX control; the sidebar's Appearance
        // picker can swap it again at runtime.
        Theme theme = ThemeManager.current();
        Application.setUserAgentStylesheet(theme.userAgentStylesheet());

        AppShell shell = new AppShell(new ClientService(database),
                new AccountService(database), new FxRateService(database),
                new JournalService(database, new FxRateService(database)),
                new PeriodService(database), new WorksheetService(database),
                new AdjTemplateService(database), new AuditService(database),
                database);
        Scene scene = new Scene(shell, width, height);
        scene.getStylesheets().add(Objects.requireNonNull(
                App.class.getResource("/css/ledgerpro.css")).toExternalForm());
        // The theme's palette overlay (Alexia's theme has one) goes AFTER the
        // author stylesheet so its re-tints win over ledgerpro.css.
        ThemeManager.attachOverlay(scene);
        // Ctrl/Cmd+1…9 view jumps and Ctrl/Cmd+N new entry
        UiStartup.installShortcuts(scene, shell);
        // Responsive text: the root font rides the UiScale property, so every
        // em-sized label, cell and button re-fits the window together (the
        // controller follows the scene's size — works headless too). The
        // chosen density class lands on the root at the same time.
        UiStartup.installResponsiveText(scene);
        UiSettings.applyDensity(scene, Prefs.getInstance().isCompactDensity());
        return scene;
    }

    /**
     * Minimal, unmissable error surface for a broken/unwritable database.
     * 2.12.0: styled through classes + the failure-scene stylesheet so it
     * follows the palette like everything else (the old hard-coded #fff /
     * #b42318 could not).
     */
    private static Scene failureScene(Exception cause) {
        Label message = new Label(
                "LedgerPro could not prepare its database.\n\n"
                        + cause.getClass().getSimpleName() + ": " + cause.getMessage()
                        + "\n\nCheck that the data folder is writable and not locked"
                        + " by another LedgerPro instance, then start again.");
        message.setWrapText(true);
        message.setMaxWidth(460);
        message.getStyleClass().add("lp-failure-message");
        StackPane root = new StackPane(message);
        root.setPadding(new Insets(32));
        root.getStyleClass().add("lp-failure-root");
        Scene scene = new Scene(root, 560, 300);
        scene.getStylesheets().add(Objects.requireNonNull(
                App.class.getResource("/css/ledgerpro.css")).toExternalForm());
        return scene;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
