package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * The 2.7.0 statement of cash flows — the fourth statement the 2.6.0 audit
 * found missing, built by the <b>indirect method</b>: operating cash starts
 * from net income, adds back non-cash items (depreciation, amortization),
 * and adjusts for working-capital movements (receivables, inventory,
 * prepayments, payables, accruals); investing and financing sections
 * classify the period's movements in the corresponding account groups. The
 * whole statement reconciles to the actual movement of the cash accounts —
 * the proof line the app's other statements carry too.
 *
 * <p>Classification follows the chart's account types (the shipped STANDARD
 * chart carries depreciation/amortization contra-asset accounts and
 * long-term investment/notes accounts, so the type+normal-side mapping
 * covers the common cases without a per-client table). Borderline accounts
 * can be reclassified later; the 2.7.0 scope keeps the type-driven default
 * and prints the classification on each line so a reviewer sees it.</p>
 *
 * <p>All figures are period <b>movements</b> (this period's posted debit and
 * credit totals per account, net), not closing balances — cash flow is about
 * flow.</p>
 */
public final class CashFlowService {

    private final Database database;

    public CashFlowService(Database database) {
        this.database = database;
    }

    // ------------------------------------------------------------------
    // The statement
    // ------------------------------------------------------------------

    /** One line of the statement (caption + signed amount). */
    public record FlowRow(String section, String caption, long amountCents) {
    }

    /**
     * The complete statement. {@code netIncome} comes from the income
     * statement; every other row is a movement-derived adjustment.
     */
    public record CashFlowStatement(
            Period period,
            Client client,
            long netIncome,
            List<FlowRow> operating,
            List<FlowRow> investing,
            List<FlowRow> financing,
            long operatingTotal,
            long investingTotal,
            long financingTotal,
            long netMovement,
            long cashStart,
            long cashEnd) {

        /** The proof: net movement must equal the cash accounts' movement. */
        public boolean reconciles() {
            return netMovement == cashEnd - cashStart;
        }
    }

    /**
     * Builds the statement for a period: the indirect-method operating
     * section from the income statement plus ledger movements, investing
     * and financing from their account groups, reconciled to the cash
     * accounts' own movement.
     */
    public CashFlowStatement statement(long periodId) {
        Period period = period(periodId);
        Client client = client(period.clientId());
        WorksheetService worksheets = new WorksheetService(database);
        WorksheetService.IncomeStatement income = worksheets.incomeStatement(periodId);

        // net movement per account for the period (posted entries, all types:
        // closing entries are period facts too)
        List<Movement> movements = movements(periodId);

        long cashMovement = 0;
        List<FlowRow> operating = new ArrayList<>();
        List<FlowRow> investing = new ArrayList<>();
        List<FlowRow> financing = new ArrayList<>();

        operating.add(new FlowRow("operating", "Net income", income.netIncome()));

        for (Movement m : movements) {
            long delta = m.debit - m.credit;   // signed: + increases a debit-normal account
            if (delta == 0) {
                continue;
            }
            if (m.cash) {
                cashMovement += delta;
                continue;   // cash itself is the reconciliation target, not a row
            }
            switch (m.classify()) {
                case "noncash-asset" ->
                    // depreciation/amortization contra assets: credit
                    // movement added back (delta negative → add -delta)
                    operating.add(new FlowRow("operating",
                            m.name + " (depreciation/amortization or asset movement)", -delta));
                case "working-capital" ->
                    // receivables/inventory/prepayments up = cash out
                    operating.add(new FlowRow("operating",
                            m.name + " (working capital)", -delta));
                case "operating-liability" ->
                    // payables up (credit movement) = cash retained
                    operating.add(new FlowRow("operating",
                            m.name + " (payable/accrued)", -delta));
                case "investing" ->
                    investing.add(new FlowRow("investing", m.name, -delta));
                case "financing-equity" ->
                    financing.add(new FlowRow("financing", m.name, -delta));
                case "financing-debt" ->
                    financing.add(new FlowRow("financing", m.name, -delta));
                default -> {
                    // revenue/expense/drawing movement: already inside net
                    // income (revenues and expenses) or a financing item
                    // (dividends declared)
                    if (m.type == AccountType.EQUITY && m.debit > 0) {
                        financing.add(new FlowRow("financing", m.name + " (dividends)", -delta));
                    }
                    // revenue/expense accounts: no row — net income covers them
                }
            }
        }

        long operatingTotal = operating.stream().mapToLong(FlowRow::amountCents).sum();
        long investingTotal = investing.stream().mapToLong(FlowRow::amountCents).sum();
        long financingTotal = financing.stream().mapToLong(FlowRow::amountCents).sum();
        long netMovement = operatingTotal + investingTotal + financingTotal;

        long[] cashBounds = cashBounds(period);
        return new CashFlowStatement(period, client, income.netIncome(),
                List.copyOf(operating), List.copyOf(investing), List.copyOf(financing),
                operatingTotal, investingTotal, financingTotal,
                netMovement, cashBounds[0], cashBounds[1]);
    }

    // ------------------------------------------------------------------
    // internals
    // ------------------------------------------------------------------

    /** One account's posted movement in the period. */
    private record Movement(String code, String name, AccountType type, boolean contraAsset,
                            boolean cash, long debit, long credit) {

        /**
         * Classification bucket for the statement. Chart-code aware: the
         * 1xxx block decides — 11xx receivables, 12xx inventory, 13xx
         * prepayments and 1150 advances are working capital; 14xx-17xx
         * (investments, PP&E, intangibles) are investing activity.
         */
        String classify() {
            if (cash) {
                return "cash";
            }
            if (contraAsset) {
                return "noncash-asset";
            }
            return switch (type) {
                case ASSET -> {
                    if (code != null) {
                        if (code.startsWith("11") || code.startsWith("12")
                                || code.startsWith("130")) {
                            yield "working-capital";
                        }
                        // 14xx+ : investments, PP&E, intangibles
                        if (code.compareTo("1400") >= 0) {
                            yield "investing";
                        }
                        // 1000-1099 cash handled above; anything else in 1xxx
                        // defaults to working capital (bank charges etc.)
                    }
                    yield "working-capital";
                }
                case LIABILITY -> "operating-liability";
                case EQUITY -> "financing-equity";
                case REVENUE, EXPENSE -> "income";
            };
        }
    }

    private List<Movement> movements(long periodId) {
        String sql = "SELECT a.code, a.name, a.type, a.normal_side, a.id,"
                + " COALESCE(SUM(l.debit_cents), 0) AS dr, COALESCE(SUM(l.credit_cents), 0) AS cr"
                + " FROM journal_entries e"
                + " JOIN journal_lines l ON l.entry_id = e.id"
                + " JOIN accounts a ON a.id = l.account_id"
                + " WHERE e.period_id = ? AND e.posted = 1"
                + " GROUP BY a.id ORDER BY a.code";
        List<Movement> result = new ArrayList<>();
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, periodId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String code = rs.getString("code");
                    String name = rs.getString("name");
                    AccountType type = AccountType.parse(rs.getString("type"));
                    boolean contraAsset = "ASSET".equals(rs.getString("type"))
                            && "CREDIT".equals(rs.getString("normal_side"));
                    boolean cash = isCashAccount(code, name);
                    result.add(new Movement(code, name, type, contraAsset, cash,
                            rs.getLong("dr"), rs.getLong("cr")));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read period movements", e);
        }
        return result;
    }

    /** Cash accounts: the chart's 1000/1010/1020 family (code prefix rule). */
    private static boolean isCashAccount(String code, String name) {
        if (code == null) {
            return false;
        }
        return code.startsWith("100") || code.startsWith("101") || code.startsWith("102")
                || name.toLowerCase().contains("cash");
    }

    /**
     * The cash accounts' opening and closing balances for the period: the
     * ledger_balances opening_cents (carried from the prior period) plus
     * this period's movement, per cash account, summed.
     */
    private long[] cashBounds(Period period) {
        String sql = "SELECT COALESCE(b.opening_cents, 0) AS opening,"
                + " COALESCE(b.regular_dr, 0) + COALESCE(b.adjusting_dr, 0)"
                + " + COALESCE(b.regular_cr, 0) + COALESCE(b.adjusting_cr, 0)"
                + " FROM ledger_balances b"
                + " JOIN accounts a ON a.id = b.account_id"
                + " WHERE b.period_id = ? AND (a.code LIKE '10%' OR lower(a.name) LIKE '%cash%')";
        // careful: dr/cr are separate columns; do it properly:
        sql = "SELECT COALESCE(b.opening_cents, 0) AS opening,"
                + " COALESCE(b.regular_dr, 0) AS regdr, COALESCE(b.regular_cr, 0) AS regcr,"
                + " COALESCE(b.adjusting_dr, 0) AS adjdr, COALESCE(b.adjusting_cr, 0) AS adjcr"
                + " FROM ledger_balances b"
                + " JOIN accounts a ON a.id = b.account_id"
                + " WHERE b.period_id = ? AND (a.code LIKE '10%' OR lower(a.name) LIKE '%cash%')";
        long opening = 0;
        long closing = 0;
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, period.id());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long open = rs.getLong("opening");
                    long move = rs.getLong("regdr") - rs.getLong("regcr")
                            + rs.getLong("adjdr") - rs.getLong("adjcr");
                    opening += open;
                    closing += open + move;
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read cash bounds", e);
        }
        return new long[]{opening, closing};
    }

    private Period period(long periodId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, client_id, name, start_date, end_date, status, closed_at,"
                             + " locked_at FROM periods WHERE id = ?")) {
            ps.setLong(1, periodId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new NoSuchElementException("no period with id " + periodId);
                }
                return new Period(rs.getLong("id"), rs.getLong("client_id"),
                        rs.getString("name"),
                        java.time.LocalDate.parse(rs.getString("start_date")),
                        java.time.LocalDate.parse(rs.getString("end_date")),
                        "CLOSED".equals(rs.getString("status")),
                        rs.getString("closed_at"), rs.getString("locked_at"));
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read period " + periodId, e);
        }
    }

    private Client client(long clientId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, code, name, base_currency, tax_id, is_setup, active,"
                             + " created_at FROM clients WHERE id = ?")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new NoSuchElementException("no client with id " + clientId);
                }
                return new Client(rs.getLong("id"), rs.getString("code"),
                        rs.getString("name"), rs.getString("base_currency"),
                        rs.getString("tax_id"), rs.getInt("is_setup") == 1,
                        rs.getInt("active") == 1, rs.getString("created_at"));
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read client " + clientId, e);
        }
    }
}
