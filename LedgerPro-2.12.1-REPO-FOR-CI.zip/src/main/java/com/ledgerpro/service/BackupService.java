package com.ledgerpro.service;

import com.ledgerpro.db.Database;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.Statement;

/**
 * One-click backup and restore of the working database (2.12.0).
 *
 * <p>Backup uses SQLite's own online-backup path — {@code VACUUM INTO} —
 * which produces a compacted, consistent snapshot of a LIVE database
 * (safe under WAL, no read-lock juggling, no schema change). Restore
 * copies the chosen file over the current one <b>while the app holds no
 * open transaction</b>, then re-migrates so a backup from an older
 * LedgerPro version comes up to the current schema automatically.</p>
 *
 * <p>The default backup location is {@code ~/.ledgerpro/backups/} with a
 * timestamped name, so the one-click flow needs no file chooser at all.</p>
 */
public final class BackupService {

    private final Database database;

    public BackupService(Database database) {
        this.database = database;
    }

    /** The default backup folder: ~/.ledgerpro/backups. */
    public static Path defaultBackupFolder() {
        return Path.of(System.getProperty("user.home"), ".ledgerpro", "backups");
    }

    /**
     * Writes a consistent snapshot to {@code target} and returns it.
     *
     * @throws IllegalStateException the snapshot could not be written
     */
    public Path backupTo(Path target) {
        try {
            Files.createDirectories(target.toAbsolutePath().getParent());
            Files.deleteIfExists(target);   // VACUUM INTO refuses to overwrite
            try (Connection con = database.open();
                 Statement st = con.createStatement()) {
                st.executeUpdate("VACUUM INTO '" + target.toString().replace("'", "''") + "'");
            }
            return target;
        } catch (Exception e) {
            throw new IllegalStateException(
                    "backup failed: " + e.getMessage(), e);
        }
    }

    /**
     * A timestamped one-click backup in the default folder:
     * ledgerpro-backup-2026-11-24-1530.db.
     */
    public Path backupNow() {
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        String stamp = String.format(java.util.Locale.ROOT, "%4d-%02d-%02d-%02d%02d",
                now.getYear(), now.getMonthValue(), now.getDayOfMonth(),
                now.getHour(), now.getMinute());
        return backupTo(defaultBackupFolder()
                .resolve("ledgerpro-backup-" + stamp + ".db"));
    }

    /**
     * Restores the database from {@code source}: copies it over the live
     * file (the caller then re-opens / re-migrates).
     *
     * @throws IllegalStateException the copy or the verification failed
     */
    public void restoreFrom(Path source) {
        if (source == null || !Files.isRegularFile(source)) {
            throw new IllegalStateException("no backup file to restore");
        }
        Path live = Path.of(database.filePath());
        try {
            // verify the backup is a readable SQLite database BEFORE we
            // touch the live file: header + one query
            try (Connection check = java.sql.DriverManager.getConnection(
                    "jdbc:sqlite:" + source.toAbsolutePath())) {
                try (Statement st = check.createStatement()) {
                    st.executeQuery("SELECT 1 FROM sqlite_master LIMIT 1").close();
                }
            }
            Files.createDirectories(live.toAbsolutePath().getParent());
            Files.copy(source, live, StandardCopyOption.REPLACE_EXISTING);
            database.migrate();
        } catch (Exception e) {
            throw new IllegalStateException(
                    "restore failed: " + e.getMessage(), e);
        }
    }
}
