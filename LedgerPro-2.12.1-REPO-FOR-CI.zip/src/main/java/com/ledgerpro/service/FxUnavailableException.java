package com.ledgerpro.service;

/**
 * Thrown when a live FX rate could not be fetched — network down, timeout,
 * or the Frankfurter API rejecting the date/currency pair (e.g. a currency
 * the ECB reference set does not cover, or a weekend/holiday date).
 *
 * <p>Carried as its own type so the UI can react precisely: offer the cached
 * fallback (if any) or a manual rate entry instead of a raw IO error.</p>
 */
public class FxUnavailableException extends IllegalStateException {

    public FxUnavailableException(String message) {
        super(message);
    }

    public FxUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }
}
