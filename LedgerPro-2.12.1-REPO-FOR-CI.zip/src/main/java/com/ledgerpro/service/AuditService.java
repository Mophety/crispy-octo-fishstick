package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.AuditEntry;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Read access to the {@code audit_log}: the trail of every mutation the
 * firm ever made, newest first. Since migration V4 each row carries the
 * structured entity it touched, so the Audit view can say WHAT and WHO
 * without parsing the free-text detail.
 *
 * <p>Read-only by design: audit rows are written only inside the mutating
 * transactions of the other services (and {@link Audit}), never after the
 * fact, never editable — an audit trail that can be edited is a diary.</p>
 */
public final class AuditService {

    private final Database database;

    public AuditService(Database database) {
        this.database = database;
    }

    /**
     * The most recent audit rows. {@code clientId} null = the whole firm
     * (including firm-wide actions like FX-rate fetches).
     */
    public List<AuditEntry> list(Long clientId, int limit) {
        String sql = "SELECT id, client_id, period_id, action, entity_type, entity_id,"
                + " detail, actor, at FROM audit_log"
                + (clientId == null ? "" : " WHERE client_id = ?")
                + " ORDER BY id DESC LIMIT ?";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            int next = 1;
            if (clientId != null) {
                ps.setLong(next++, clientId);
            }
            ps.setInt(next, limit);
            try (ResultSet rs = ps.executeQuery()) {
                List<AuditEntry> result = new ArrayList<>();
                while (rs.next()) {
                    result.add(new AuditEntry(
                            rs.getLong("id"),
                            rs.getObject("client_id") == null ? null : rs.getLong("client_id"),
                            rs.getObject("period_id") == null ? null : rs.getLong("period_id"),
                            rs.getString("action"),
                            rs.getString("entity_type"),
                            rs.getObject("entity_id") == null ? null : rs.getLong("entity_id"),
                            rs.getString("detail"),
                            rs.getString("actor"),
                            rs.getString("at")));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list audit entries", e);
        }
    }
}
