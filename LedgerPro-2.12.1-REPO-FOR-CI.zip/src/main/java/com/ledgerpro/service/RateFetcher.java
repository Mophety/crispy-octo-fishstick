package com.ledgerpro.service;

import java.time.LocalDate;

/**
 * One live FX quote from the outside world, decoupled from storage so tests
 * can inject deterministic rates without touching the network.
 */
public interface RateFetcher {

    /**
     * A fetched quote. {@code date} is the <b>effective</b> date the provider
     * used — for a weekend/holiday request the ECB reference set answers with
     * the previous trading day, and the cache must be truthful about that.
     */
    record Result(LocalDate date, double rate) {}

    /**
     * Fetches how many {@code to} units one {@code from} unit is worth on the
     * given date (or the nearest earlier trading day the provider has).
     *
     * @throws Exception anything the transport or the provider wants to say;
     *                   {@link FxRateService} wraps it into
     *                   {@link FxUnavailableException}
     */
    Result fetch(LocalDate date, String from, String to) throws Exception;
}
