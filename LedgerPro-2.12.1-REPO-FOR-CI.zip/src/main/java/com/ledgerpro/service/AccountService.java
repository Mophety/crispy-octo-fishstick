package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Side;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;

/**
 * All reading and writing of the {@code accounts} table goes through here —
 * one chart of accounts per client.
 *
 * <p>Rules this service guarantees (so the UI never has to think about them):</p>
 * <ul>
 *   <li><b>Never delete.</b> Deactivating sets {@code active = 0}; journal
 *       lines and the audit trail keep pointing at the account.</li>
 *   <li><b>Every mutation is one transaction</b> that also writes an
 *       {@code audit_log} row.</li>
 *   <li><b>Codes are normalized</b> to trimmed uppercase and validated before
 *       they reach SQLite; the per-client UNIQUE constraint is the backstop,
 *       this class is the front line.</li>
 *   <li><b>Structure freezes once posting begins.</b> An account that already
 *       carries journal lines may be renamed, but its code, type and normal
 *       side can no longer change — history must never be re-classified
 *       underneath. {@link #hasJournalLines(long)} lets the dialog disable
 *       those fields before the user even tries.</li>
 * </ul>
 */
public final class AccountService {

    private static final int MAX_CODE_LENGTH = 12;
    private static final int MAX_NAME_LENGTH = 200;

    private final Database database;

    public AccountService(Database database) {
        this.database = database;
    }

    // ------------------------------------------------------------------
    // Queries
    // ------------------------------------------------------------------

    /**
     * Lists the client's accounts ordered by code (lexicographic — standard
     * charts use uniform-width codes, so this reads naturally).
     *
     * @param includeInactive false = only active accounts (what the journal
     *                         pickers of Phase 4 will offer); true = all
     */
    public List<Account> list(long clientId, boolean includeInactive) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, client_id, code, name, type, normal_side, is_permanent, is_retained_earnings, parent_id, active"
                             + " FROM accounts WHERE client_id = ?"
                             + (includeInactive ? "" : " AND active = 1")
                             + " ORDER BY code")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Account> result = new ArrayList<>();
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list accounts", e);
        }
    }

    /** Looks an account up by code within the client's chart (case-insensitive). */
    public Optional<Account> findByCode(long clientId, String code) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, client_id, code, name, type, normal_side, is_permanent, is_retained_earnings, parent_id, active"
                             + " FROM accounts WHERE client_id = ? AND code = ?")) {
            ps.setLong(1, clientId);
            ps.setString(2, normalizeCode(code));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to look up account", e);
        }
    }

    /** True once any journal line references the account (posting has begun). */
    public boolean hasJournalLines(long accountId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT EXISTS(SELECT 1 FROM journal_lines WHERE account_id = ?)")) {
            ps.setLong(1, accountId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getBoolean(1);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to check journal lines", e);
        }
    }

    // ------------------------------------------------------------------
    // Mutations (transactional, audited)
    // ------------------------------------------------------------------

    /**
     * Creates an account in the client's chart and returns the stored row.
     *
     * @throws IllegalArgumentException        blank/malformed code or name,
     *                                         null type or side
     * @throws NoSuchElementException          no client with this id
     * @throws DuplicateAccountCodeException   the code is already in this chart
     */
    public Account create(long clientId, String code, String name,
                          AccountType type, Side normalSide) {
        String validCode = normalizeCode(code);
        String validName = normalizeName(name);
        requireType(type);
        requireSide(normalSide);

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                requireClient(con, clientId);
                long id;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO accounts(client_id, code, name, type, normal_side,"
                                + " is_permanent, is_retained_earnings)"
                                + " VALUES (?, ?, ?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setLong(1, clientId);
                    ps.setString(2, validCode);
                    ps.setString(3, validName);
                    ps.setString(4, type.name());
                    ps.setString(5, normalSide.name());
                    ps.setInt(6, type.isPermanent() ? 1 : 0);
                    ps.setInt(7, isRetainedEarningsName(validName) ? 1 : 0);
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new IllegalStateException("SQLite returned no generated key");
                        }
                        id = keys.getLong(1);
                    }
                }
                Audit.write(con, clientId, null, "CREATE_ACCOUNT", "ACCOUNT", id,
                        "id=%d code='%s' name='%s' type=%s side=%s".formatted(
                                id, validCode, validName, type, normalSide));
                con.commit();
                return read(con, id)
                        .orElseThrow(() -> new IllegalStateException("account vanished after insert"));

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof SQLException sx && isUniqueViolation(sx)) {
                    throw new DuplicateAccountCodeException(validCode);
                }
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to create account", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to create account", e);
        }
    }

    /**
     * Updates an account. Renaming is always allowed; changing code, type or
     * normal side is refused once the account carries journal lines.
     *
     * @throws NoSuchElementException        no account with this id
     * @throws DuplicateAccountCodeException the new code is already in the chart
     * @throws AccountFrozenException        structural change on a posted account
     */
    public Account update(long id, String code, String name,
                          AccountType type, Side normalSide) {
        String validCode = normalizeCode(code);
        String validName = normalizeName(name);
        requireType(type);
        requireSide(normalSide);

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Account current = read(con, id)
                        .orElseThrow(() -> new NoSuchElementException("no account with id " + id));

                boolean structuralChange = !current.code().equals(validCode)
                        || current.type() != type
                        || current.normalSide() != normalSide;
                if (structuralChange && hasJournalLines(con, id)) {
                    throw new AccountFrozenException(current.code());
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET code = ?, name = ?, type = ?, normal_side = ?,"
                                + " is_permanent = ?, is_retained_earnings = ?"
                                + " WHERE id = ?")) {
                    ps.setString(1, validCode);
                    ps.setString(2, validName);
                    ps.setString(3, type.name());
                    ps.setString(4, normalSide.name());
                    ps.setInt(5, type.isPermanent() ? 1 : 0);
                    ps.setInt(6, isRetainedEarningsName(validName) ? 1 : 0);
                    ps.setLong(7, id);
                    ps.executeUpdate();
                }
                Audit.write(con, current.clientId(), null, "UPDATE_ACCOUNT", "ACCOUNT", id,
                        "id=%d code='%s' name='%s' type=%s side=%s (was code='%s' name='%s'"
                                + " type=%s side=%s)".formatted(id, validCode, validName, type,
                                normalSide, current.code(), current.name(),
                                current.type(), current.normalSide()));
                con.commit();
                return read(con, id)
                        .orElseThrow(() -> new IllegalStateException("account vanished after update"));

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof SQLException sx && isUniqueViolation(sx)) {
                    throw new DuplicateAccountCodeException(validCode);
                }
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to update account", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to update account", e);
        }
    }

    /**
     * Deactivates ({@code active = false}) or restores an account. Deactivated
     * accounts keep their history and drop out of Phase-4 pickers.
     *
     * @throws NoSuchElementException no account with this id
     */
    public void setActive(long id, boolean active) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Account current = read(con, id)
                        .orElseThrow(() -> new NoSuchElementException("no account with id " + id));
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET active = ? WHERE id = ?")) {
                    ps.setInt(1, active ? 1 : 0);
                    ps.setLong(2, id);
                    ps.executeUpdate();
                }
                Audit.write(con, current.clientId(), null,
                        active ? "RESTORE_ACCOUNT" : "DEACTIVATE_ACCOUNT", "ACCOUNT", id,
                        "id=%d code='%s'".formatted(id, current.code()));
                con.commit();

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to update account", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to update account", e);
        }
    }

    /**
     * Applies the firm's {@link StandardChart} to the client's chart — the
     * same as {@link #applyChartTemplate(long, ChartTemplates.Definition)}
     * with the STANDARD preset. Kept because Phase-3 flows and tests use it
     * by name.
     *
     * @return how many accounts were inserted
     * @throws NoSuchElementException no client with this id
     */
    public int applyStandardChart(long clientId) {
        return applyChartTemplate(clientId,
                ChartTemplates.byCode("STANDARD").orElseThrow());
    }

    /**
     * Applies any preset chart ({@link ChartTemplates}) to the client's
     * chart: inserts every template account whose code is not yet present,
     * leaves existing rows untouched. Idempotent — running it twice inserts
     * nothing the second time. The whole batch is one transaction with one
     * audit row.
     *
     * @return how many accounts were inserted
     * @throws NoSuchElementException   no client with this id
     * @throws IllegalArgumentException the definition is null
     */
    public int applyChartTemplate(long clientId, ChartTemplates.Definition template) {
        if (template == null) {
            throw new IllegalArgumentException("chart template must be selected");
        }
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                requireClient(con, clientId);

                Set<String> existing = new HashSet<>();
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT code FROM accounts WHERE client_id = ?")) {
                    ps.setLong(1, clientId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            existing.add(rs.getString(1));
                        }
                    }
                }

                int inserted = 0;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO accounts(client_id, code, name, type, normal_side,"
                                + " is_permanent, is_retained_earnings)"
                                + " VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                    for (StandardChart.Row row : template.rows()) {
                        if (existing.contains(row.code())) {
                            continue;
                        }
                        ps.setLong(1, clientId);
                        ps.setString(2, row.code());
                        ps.setString(3, row.name());
                        ps.setString(4, row.type().name());
                        ps.setString(5, row.side().name());
                        ps.setInt(6, row.type().isPermanent() ? 1 : 0);
                        ps.setInt(7, isRetainedEarningsName(row.name()) ? 1 : 0);
                        ps.executeUpdate();
                        inserted++;
                    }
                }
                Audit.write(con, clientId, null, "APPLY_COA_TEMPLATE", "CLIENT", clientId,
                        "template=%s inserted=%d skipped_existing=%d template_size=%d".formatted(
                                template.code(), inserted,
                                template.size() - inserted, template.size()));
                con.commit();
                return inserted;

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to apply chart template", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to apply chart template", e);
        }
    }

    // ------------------------------------------------------------------
    // Validation / normalization helpers
    // ------------------------------------------------------------------

    /** Codes: trimmed, uppercase, 1-12 chars of A-Z, 0-9 or '-'. */
    private static String normalizeCode(String raw) {
        String code = raw == null ? "" : raw.trim().toUpperCase();
        if (code.isEmpty()) {
            throw new IllegalArgumentException("account code must not be blank");
        }
        if (code.length() > MAX_CODE_LENGTH) {
            throw new IllegalArgumentException(
                    "account code must be at most " + MAX_CODE_LENGTH + " characters");
        }
        if (!code.matches("[A-Z0-9-]+")) {
            throw new IllegalArgumentException(
                    "account code may only contain letters, digits and '-'");
        }
        return code;
    }

    /** Names: trimmed, 1-200 chars. */
    private static String normalizeName(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (name.isEmpty()) {
            throw new IllegalArgumentException("account name must not be blank");
        }
        if (name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException(
                    "account name must be at most " + MAX_NAME_LENGTH + " characters");
        }
        return name;
    }

    private static void requireType(AccountType type) {
        if (type == null) {
            throw new IllegalArgumentException("account type must be selected");
        }
    }

    private static void requireSide(Side side) {
        if (side == null) {
            throw new IllegalArgumentException("normal side must be selected");
        }
    }

    // ------------------------------------------------------------------
    // Row plumbing
    // ------------------------------------------------------------------

    private static Account mapRow(ResultSet rs) throws SQLException {
        return new Account(
                rs.getLong("id"),
                rs.getLong("client_id"),
                rs.getString("code"),
                rs.getString("name"),
                AccountType.parse(rs.getString("type")),
                Side.parse(rs.getString("normal_side")),
                rs.getInt("is_permanent") == 1,
                rs.getInt("is_retained_earnings") == 1,
                rs.getObject("parent_id") == null ? null : rs.getLong("parent_id"),
                rs.getInt("active") == 1);
    }

    private static Optional<Account> read(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, client_id, code, name, type, normal_side, is_permanent, is_retained_earnings, parent_id, active"
                        + " FROM accounts WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        }
    }

    /** Overload used inside an already-open transaction. */
    private static boolean hasJournalLines(Connection con, long accountId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT EXISTS(SELECT 1 FROM journal_lines WHERE account_id = ?)")) {
            ps.setLong(1, accountId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getBoolean(1);
            }
        }
    }

    private static void requireClient(Connection con, long clientId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT EXISTS(SELECT 1 FROM clients WHERE id = ?)")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next() || !rs.getBoolean(1)) {
                    throw new NoSuchElementException("no client with id " + clientId);
                }
            }
        }
    }

    /** The name closing entries sweep net income into — best-effort detection. */
    private static boolean isRetainedEarningsName(String name) {
        return name != null && name.toLowerCase().contains("retained earnings");
    }

    /** SQLite signals the per-client UNIQUE breach through the message text. */
    private static boolean isUniqueViolation(SQLException e) {
        String message = e.getMessage();
        return message != null
                && message.contains("UNIQUE constraint failed")
                && message.contains("accounts.client_id");
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // rollback failed: the connection is being closed right after anyway
        }
    }
}
