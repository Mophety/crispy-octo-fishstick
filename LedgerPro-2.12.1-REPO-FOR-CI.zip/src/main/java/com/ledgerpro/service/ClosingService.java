package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.model.Side;
import com.ledgerpro.model.TbStage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * The 2.7.0 closing workflow — the piece the 2.6.0 audit flagged as the
 * cycle's functional gap: the schema knew about CLOSING entries (type,
 * post-closing stage, worksheet columns) but nothing produced them, so the
 * post-closing trial balance was unreachable in practice.
 *
 * <p>The service follows the classic four-step process (Principles of
 * Accounting, Ch. 4):</p>
 * <ol>
 *   <li>every REVENUE account's balance is zeroed into Income Summary;</li>
 *   <li>every EXPENSE account's balance is zeroed into Income Summary;</li>
 *   <li>Income Summary's net is closed into Retained Earnings;</li>
 *   <li>dividends/drawings (equity contra with a debit balance) are closed
 *       into Retained Earnings.</li>
 * </ol>
 *
 * <p><b>The generator never posts.</b> It creates a DRAFT closing set —
 * one CLOSING draft entry per step group — that the accountant reviews in
 * the journal and posts deliberately, exactly like every other entry. A
 * period with an existing draft closing set refuses a second generation
 * until those drafts are posted or voided, so the close stays one deliberate
 * pass.</p>
 *
 * <p>Income Summary: created on demand (EQUITY, credit side, code 3901,
 * marked non-permanent by type? no — it IS temporary: the account itself is
 * a transient clearing account, so it is created as EQUITY/credit and zeroes
 * itself out in step 3; the {@code is_permanent} flag follows the EQUITY
 * type, which the schema's own convention does for equity accounts; the
 * closing entries zero it anyway). Retained Earnings is the client's
 * {@code is_retained_earnings} account; every shipped chart template marks
 * one ("Retained Earnings", 3200). Dividend accounts are EQUITY-type
 * accounts with a DEBIT normal side (3900 "Dividends Declared" in the
 * STANDARD chart).</p>
 */
public final class ClosingService {

    /** The Income Summary chart code the generator ensures exists. */
    public static final String INCOME_SUMMARY_CODE = "3901";
    /** The Income Summary account name. */
    public static final String INCOME_SUMMARY_NAME = "Income Summary";

    private final Database database;
    private final JournalService journalService;
    private final AccountService accountService;

    public ClosingService(Database database, JournalService journalService,
                          AccountService accountService) {
        this.database = database;
        this.journalService = journalService;
        this.accountService = accountService;
    }

    // ------------------------------------------------------------------
    // The close checklist
    // ------------------------------------------------------------------

    /** One checklist row: what it checks, whether it blocks, and the answer. */
    public record CheckItem(String key, String label, boolean blocking,
                            boolean ok, String detail) {
    }

    /**
     * The pre-close checklist the Close wizard walks: unposted drafts block
     * (they would vanish from a closed period's reports), the unbalanced
     * adjusted trial balance blocks (closing would bake the error in), and
     * the informational rows (no entries at all, closing drafts already
     * present) shape the next button rather than block it.
     */
    public List<CheckItem> closeChecklist(long periodId) {
        Period period = period(periodId);
        List<CheckItem> items = new ArrayList<>();

        long drafts = countDrafts(period);
        items.add(new CheckItem("drafts", "All entries posted", true,
                drafts == 0,
                drafts == 0 ? "no draft entries in the period"
                        : drafts + " draft entries waiting to be posted"));

        JournalService.TrialBalance adjusted =
                journalService.trialBalance(periodId, TbStage.ADJUSTED);
        boolean balanced = adjusted.balanced();
        items.add(new CheckItem("balanced", "Adjusted trial balance balanced", true,
                balanced,
                balanced ? "debit total equals credit total"
                        : "debits exceed credits by "
                                + Math.abs(adjusted.totalDebitCents() - adjusted.totalCreditCents())
                                + " cents (or vice versa)"));

        boolean hasClosingDrafts = hasDraftClosingEntries(period);
        items.add(new CheckItem("closing-drafts", "No pending closing set", true,
                !hasClosingDrafts,
                hasClosingDrafts
                        ? "closing drafts exist — post or void them before regenerating"
                        : "no closing entries drafted yet"));

        long postedLines = countPostedLines(period);
        items.add(new CheckItem("activity", "Period has activity", false,
                postedLines > 0,
                postedLines > 0 ? postedLines + " posted lines in the period"
                        : "the period holds no posted entries — closing would be a no-op"));

        boolean alreadyClosed = period.closed();
        items.add(new CheckItem("open", "Period still open", true,
                !alreadyClosed,
                alreadyClosed ? "the period is closed already" : "period is open"));

        return List.copyOf(items);
    }

    // ------------------------------------------------------------------
    // The generator
    // ------------------------------------------------------------------

    /** The generated set, as the journal will show it. */
    public record ClosingSet(Period period, Account incomeSummary, Account retainedEarnings,
                             List<JournalService.EntrySummary> entries,
                             long netIncomeCents) {

        /** True when the period needed no closing lines (nothing temporary). */
        public boolean empty() {
            return entries.isEmpty();
        }
    }

    /**
     * Generates the closing entry drafts for a period. Refuses when the
     * checklist's blocking items fail (unposted drafts, unbalanced TB, a
     * pending closing set, closed period).
     *
     * @throws IllegalStateException a blocking checklist item failed
     */
    public ClosingSet generateClosingDrafts(long periodId) {
        for (CheckItem item : closeChecklist(periodId)) {
            if (item.blocking() && !item.ok()) {
                throw new IllegalStateException("close blocked — " + item.label()
                        + ": " + item.detail());
            }
        }
        Period period = period(periodId);
        Client client = client(period.clientId());

        Account incomeSummary = ensureIncomeSummary(client.id());
        Account retained = retainedEarnings(client.id())
                .orElseGet(() -> {
                    throw new IllegalStateException("client '" + client.code()
                            + "' has no Retained Earnings account (flag the account"
                            + " in Chart of Accounts first)");
                });

        // the adjusted trial balance is the input to closing
        JournalService.TrialBalance tb = journalService.trialBalance(periodId, TbStage.ADJUSTED);
        List<JournalService.TrialBalanceRow> rows = tb.rows();

        long revenues = 0;
        long expenses = 0;
        List<JournalService.NewLine> revenueLines = new ArrayList<>();
        List<JournalService.NewLine> expenseLines = new ArrayList<>();
        List<JournalService.NewLine> dividendLines = new ArrayList<>();

        for (JournalService.TrialBalanceRow row : rows) {
            Account account = row.account();
            if (account.isRetainedEarnings()) {
                continue;   // the target, never a source
            }
            long net = row.debitCents() - row.creditCents();   // + = debit balance
            if (net == 0) {
                continue;
            }
            AccountType type = account.type();
            if (type == AccountType.REVENUE) {
                // credit balance (negative net): debit the revenue, credit IS
                revenues += -net;
                revenueLines.add(new JournalService.NewLine(account.id(),
                        -net, null, "close " + account.code() + " — " + account.name()));
            } else if (type == AccountType.EXPENSE) {
                // debit balance: credit the expense, debit IS
                expenses += net;
                expenseLines.add(new JournalService.NewLine(account.id(),
                        null, net, "close " + account.code() + " — " + account.name()));
            } else if (type == AccountType.EQUITY && account.normalSide() == Side.DEBIT
                    && !account.code().equals(INCOME_SUMMARY_CODE)) {
                // dividends/drawings contra equity: credit it, debit RE
                dividendLines.add(new JournalService.NewLine(account.id(),
                        null, net, "close " + account.code() + " — " + account.name()));
            }
        }

        long netIncome = revenues - expenses;
        LocalDate closeDate = period.end();

        List<JournalService.EntrySummary> created = new ArrayList<>();
        if (!revenueLines.isEmpty()) {
            List<JournalService.NewLine> lines = new ArrayList<>(revenueLines);
            lines.add(new JournalService.NewLine(incomeSummary.id(), null, revenues,
                    "revenues closed to Income Summary"));
            created.add(draft(period, client, closeDate, "Close revenues to Income Summary",
                    lines));
        }
        if (!expenseLines.isEmpty()) {
            List<JournalService.NewLine> lines = new ArrayList<>(expenseLines);
            lines.add(new JournalService.NewLine(incomeSummary.id(), expenses, null,
                    "expenses closed to Income Summary"));
            created.add(draft(period, client, closeDate, "Close expenses to Income Summary",
                    lines));
        }
        // step 3: Income Summary's net to Retained Earnings — BOTH sides of
        // the transfer on one entry (the journal requires >= 2 lines, which
        // is also how the paper close writes it)
        if (netIncome != 0) {
            List<JournalService.NewLine> sweep = new ArrayList<>();
            if (netIncome > 0) {
                sweep.add(new JournalService.NewLine(incomeSummary.id(), null, netIncome,
                        "Income Summary net income"));
                sweep.add(new JournalService.NewLine(retained.id(), netIncome, null,
                        "net income to Retained Earnings"));
            } else {
                sweep.add(new JournalService.NewLine(incomeSummary.id(), -netIncome, null,
                        "Income Summary net loss"));
                sweep.add(new JournalService.NewLine(retained.id(), null, -netIncome,
                        "net loss to Retained Earnings"));
            }
            created.add(draft(period, client, closeDate,
                    netIncome > 0 ? "Close Income Summary (net income) to Retained Earnings"
                            : "Close Income Summary (net loss) to Retained Earnings",
                    sweep));
        }
        // step 4: dividends to Retained Earnings
        if (!dividendLines.isEmpty()) {
            long totalDividends = dividendLines.stream()
                    .mapToLong(JournalService.NewLine::amount).sum();
            List<JournalService.NewLine> lines = new ArrayList<>(dividendLines);
            lines.add(new JournalService.NewLine(retained.id(), totalDividends, null,
                    "dividends closed to Retained Earnings"));
            created.add(draft(period, client, closeDate,
                    "Close dividends to Retained Earnings", lines));
        }

        return new ClosingSet(period, incomeSummary, retained, List.copyOf(created), netIncome);
    }

    // ------------------------------------------------------------------
    // The full close (wizard's last button)
    // ------------------------------------------------------------------

    /**
     * Convenience for the wizard: generates the drafts AND posts them in one
     * audited pass, returning the set that was posted. The drafts still
     * exist as journal entries first — posting is the normal {@link
     * JournalService#post(long)} path, so a failure mid-set leaves drafts,
     * never half-facts.
     */
    public ClosingSet generateAndPost(long periodId) {
        ClosingSet set = generateClosingDrafts(periodId);
        for (JournalService.EntrySummary summary : set.entries()) {
            journalService.post(summary.entry().id());
        }
        return set;
    }

    // ------------------------------------------------------------------
    // Reversing entries (the next period's opening)
    // ------------------------------------------------------------------

    /** One candidate for reversal: the adjusting entry and its date. */
    public record ReversalCandidate(JournalService.EntrySummary entry, LocalDate date,
                                     String memo) {
    }

    /**
     * Lists the period's posted ADJUSTING entries that reference accrual
     * keywords in their memo (the convention for reversible accruals).
     */
    public List<ReversalCandidate> reversalCandidates(long periodId) {
        Period period = period(periodId);
        String sql = "SELECT e.id FROM journal_entries e"
                + " WHERE e.period_id = ? AND e.posted = 1 AND e.type = 'ADJUSTING'"
                + " AND (lower(e.memo) LIKE '%accrued%'"
                + "      OR lower(e.memo) LIKE '%accrual%')"
                + " ORDER BY e.entry_date, e.id";
        List<ReversalCandidate> candidates = new ArrayList<>();
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, periodId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long id = rs.getLong(1);
                    for (JournalService.EntrySummary summary : journalService.list(
                            period.clientId(), periodId)) {
                        if (summary.entry().id() == id) {
                            candidates.add(new ReversalCandidate(summary,
                                    summary.entry().date(), summary.entry().memo()));
                            break;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list reversal candidates", e);
        }
        period.start();   // the generated reversals date to the NEXT period's start
        return List.copyOf(candidates);
    }

    /**
     * Reverses one posted ADJUSTING entry into {@code targetPeriod} as a
     * REVERSING draft: every line swaps sides, memo records the linkage.
     * Only entries in an open period can be reversed, and only into an open
     * target period.
     */
    public JournalService.EntrySummary reverseInto(long entryId, long targetPeriodId) {
        Period target = period(targetPeriodId);
        if (target.closed()) {
            throw new IllegalStateException("target period '" + target.name()
                    + "' is closed");
        }
        var entry = journalService.find(entryId)
                .orElseThrow(() -> new NoSuchElementException("no entry with id " + entryId));
        if (!entry.posted()) {
            throw new IllegalStateException("only posted entries can be reversed");
        }
        if (entry.type() != EntryType.ADJUSTING) {
            throw new IllegalStateException("reversals are for ADJUSTING entries; this one is "
                    + entry.type());
        }
        Client client = client(entry.clientId());
        List<JournalService.LineRow> lines = journalService.lines(entryId);
        List<JournalService.NewLine> reversed = new ArrayList<>();
        for (JournalService.LineRow row : lines) {
            reversed.add(new JournalService.NewLine(
                    row.account().id(),
                    row.line().creditCents() == null ? null : row.line().creditCents(),
                    row.line().debitCents() == null ? null : row.line().debitCents(),
                    "reverse: " + (row.line().memo() == null ? "adjustment" : row.line().memo())));
        }
        var created = journalService.createDraft(new JournalService.NewEntry(
                client.id(), targetPeriodId, target.start(), EntryType.REVERSING,
                "REV-" + entry.reference(), "reversal of entry #" + entry.entryNo()
                        + (entry.memo() == null ? "" : " — " + entry.memo()),
                null, null, reversed));
        return new JournalService.EntrySummary(created, periodName(targetPeriodId),
                0, 0, false);
    }

    // ------------------------------------------------------------------
    // internals
    // ------------------------------------------------------------------

    private JournalService.EntrySummary draft(Period period, Client client,
                                              LocalDate date, String memo,
                                              List<JournalService.NewLine> lines) {
        var created = journalService.createDraft(new JournalService.NewEntry(
                client.id(), period.id(), date, EntryType.CLOSING, null, memo,
                null, null, lines));
        return new JournalService.EntrySummary(created, period.name(),
                0, 0, false);
    }

    private Account ensureIncomeSummary(long clientId) {
        Optional<Account> existing = accountService.findByCode(clientId, INCOME_SUMMARY_CODE);
        if (existing.isPresent()) {
            return existing.get();
        }
        return accountService.create(clientId, INCOME_SUMMARY_CODE, INCOME_SUMMARY_NAME,
                AccountType.EQUITY, Side.CREDIT);
    }

    private Optional<Account> retainedEarnings(long clientId) {
        return accountService.list(clientId, true).stream()
                .filter(Account::isRetainedEarnings)
                .findFirst();
    }

    private Period period(long periodId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, client_id, name, start_date, end_date, status, closed_at,"
                             + " locked_at FROM periods WHERE id = ?")) {
            ps.setLong(1, periodId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new NoSuchElementException("no period with id " + periodId);
                }
                return mapPeriod(rs);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read period " + periodId, e);
        }
    }

    private Client client(long clientId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, code, name, base_currency, tax_id, is_setup, active,"
                             + " created_at FROM clients WHERE id = ?")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new NoSuchElementException("no client with id " + clientId);
                }
                return new Client(rs.getLong("id"), rs.getString("code"),
                        rs.getString("name"), rs.getString("base_currency"),
                        rs.getString("tax_id"), rs.getInt("is_setup") == 1,
                        rs.getInt("active") == 1, rs.getString("created_at"));
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read client " + clientId, e);
        }
    }

    private boolean hasDraftClosingEntries(Period period) {
        String sql = "SELECT EXISTS(SELECT 1 FROM journal_entries"
                + " WHERE period_id = ? AND posted = 0 AND type = 'CLOSING')";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, period.id());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) == 1;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to check closing drafts", e);
        }
    }

    private long countDrafts(Period period) {
        String sql = "SELECT COUNT(*) FROM journal_entries e"
                + " WHERE e.period_id = ? AND e.posted = 0"
                + " AND NOT EXISTS(SELECT 1 FROM journal_entries v WHERE v.void_of_id = e.id)";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, period.id());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to count drafts", e);
        }
    }

    private long countPostedLines(Period period) {
        String sql = "SELECT COUNT(*) FROM journal_lines l"
                + " JOIN journal_entries e ON e.id = l.entry_id"
                + " WHERE e.period_id = ? AND e.posted = 1";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, period.id());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to count posted lines", e);
        }
    }

    private String periodName(long periodId) {
        return period(periodId).name();
    }

    private static Period mapPeriod(ResultSet rs) throws SQLException {
        return new Period(rs.getLong("id"), rs.getLong("client_id"), rs.getString("name"),
                LocalDate.parse(rs.getString("start_date")),
                LocalDate.parse(rs.getString("end_date")),
                "CLOSED".equals(rs.getString("status")),
                rs.getString("closed_at"), rs.getString("locked_at"));
    }
}
