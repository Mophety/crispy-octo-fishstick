package com.ledgerpro.service;

import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Side;

import java.util.List;

/**
 * The firm's standard chart of accounts — a corporate, Philippine-style
 * starting chart an accountant can apply to any client with one click, then
 * prune and extend.
 *
 * <p>Codes use the classic four-digit blocks: 1xxx assets, 2xxx liabilities,
 * 3xxx equity, 4xxx revenue, 5xxx/6xxx expenses. Contra accounts are part of
 * the standard: 'Allowance for Doubtful Accounts' and both accumulated
 * depreciation/amortization accounts are ASSETs with a CREDIT normal side,
 * 'Treasury Shares' and 'Dividends Declared' are EQUITY with a DEBIT normal
 * side, and the sales-returns/discounts accounts are REVENUE debited.</p>
 *
 * <p>This class is pure data: applying it (idempotently, per client, audited)
 * is {@link AccountService#applyStandardChart(long)}.</p>
 */
public final class StandardChart {

    /** One line of the template. */
    public record Row(String code, String name, AccountType type, Side side) {}

    private static final List<Row> ROWS = List.of(
            // ---- 1xxx ASSETS (debit) --------------------------------------
            row("1000", "Cash on Hand", AccountType.ASSET, Side.DEBIT),
            row("1010", "Cash in Bank — Operating", AccountType.ASSET, Side.DEBIT),
            row("1020", "Petty Cash Fund", AccountType.ASSET, Side.DEBIT),
            row("1100", "Accounts Receivable — Trade", AccountType.ASSET, Side.DEBIT),
            row("1110", "Allowance for Doubtful Accounts", AccountType.ASSET, Side.CREDIT),
            row("1150", "Advances to Employees", AccountType.ASSET, Side.DEBIT),
            row("1200", "Inventory", AccountType.ASSET, Side.DEBIT),
            row("1300", "Prepaid Expenses", AccountType.ASSET, Side.DEBIT),
            row("1400", "Short-term Investments", AccountType.ASSET, Side.DEBIT),
            row("1500", "Property, Plant and Equipment", AccountType.ASSET, Side.DEBIT),
            row("1510", "Accumulated Depreciation — PP&E", AccountType.ASSET, Side.CREDIT),
            row("1600", "Long-term Investments", AccountType.ASSET, Side.DEBIT),
            row("1700", "Intangible Assets", AccountType.ASSET, Side.DEBIT),
            row("1710", "Accumulated Amortization — Intangibles", AccountType.ASSET, Side.CREDIT),

            // ---- 2xxx LIABILITIES (credit) --------------------------------
            row("2000", "Accounts Payable — Trade", AccountType.LIABILITY, Side.CREDIT),
            row("2010", "Accrued Expenses Payable", AccountType.LIABILITY, Side.CREDIT),
            row("2100", "Salaries Payable", AccountType.LIABILITY, Side.CREDIT),
            row("2110", "Withholding Taxes Payable", AccountType.LIABILITY, Side.CREDIT),
            row("2120", "SSS, Pag-IBIG and PhilHealth Contributions Payable",
                    AccountType.LIABILITY, Side.CREDIT),
            row("2130", "VAT Payable", AccountType.LIABILITY, Side.CREDIT),
            row("2140", "Income Tax Payable", AccountType.LIABILITY, Side.CREDIT),
            row("2200", "Notes Payable — Current Portion", AccountType.LIABILITY, Side.CREDIT),
            row("2300", "Long-term Notes Payable", AccountType.LIABILITY, Side.CREDIT),

            // ---- 3xxx EQUITY (credit; 33x0/39x0 are contra) ---------------
            row("3000", "Ordinary Share Capital", AccountType.EQUITY, Side.CREDIT),
            row("3100", "Share Premium", AccountType.EQUITY, Side.CREDIT),
            row("3200", "Retained Earnings", AccountType.EQUITY, Side.CREDIT),
            row("3300", "Treasury Shares", AccountType.EQUITY, Side.DEBIT),
            row("3900", "Dividends Declared", AccountType.EQUITY, Side.DEBIT),

            // ---- 4xxx REVENUE (credit; returns/discounts are contra) ------
            row("4000", "Service Revenue", AccountType.REVENUE, Side.CREDIT),
            row("4010", "Sales — Goods", AccountType.REVENUE, Side.CREDIT),
            row("4020", "Sales Returns and Allowances", AccountType.REVENUE, Side.DEBIT),
            row("4030", "Sales Discounts", AccountType.REVENUE, Side.DEBIT),
            row("4100", "Interest Income", AccountType.REVENUE, Side.CREDIT),
            row("4200", "Foreign Exchange Gain", AccountType.REVENUE, Side.CREDIT),
            row("4300", "Other Income", AccountType.REVENUE, Side.CREDIT),

            // ---- 5xxx/6xxx EXPENSES (debit) --------------------------------
            row("5000", "Cost of Sales", AccountType.EXPENSE, Side.DEBIT),
            row("6000", "Salaries and Wages Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6010", "Employee Benefits Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6100", "Rent Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6110", "Utilities Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6120", "Communication and Internet Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6130", "Repairs and Maintenance Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6140", "Transportation and Travel Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6150", "Supplies Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6160", "Representation and Entertainment Expense",
                    AccountType.EXPENSE, Side.DEBIT),
            row("6200", "Insurance Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6210", "Professional Fees", AccountType.EXPENSE, Side.DEBIT),
            row("6300", "Taxes and Licenses Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6400", "Depreciation Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6410", "Amortization Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6500", "Bad Debts Expense", AccountType.EXPENSE, Side.DEBIT),
            row("6600", "Bank Charges", AccountType.EXPENSE, Side.DEBIT),
            row("6700", "Foreign Exchange Loss", AccountType.EXPENSE, Side.DEBIT),
            row("6800", "Miscellaneous Expense", AccountType.EXPENSE, Side.DEBIT));

    private static Row row(String code, String name, AccountType type, Side side) {
        return new Row(code, name, type, side);
    }

    private StandardChart() {
    }

    /** The full template, in code order. */
    public static List<Row> rows() {
        return ROWS;
    }

    /** Number of template rows (convenience for UI copy: "N standard accounts"). */
    public static int size() {
        return ROWS.size();
    }
}
