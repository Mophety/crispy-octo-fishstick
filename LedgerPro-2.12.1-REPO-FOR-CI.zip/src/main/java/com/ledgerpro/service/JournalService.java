package com.ledgerpro.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.FxRate;
import com.ledgerpro.model.JournalEntry;
import com.ledgerpro.model.JournalLine;
import com.ledgerpro.model.Period;
import com.ledgerpro.model.Side;
import com.ledgerpro.model.TbStage;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.StringJoiner;

/**
 * The journal of Phase 4 — the ONLY writer of {@code journal_entries},
 * {@code journal_lines}, {@code ledger_balances} and {@code tb_snapshots}.
 * All accounting rules of the cycle live here (golden rule 3).
 *
 * <p>Rules this service guarantees:</p>
 * <ul>
 *   <li><b>Debits = credits, always.</b> Enforced on the typed amounts at
 *       creation — even a draft must balance — and guaranteed again in base
 *       currency after FX conversion (see below).</li>
 *   <li><b>Multi-currency entries read the Phase-3 FX cache.</b> The typed
 *       amounts are in the entry's original currency; the rate is resolved
 *       from {@link FxRateService#latestUpTo} and snapshotted onto the entry
 *       (it never silently changes later). The stored <b>lines carry
 *       base-currency cents</b> — converted half-up per line, with the tiny
 *       rounding residual (a cent or two) absorbed by the largest line so
 *       the entry balances exactly in the currency every report reads.</li>
 *   <li><b>Nothing is ever deleted.</b> A posted entry is voided by a
 *       mirrored REVERSING entry (same accounts, Dr/Cr flipped, auto-posted)
 *       that points back via {@code void_of_id}. An entry "is voided" exactly
 *       when such a mirror exists — there is no flag that could disagree.</li>
 *   <li><b>Closed periods are frozen.</b> New entries, posting drafts and
 *       voiding all refuse inside a CLOSED period.</li>
 *   <li><b>Every mutation is one transaction</b> that also writes an
 *       {@code audit_log} row.</li>
 * </ul>
 */
public final class JournalService {

    /** Sanity ceiling for one line: 10^15 cents = 10 trillion currency units. */
    private static final long MAX_LINE_CENTS = 1_000_000_000_000_000L;

    private static final ObjectMapper JSON = new ObjectMapper();

    private final Database database;
    private final FxRateService fxService;

    public JournalService(Database database, FxRateService fxService) {
        this.database = database;
        this.fxService = fxService;
    }

    /** 2.7.0: the close wizard builds a ClosingService from this journal. */
    public Database database() {
        return database;
    }

    // ------------------------------------------------------------------
    // Command shapes
    // ------------------------------------------------------------------

    /**
     * A would-be journal entry, as typed by the accountant. Amounts are
     * cents <b>in the entry's currency</b> (which for a base-currency entry
     * is the base currency itself).
     *
     * @param clientId owning client
     * @param periodId period the entry belongs to
     * @param date      accounting date, must lie inside the period
     * @param type      NORMAL, ADJUSTING or CLOSING (REVERSING is born only
     *                  from voiding)
     * @param reference optional document number ('OR-2026-114')
     * @param memo      free-text description, optional
     * @param currency  original currency, null/blank = client base currency
     * @param adjTemplateId recurring template this entry was prefilled from,
     *                      when known (provenance only, never enforced)
     * @param lines     the Dr/Cr lines, at least two, balanced
     */
    public record NewEntry(long clientId, long periodId, LocalDate date, EntryType type,
                           String reference, String memo, String currency,
                           Long adjTemplateId, List<NewLine> lines) {
    }

    /**
     * One typed line: exactly one of {@code debitCents} / {@code creditCents}
     * is non-null and positive.
     */
    public record NewLine(long accountId, Long debitCents, Long creditCents, String memo) {

        /** Typed amount regardless of side (throws on a malformed line). */
        public long amount() {
            return debitCents != null ? debitCents : creditCents;
        }
    }

    /** Register row: the entry plus everything the list view derives. */
    public record EntrySummary(JournalEntry entry, String periodName,
                               int lineCount, long totalBaseCents, boolean voided) {
    }

    /** One stored line joined with its account (for detail and ledger views). */
    public record LineRow(JournalLine line, Account account) {
    }

    /** General-ledger row with the account's running balance. */
    public record LedgerRow(LocalDate date, int entryNo, EntryType type, String memo,
                            Long debitCents, Long creditCents, long balanceCents) {
    }

    /** One trial-balance line. */
    public record TrialBalanceRow(Account account, long debitCents, long creditCents) {
    }

    /** A computed trial balance: rows plus the grand totals that must match. */
    public record TrialBalance(TbStage stage, List<TrialBalanceRow> rows,
                               long totalDebitCents, long totalCreditCents) {

        /** The double-entry check the whole report exists to make visible. */
        public boolean balanced() {
            return totalDebitCents == totalCreditCents;
        }
    }

    // ------------------------------------------------------------------
    // Queries
    // ------------------------------------------------------------------

    /** Looks an entry up by id. */
    public Optional<JournalEntry> find(long id) {
        try (Connection con = database.open()) {
            return readEntry(con, id);
        } catch (SQLException e) {
            throw new IllegalStateException("failed to look up entry", e);
        }
    }

    /**
     * The client's register, newest entry number first. {@code periodId}
     * null = all periods. The {@code voided} flag is derived from the mirror
     * entry, never stored.
     */
    public List<EntrySummary> list(long clientId, Long periodId) {
        String sql = "SELECT e.id, e.client_id, e.period_id, e.entry_no, e.entry_date,"
                + " e.type, e.reference, e.memo, e.currency, e.fx_rate, e.void_of_id, e.posted,"
                + " e.posted_at, e.adj_template_id, e.created_at, p.name AS period_name,"
                + " (SELECT COUNT(*) FROM journal_lines l WHERE l.entry_id = e.id) AS line_count,"
                + " COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l"
                + "           WHERE l.entry_id = e.id), 0) AS total_cents,"
                + " EXISTS(SELECT 1 FROM journal_entries v WHERE v.void_of_id = e.id) AS voided"
                + " FROM journal_entries e JOIN periods p ON p.id = e.period_id"
                + " WHERE e.client_id = ?" + (periodId == null ? "" : " AND e.period_id = ?")
                + " ORDER BY e.entry_no DESC";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, clientId);
            if (periodId != null) {
                ps.setLong(2, periodId);
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<EntrySummary> result = new ArrayList<>();
                while (rs.next()) {
                    result.add(new EntrySummary(
                            mapEntry(rs),
                            rs.getString("period_name"),
                            rs.getInt("line_count"),
                            rs.getLong("total_cents"),
                            rs.getBoolean("voided")));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list journal entries", e);
        }
    }

    /** The stored lines of an entry, joined with their accounts, in order. */
    public List<LineRow> lines(long entryId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT l.id, l.entry_id, l.line_no, l.account_id, l.debit_cents,"
                             + " l.credit_cents, l.memo, l.txn_currency, l.txn_debit_cents,"
                             + " l.txn_credit_cents, l.fx_rate, l.fx_rate_id,"
                             + " a.client_id AS a_client, a.code, a.name AS a_name,"
                             + " a.type AS a_type, a.normal_side, a.is_permanent,"
                             + " a.is_retained_earnings, a.parent_id, a.active"
                             + " FROM journal_lines l JOIN accounts a ON a.id = l.account_id"
                             + " WHERE l.entry_id = ? ORDER BY l.line_no, l.id")) {
            ps.setLong(1, entryId);
            try (ResultSet rs = ps.executeQuery()) {
                List<LineRow> result = new ArrayList<>();
                while (rs.next()) {
                    JournalLine line = new JournalLine(
                            rs.getLong("id"),
                            rs.getLong("entry_id"),
                            rs.getInt("line_no"),
                            rs.getLong("account_id"),
                            (Long) getObject(rs, "debit_cents"),
                            (Long) getObject(rs, "credit_cents"),
                            rs.getString("memo"),
                            rs.getString("txn_currency"),
                            (Long) getObject(rs, "txn_debit_cents"),
                            (Long) getObject(rs, "txn_credit_cents"),
                            (Double) getObject(rs, "fx_rate"),
                            (Long) getObject(rs, "fx_rate_id"));
                    Account account = new Account(
                            rs.getLong("account_id"),
                            rs.getLong("a_client"),
                            rs.getString("code"),
                            rs.getString("a_name"),
                            AccountType.parse(rs.getString("a_type")),
                            Side.parse(rs.getString("normal_side")),
                            rs.getInt("is_permanent") == 1,
                            rs.getInt("is_retained_earnings") == 1,
                            (Long) getObject(rs, "parent_id"),
                            rs.getInt("active") == 1);
                    result.add(new LineRow(line, account));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list entry lines", e);
        }
    }

    /**
     * The stored lines of MANY entries in ONE pass (2.10.0): the lines of
     * the client's entries, joined with their accounts, grouped by entry
     * id, each group ordered by line_no. The paper journal used to call
     * {@link #lines} per entry — one connection and one round trip per
     * entry, hundreds of queries for a full year. This single pass
     * replaces that loop.
     *
     * <p>Entries with no lines simply have no key in the returned map —
     * the same contract {@link #lines} gives by returning an empty list,
     * and the caller already handles that case.</p>
     */
    public Map<Long, List<LineRow>> linesForEntries(long clientId) {
        Map<Long, List<LineRow>> byEntry = new HashMap<>();
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT l.id, l.entry_id, l.line_no, l.account_id, l.debit_cents,"
                             + " l.credit_cents, l.memo, l.txn_currency, l.txn_debit_cents,"
                             + " l.txn_credit_cents, l.fx_rate, l.fx_rate_id,"
                             + " a.client_id AS a_client, a.code, a.name AS a_name,"
                             + " a.type AS a_type, a.normal_side, a.is_permanent,"
                             + " a.is_retained_earnings, a.parent_id, a.active"
                             + " FROM journal_lines l JOIN accounts a ON a.id = l.account_id"
                             + " WHERE l.entry_id IN (SELECT id FROM journal_entries"
                             + " WHERE client_id = ?)"
                             + " ORDER BY l.entry_id, l.line_no, l.id")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    JournalLine line = new JournalLine(
                            rs.getLong("id"),
                            rs.getLong("entry_id"),
                            rs.getInt("line_no"),
                            rs.getLong("account_id"),
                            (Long) getObject(rs, "debit_cents"),
                            (Long) getObject(rs, "credit_cents"),
                            rs.getString("memo"),
                            rs.getString("txn_currency"),
                            (Long) getObject(rs, "txn_debit_cents"),
                            (Long) getObject(rs, "txn_credit_cents"),
                            (Double) getObject(rs, "fx_rate"),
                            (Long) getObject(rs, "fx_rate_id"));
                    Account account = new Account(
                            rs.getLong("account_id"),
                            rs.getLong("a_client"),
                            rs.getString("code"),
                            rs.getString("a_name"),
                            AccountType.parse(rs.getString("a_type")),
                            Side.parse(rs.getString("normal_side")),
                            rs.getInt("is_permanent") == 1,
                            rs.getInt("is_retained_earnings") == 1,
                            (Long) getObject(rs, "parent_id"),
                            rs.getInt("active") == 1);
                    byEntry.computeIfAbsent(rs.getLong("entry_id"),
                            k -> new ArrayList<>()).add(new LineRow(line, account));
                }
            }
            return byEntry;
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list entry lines (batch)", e);
        }
    }

    /**
     * The general ledger of one account: every posted line across all of the
     * client's periods, oldest first, with the running balance signed in the
     * account's normal direction (contra accounts included).
     */
    public List<LedgerRow> ledger(long clientId, long accountId) {
        Account account;
        try (Connection con = database.open()) {
            account = readAccount(con, accountId)
                    .orElseThrow(() -> new NoSuchElementException("no account with id " + accountId));
            if (account.clientId() != clientId) {
                throw new IllegalArgumentException(
                        "account '" + account.code() + "' belongs to another client");
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read account", e);
        }

        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT e.entry_date, e.entry_no, e.type, e.memo AS entry_memo,"
                             + " l.debit_cents, l.credit_cents, l.memo AS line_memo"
                             + " FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id"
                             + " WHERE e.client_id = ? AND l.account_id = ? AND e.posted = 1"
                             + " ORDER BY e.entry_date, e.entry_no, l.id")) {
            ps.setLong(1, clientId);
            ps.setLong(2, accountId);
            try (ResultSet rs = ps.executeQuery()) {
                List<LedgerRow> result = new ArrayList<>();
                long balance = 0;
                while (rs.next()) {
                    Long debit = (Long) getObject(rs, "debit_cents");
                    Long credit = (Long) getObject(rs, "credit_cents");
                    long movement = debit != null ? debit : -credit;             // debit-normal
                    if (account.normalSide() == Side.CREDIT) {
                        movement = -movement;                                     // credit-normal
                    }
                    balance += movement;
                    String memo = rs.getString("line_memo") != null
                            ? rs.getString("line_memo") : rs.getString("entry_memo");
                    result.add(new LedgerRow(
                            LocalDate.parse(rs.getString("entry_date")),
                            rs.getInt("entry_no"),
                            EntryType.parse(rs.getString("type")),
                            memo, debit, credit, balance));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read ledger", e);
        }
    }

    /**
     * The trial balance of a period at one of the three checkpoints. Only
     * posted entries of the stage's entry types count; see {@link TbStage}
     * for exactly which.
     */
    public TrialBalance trialBalance(long periodId, TbStage stage) {
        StringJoiner types = new StringJoiner(",", "(", ")");
        for (EntryType t : stage.includes) {
            types.add("'" + t.name() + "'");
        }
        String sql = "SELECT a.id, a.client_id, a.code, a.name, a.type, a.normal_side,"
                + " a.is_permanent, a.is_retained_earnings, a.active,"
                + " COALESCE(SUM(l.debit_cents), 0) AS dr, COALESCE(SUM(l.credit_cents), 0) AS cr"
                + " FROM journal_entries e"
                + " JOIN journal_lines l ON l.entry_id = e.id"
                + " JOIN accounts a ON a.id = l.account_id"
                + " WHERE e.period_id = ? AND e.posted = 1 AND e.type IN " + types
                + " GROUP BY a.id ORDER BY a.code";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, periodId);
            try (ResultSet rs = ps.executeQuery()) {
                List<TrialBalanceRow> rows = new ArrayList<>();
                long totalDr = 0;
                long totalCr = 0;
                while (rs.next()) {
                    long dr = rs.getLong("dr");
                    long cr = rs.getLong("cr");
                    totalDr += dr;
                    totalCr += cr;
                    rows.add(new TrialBalanceRow(new Account(
                            rs.getLong("id"),
                            rs.getLong("client_id"),
                            rs.getString("code"),
                            rs.getString("name"),
                            AccountType.parse(rs.getString("type")),
                            Side.parse(rs.getString("normal_side")),
                            rs.getInt("is_permanent") == 1,
                            rs.getInt("is_retained_earnings") == 1,
                            null,
                            rs.getInt("active") == 1), dr, cr));
                }
                return new TrialBalance(stage, List.copyOf(rows), totalDr, totalCr);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to compute trial balance", e);
        }
    }

    /**
     * Builds the {@link Formula} evaluation context from a computed trial
     * balance: {@code BAL(code)} reads the net debit-positive balance,
     * {@code DR}/{@code CR(code)} the gross movements. Adjustment-template
     * formulas evaluate against the ADJUSTED stage, which is what the
     * accountant means by "5% of the balance".
     */
    public static Formula.Context formulaContext(TrialBalance tb) {
        Map<String, long[]> byCode = new HashMap<>();
        for (TrialBalanceRow row : tb.rows()) {
            byCode.put(row.account().code(), new long[]{
                    row.debitCents(), row.creditCents()});
        }
        return new Formula.Context() {
            @Override
            public long bal(String code) {
                long[] drCr = byCode.get(code);
                return drCr == null ? 0 : drCr[0] - drCr[1];
            }

            @Override
            public long dr(String code) {
                long[] drCr = byCode.get(code);
                return drCr == null ? 0 : drCr[0];
            }

            @Override
            public long cr(String code) {
                long[] drCr = byCode.get(code);
                return drCr == null ? 0 : drCr[1];
            }
        };
    }

    /**
     * Ids of the client's accounts that carry at least one posted line — the
     * ledgers view uses this to default to an account worth looking at.
     */
    public java.util.Set<Long> accountIdsWithPostedLines(long clientId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT DISTINCT l.account_id FROM journal_lines l"
                             + " JOIN journal_entries e ON e.id = l.entry_id"
                             + " WHERE e.client_id = ? AND e.posted = 1")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                java.util.Set<Long> result = new java.util.HashSet<>();
                while (rs.next()) {
                    result.add(rs.getLong(1));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list active accounts", e);
        }
    }

    // ------------------------------------------------------------------
    // Mutations (transactional, audited)
    // ------------------------------------------------------------------

    /**
     * Validates and stores a new entry as a DRAFT (no ledger effect yet).
     *
     * @throws NoSuchElementException     unknown client, period or account id
     * @throws IllegalArgumentException   malformed line/date/currency, date
     *                                    outside the period, deactivated
     *                                    account, archived client
     * @throws PeriodClosedException      the period is CLOSED
     * @throws EntryStateException        type REVERSING (born only from voiding)
     * @throws UnbalancedEntryException   typed debits ≠ typed credits
     * @throws FxUnavailableException     non-base currency with no cached rate
     *                                    on or before the entry date
     */
    public JournalEntry createDraft(NewEntry command) {
        requireShape(command);

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Client client = readClient(con, command.clientId())
                        .orElseThrow(() -> new NoSuchElementException(
                                "no client with id " + command.clientId()));
                Period period = readPeriod(con, command.periodId());
                if (period.clientId() != client.id()) {
                    throw new IllegalArgumentException(
                            "period '" + period.name() + "' belongs to another client");
                }
                if (period.closed()) {
                    throw new PeriodClosedException(period.name());
                }
                if (!period.contains(command.date())) {
                    throw new IllegalArgumentException("the entry date " + command.date()
                            + " lies outside period '" + period.name() + "' ("
                            + period.start() + " … " + period.end() + ")");
                }
                if (command.type() == EntryType.REVERSING
                        && command.adjTemplateId() == null
                        && !isReversalWorkflow(command)) {
                    // 2.7.0: the reversal workflow (ClosingService.reverseInto)
                    // also creates REVERSING drafts, marked by a memo prefix.
                    // Hand-typing one in the entry dialog stays refused —
                    // userSelectable() keeps the type out of the dialog anyway.
                    throw new EntryStateException(
                            "REVERSING entries are born only from voiding a posted entry"
                                    + " or the reversal workflow");
                }

                List<PreparedLine> prepared = prepareLines(con, command, client);

                long entryNo = nextEntryNo(con, client.id());
                long id;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO journal_entries(client_id, period_id, entry_no, entry_date,"
                                + " type, reference, memo, currency, fx_rate, adj_template_id)"
                                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setLong(1, client.id());
                    ps.setLong(2, period.id());
                    ps.setInt(3, (int) entryNo);
                    ps.setString(4, command.date().toString());
                    ps.setString(5, command.type().name());
                    ps.setString(6, blankToNull(command.reference()));
                    ps.setString(7, blankToNull(command.memo()));
                    ps.setString(8, prepared.isEmpty() ? null : prepared.get(0).currency());
                    ps.setObject(9, prepared.isEmpty() ? null : prepared.get(0).rate());
                    ps.setObject(10, command.adjTemplateId());
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new IllegalStateException("SQLite returned no generated key");
                        }
                        id = keys.getLong(1);
                    }
                }
                insertLines(con, id, prepared);

                String fxNote = prepared.isEmpty()
                        ? "base currency " + client.baseCurrency()
                        : "FX " + prepared.get(0).currency() + "→" + client.baseCurrency()
                                + " @ " + prepared.get(0).rate()
                                + " (cached " + prepared.get(0).rateDate() + ", "
                                + prepared.get(0).rateSource() + ")";
                long total = prepared.stream().mapToLong(PreparedLine::debitOrCredit).sum() / 2;
                String roundingNote = prepared.stream().anyMatch(PreparedLine::rounded)
                        ? " (rounding residual absorbed by the largest line)"
                        : "";
                Audit.write(con, client.id(), period.id(), "CREATE_ENTRY", "ENTRY", id,
                        "id=%d no=%d date=%s type=%s lines=%d total=%d %s%s%s".formatted(
                                id, entryNo, command.date(), command.type(), prepared.size(),
                                total, fxNote, roundingNote,
                                command.memo() == null || command.memo().isBlank()
                                        ? "" : " memo='" + command.memo().trim() + "'"));
                con.commit();
                return readEntry(con, id).orElseThrow(
                        () -> new IllegalStateException("entry vanished after insert"));

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to create entry", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to create entry", e);
        }
    }

    /**
     * Posts a draft: the entry becomes ledger fact — its lines flow into
     * {@code ledger_balances} and every trial balance from now on.
     *
     * @throws NoSuchElementException no entry with this id
     * @throws EntryStateException    the entry is posted already
     * @throws PeriodClosedException  the entry's period is CLOSED
     */
    public JournalEntry post(long entryId) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                JournalEntry entry = readEntry(con, entryId)
                        .orElseThrow(() -> new NoSuchElementException("no entry with id " + entryId));
                if (entry.posted()) {
                    throw new EntryStateException("entry #" + entry.entryNo()
                            + " is posted already — posted entries are immutable"
                            + " (void them instead)");
                }
                Period period = readPeriod(con, entry.periodId());
                if (period.closed()) {
                    throw new PeriodClosedException(period.name());
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE journal_entries SET posted = 1, posted_at = datetime('now')"
                                + " WHERE id = ?")) {
                    ps.setLong(1, entryId);
                    ps.executeUpdate();
                }
                addToBalances(con, entry.periodId(), rawLines(con, entryId));

                Audit.write(con, entry.clientId(), entry.periodId(), "POST_ENTRY", "ENTRY",
                        entryId,
                        "id=%d no=%d date=%s type=%s — now ledger fact".formatted(
                                entry.id(), entry.entryNo(), entry.date(), entry.type()));
                con.commit();
                return readEntry(con, entryId).orElseThrow(
                        () -> new IllegalStateException("entry vanished after update"));

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to post entry", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to post entry", e);
        }
    }

    /**
     * Voids a posted entry by recording its mirrored REVERSING entry — same
     * accounts, Dr and Cr flipped, auto-posted, pointing back at the original
     * through {@code void_of_id}. The original stays visible forever; its
     * ledger effect is exactly cancelled. Nothing is deleted.
     *
     * @throws NoSuchElementException no entry with this id
     * @throws EntryStateException    the entry is a draft (nothing to negate)
     *                                or already voided
     * @throws PeriodClosedException  the entry's period is CLOSED
     */
    public JournalEntry voidEntry(long entryId, String reason) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                JournalEntry original = readEntry(con, entryId)
                        .orElseThrow(() -> new NoSuchElementException("no entry with id " + entryId));
                if (!original.posted()) {
                    throw new EntryStateException("entry #" + original.entryNo()
                            + " is a draft — it carries no ledger effect, so there is nothing"
                            + " to void. Simply never post it.");
                }
                if (mirrorOf(con, entryId).isPresent()) {
                    throw new EntryStateException("entry #" + original.entryNo()
                            + " is voided already (mirror entry #"
                            + mirrorOf(con, entryId).orElseThrow().entryNo() + ")");
                }
                if (original.voidOfId() != null) {
                    throw new EntryStateException("entry #" + original.entryNo()
                            + " is itself a REVERSING mirror — mirrors are not voided,"
                            + " the voided original below tells the story");
                }
                Period period = readPeriod(con, original.periodId());
                if (period.closed()) {
                    throw new PeriodClosedException(period.name());
                }

                List<JournalLine> originalLines = rawLines(con, entryId);
                long mirrorId;
                long mirrorNo = nextEntryNo(con, original.clientId());
                String memo = "VOID of entry #" + original.entryNo()
                        + (reason == null || reason.isBlank() ? "" : ": " + reason.trim());
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO journal_entries(client_id, period_id, entry_no, entry_date,"
                                + " type, reference, memo, currency, fx_rate, void_of_id, posted,"
                                + " posted_at, adj_template_id)"
                                + " VALUES (?, ?, ?, ?, 'REVERSING', ?, ?, ?, ?, ?, 1,"
                                + " datetime('now'), ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setLong(1, original.clientId());
                    ps.setLong(2, original.periodId());
                    ps.setInt(3, (int) mirrorNo);
                    ps.setString(4, original.date().toString());
                    ps.setString(5, original.reference());
                    ps.setString(6, memo);
                    ps.setString(7, original.currency());
                    ps.setObject(8, original.fxRate());
                    ps.setLong(9, original.id());
                    ps.setObject(10, original.adjTemplateId());
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new IllegalStateException("SQLite returned no generated key");
                        }
                        mirrorId = keys.getLong(1);
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO journal_lines(entry_id, line_no, account_id, debit_cents,"
                                + " credit_cents, memo, txn_currency, txn_debit_cents,"
                                + " txn_credit_cents, fx_rate, fx_rate_id)"
                                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                    int lineNo = 0;
                    for (JournalLine line : originalLines) {
                        ps.setLong(1, mirrorId);
                        ps.setInt(2, ++lineNo);
                        ps.setLong(3, line.accountId());
                        ps.setObject(4, line.creditCents());   // flipped: the mirror
                        ps.setObject(5, line.debitCents());    // negates line by line
                        ps.setString(6, line.memo());
                        ps.setString(7, line.txnCurrency());
                        ps.setObject(8, line.txnCreditCents());
                        ps.setObject(9, line.txnDebitCents());
                        ps.setObject(10, line.fxRate());
                        ps.setObject(11, line.fxRateId());
                        ps.executeUpdate();
                    }
                }
                addToBalances(con, original.periodId(), rawLines(con, mirrorId));

                Audit.write(con, original.clientId(), original.periodId(), "VOID_ENTRY",
                        "ENTRY", mirrorId,
                        "id=%d no=%d voided_by mirror id=%d no=%d reason='%s'".formatted(
                                original.id(), original.entryNo(), mirrorId, mirrorNo,
                                reason == null ? "" : reason.trim()));
                con.commit();
                return readEntry(con, mirrorId).orElseThrow(
                        () -> new IllegalStateException("mirror vanished after insert"));

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to void entry", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to void entry", e);
        }
    }

    /**
     * Freezes a computed trial balance into {@code tb_snapshots} as JSON —
     * the audit trail of every report the firm ever produced.
     *
     * @return the snapshot's database id
     */
    public long snapshotTrialBalance(long periodId, TbStage stage) {
        TrialBalance tb = trialBalance(periodId, stage);
        Period period;
        try (Connection con = database.open()) {
            period = readPeriod(con, periodId);
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read period", e);
        }

        String asOf = LocalDateTime.now(ZoneOffset.UTC).withNano(0).toString().replace('T', ' ');
        List<Object> rows = new ArrayList<>();
        for (TrialBalanceRow r : tb.rows()) {
            Map<String, Object> row = new java.util.LinkedHashMap<>();
            row.put("code", r.account().code());
            row.put("name", r.account().name());
            row.put("type", r.account().type().name());
            row.put("debit_cents", r.debitCents());
            row.put("credit_cents", r.creditCents());
            rows.add(row);
        }
        Map<String, Object> payload = new java.util.LinkedHashMap<>();
        payload.put("stage", stage.name());
        payload.put("period", period.name());
        payload.put("as_of", asOf);
        payload.put("rows", rows);
        payload.put("total_debit_cents", tb.totalDebitCents());
        payload.put("total_credit_cents", tb.totalCreditCents());
        String json;
        try {
            json = JSON.writeValueAsString(payload);
        } catch (Exception e) {
            throw new IllegalStateException("failed to serialize the trial balance", e);
        }

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                long id;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO tb_snapshots(client_id, period_id, stage, as_of, payload,"
                                + " total_debit_cents, total_credit_cents, is_balanced)"
                                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setLong(1, period.clientId());
                    ps.setLong(2, periodId);
                    ps.setString(3, stage.name());
                    ps.setString(4, asOf);
                    ps.setString(5, json);
                    ps.setLong(6, tb.totalDebitCents());
                    ps.setLong(7, tb.totalCreditCents());
                    ps.setInt(8, tb.balanced() ? 1 : 0);
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new IllegalStateException("SQLite returned no generated key");
                        }
                        id = keys.getLong(1);
                    }
                }
                Audit.write(con, period.clientId(), periodId, "SNAPSHOT_TB", "TB_SNAPSHOT",
                        id,
                        "id=%d period='%s' stage=%s rows=%d totals dr=%d cr=%d".formatted(
                                id, period.name(), stage, tb.rows().size(),
                                tb.totalDebitCents(), tb.totalCreditCents()));
                con.commit();
                return id;

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to snapshot trial balance", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to snapshot trial balance", e);
        }
    }

    // ------------------------------------------------------------------
    // Entry preparation (validation + FX conversion + re-balancing)
    // ------------------------------------------------------------------

    /** A line after validation and conversion: base-currency cents plus the
     *  transaction-currency audit trail that migration V4 stores. */
    private record PreparedLine(long accountId, Long debitCents, Long creditCents,
                                String memo, String currency, Double rate, Long rateId,
                                Long txnDebitCents, Long txnCreditCents,
                                String rateDate, String rateSource, boolean rounded) {

        long debitOrCredit() {
            return debitCents != null ? debitCents : creditCents;
        }
    }

    /** Shape checks that need no database. */
    /**
     * 2.7.0: the reversal workflow marks its REVERSING drafts with a memo
     * prefix so createDraft can tell them from a hand-typed attempt. Only
     * ClosingService uses this; the marker is not a public contract.
     */
    static boolean isReversalWorkflow(NewEntry command) {
        return command.memo() != null && command.memo().startsWith("reversal of entry #");
    }

    private static void requireShape(NewEntry command) {
        if (command == null) {
            throw new IllegalArgumentException("the entry must not be null");
        }
        if (command.date() == null) {
            throw new IllegalArgumentException("the entry date must be picked");
        }
        if (command.type() == null) {
            throw new IllegalArgumentException("the entry type must be selected");
        }
        if (command.lines() == null || command.lines().size() < 2) {
            throw new IllegalArgumentException(
                    "an entry needs at least two lines — one debit and one credit");
        }
        for (NewLine line : command.lines()) {
            boolean hasDebit = line.debitCents() != null;
            boolean hasCredit = line.creditCents() != null;
            if (hasDebit == hasCredit) {
                throw new IllegalArgumentException(
                        "every line needs exactly one of debit or credit");
            }
            long amount = line.amount();
            if (amount <= 0) {
                throw new IllegalArgumentException("line amounts must be positive");
            }
            if (amount > MAX_LINE_CENTS) {
                throw new IllegalArgumentException("a single line may not exceed "
                        + MAX_LINE_CENTS / 100 + " currency units");
            }
        }
    }

    /**
     * Loads the accounts, enforces the client/active rules, resolves the FX
     * rate, converts to base cents and re-balances the rounding residual —
     * the entire multi-currency contract of this class in one place.
     */
    private List<PreparedLine> prepareLines(Connection con, NewEntry command, Client client)
            throws SQLException {

        List<JournalService.PreparedLine> out = new ArrayList<>();
        String typedCurrency = command.currency() == null ? "" : command.currency().trim();
        boolean baseEntry = typedCurrency.isEmpty()
                || typedCurrency.equalsIgnoreCase(client.baseCurrency());
        Double rate = null;
        String currency = null;
        String rateDate = null;
        String rateSource = null;
        Long rateId = null;

        if (!baseEntry) {
            currency = typedCurrency.toUpperCase();
            if (!currency.matches("[A-Z]{3}")) {
                throw new IllegalArgumentException("the entry currency must be a 3-letter"
                        + " ISO 4217 code (e.g. USD), not '" + typedCurrency + "'");
            }
            Optional<FxRate> cached = fxService.latestUpTo(command.date(), currency,
                    client.baseCurrency());
            if (cached.isEmpty()) {
                throw new FxUnavailableException("no cached " + currency + "→"
                        + client.baseCurrency() + " rate on or before " + command.date()
                        + " — fetch or store one in the FX Rates view first,"
                        + " then record this entry");
            }
            rate = cached.orElseThrow().rate();
            rateDate = cached.orElseThrow().asOf().toString();
            rateSource = cached.orElseThrow().source().name();
            rateId = cached.orElseThrow().id() > 0 ? cached.orElseThrow().id() : null;
        }

        long totalDr = 0;
        long totalCr = 0;
        for (NewLine line : command.lines()) {
            Account account = readAccount(con, line.accountId())
                    .orElseThrow(() -> new NoSuchElementException(
                            "no account with id " + line.accountId()));
            if (account.clientId() != client.id()) {
                throw new IllegalArgumentException("account '" + account.code()
                        + "' belongs to another client's chart");
            }
            if (!account.active()) {
                throw new IllegalArgumentException("account '" + account.code() + " — "
                        + account.name() + "' is deactivated — reactivate it before posting");
            }

            long typed = line.amount();
            long base;
            boolean rounded = false;
            if (baseEntry) {
                base = typed;
            } else {
                BigDecimal converted = BigDecimal.valueOf(typed)
                        .multiply(BigDecimal.valueOf(rate))
                        .setScale(0, RoundingMode.HALF_UP);
                if (converted.compareTo(BigDecimal.valueOf(MAX_LINE_CENTS)) > 0) {
                    throw new IllegalArgumentException("the converted amount of account '"
                            + account.code() + "' exceeds the ceiling after applying the rate");
                }
                base = converted.longValueExact();
                rounded = converted.longValueExact() != BigDecimal.valueOf(typed)
                        .multiply(BigDecimal.valueOf(rate)).longValue();
            }
            if (line.debitCents() != null) {
                totalDr += typed;
                out.add(new PreparedLine(account.id(), base, null, blankToNull(line.memo()),
                        currency, rate, rateId, baseEntry ? null : typed, null,
                        rateDate, rateSource, rounded));
            } else {
                totalCr += typed;
                out.add(new PreparedLine(account.id(), null, base, blankToNull(line.memo()),
                        currency, rate, rateId, null, baseEntry ? null : typed,
                        rateDate, rateSource, rounded));
            }
        }

        if (totalDr != totalCr) {
            throw new UnbalancedEntryException(totalDr, totalCr);
        }

        // The typed entry balances; pure rounding may have left the converted
        // entry a cent or two off. The largest line on the short side absorbs
        // the residual so debits = credits holds exactly in base currency.
        long baseDr = out.stream().filter(l -> l.debitCents() != null)
                .mapToLong(PreparedLine::debitOrCredit).sum();
        long baseCr = out.stream().filter(l -> l.creditCents() != null)
                .mapToLong(PreparedLine::debitOrCredit).sum();
        long residual = baseDr - baseCr;
        if (residual != 0) {
            absorbResidual(out, residual);
        }
        return out;
    }

    /** Adds {@code residual} (signed Dr−Cr) to the largest opposing line. */
    private static void absorbResidual(List<PreparedLine> lines, long residual) {
        if (residual > 0) {
            // debits are too big by |residual| → grow the largest credit line
            PreparedLine target = null;
            for (PreparedLine line : lines) {
                if (line.creditCents() != null
                        && (target == null || line.creditCents() > target.creditCents())) {
                    target = line;
                }
            }
            if (target == null) {
                throw new UnbalancedEntryException(residual, 0);
            }
            lines.set(lines.indexOf(target), new PreparedLine(target.accountId(),
                    null, target.creditCents() + residual, target.memo(), target.currency(),
                    target.rate(), target.rateId(), target.txnDebitCents(),
                    target.txnCreditCents(), target.rateDate(), target.rateSource(), true));
        } else {
            PreparedLine target = null;
            for (PreparedLine line : lines) {
                if (line.debitCents() != null
                        && (target == null || line.debitCents() > target.debitCents())) {
                    target = line;
                }
            }
            if (target == null) {
                throw new UnbalancedEntryException(0, -residual);
            }
            lines.set(lines.indexOf(target), new PreparedLine(target.accountId(),
                    target.debitCents() - residual, null, target.memo(), target.currency(),
                    target.rate(), target.rateId(), target.txnDebitCents(),
                    target.txnCreditCents(), target.rateDate(), target.rateSource(), true));
        }
    }

    private static void insertLines(Connection con, long entryId, List<PreparedLine> lines)
            throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO journal_lines(entry_id, line_no, account_id, debit_cents,"
                        + " credit_cents, memo, txn_currency, txn_debit_cents,"
                        + " txn_credit_cents, fx_rate, fx_rate_id)"
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            int lineNo = 0;
            for (PreparedLine line : lines) {
                ps.setLong(1, entryId);
                ps.setInt(2, ++lineNo);
                ps.setLong(3, line.accountId());
                ps.setObject(4, line.debitCents());
                ps.setObject(5, line.creditCents());
                ps.setString(6, line.memo());
                ps.setString(7, line.currency());
                ps.setObject(8, line.txnDebitCents());
                ps.setObject(9, line.txnCreditCents());
                ps.setObject(10, line.rate());
                ps.setObject(11, line.rateId());
                ps.executeUpdate();
            }
        }
    }

    /** Upserts the per-period account totals cache (posted lines only),
     *  split columns included (migration V4). */
    private static void addToBalances(Connection con, long periodId, List<JournalLine> lines)
            throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO ledger_balances(period_id, account_id, debit_total_cents,"
                        + " credit_total_cents, opening_cents, regular_dr, regular_cr,"
                        + " adjusting_dr, adjusting_cr, closing_dr, closing_cr, updated_at)"
                        + " VALUES (?, ?, ?, ?, 0, 0, 0, 0, 0, 0, 0, datetime('now'))"
                        + " ON CONFLICT(period_id, account_id) DO UPDATE SET"
                        + " debit_total_cents = debit_total_cents + excluded.debit_total_cents,"
                        + " credit_total_cents = credit_total_cents"
                        + " + excluded.credit_total_cents, updated_at = datetime('now')")) {
            for (JournalLine line : lines) {
                ps.setLong(1, periodId);
                ps.setLong(2, line.accountId());
                ps.setLong(3, line.debitCents() == null ? 0 : line.debitCents());
                ps.setLong(4, line.creditCents() == null ? 0 : line.creditCents());
                ps.executeUpdate();
            }
        }
        // keep the split columns consistent with the totals (SQLite UPDATE
        // takes no table alias, so the target is correlated by its name)
        try (PreparedStatement ps = con.prepareStatement(
                "UPDATE ledger_balances SET"
                        + " regular_dr = COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l"
                        + "   JOIN journal_entries e ON e.id = l.entry_id"
                        + "   WHERE e.period_id = ledger_balances.period_id"
                        + "     AND l.account_id = ledger_balances.account_id"
                        + "     AND e.posted = 1 AND e.type IN ('NORMAL','REVERSING')), 0),"
                        + " regular_cr = COALESCE((SELECT SUM(l.credit_cents) FROM journal_lines l"
                        + "   JOIN journal_entries e ON e.id = l.entry_id"
                        + "   WHERE e.period_id = ledger_balances.period_id"
                        + "     AND l.account_id = ledger_balances.account_id"
                        + "     AND e.posted = 1 AND e.type IN ('NORMAL','REVERSING')), 0),"
                        + " adjusting_dr = COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l"
                        + "   JOIN journal_entries e ON e.id = l.entry_id"
                        + "   WHERE e.period_id = ledger_balances.period_id"
                        + "     AND l.account_id = ledger_balances.account_id"
                        + "     AND e.posted = 1 AND e.type = 'ADJUSTING'), 0),"
                        + " adjusting_cr = COALESCE((SELECT SUM(l.credit_cents) FROM journal_lines l"
                        + "   JOIN journal_entries e ON e.id = l.entry_id"
                        + "   WHERE e.period_id = ledger_balances.period_id"
                        + "     AND l.account_id = ledger_balances.account_id"
                        + "     AND e.posted = 1 AND e.type = 'ADJUSTING'), 0),"
                        + " closing_dr = COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l"
                        + "   JOIN journal_entries e ON e.id = l.entry_id"
                        + "   WHERE e.period_id = ledger_balances.period_id"
                        + "     AND l.account_id = ledger_balances.account_id"
                        + "     AND e.posted = 1 AND e.type = 'CLOSING'), 0),"
                        + " closing_cr = COALESCE((SELECT SUM(l.credit_cents) FROM journal_lines l"
                        + "   JOIN journal_entries e ON e.id = l.entry_id"
                        + "   WHERE e.period_id = ledger_balances.period_id"
                        + "     AND l.account_id = ledger_balances.account_id"
                        + "     AND e.posted = 1 AND e.type = 'CLOSING'), 0)"
                        + " WHERE period_id = ?")) {
            ps.setLong(1, periodId);
            ps.executeUpdate();
        }
    }

    // ------------------------------------------------------------------
    // Row plumbing
    // ------------------------------------------------------------------

    private long nextEntryNo(Connection con, long clientId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT COALESCE(MAX(entry_no), 0) + 1 FROM journal_entries WHERE client_id = ?")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 1;
            }
        }
    }

    /** The mirror entry that voids {@code id}, if any. */
    private Optional<JournalEntry> mirrorOf(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, client_id, period_id, entry_no, entry_date, type, reference, memo,"
                        + " currency, fx_rate, void_of_id, posted, posted_at, adj_template_id,"
                        + " created_at FROM journal_entries WHERE void_of_id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapEntry(rs)) : Optional.empty();
            }
        }
    }

    private List<JournalLine> rawLines(Connection con, long entryId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, entry_id, line_no, account_id, debit_cents, credit_cents, memo,"
                        + " txn_currency, txn_debit_cents, txn_credit_cents, fx_rate, fx_rate_id"
                        + " FROM journal_lines WHERE entry_id = ? ORDER BY line_no, id")) {
            ps.setLong(1, entryId);
            try (ResultSet rs = ps.executeQuery()) {
                List<JournalLine> result = new ArrayList<>();
                while (rs.next()) {
                    result.add(new JournalLine(
                            rs.getLong("id"),
                            rs.getLong("entry_id"),
                            rs.getInt("line_no"),
                            rs.getLong("account_id"),
                            (Long) getObject(rs, "debit_cents"),
                            (Long) getObject(rs, "credit_cents"),
                            rs.getString("memo"),
                            rs.getString("txn_currency"),
                            (Long) getObject(rs, "txn_debit_cents"),
                            (Long) getObject(rs, "txn_credit_cents"),
                            (Double) getObject(rs, "fx_rate"),
                            (Long) getObject(rs, "fx_rate_id")));
                }
                return result;
            }
        }
    }

    private static Optional<Client> readClient(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, code, name, base_currency, tax_id, is_setup, active, created_at"
                        + " FROM clients WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                Client client = new Client(rs.getLong("id"), rs.getString("code"),
                        rs.getString("name"), rs.getString("base_currency"),
                        rs.getString("tax_id"), rs.getInt("is_setup") == 1,
                        rs.getInt("active") == 1, rs.getString("created_at"));
                if (!client.active()) {
                    throw new IllegalArgumentException("client '" + client.code()
                            + "' is archived — restore it before recording entries");
                }
                return Optional.of(client);
            }
        }
    }

    private static Period readPeriod(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, client_id, name, start_date, end_date, status, closed_at,"
                        + " locked_at FROM periods WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new NoSuchElementException("no period with id " + id);
                }
                return new Period(rs.getLong("id"), rs.getLong("client_id"),
                        rs.getString("name"), LocalDate.parse(rs.getString("start_date")),
                        LocalDate.parse(rs.getString("end_date")),
                        "CLOSED".equals(rs.getString("status")),
                        rs.getString("closed_at"), rs.getString("locked_at"));
            }
        }
    }

    private static Optional<Account> readAccount(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, client_id, code, name, type, normal_side, is_permanent,"
                        + " is_retained_earnings, parent_id, active"
                        + " FROM accounts WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(new Account(
                        rs.getLong("id"), rs.getLong("client_id"), rs.getString("code"),
                        rs.getString("name"), AccountType.parse(rs.getString("type")),
                        Side.parse(rs.getString("normal_side")),
                        rs.getInt("is_permanent") == 1,
                        rs.getInt("is_retained_earnings") == 1,
                        (Long) getObject(rs, "parent_id"),
                        rs.getInt("active") == 1))
                        : Optional.empty();
            }
        }
    }

    private static Optional<JournalEntry> readEntry(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, client_id, period_id, entry_no, entry_date, type, reference, memo,"
                        + " currency, fx_rate, void_of_id, posted, posted_at, adj_template_id,"
                        + " created_at FROM journal_entries WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapEntry(rs)) : Optional.empty();
            }
        }
    }

    private static JournalEntry mapEntry(ResultSet rs) throws SQLException {
        Double rate = (Double) getObject(rs, "fx_rate");
        Long voidOf = (Long) getObject(rs, "void_of_id");
        Long adjTemplate = (Long) getObject(rs, "adj_template_id");
        return new JournalEntry(
                rs.getLong("id"),
                rs.getLong("client_id"),
                rs.getLong("period_id"),
                rs.getInt("entry_no"),
                LocalDate.parse(rs.getString("entry_date")),
                EntryType.parse(rs.getString("type")),
                rs.getString("reference"),
                rs.getString("memo"),
                rs.getString("currency"),
                rate,
                voidOf,
                rs.getInt("posted") == 1,
                rs.getString("posted_at"),
                adjTemplate,
                rs.getString("created_at"));
    }

    /** Reads a nullable column without the wasNull dance. */
    private static Object getObject(ResultSet rs, String column) throws SQLException {
        Object value = rs.getObject(column);
        return value == null ? null : switch (value) {
            case Integer i -> i.longValue();
            case Float f -> f.doubleValue();
            default -> value;
        };
    }

    private static String blankToNull(String raw) {
        return raw == null || raw.isBlank() ? null : raw.trim();
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // rollback failed: the connection is being closed right after anyway
        }
    }
}
