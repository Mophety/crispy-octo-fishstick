package com.ledgerpro.service;

import java.util.ArrayList;
import java.util.List;

/**
 * Safe expression engine for FORMULA amounts in adjustment templates.
 *
 * <p>Supported grammar (classic precedence, {@code %} binds tighter than {@code *}):
 * <pre>
 *   expr    := term (('+'|'-') term)*
 *   term    := unary (('*'|'/') unary)*
 *   unary   := ('-'|'+') unary | postfix
 *   postfix := primary ('%')*
 *   primary := NUMBER | FUNC '(' NUMBER ')' | '(' expr ')'
 *   FUNC    := BAL | DR | CR      (account code as the numeric argument)
 * </pre>
 *
 * <p>Examples: {@code 5% * BAL(1100)}, {@code BAL(1430) * 10% / 12}, {@code 1250.00}.
 * BAL/DR/CR resolve against the period's ledger balances in cents; evaluation
 * itself happens in currency units and is rounded to cents by {@link #evalCents}.
 */
public final class Formula {

    /** Resolves account figures for the evaluation context. */
    public interface Context {
        /** Net balance through the adjusted stage, debit-positive signed, in cents. */
        long bal(String code);

        /** Gross debit movement through the adjusted stage, in cents. */
        long dr(String code);

        /** Gross credit movement through the adjusted stage, in cents. */
        long cr(String code);
    }

    public static final class FormulaException extends IllegalArgumentException {
        public FormulaException(String message) {
            super(message);
        }
    }

    private Formula() {
    }

    public static long evalCents(String expression, Context ctx) {
        return Math.round(eval(expression, ctx) * 100.0);
    }

    /** Parses and validates a formula without evaluating it (for template editing). */
    public static void syntaxCheck(String expression) {
        List<Token> tokens = tokenize(expression);
        Context noop = new Context() {
            @Override
            public long bal(String code) {
                return 0L;
            }

            @Override
            public long dr(String code) {
                return 0L;
            }

            @Override
            public long cr(String code) {
                return 0L;
            }
        };
        Parser p = new Parser(tokens, noop);
        double v = p.parseExpr();
        if (!p.atEnd()) {
            throw new FormulaException("Unexpected trailing input near \"" + p.peek() + "\"");
        }
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            throw new FormulaException("Formula evaluated to a non-finite value");
        }
    }

    public static double eval(String expression, Context ctx) {
        if (expression == null || expression.isBlank()) {
            throw new FormulaException("Empty formula");
        }
        List<Token> tokens = tokenize(expression);
        Parser p = new Parser(tokens, ctx);
        double v = p.parseExpr();
        if (!p.atEnd()) {
            throw new FormulaException("Unexpected trailing input near \"" + p.peek() + "\"");
        }
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            throw new FormulaException("Formula evaluated to a non-finite value");
        }
        return v;
    }

    // ------------------------------------------------------------------ lexer

    private record Token(String text, Type type) {
        enum Type { NUMBER, IDENT, OP }
    }

    private static List<Token> tokenize(String s) {
        List<Token> out = new ArrayList<>();
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }
            if (Character.isDigit(c) || (c == '.' && i + 1 < s.length() && Character.isDigit(s.charAt(i + 1)))) {
                int j = i;
                boolean dot = false;
                while (j < s.length() && (Character.isDigit(s.charAt(j)) || s.charAt(j) == '.')) {
                    if (s.charAt(j) == '.') {
                        if (dot) {
                            throw new FormulaException("Malformed number at \"" + s.substring(i, j + 1) + "\"");
                        }
                        dot = true;
                    }
                    j++;
                }
                out.add(new Token(s.substring(i, j), Token.Type.NUMBER));
                i = j;
                continue;
            }
            if (Character.isLetter(c)) {
                int j = i;
                while (j < s.length() && Character.isLetter(s.charAt(j))) {
                    j++;
                }
                out.add(new Token(s.substring(i, j).toUpperCase(), Token.Type.IDENT));
                i = j;
                continue;
            }
            if ("+-*/()%".indexOf(c) >= 0) {
                out.add(new Token(String.valueOf(c), Token.Type.OP));
                i++;
                continue;
            }
            throw new FormulaException("Unexpected character '" + c + "' in formula");
        }
        if (out.isEmpty()) {
            throw new FormulaException("Empty formula");
        }
        return out;
    }

    // ----------------------------------------------------------------- parser

    private static final class Parser {
        private final List<Token> tokens;
        private final Context ctx;
        private int pos;

        Parser(List<Token> tokens, Context ctx) {
            this.tokens = tokens;
            this.ctx = ctx;
        }

        boolean atEnd() {
            return pos >= tokens.size();
        }

        String peek() {
            return atEnd() ? "<end>" : tokens.get(pos).text();
        }

        double parseExpr() {
            double v = parseTerm();
            while (!atEnd() && isOp("+-")) {
                String op = tokens.get(pos++).text();
                double r = parseTerm();
                v = op.equals("+") ? v + r : v - r;
            }
            return v;
        }

        double parseTerm() {
            double v = parseUnary();
            while (!atEnd() && isOp("*/")) {
                String op = tokens.get(pos++).text();
                double r = parseUnary();
                if (op.equals("*")) {
                    v = v * r;
                } else {
                    if (r == 0) {
                        throw new FormulaException("Division by zero in formula");
                    }
                    v = v / r;
                }
            }
            return v;
        }

        double parseUnary() {
            if (!atEnd() && isOp("+-")) {
                String op = tokens.get(pos++).text();
                double v = parseUnary();
                return op.equals("-") ? -v : v;
            }
            return parsePostfix();
        }

        double parsePostfix() {
            double v = parsePrimary();
            while (!atEnd() && isOp("%")) {
                pos++;
                v = v / 100.0;
            }
            return v;
        }

        double parsePrimary() {
            if (atEnd()) {
                throw new FormulaException("Formula ends unexpectedly");
            }
            Token t = tokens.get(pos);
            if (t.type() == Token.Type.NUMBER) {
                pos++;
                return parseNumber(t.text());
            }
            if (t.type() == Token.Type.IDENT) {
                pos++;
                expectOp("(");
                Token arg = pos < tokens.size() ? tokens.get(pos) : null;
                if (arg == null || arg.type() != Token.Type.NUMBER) {
                    throw new FormulaException(t.text() + "(...) needs an account code, e.g. " + t.text() + "(1100)");
                }
                pos++;
                expectOp(")");
                return functionValue(t.text(), arg.text());
            }
            if (isOp("(")) {
                pos++;
                double v = parseExpr();
                expectOp(")");
                return v;
            }
            throw new FormulaException("Unexpected token \"" + t.text() + "\"");
        }

        private double functionValue(String name, String code) {
            long cents = switch (name) {
                case "BAL" -> ctx.bal(code);
                case "DR" -> ctx.dr(code);
                case "CR" -> ctx.cr(code);
                default -> throw new FormulaException("Unknown function " + name + " (use BAL, DR or CR)");
            };
            return cents / 100.0;
        }

        private static double parseNumber(String text) {
            try {
                return Double.parseDouble(text);
            } catch (NumberFormatException e) {
                throw new FormulaException("Malformed number \"" + text + "\"");
            }
        }

        private void expectOp(String op) {
            if (atEnd() || !tokens.get(pos).text().equals(op)) {
                throw new FormulaException("Expected \"" + op + "\" but found \"" + peek() + "\"");
            }
            pos++;
        }

        private boolean isOp(String ops) {
            return !atEnd() && tokens.get(pos).type() == Token.Type.OP && ops.contains(tokens.get(pos).text());
        }
    }
}
