package com.ledgerpro.service;

/**
 * Thrown when a journal entry is asked to do something its state forbids:
 * posting an already-posted entry, voiding a draft (drafts carry no ledger
 * effect — nothing to negate), voiding an entry that is already voided, or
 * creating a REVERSING entry by hand (those are born only from voiding).
 */
public class EntryStateException extends IllegalStateException {

    public EntryStateException(String message) {
        super(message);
    }
}
