package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Period;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * All reading and writing of the {@code periods} table goes through here.
 *
 * <p>Rules this service guarantees:</p>
 * <ul>
 *   <li><b>Never delete.</b> Periods are opened and closed; closing locks the
 *       period (no new entries, no posting, no voiding — enforced by
 *       {@link JournalService}), reopening is audited and deliberate.</li>
 *   <li><b>Names are unique per client</b> (checked here, backed by the
 *       schema's UNIQUE constraint).</li>
 *   <li><b>Periods never overlap</b> within a client — an accounting date
 *       must belong to exactly one period, or the trial balances of two
 *       periods would double-count the same transaction.</li>
 *   <li><b>Every mutation is one transaction</b> that also writes an
 *       {@code audit_log} row.</li>
 * </ul>
 */
public final class PeriodService {

    private static final int MAX_NAME_LENGTH = 60;

    private final Database database;

    public PeriodService(Database database) {
        this.database = database;
    }

    // ------------------------------------------------------------------
    // Queries
    // ------------------------------------------------------------------

    /** The client's periods, oldest start date first. */
    public List<Period> list(long clientId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, client_id, name, start_date, end_date, status, closed_at, locked_at"
                             + " FROM periods WHERE client_id = ?"
                             + " ORDER BY start_date, id")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Period> result = new ArrayList<>();
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list periods", e);
        }
    }

    /** Looks a period up by id. */
    public Optional<Period> find(long id) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id, client_id, name, start_date, end_date, status, closed_at, locked_at"
                             + " FROM periods WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to look up period", e);
        }
    }

    // ------------------------------------------------------------------
    // Mutations (transactional, audited)
    // ------------------------------------------------------------------

    /**
     * Creates a period for the client and returns the stored row.
     *
     * @throws IllegalArgumentException          blank/malformed name, null
     *                                           dates, end before start
     * @throws NoSuchElementException            no client with this id
     * @throws DuplicatePeriodNameException      name already used by this
     *                                           client
     * @throws IllegalArgumentException          the period would overlap an
     *                                           existing period of this client
     */
    public Period create(long clientId, String name, LocalDate start, LocalDate end) {
        String validName = normalizeName(name);
        if (start == null || end == null) {
            throw new IllegalArgumentException("start and end dates must be picked");
        }
        if (end.isBefore(start)) {
            throw new IllegalArgumentException(
                    "the period end (" + end + ") is before its start (" + start + ")");
        }

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                requireClient(con, clientId);
                requireNoOverlap(con, clientId, start, end);

                long id;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO periods(client_id, name, start_date, end_date)"
                                + " VALUES (?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setLong(1, clientId);
                    ps.setString(2, validName);
                    ps.setString(3, start.toString());
                    ps.setString(4, end.toString());
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new IllegalStateException("SQLite returned no generated key");
                        }
                        id = keys.getLong(1);
                    }
                }
                Audit.write(con, clientId, id, "CREATE_PERIOD", "PERIOD", id,
                        "id=%d name='%s' %s…%s".formatted(id, validName, start, end));
                con.commit();
                return read(con, id)
                        .orElseThrow(() -> new IllegalStateException("period vanished after insert"));

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof SQLException sx && isUniqueViolation(sx)) {
                    throw new DuplicatePeriodNameException(validName);
                }
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to create period", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to create period", e);
        }
    }

    /**
     * Locks the period: no new entries, no posting, no voiding inside it
     * afterwards. Audited as {@code CLOSE_PERIOD}.
     *
     * @throws NoSuchElementException  no period with this id
     * @throws PeriodClosedException   the period is closed already
     */
    public void close(long id) {
        setStatus(id, false, "CLOSE_PERIOD",
                "closed — reported numbers of this period are now frozen");
    }

    /** Reopens a closed period for corrections; audited as {@code REOPEN_PERIOD}. */
    public void reopen(long id) {
        setStatus(id, true, "REOPEN_PERIOD",
                "reopened for corrections — will be re-closed when done");
    }

    private void setStatus(long id, boolean open, String action, String note) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Period current = read(con, id)
                        .orElseThrow(() -> new NoSuchElementException("no period with id " + id));
                if (open && !current.closed()) {
                    throw new IllegalStateException(
                            "period '" + current.name() + "' is open already");
                }
                if (!open && current.closed()) {
                    throw new IllegalStateException(
                            "period '" + current.name() + "' is closed already");
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE periods SET status = ?, closed_at = ?, locked_at = ?"
                                + " WHERE id = ?")) {
                    ps.setString(1, open ? "OPEN" : "CLOSED");
                    ps.setString(2, open ? null : now());
                    ps.setString(3, open ? null : now());
                    ps.setLong(4, id);
                    ps.executeUpdate();
                }
                Audit.write(con, current.clientId(), id, action, "PERIOD", id,
                        "id=%d name='%s' %s…%s — %s".formatted(
                                id, current.name(), current.start(), current.end(), note));
                con.commit();

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to update period status", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to update period status", e);
        }
    }

    // ------------------------------------------------------------------
    // Validation / row plumbing
    // ------------------------------------------------------------------

    /** Names: trimmed, 1-60 chars. */
    private static String normalizeName(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (name.isEmpty()) {
            throw new IllegalArgumentException("period name must not be blank");
        }
        if (name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException(
                    "period name must be at most " + MAX_NAME_LENGTH + " characters");
        }
        return name;
    }

    /**
     * Overlap guard: an accounting date must belong to exactly one period.
     * Half-open intervals would make "…12-31" vs "01-01…" touch cleanly, but
     * the schema stores inclusive ends, so the check is inclusive on both
     * sides and honestly strict.
     */
    private static void requireNoOverlap(Connection con, long clientId,
                                         LocalDate start, LocalDate end) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT name FROM periods WHERE client_id = ?"
                        + " AND start_date <= ? AND end_date >= ?")) {
            ps.setLong(1, clientId);
            ps.setString(2, end.toString());
            ps.setString(3, start.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    throw new IllegalArgumentException(
                            "the period " + start + " … " + end + " would overlap '"
                                    + rs.getString(1) + "' — a date must belong to exactly"
                                    + " one period");
                }
            }
        }
    }

    private static Period mapRow(ResultSet rs) throws SQLException {
        return new Period(
                rs.getLong("id"),
                rs.getLong("client_id"),
                rs.getString("name"),
                LocalDate.parse(rs.getString("start_date")),
                LocalDate.parse(rs.getString("end_date")),
                "CLOSED".equals(rs.getString("status")),
                rs.getString("closed_at"),
                rs.getString("locked_at"));
    }

    /** UTC 'now' in the schema's timestamp shape. */
    private static String now() {
        return java.time.LocalDateTime.now(java.time.ZoneOffset.UTC)
                .withNano(0).toString().replace('T', ' ');
    }

    private static Optional<Period> read(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, client_id, name, start_date, end_date, status, closed_at, locked_at"
                        + " FROM periods WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        }
    }

    private static void requireClient(Connection con, long clientId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT EXISTS(SELECT 1 FROM clients WHERE id = ?)")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next() || !rs.getBoolean(1)) {
                    throw new NoSuchElementException("no client with id " + clientId);
                }
            }
        }
    }


    /** SQLite signals the per-client UNIQUE breach through the message text. */
    private static boolean isUniqueViolation(SQLException e) {
        String message = e.getMessage();
        return message != null
                && message.contains("UNIQUE constraint failed")
                && message.contains("periods.client_id");
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // rollback failed: the connection is being closed right after anyway
        }
    }
}
