package com.ledgerpro.service;

/**
 * Thrown when a mutation targets a CLOSED accounting period: new entries,
 * posting a draft, or voiding a posted entry all refuse.
 *
 * <p>A closed period's reported numbers must stay put. Corrections are
 * deliberate: reopen the period (audited), fix, re-close. The message says
 * exactly that, so the UI never has to explain policy itself.</p>
 */
public class PeriodClosedException extends IllegalStateException {

    private final String periodName;

    public PeriodClosedException(String periodName) {
        super("period '" + periodName + "' is CLOSED — reopen it first"
                + " (Periods are reopened and re-closed in daylight, with an"
                + " audit row, never edited silently)");
        this.periodName = periodName;
    }

    /** The locked period's name. */
    public String periodName() {
        return periodName;
    }
}
