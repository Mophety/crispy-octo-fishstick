package com.ledgerpro.service;

/**
 * Thrown when a period is created with a name another period of the same
 * client already carries — the per-client UNIQUE constraint as a friendly,
 * early exception.
 */
public class DuplicatePeriodNameException extends IllegalStateException {

    private final String name;

    public DuplicatePeriodNameException(String name) {
        super("this client already has a period named '" + name
                + "' — period names are unique per client");
        this.name = name;
    }

    /** The duplicated period name. */
    public String name() {
        return name;
    }
}
