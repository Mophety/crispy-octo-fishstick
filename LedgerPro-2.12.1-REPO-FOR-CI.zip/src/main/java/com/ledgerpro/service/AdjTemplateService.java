package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Recurring adjustment templates (step-4 machinery, migrations V3 + V4):
 * reusable journal-entry skeletons a firm records over and over —
 * depreciation, accrued salaries, prepaid amortization, bank reconciliation
 * adjustments.
 *
 * <p>A template is a code plus a balanced set of Dr/Cr lines whose accounts
 * are referenced by <b>code</b>, not id, so a template survives chart
 * rebuilds and can be shared across clients ({@code client_id NULL} =
 * shared by every client). Templates are NOT accounting data: they can be
 * deleted and recreated freely — but every mutation is still one audited
 * transaction, in the house style.</p>
 *
 * <p>Since migration V4 every line carries an explicit <b>side</b> (DR/CR)
 * and an <b>amount source</b>:</p>
 * <ul>
 *   <li>{@code FIXED} — {@code value} is a plain decimal amount ('1250.00')
 *       posted exactly as typed;</li>
 *   <li>{@code FORMULA} — {@code value} is an expression evaluated at apply
 *       time against the period's ledger ({@code 5% * BAL(1100)},
 *       {@code BAL(1430) * 10% / 12}) — see {@link Formula} for the grammar.
 *       A template that mixes both simply evaluates to its numbers before
 *       the balance check.</li>
 * </ul>
 *
 * <p>Rules guaranteed here so the UI never has to think about them:</p>
 * <ul>
 *   <li>a save is an upsert: same scope + same code replaces the lines;</li>
 *   <li>every template has at least two lines, each exactly one side;</li>
 *   <li>all-FIXED templates must balance at save time; formula templates
 *       are syntax-checked at save time and balance-checked at apply time,
 *       once their formulas have produced numbers;</li>
 *   <li>applying a template resolves account codes against that client's
 *       chart and refuses (with the list of missing codes) rather than
 *       silently posting to the wrong account;</li>
 *   <li>amounts are integer cents, like everywhere else in LedgerPro.</li>
 * </ul>
 */
public final class AdjTemplateService {

    public static final String FIXED = "FIXED";
    public static final String FORMULA = "FORMULA";

    private static final int MAX_CODE_LENGTH = 24;
    private static final int MAX_NAME_LENGTH = 120;
    private static final int MAX_MEMO_LENGTH = 200;
    private static final int MAX_VALUE_LENGTH = 200;

    private final Database database;

    public AdjTemplateService(Database database) {
        this.database = database;
    }

    // ------------------------------------------------------------------
    // Records
    // ------------------------------------------------------------------

    /**
     * One stored template line: an account CODE, one side, and an amount
     * that is either a fixed decimal or a formula over the ledger.
     */
    public record TemplateLine(int lineNo, String accountCode, String side,
                               String amountSource, String value, String memo) {

        public boolean isFormula() {
            return FORMULA.equals(amountSource);
        }

        /** The fixed amount in cents — only meaningful for FIXED lines. */
        public long fixedCents() {
            if (isFormula()) {
                throw new IllegalStateException("line " + lineNo + " is a formula,"
                        + " not a fixed amount");
            }
            return parseCents(value);
        }

        /** Human preview: '1010 DR 1250.00' or '1010 DR 5% * BAL(1100)'. */
        @Override
        public String toString() {
            return accountCode() + " " + side() + " " + value();
        }
    }

    /** A stored template with its lines, ready to preview or instantiate. */
    public record Template(long id, Long clientId, String clientCode, String code,
                           String name, String description, boolean isActive,
                           List<TemplateLine> lines) {

        /** True when the template is shared across all clients. */
        public boolean shared() {
            return clientId == null;
        }

        /** Total debits of the FIXED lines — equals fixed credits, enforced
         *  at save time; formula lines contribute once evaluated. */
        public long totalCents() {
            return lines.stream()
                    .filter(l -> !l.isFormula() && "DR".equals(l.side()))
                    .mapToLong(TemplateLine::fixedCents)
                    .sum();
        }

        /** Scope + code + name, e.g. "ACME · DEP_SL — Monthly depreciation". */
        @Override
        public String toString() {
            return (shared() ? "shared · " : clientCode + " · ")
                    + code + " — " + name;
        }
    }

    /** What {@link #instantiate(long, List, Formula.Context)} hands back:
     *  lines ready to edit. */
    public record AppliedLine(Account account, Long debitCents, Long creditCents,
                              String memo) {
    }

    // ------------------------------------------------------------------
    // Queries
    // ------------------------------------------------------------------

    /**
     * Templates available to a client: the client's own first (by code),
     * then the shared ones. Callers pass the client's code only for display.
     */
    public List<Template> list(long clientId, String clientCode) {
        String sql = "SELECT t.id, t.client_id, t.code, t.name, t.description,"
                + " t.is_active, c.code AS client_code"
                + " FROM adj_templates t LEFT JOIN clients c ON c.id = t.client_id"
                + " WHERE t.client_id = ? OR t.client_id IS NULL"
                + " ORDER BY (t.client_id IS NULL), t.code";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Template> result = new ArrayList<>();
                while (rs.next()) {
                    long id = rs.getLong("id");
                    Long owner = rs.getObject("client_id") == null
                            ? null : rs.getLong("client_id");
                    result.add(new Template(id, owner, clientCode,
                            rs.getString("code"), rs.getString("name"),
                            rs.getString("description"),
                            rs.getInt("is_active") != 0,
                            List.copyOf(loadLines(con, id))));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list adjustment templates", e);
        }
    }

    private List<TemplateLine> loadLines(Connection con, long templateId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT line_no, account_code, side, amount_source, value, memo"
                        + " FROM adj_template_lines WHERE template_id = ?"
                        + " ORDER BY line_no")) {
            ps.setLong(1, templateId);
            try (ResultSet rs = ps.executeQuery()) {
                List<TemplateLine> lines = new ArrayList<>();
                while (rs.next()) {
                    lines.add(new TemplateLine(
                            rs.getInt("line_no"),
                            rs.getString("account_code"),
                            rs.getString("side"),
                            rs.getString("amount_source"),
                            rs.getString("value"),
                            rs.getString("memo")));
                }
                return lines;
            }
        }
    }

    // ------------------------------------------------------------------
    // Mutations (transactional, audited)
    // ------------------------------------------------------------------

    /**
     * Upserts a template, addressed by scope + code — like saving a file by
     * name: a template with the same client scope and code is updated
     * (name and lines replaced atomically), otherwise a new template is
     * inserted. That is exactly what "remember these lines again" should do
     * for a recurring adjustment whose amounts changed.
     *
     * @throws IllegalArgumentException malformed code/name, fewer than two
     *                                  lines, a line with no side, a bad
     *                                  fixed amount, an invalid formula, or
     *                                  an all-FIXED template that does not
     *                                  balance
     */
    public Template save(Long clientId, String code, String name,
                         String description, List<TemplateLine> lines) {
        String validCode = normalizeCode(code);
        String validName = normalizeName(name);
        String validDescription = description == null ? "" : description.trim();
        List<TemplateLine> validLines = normalizeLines(lines);

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Long existing = findIdByScopeAndCode(con, clientId, validCode);
                long id;
                if (existing != null) {
                    id = existing;
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE adj_templates SET name = ?, description = ?"
                                    + " WHERE id = ?")) {
                        ps.setString(1, validName);
                        ps.setString(2, validDescription);
                        ps.setLong(3, id);
                        ps.executeUpdate();
                    }
                    try (PreparedStatement ps = con.prepareStatement(
                            "DELETE FROM adj_template_lines WHERE template_id = ?")) {
                        ps.setLong(1, id);
                        ps.executeUpdate();
                    }
                } else {
                    try (PreparedStatement ps = con.prepareStatement(
                            "INSERT INTO adj_templates(client_id, code, name, description)"
                                    + " VALUES (?, ?, ?, ?)",
                            Statement.RETURN_GENERATED_KEYS)) {
                        if (clientId == null) {
                            ps.setNull(1, java.sql.Types.INTEGER);
                        } else {
                            ps.setLong(1, clientId);
                        }
                        ps.setString(2, validCode);
                        ps.setString(3, validName);
                        ps.setString(4, validDescription);
                        ps.executeUpdate();
                        try (ResultSet keys = ps.getGeneratedKeys()) {
                            if (!keys.next()) {
                                throw new IllegalStateException("SQLite returned no generated key");
                            }
                            id = keys.getLong(1);
                        }
                    }
                }
                insertLines(con, id, validLines);
                long fixedDr = validLines.stream()
                        .filter(l -> !l.isFormula() && "DR".equals(l.side()))
                        .mapToLong(TemplateLine::fixedCents).sum();
                Audit.write(con, clientId, null, "SAVE_ADJ_TEMPLATE", "ADJ_TEMPLATE", id,
                        "id=%d code='%s' name='%s' lines=%d fixed_dr_cents=%d formulas=%d"
                                .formatted(id, validCode, validName, validLines.size(),
                                        fixedDr,
                                        validLines.stream().filter(TemplateLine::isFormula)
                                                .count()));
                con.commit();
                return new Template(id, clientId, null, validCode, validName,
                        validDescription, true, validLines);

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to save adjustment template", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to save adjustment template", e);
        }
    }

    /**
     * Activates or deactivates a template. Deactivated templates stay in the
     * register for provenance but drop out of the "Load template…" picker —
     * the annual-only adjustments stop cluttering the monthly routine.
     */
    public void setActive(long templateId, boolean active) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Long owner = null;
                String code = null;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT client_id, code FROM adj_templates WHERE id = ?")) {
                    ps.setLong(1, templateId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            owner = rs.getObject("client_id") == null
                                    ? null : rs.getLong("client_id");
                            code = rs.getString("code");
                        }
                    }
                }
                if (code == null) {
                    throw new java.util.NoSuchElementException(
                            "no adjustment template with id " + templateId);
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE adj_templates SET is_active = ? WHERE id = ?")) {
                    ps.setInt(1, active ? 1 : 0);
                    ps.setLong(2, templateId);
                    ps.executeUpdate();
                }
                Audit.write(con, owner, null,
                        active ? "ACTIVATE_ADJ_TEMPLATE" : "DEACTIVATE_ADJ_TEMPLATE",
                        "ADJ_TEMPLATE", templateId, "code='%s'".formatted(code));
                con.commit();
            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to update template", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to update template", e);
        }
    }

    /**
     * Deletes a template and its lines. Templates are reusable scaffolding,
     * not accounting data — deleting one touches no journal entry.
     */
    public void delete(long templateId) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Long owner = null;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT client_id FROM adj_templates WHERE id = ?")) {
                    ps.setLong(1, templateId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            owner = rs.getObject("client_id") == null
                                    ? null : rs.getLong("client_id");
                        }
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM adj_template_lines WHERE template_id = ?")) {
                    ps.setLong(1, templateId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM adj_templates WHERE id = ?")) {
                    ps.setLong(1, templateId);
                    ps.executeUpdate();
                }
                Audit.write(con, owner, null, "DELETE_ADJ_TEMPLATE", "ADJ_TEMPLATE",
                        templateId, "id=%d".formatted(templateId));
                con.commit();
            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to delete adjustment template", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to delete adjustment template", e);
        }
    }

    // ------------------------------------------------------------------
    // Applying a template to a client's chart
    // ------------------------------------------------------------------

    /**
     * Resolves a template's account codes against {@code chart} (the
     * client's ACTIVE accounts) and returns editable lines for the
     * new-entry form.
     *
     * @throws IllegalArgumentException one or more codes are not in the chart
     *                                  (the message lists them all), or a
     *                                  formula failed to evaluate
     */
    public List<AppliedLine> instantiate(long templateId, List<Account> chart) {
        return instantiate(templateId, chart, null);
    }

    /**
     * Full form: FIXED lines post as stored; FORMULA lines are evaluated
     * against {@code ctx} (the period's adjusted trial balance — see
     * {@link JournalService#formulaContext}). The result must balance, or
     * the apply is refused with both totals in the message.
     */
    public List<AppliedLine> instantiate(long templateId, List<Account> chart,
                                         Formula.Context ctx) {
        List<TemplateLine> lines = loadLinesOpen(templateId);
        Map<String, Account> byCode = chart.stream()
                .collect(Collectors.toMap(a -> a.code().toUpperCase(Locale.ROOT),
                        Function.identity(), (a, b) -> a, TreeMap::new));

        Set<String> missing = new HashSet<>();
        List<AppliedLine> applied = new ArrayList<>();
        for (TemplateLine line : lines) {
            Account account = byCode.get(line.accountCode().toUpperCase(Locale.ROOT));
            if (account == null) {
                missing.add(line.accountCode());
                continue;
            }
            Long debit;
            Long credit;
            if (line.isFormula()) {
                if (ctx == null) {
                    throw new IllegalArgumentException("template line " + line.lineNo()
                            + " is a formula (" + line.value() + ") but no period balances"
                            + " were provided to evaluate it against");
                }
                long cents = Formula.evalCents(line.value(), ctx);
                debit = "DR".equals(line.side()) ? cents : null;
                credit = "CR".equals(line.side()) ? cents : null;
            } else {
                long cents = line.fixedCents();
                debit = "DR".equals(line.side()) ? cents : null;
                credit = "CR".equals(line.side()) ? cents : null;
            }
            applied.add(new AppliedLine(account, debit, credit, line.memo()));
        }
        if (!missing.isEmpty()) {
            throw new IllegalArgumentException("this client's chart has no account"
                    + (missing.size() == 1 ? " " : "s ") + String.join(", ", missing)
                    + " — add the account or edit the template first");
        }
        long dr = applied.stream().mapToLong(l -> l.debitCents() == null ? 0 : l.debitCents()).sum();
        long cr = applied.stream().mapToLong(l -> l.creditCents() == null ? 0 : l.creditCents()).sum();
        if (dr != cr) {
            throw new IllegalArgumentException("the evaluated template does not balance —"
                    + " debits " + java.math.BigDecimal.valueOf(dr, 2).toPlainString()
                    + " ≠ credits " + java.math.BigDecimal.valueOf(cr, 2).toPlainString()
                    + ". Adjust the formulas or amounts and save the template again.");
        }
        return applied;
    }

    private List<TemplateLine> loadLinesOpen(long templateId) {
        try (Connection con = database.open()) {
            return loadLines(con, templateId);
        } catch (SQLException e) {
            throw new IllegalStateException("failed to load template lines", e);
        }
    }

    // ------------------------------------------------------------------
    // Validation / normalization helpers
    // ------------------------------------------------------------------

    /** Codes: trimmed, uppercase, 1-24 chars of A-Z, 0-9, '_' or '-'. */
    private static String normalizeCode(String raw) {
        String code = raw == null ? "" : raw.trim().toUpperCase(Locale.ROOT);
        if (code.isEmpty()) {
            throw new IllegalArgumentException("template code must not be blank");
        }
        if (code.length() > MAX_CODE_LENGTH) {
            throw new IllegalArgumentException(
                    "template code must be at most " + MAX_CODE_LENGTH + " characters");
        }
        if (!code.matches("[A-Z0-9_-]+")) {
            throw new IllegalArgumentException(
                    "template code may only contain letters, digits, '_' and '-'");
        }
        return code;
    }

    /** Names: trimmed, 1-120 chars. */
    private static String normalizeName(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (name.isEmpty()) {
            throw new IllegalArgumentException("template name must not be blank");
        }
        if (name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException(
                    "template name must be at most " + MAX_NAME_LENGTH + " characters");
        }
        return name;
    }

    /**
     * The double-entry discipline, exactly like the journal service — with
     * the formula twist: formulas are syntax-checked here and balance-checked
     * at apply time, once they have produced numbers.
     */
    private static List<TemplateLine> normalizeLines(List<TemplateLine> raw) {
        if (raw == null || raw.size() < 2) {
            throw new IllegalArgumentException("a template needs at least two lines"
                    + " (a debit and a credit)");
        }
        long dr = 0;
        long cr = 0;
        boolean anyFormula = false;
        List<TemplateLine> clean = new ArrayList<>();
        for (int i = 0; i < raw.size(); i++) {
            TemplateLine line = raw.get(i);
            String accountCode = line.accountCode() == null ? "" : line.accountCode().trim();
            if (accountCode.isEmpty()) {
                throw new IllegalArgumentException("line " + (i + 1) + " has no account");
            }
            if (accountCode.length() > 12) {
                throw new IllegalArgumentException("line " + (i + 1)
                        + ": account code must be at most 12 characters");
            }
            String side = line.side() == null ? "" : line.side().trim().toUpperCase(Locale.ROOT);
            if (!side.equals("DR") && !side.equals("CR")) {
                throw new IllegalArgumentException("line " + (i + 1)
                        + ": side must be DR or CR");
            }
            boolean formula = FORMULA.equals(line.amountSource());
            String value = line.value() == null ? "" : line.value().trim();
            if (value.isEmpty()) {
                throw new IllegalArgumentException("line " + (i + 1)
                        + (formula ? " needs its formula" : " needs its amount"));
            }
            if (value.length() > MAX_VALUE_LENGTH) {
                throw new IllegalArgumentException("line " + (i + 1)
                        + ": amount/formula must be at most " + MAX_VALUE_LENGTH
                        + " characters");
            }
            if (formula) {
                anyFormula = true;
                try {
                    Formula.syntaxCheck(value);
                } catch (Formula.FormulaException e) {
                    throw new IllegalArgumentException("line " + (i + 1) + ": " + e.getMessage());
                }
            } else {
                long cents = parseCents(value);
                if (cents <= 0) {
                    throw new IllegalArgumentException("line " + (i + 1)
                            + ": amounts must be positive");
                }
                dr += side.equals("DR") ? cents : 0;
                cr += side.equals("CR") ? cents : 0;
            }
            String memo = line.memo() == null ? null : line.memo().trim();
            if (memo != null && memo.length() > MAX_MEMO_LENGTH) {
                throw new IllegalArgumentException("line " + (i + 1)
                        + ": memo must be at most " + MAX_MEMO_LENGTH + " characters");
            }
            if (memo != null && memo.isEmpty()) {
                memo = null;
            }
            clean.add(new TemplateLine(i + 1, accountCode, side,
                    formula ? FORMULA : FIXED, value, memo));
        }
        if (!anyFormula && dr != cr) {
            throw new IllegalArgumentException("the template must balance — debits "
                    + java.math.BigDecimal.valueOf(dr, 2).toPlainString()
                    + " ≠ credits " + java.math.BigDecimal.valueOf(cr, 2).toPlainString());
        }
        return clean;
    }

    /** '1250.00' → 125000 cents; accepts commas and a leading currency sign. */
    private static long parseCents(String value) {
        String cleaned = value.replace(",", "").replace("₱", "").replace("$", "").trim();
        try {
            return java.math.BigDecimal.valueOf(Double.parseDouble(cleaned))
                    .movePointRight(2)
                    .setScale(0, java.math.RoundingMode.HALF_UP)
                    .longValueExact();
        } catch (NumberFormatException | ArithmeticException e) {
            throw new IllegalArgumentException("'" + value + "' is not a valid amount"
                    + " (expected e.g. 1250.00)");
        }
    }

    private static void insertLines(Connection con, long templateId,
                                    List<TemplateLine> lines) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO adj_template_lines(template_id, line_no, account_code,"
                        + " side, amount_source, value, memo) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
            for (TemplateLine line : lines) {
                ps.setLong(1, templateId);
                ps.setInt(2, line.lineNo());
                ps.setString(3, line.accountCode());
                ps.setString(4, line.side());
                ps.setString(5, line.amountSource());
                ps.setString(6, line.value());
                ps.setString(7, line.memo());
                ps.executeUpdate();
            }
        }
    }

    private static Long findIdByScopeAndCode(Connection con, Long clientId, String code)
            throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id FROM adj_templates WHERE code = ?"
                        + " AND ((client_id IS NULL AND ? IS NULL) OR client_id = ?)")) {
            ps.setString(1, code);
            if (clientId == null) {
                ps.setNull(2, java.sql.Types.INTEGER);
                ps.setNull(3, java.sql.Types.INTEGER);
            } else {
                ps.setLong(2, clientId);
                ps.setLong(3, clientId);
            }
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : null;
            }
        }
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // rollback failed: the connection is being closed right after anyway
        }
    }
}
