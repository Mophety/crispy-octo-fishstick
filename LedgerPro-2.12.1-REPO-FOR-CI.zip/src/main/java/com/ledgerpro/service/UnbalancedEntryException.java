package com.ledgerpro.service;

/**
 * Thrown when the debit and credit totals of a would-be journal entry do not
 * match — in the currency the amounts were typed in.
 *
 * <p>The double-entry equation is non-negotiable, so the entry is rejected
 * whole: nothing is stored, not even as a draft. (After FX conversion the
 * service itself re-balances pure rounding residuals, so what the accountant
 * typed is always what has to balance.)</p>
 */
public class UnbalancedEntryException extends IllegalArgumentException {

    private final long debitCents;
    private final long creditCents;

    public UnbalancedEntryException(long debitCents, long creditCents) {
        super("the entry is not balanced: debits of " + cents(debitCents)
                + " do not equal credits of " + cents(creditCents)
                + " (difference " + cents(Math.abs(debitCents - creditCents)) + ")");
        this.debitCents = debitCents;
        this.creditCents = creditCents;
    }

    /** Typed debit total, cents. */
    public long debitCents() {
        return debitCents;
    }

    /** Typed credit total, cents. */
    public long creditCents() {
        return creditCents;
    }

    private static String cents(long value) {
        return String.format("%,d.%02d", value / 100, Math.abs(value % 100));
    }
}
