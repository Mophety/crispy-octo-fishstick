package com.ledgerpro.service;

/**
 * Thrown when an account is created (or renamed to) a code that already
 * exists in the same client's chart of accounts.
 *
 * <p>Carried as its own type (instead of a raw {@link java.sql.SQLException})
 * so the UI can show a friendly, actionable message instead of a stack trace:
 * "Account code '1010' already exists in this chart of accounts".</p>
 */
public class DuplicateAccountCodeException extends IllegalStateException {

    private final String code;

    public DuplicateAccountCodeException(String code) {
        super("Account code '" + code + "' already exists in this chart of accounts");
        this.code = code;
    }

    /** The offending code, normalized to uppercase. */
    public String code() {
        return code;
    }
}
