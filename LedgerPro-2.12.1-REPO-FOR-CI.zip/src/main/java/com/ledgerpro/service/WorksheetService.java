package com.ledgerpro.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;
import com.ledgerpro.model.Side;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * The worksheet and the financial statements of Phase 5 — the reports the
 * accounting cycle has been building toward. The ONLY writer of
 * {@code report_snapshots}; everything else here is pure derivation from the
 * posted journal, so every figure below can always be recomputed and checked
 * against the ledger.
 *
 * <p><b>The worksheet</b> is the firm's internal working paper: every account
 * of the period as an unadjusted balance (day-to-day {@code NORMAL} entries
 * plus {@code REVERSING} voiding mirrors — voiding must remove an entry's
 * effect from every column), the end-of-period {@code ADJUSTING} entries in
 * their own two columns, the adjusted trial balance as the net of the two,
 * and then the sorting of every adjusted balance into exactly one pair of
 * statement columns:</p>
 * <ul>
 *   <li>revenue and expense accounts → <b>Income Statement</b> columns</li>
 *   <li>equity accounts (capital normal, drawing/treasury/dividends contra)
 *       → <b>Changes in Owner's Equity</b> columns (13-column format) or,
 *       folded directly into the balance sheet columns, in the classic
 *       10-column format</li>
 *   <li>asset and liability accounts → <b>Balance Sheet</b> columns (contra
 *       assets such as Accumulated Depreciation land on the credit side, as
 *       the deduction lines they are)</li>
 * </ul>
 *
 * <p>Accounts that net to zero in every column — a receivable collected in
 * full within the period, an entry voided by its mirror — read as blank
 * lines on the paper sheet, so they are dropped from the grid and from the
 * statements the same way.</p>
 *
 * <p><b>Closing entries deliberately stay out of the worksheet.</b> The
 * worksheet is the paper that precedes closing: its income statement columns
 * are the very figures closing zeroes out, so it keeps showing them — before,
 * during and after the close. The post-closing checkpoint lives in the trial
 * balance view instead.</p>
 *
 * <p>The two special rows every paper worksheet carries fall out of the same
 * arithmetic:</p>
 * <ul>
 *   <li><b>NET INCOME</b> — income statement credits minus debits; it
 *       balances the income statement columns and lands on the credit side of
 *       the changes-in-equity columns (a net loss mirrors to both).</li>
 *   <li><b>ENDING CAPITAL</b> — the equity columns' credit total minus their
 *       debit total; it balances the changes-in-equity columns and becomes
 *       the equity figure on the balance sheet.</li>
 * </ul>
 *
 * <p><b>The statements</b> — income statement, statement of changes in equity
 * and balance sheet — are the same worksheet read as a narrative: revenues
 * and expenses with net income; beginning capital plus investments plus net
 * income minus withdrawals equal to ending capital; and assets equal to
 * liabilities plus that ending capital. The balance sheet check
 * {@code totalAssets == totalLiabilities + totalEquity} is asserted on every
 * build — it is a theorem of {@code Dr = Cr}, and the day it fails is the day
 * something upstream is broken.</p>
 *
 * <p><b>Exports</b>: CSV (exact ungrouped decimals, one line per row — the
 * format a spreadsheet ingests losslessly) and a self-contained print-ready
 * HTML page of all three statements (print to PDF from any browser). Both are
 * produced from the same computed reports, and both are tested.</p>
 */
public final class WorksheetService {

    private static final ObjectMapper JSON = new ObjectMapper();

    private final Database database;

    public WorksheetService(Database database) {
        this.database = database;
    }

    // ------------------------------------------------------------------
    // Worksheet
    // ------------------------------------------------------------------

    /**
     * The two paper formats the firm's worksheets come in. The 13-column
     * format carries a dedicated pair of Changes in Owner's Equity columns;
     * the classic 10-column format folds equity into the balance sheet
     * columns instead (drawing on the debit side, net income on the credit
     * side, capital at its adjusted balance).
     */
    public enum WorksheetFormat {

        COLUMNS_10("10-column"),
        COLUMNS_13("13-column");

        /** Human-friendly label for the toolbar combo box. */
        public final String label;

        WorksheetFormat(String label) {
            this.label = label;
        }

        /** Parses the database spelling ('COLUMNS_10', '13-column', …). */
        public static WorksheetFormat parse(String raw) {
            return switch (raw == null ? "" : raw.trim().toUpperCase()) {
                case "COLUMNS_10", "10-COLUMN", "10" -> COLUMNS_10;
                case "COLUMNS_13", "13-COLUMN", "13" -> COLUMNS_13;
                default -> throw new IllegalArgumentException(
                        "worksheet format must be COLUMNS_10 or COLUMNS_13 — not '" + raw + "'");
            };
        }
    }

    /**
     * One account's line of the worksheet: its unadjusted and adjusting
     * amounts — each <b>netted to one side</b> the way the paper columns
     * read, so a voided entry's mirror cancels it in the unadjusted columns
     * — the adjusted balance as a single-sided net, and the routed
     * statement-column cells (exactly one pair carries the amount).
     *
     * @param investCr credits posted to this equity account in {@code NORMAL}
     *                 entries of the period — the "additional investments"
     *                 line of the statement of changes in equity (the opening
     *                 credit of a newly onboarded client is one, honestly)
     */
    public record WorksheetRow(
            Account account,
            long unadjDr, long unadjCr,
            long adjDr, long adjCr,
            long atbDr, long atbCr,
            long isDr, long isCr,
            long soceDr, long soceCr,
            long bsDr, long bsCr,
            long investCr) {

        /** The adjusted balance as a signed Dr-positive net. */
        long signedNet() {
            return atbDr - atbCr;
        }
    }

    /** Column totals over the account rows (before the special rows). */
    public record Totals(
            long unadjDr, long unadjCr,
            long adjDr, long adjCr,
            long atbDr, long atbCr,
            long isDr, long isCr,
            long soceDr, long soceCr,
            long bsDr, long bsCr) {
    }

    /**
     * The whole worksheet of one period in one format.
     *
     * <p>The grand-total methods add the NET INCOME and ENDING CAPITAL rows
     * the paper sheet prints below the account rows, so every column group
     * balances exactly the way the paper does.</p>
     */
    public record Worksheet(
            Period period,
            Client client,
            WorksheetFormat format,
            List<WorksheetRow> rows,
            Totals totals,
            long netIncome,
            long endingCapital) {

        /** Signed: positive = net income, negative = net loss. */
        public long netIncome() {
            return netIncome;
        }

        /** Equity credits minus equity debits, plus net income. */
        public long endingCapital() {
            return endingCapital;
        }

        public long isGrandDr() {
            return totals.isDr + Math.max(netIncome, 0);
        }

        public long isGrandCr() {
            return totals.isCr + Math.max(-netIncome, 0);
        }

        public long soceGrandDr() {
            return format == WorksheetFormat.COLUMNS_13
                    ? totals.soceDr + Math.max(-netIncome, 0) + Math.max(endingCapital, 0)
                    : totals.soceDr;   // account rows only: the equity pair
                                       // is hidden in 10-column, so the NET
                                       // INCOME / ENDING CAPITAL rows do not
                                       // print into it (they ride the balance
                                       // sheet columns there instead)
        }

        public long soceGrandCr() {
            return format == WorksheetFormat.COLUMNS_13
                    ? totals.soceCr + Math.max(netIncome, 0) + Math.max(-endingCapital, 0)
                    : totals.soceCr;
        }

        public long bsGrandDr() {
            return format == WorksheetFormat.COLUMNS_13
                    ? totals.bsDr + Math.max(-endingCapital, 0)
                    : totals.bsDr + Math.max(-netIncome, 0);
        }

        public long bsGrandCr() {
            return format == WorksheetFormat.COLUMNS_13
                    ? totals.bsCr + Math.max(endingCapital, 0)
                    : totals.bsCr + Math.max(netIncome, 0);
        }

        /**
         * The worksheet's grand-total Dr: the printed column groups' totals.
         * In 10-column that is the income statement + balance sheet pairs
         * (the kept-live equity cells are a reference strip, not a printed
         * pair, so they are not cross-footed into the grand total).
         */
        public long grandDr() {
            return format == WorksheetFormat.COLUMNS_13
                    ? isGrandDr() + soceGrandDr() + bsGrandDr()
                    : isGrandDr() + bsGrandDr();
        }

        /** Same as {@link #grandDr()} on the credit side. */
        public long grandCr() {
            return format == WorksheetFormat.COLUMNS_13
                    ? isGrandCr() + soceGrandCr() + bsGrandCr()
                    : isGrandCr() + bsGrandCr();
        }

        /**
         * The worksheet's own proof: unadjusted, adjustments, adjusted and
         * every statement column group balance. All of these are theorems of
         * {@code Dr = Cr} per entry; the check exists so a regression
         * announces itself loudly instead of quietly misstating a report.
         */
        public boolean balanced() {
            return totals.unadjDr == totals.unadjCr
                    && totals.adjDr == totals.adjCr
                    && totals.atbDr == totals.atbCr
                    && isGrandDr() == isGrandCr()
                    && (format == WorksheetFormat.COLUMNS_13
                        ? soceGrandDr() == soceGrandCr() && bsGrandDr() == bsGrandCr()
                        : bsGrandDr() == bsGrandCr())
                    && grandDr() == grandCr();
        }
    }

    /**
     * Builds the worksheet of one period in the requested format.
     *
     * @throws NoSuchElementException no period with this id
     */
    public Worksheet worksheet(long periodId, WorksheetFormat format) {
        try (Connection con = database.open()) {
            Period period = readPeriod(con, periodId);
            Client client = readClient(con, period.clientId());

            List<WorksheetRow> rows = new ArrayList<>();
            String sql = "SELECT a.id, a.client_id, a.code, a.name, a.type, a.normal_side,"
                    + " a.is_permanent, a.is_retained_earnings, a.active,"
                    + " COALESCE(SUM(CASE WHEN e.type IN ('NORMAL','REVERSING')"
                    + "        THEN l.debit_cents  END), 0) AS unadj_dr,"
                    + " COALESCE(SUM(CASE WHEN e.type IN ('NORMAL','REVERSING')"
                    + "        THEN l.credit_cents END), 0) AS unadj_cr,"
                    + " COALESCE(SUM(CASE WHEN e.type = 'ADJUSTING'"
                    + "        THEN l.debit_cents  END), 0) AS adj_dr,"
                    + " COALESCE(SUM(CASE WHEN e.type = 'ADJUSTING'"
                    + "        THEN l.credit_cents END), 0) AS adj_cr,"
                    + " COALESCE(SUM(CASE WHEN e.type = 'NORMAL' AND a.type = 'EQUITY'"
                    + "        AND a.normal_side = 'CREDIT'"
                    + "        THEN l.credit_cents END), 0) AS invest_cr"
                    + " FROM journal_entries e"
                    + " JOIN journal_lines l ON l.entry_id = e.id"
                    + " JOIN accounts a ON a.id = l.account_id"
                    + " WHERE e.period_id = ? AND e.posted = 1"
                    + "   AND e.type IN ('NORMAL','REVERSING','ADJUSTING')"
                    + " GROUP BY a.id ORDER BY a.code";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setLong(1, periodId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Account account = new Account(
                                rs.getLong("id"),
                                rs.getLong("client_id"),
                                rs.getString("code"),
                                rs.getString("name"),
                                AccountType.parse(rs.getString("type")),
                                Side.parse(rs.getString("normal_side")),
                                rs.getInt("is_permanent") == 1,
                                rs.getInt("is_retained_earnings") == 1,
                                null,
                                rs.getInt("active") == 1);
                        WorksheetRow row = buildRow(account, format,
                                rs.getLong("unadj_dr"), rs.getLong("unadj_cr"),
                                rs.getLong("adj_dr"), rs.getLong("adj_cr"),
                                rs.getLong("invest_cr"));
                        if (row.unadjDr() == 0 && row.unadjCr() == 0
                                && row.adjDr() == 0 && row.adjCr() == 0) {
                            continue;   // nets to zero everywhere — the paper
                                        // sheet leaves such lines out entirely
                        }
                        rows.add(row);
                    }
                }
            }

            Totals totals = new Totals(
                    sum(rows, r -> r.unadjDr), sum(rows, r -> r.unadjCr),
                    sum(rows, r -> r.adjDr), sum(rows, r -> r.adjCr),
                    sum(rows, r -> r.atbDr), sum(rows, r -> r.atbCr),
                    sum(rows, r -> r.isDr), sum(rows, r -> r.isCr),
                    sum(rows, r -> r.soceDr), sum(rows, r -> r.soceCr),
                    sum(rows, r -> r.bsDr), sum(rows, r -> r.bsCr));
            long netIncome = totals.isCr - totals.isDr;
            long equityNetCr = rows.stream()
                    .filter(r -> r.account().type() == AccountType.EQUITY)
                    .mapToLong(WorksheetRow::signedNet)
                    .map(n -> -n)
                    .sum();
            long endingCapital = equityNetCr + netIncome;

            return new Worksheet(period, client, format, List.copyOf(rows),
                    totals, netIncome, endingCapital);

        } catch (SQLException e) {
            throw new IllegalStateException("failed to build the worksheet", e);
        }
    }

    /** Routes one account's gross column sums into the netted worksheet cells. */
    private static WorksheetRow buildRow(Account account, WorksheetFormat format,
                                         long unadjDrGross, long unadjCrGross,
                                         long adjDrGross, long adjCrGross, long investCr) {
        long unadjNet = unadjDrGross - unadjCrGross;
        long adjNet = adjDrGross - adjCrGross;
        long unadjDr = Math.max(unadjNet, 0);
        long unadjCr = Math.max(-unadjNet, 0);
        long adjDr = Math.max(adjNet, 0);
        long adjCr = Math.max(-adjNet, 0);

        long net = unadjNet + adjNet;
        long atbDr = Math.max(net, 0);
        long atbCr = Math.max(-net, 0);

        long isDr = 0;
        long isCr = 0;
        long soceDr = 0;
        long soceCr = 0;
        long bsDr = 0;
        long bsCr = 0;

        switch (account.type()) {
            case REVENUE, EXPENSE -> {
                isDr = atbDr;
                isCr = atbCr;
            }
            case ASSET, LIABILITY -> {
                bsDr = atbDr;
                bsCr = atbCr;
            }
            case EQUITY -> {
                // equity always rides the changes-in-equity cells, in BOTH
                // formats — the 10-column sheet merely hides that column
                // pair from printouts, and a user who re-enables it via the
                // table menu sees the amounts that were there all along
                soceDr = atbDr;
                soceCr = atbCr;
                if (format == WorksheetFormat.COLUMNS_10) {
                    // …and the classic 10-column sheet ALSO folds equity into
                    // the balance sheet columns (contra equity on the debit
                    // side), because with no equity columns of its own, that
                    // pair must balance alone
                    bsDr = atbDr;
                    bsCr = atbCr;
                }
            }
        }
        return new WorksheetRow(account, unadjDr, unadjCr, adjDr, adjCr,
                atbDr, atbCr, isDr, isCr, soceDr, soceCr, bsDr, bsCr, investCr);
    }

    private static long sum(List<WorksheetRow> rows, java.util.function.ToLongFunction<WorksheetRow> f) {
        return rows.stream().mapToLong(f).sum();
    }

    // ------------------------------------------------------------------
    // Statements
    // ------------------------------------------------------------------

    /**
     * One line of a statement: the account's amount signed in its section's
     * natural direction. Contra accounts carry negative amounts and render
     * as deduction lines ("(57,000.00)") exactly like the paper statements.
     */
    public record StatementRow(String code, String name, long amountCents) {
    }

    /** Single-step income statement: revenues, expenses, net income. */
    public record IncomeStatement(
            Period period,
            Client client,
            List<StatementRow> revenues,
            List<StatementRow> expenses,
            long totalRevenues,
            long totalExpenses,
            long netIncome) {

        public long netIncome() {
            return netIncome;
        }
    }

    /**
     * Statement of changes in owner's equity. "Beginning capital" is the
     * capital accounts' (equity with a credit normal side) adjusted balance
     * minus the credits posted to them in {@code NORMAL} entries — the
     * period's investments. Contra equity (drawing, treasury shares,
     * dividends declared) is never part of capital: it reads as the
     * withdrawals it is. For a newly onboarded client that honestly reads
     * as beginning zero with the opening credit as the investment; rare
     * adjusting credits straight to a capital account (a revaluation, say)
     * fold into the beginning figure and are documented here.
     */
    public record EquityChange(
            Period period,
            Client client,
            long beginningCapital,
            List<StatementRow> investments,
            long netIncome,
            List<StatementRow> withdrawals,
            long endingCapital) {

        public long endingCapital() {
            return endingCapital;
        }

        /** beginning + investments + net income − withdrawals. */
        public boolean addsUp() {
            long invested = investments.stream().mapToLong(StatementRow::amountCents).sum();
            long drawn = withdrawals.stream().mapToLong(StatementRow::amountCents).sum();
            return endingCapital == beginningCapital + invested + netIncome - drawn;
        }
    }

    /** Balance sheet: assets, liabilities, ending equity — and the proof. */
    public record BalanceSheet(
            Period period,
            Client client,
            List<StatementRow> assets,
            List<StatementRow> liabilities,
            long totalAssets,
            long totalLiabilities,
            long totalEquity) {

        /** Assets = liabilities + equity, every single build. */
        public boolean balanced() {
            return totalAssets == totalLiabilities + totalEquity;
        }
    }

    /** The income statement of one period. */
    public IncomeStatement incomeStatement(long periodId) {
        Worksheet w = worksheet(periodId, WorksheetFormat.COLUMNS_13);
        List<StatementRow> revenues = new ArrayList<>();
        List<StatementRow> expenses = new ArrayList<>();
        for (WorksheetRow r : w.rows()) {
            switch (r.account().type()) {
                case REVENUE -> {
                    if (r.atbCr() - r.atbDr() != 0) {
                        revenues.add(new StatementRow(
                                r.account().code(), r.account().name(), r.atbCr() - r.atbDr()));
                    }
                }
                case EXPENSE -> {
                    if (r.atbDr() - r.atbCr() != 0) {
                        expenses.add(new StatementRow(
                                r.account().code(), r.account().name(), r.atbDr() - r.atbCr()));
                    }
                }
                default -> { }
            }
        }
        long totalRevenues = revenues.stream().mapToLong(StatementRow::amountCents).sum();
        long totalExpenses = expenses.stream().mapToLong(StatementRow::amountCents).sum();
        return new IncomeStatement(w.period(), w.client(), List.copyOf(revenues),
                List.copyOf(expenses), totalRevenues, totalExpenses,
                totalRevenues - totalExpenses);
    }

    /** The statement of changes in owner's equity of one period. */
    public EquityChange equityChange(long periodId) {
        Worksheet w = worksheet(periodId, WorksheetFormat.COLUMNS_13);
        List<StatementRow> investments = new ArrayList<>();
        List<StatementRow> withdrawals = new ArrayList<>();
        long capitalNetCr = 0;
        for (WorksheetRow r : w.rows()) {
            if (r.account().type() != AccountType.EQUITY) {
                continue;
            }
            boolean contraEquity = r.account().normalSide() == Side.DEBIT;
            if (!contraEquity) {
                // capital-type equity only — contra equity (drawing,
                // treasury shares, dividends) is a withdrawal, not capital
                capitalNetCr += r.atbCr() - r.atbDr();
                if (r.investCr() > 0) {
                    investments.add(new StatementRow(r.account().code(),
                            r.account().name(), r.investCr()));
                }
            } else if (r.atbDr() > 0) {
                withdrawals.add(new StatementRow(r.account().code(),
                        r.account().name(), r.atbDr() - r.atbCr()));
            }
        }
        long invested = investments.stream().mapToLong(StatementRow::amountCents).sum();
        long beginning = capitalNetCr - invested;
        return new EquityChange(w.period(), w.client(), beginning,
                List.copyOf(investments), w.netIncome(),
                List.copyOf(withdrawals), w.endingCapital());
    }

    /** The balance sheet of one period (equity at its ending figure). */
    public BalanceSheet balanceSheet(long periodId) {
        Worksheet w = worksheet(periodId, WorksheetFormat.COLUMNS_13);
        List<StatementRow> assets = new ArrayList<>();
        List<StatementRow> liabilities = new ArrayList<>();
        for (WorksheetRow r : w.rows()) {
            switch (r.account().type()) {
                case ASSET -> {
                    if (r.atbDr() - r.atbCr() != 0) {
                        assets.add(new StatementRow(
                                r.account().code(), r.account().name(), r.atbDr() - r.atbCr()));
                    }
                }
                case LIABILITY -> {
                    if (r.atbCr() - r.atbDr() != 0) {
                        liabilities.add(new StatementRow(
                                r.account().code(), r.account().name(), r.atbCr() - r.atbDr()));
                    }
                }
                default -> { }
            }
        }
        long totalAssets = assets.stream().mapToLong(StatementRow::amountCents).sum();
        long totalLiabilities = liabilities.stream().mapToLong(StatementRow::amountCents).sum();
        return new BalanceSheet(w.period(), w.client(), List.copyOf(assets),
                List.copyOf(liabilities), totalAssets, totalLiabilities, w.endingCapital());
    }

    // ------------------------------------------------------------------
    // Snapshots — the immutable audit trail of every report produced
    // ------------------------------------------------------------------

    /** The {@code report_snapshots} kinds this service writes. */
    public enum ReportKind {
        WORKSHEET, INCOME_STATEMENT, SOCE, BALANCE_SHEET
    }

    /**
     * Freezes the worksheet of one period into {@code report_snapshots} as
     * JSON — every column of every row, the totals, net income and ending
     * capital, exactly as computed when the firm produced it.
     *
     * @return the snapshot's database id
     */
    public long snapshotWorksheet(long periodId, WorksheetFormat format) {
        Worksheet w = worksheet(periodId, format);
        Map<String, Object> payload = basePayload(w.period(), w.client());
        payload.put("format", format.name());
        List<Object> rows = new ArrayList<>();
        for (WorksheetRow r : w.rows()) {
            rows.add(rowPayload(r));
        }
        payload.put("rows", rows);
        payload.put("total_unadj_debit_cents", w.totals().unadjDr());
        payload.put("total_unadj_credit_cents", w.totals().unadjCr());
        payload.put("total_adj_debit_cents", w.totals().adjDr());
        payload.put("total_adj_credit_cents", w.totals().adjCr());
        payload.put("total_atb_debit_cents", w.totals().atbDr());
        payload.put("total_atb_credit_cents", w.totals().atbCr());
        payload.put("total_is_debit_cents", w.totals().isDr());
        payload.put("total_is_credit_cents", w.totals().isCr());
        payload.put("total_soce_debit_cents", w.totals().soceDr());
        payload.put("total_soce_credit_cents", w.totals().soceCr());
        payload.put("total_bs_debit_cents", w.totals().bsDr());
        payload.put("total_bs_credit_cents", w.totals().bsCr());
        payload.put("net_income_cents", w.netIncome());
        payload.put("ending_capital_cents", w.endingCapital());
        payload.put("grand_debit_cents", w.grandDr());
        payload.put("grand_credit_cents", w.grandCr());

        return store(w.period(), w.client(), ReportKind.WORKSHEET, payload,
                "rows=%d net_income=%d ending_capital=%d grand=%d/%d".formatted(
                        w.rows().size(), w.netIncome(), w.endingCapital(),
                        w.grandDr(), w.grandCr()));
    }

    /**
     * Freezes one statement of one period into {@code report_snapshots} as
     * JSON.
     *
     * @param kind one of INCOME_STATEMENT, SOCE, BALANCE_SHEET
     * @return the snapshot's database id
     */
    public long snapshotStatement(long periodId, ReportKind kind) {
        Map<String, Object> payload;
        String detail;
        Period period;
        Client client;
        switch (kind) {
            case INCOME_STATEMENT -> {
                IncomeStatement s = incomeStatement(periodId);
                period = s.period();
                client = s.client();
                payload = basePayload(period, client);
                payload.put("revenues", statementRowsPayload(s.revenues()));
                payload.put("expenses", statementRowsPayload(s.expenses()));
                payload.put("total_revenue_cents", s.totalRevenues());
                payload.put("total_expense_cents", s.totalExpenses());
                payload.put("net_income_cents", s.netIncome());
                detail = "revenues=%d expenses=%d net_income=%d".formatted(
                        s.totalRevenues(), s.totalExpenses(), s.netIncome());
            }
            case SOCE -> {
                EquityChange s = equityChange(periodId);
                period = s.period();
                client = s.client();
                payload = basePayload(period, client);
                payload.put("beginning_capital_cents", s.beginningCapital());
                payload.put("investments", statementRowsPayload(s.investments()));
                payload.put("net_income_cents", s.netIncome());
                payload.put("withdrawals", statementRowsPayload(s.withdrawals()));
                payload.put("ending_capital_cents", s.endingCapital());
                detail = "beginning=%d ending=%d".formatted(
                        s.beginningCapital(), s.endingCapital());
            }
            case BALANCE_SHEET -> {
                BalanceSheet s = balanceSheet(periodId);
                period = s.period();
                client = s.client();
                payload = basePayload(period, client);
                payload.put("assets", statementRowsPayload(s.assets()));
                payload.put("liabilities", statementRowsPayload(s.liabilities()));
                payload.put("total_assets_cents", s.totalAssets());
                payload.put("total_liabilities_cents", s.totalLiabilities());
                payload.put("total_equity_cents", s.totalEquity());
                detail = "assets=%d liabilities=%d equity=%d".formatted(
                        s.totalAssets(), s.totalLiabilities(), s.totalEquity());
            }
            default -> throw new IllegalArgumentException(
                    "statement snapshots need a statement kind, not " + kind);
        }
        return store(period, client, kind, payload, detail);
    }

    private Map<String, Object> basePayload(Period period, Client client) {
        Map<String, Object> payload = new java.util.LinkedHashMap<>();
        payload.put("period", period.name());
        payload.put("period_start", period.start().toString());
        payload.put("period_end", period.end().toString());
        payload.put("client", client.code());
        payload.put("client_name", client.name());
        payload.put("base_currency", client.baseCurrency());
        payload.put("as_of", nowStamp());
        return payload;
    }

    private Map<String, Object> rowPayload(WorksheetRow r) {
        Map<String, Object> row = new java.util.LinkedHashMap<>();
        row.put("code", r.account().code());
        row.put("name", r.account().name());
        row.put("type", r.account().type().name());
        row.put("unadj_debit_cents", r.unadjDr());
        row.put("unadj_credit_cents", r.unadjCr());
        row.put("adj_debit_cents", r.adjDr());
        row.put("adj_credit_cents", r.adjCr());
        row.put("atb_debit_cents", r.atbDr());
        row.put("atb_credit_cents", r.atbCr());
        row.put("is_debit_cents", r.isDr());
        row.put("is_credit_cents", r.isCr());
        row.put("soce_debit_cents", r.soceDr());
        row.put("soce_credit_cents", r.soceCr());
        row.put("bs_debit_cents", r.bsDr());
        row.put("bs_credit_cents", r.bsCr());
        return row;
    }

    private List<Object> statementRowsPayload(List<StatementRow> rows) {
        List<Object> out = new ArrayList<>();
        for (StatementRow r : rows) {
            Map<String, Object> row = new java.util.LinkedHashMap<>();
            row.put("code", r.code());
            row.put("name", r.name());
            row.put("amount_cents", r.amountCents());
            out.add(row);
        }
        return out;
    }

    /** One transaction: the snapshot row plus its audit entry. */
    private long store(Period period, Client client, ReportKind kind,
                       Map<String, Object> payload, String detail) {
        String json;
        try {
            json = JSON.writeValueAsString(payload);
        } catch (Exception e) {
            throw new IllegalStateException("failed to serialize the report", e);
        }
        String asOf = (String) payload.get("as_of");

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                long id;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO report_snapshots(client_id, period_id, kind, as_of, payload)"
                                + " VALUES (?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setLong(1, client.id());
                    ps.setLong(2, period.id());
                    ps.setString(3, kind.name());
                    ps.setString(4, asOf);
                    ps.setString(5, json);
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new IllegalStateException("SQLite returned no generated key");
                        }
                        id = keys.getLong(1);
                    }
                }
                Audit.write(con, client.id(), period.id(), "SNAPSHOT_REPORT", "REPORT",
                        id, "id=%d kind=%s period='%s' %s".formatted(
                                id, kind, period.name(), detail));
                con.commit();
                return id;

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to snapshot the report", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to snapshot the report", e);
        }
    }

    // ------------------------------------------------------------------
    // CSV export
    // ------------------------------------------------------------------

    /**
     * The worksheet as CSV: one header line, one line per account, then the
     * paper sheet's total rows — unadjusted, adjustments, adjusted trial
     * balance, income statement (with the net income row), changes in equity
     * (with the ending capital row), balance sheet, and the grand totals.
     */
    public String toCsv(Worksheet w) {
        boolean equityColumns = w.format() == WorksheetFormat.COLUMNS_13;
        StringBuilder sb = new StringBuilder();
        sb.append("Account,Unadjusted Dr,Unadjusted Cr,Adjustments Dr,Adjustments Cr,"
                + "Adjusted TB Dr,Adjusted TB Cr,Income Stmt Dr,Income Stmt Cr");
        if (equityColumns) {
            sb.append(",Equity Dr,Equity Cr");
        }
        sb.append(",Balance Sheet Dr,Balance Sheet Cr\n");

        for (WorksheetRow r : w.rows()) {
            sb.append(csv(r.account().code())).append(',')
                    .append(csv(r.account().name())).append(',')
                    .append(amount(r.unadjDr())).append(',')
                    .append(amount(r.unadjCr())).append(',')
                    .append(amount(r.adjDr())).append(',')
                    .append(amount(r.adjCr())).append(',')
                    .append(amount(r.atbDr())).append(',')
                    .append(amount(r.atbCr())).append(',')
                    .append(amount(r.isDr())).append(',')
                    .append(amount(r.isCr()));
            if (equityColumns) {
                sb.append(',').append(amount(r.soceDr()))
                        .append(',').append(amount(r.soceCr()));
            }
            sb.append(',').append(amount(r.bsDr()))
                    .append(',').append(amount(r.bsCr())).append('\n');
        }

        // the paper sheet's special rows, each total in its own column group
        long niDr = Math.max(w.netIncome(), 0);
        long niCr = Math.max(-w.netIncome(), 0);
        long ecDr = Math.max(w.endingCapital(), 0);
        long ecCr = Math.max(-w.endingCapital(), 0);

        csvTotalRow(sb, "TOTAL Unadjusted",
                w.totals().unadjDr(), w.totals().unadjCr(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        csvTotalRow(sb, "TOTAL Adjustments",
                0, 0, w.totals().adjDr(), w.totals().adjCr(), 0, 0, 0, 0, 0, 0, 0, 0);
        csvTotalRow(sb, "TOTAL Adjusted Trial Balance",
                0, 0, 0, 0, w.totals().atbDr(), w.totals().atbCr(), 0, 0, 0, 0, 0, 0);
        if (equityColumns) {
            csvTotalRow(sb, "NET INCOME",
                    0, 0, 0, 0, 0, 0, niDr, niCr, niCr, niDr, 0, 0);
            csvTotalRow(sb, "TOTAL Income Statement",
                    0, 0, 0, 0, 0, 0, w.isGrandDr(), w.isGrandCr(), 0, 0, 0, 0);
            csvTotalRow(sb, "TOTAL Changes in Owner's Equity",
                    0, 0, 0, 0, 0, 0, 0, 0, w.soceGrandDr(), w.soceGrandCr(), 0, 0);
            csvTotalRow(sb, "ENDING CAPITAL",
                    0, 0, 0, 0, 0, 0, 0, 0, ecDr, ecCr, ecCr, ecDr);
            csvTotalRow(sb, "TOTAL Balance Sheet",
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w.bsGrandDr(), w.bsGrandCr());
            csvTotalRow(sb, "TOTALS",
                    w.totals().unadjDr(), w.totals().unadjCr(),
                    w.totals().adjDr(), w.totals().adjCr(),
                    w.totals().atbDr(), w.totals().atbCr(),
                    w.isGrandDr(), w.isGrandCr(),
                    w.soceGrandDr(), w.soceGrandCr(),
                    w.bsGrandDr(), w.bsGrandCr());
        } else {
            csvTotalRow(sb, "NET INCOME",
                    0, 0, 0, 0, 0, 0, niDr, niCr, niCr, niDr);
            csvTotalRow(sb, "TOTAL Income Statement",
                    0, 0, 0, 0, 0, 0, w.isGrandDr(), w.isGrandCr(), 0, 0);
            csvTotalRow(sb, "TOTAL Balance Sheet",
                    0, 0, 0, 0, 0, 0, 0, 0, w.bsGrandDr(), w.bsGrandCr());
            csvTotalRow(sb, "TOTALS",
                    w.totals().unadjDr(), w.totals().unadjCr(),
                    w.totals().adjDr(), w.totals().adjCr(),
                    w.totals().atbDr(), w.totals().atbCr(),
                    w.isGrandDr(), w.isGrandCr(),
                    w.bsGrandDr(), w.bsGrandCr());
        }
        return sb.toString();
    }

    /**
     * One total/special row of the worksheet CSV: the label plus the column
     * cells — twelve for the 13-column format, ten when the equity pair is
     * folded away — so every total lands in its own column group exactly
     * like the paper sheet prints it.
     */
    private void csvTotalRow(StringBuilder sb, String label, long... cells) {
        sb.append(csv(label));
        for (long cell : cells) {
            sb.append(',').append(amount(cell));
        }
        sb.append('\n');
    }

    /** The income statement as CSV. */
    public String toCsv(IncomeStatement s) {
        StringBuilder sb = new StringBuilder("Income Statement,Amount\n");
        for (StatementRow r : s.revenues()) {
            sb.append(csv(r.name())).append(',').append(amount(r.amountCents())).append('\n');
        }
        sb.append(csv("Total revenues")).append(',').append(amount(s.totalRevenues())).append('\n');
        for (StatementRow r : s.expenses()) {
            sb.append(csv(r.name())).append(',').append(amount(r.amountCents())).append('\n');
        }
        sb.append(csv("Total expenses")).append(',').append(amount(s.totalExpenses())).append('\n');
        sb.append(csv(s.netIncome() >= 0 ? "NET INCOME" : "NET LOSS"))
                .append(',').append(amount(Math.abs(s.netIncome()))).append('\n');
        return sb.toString();
    }

    /** The statement of changes in equity as CSV. */
    public String toCsv(EquityChange s) {
        StringBuilder sb = new StringBuilder("Changes in Owner's Equity,Amount\n");
        sb.append(csv("Capital, beginning")).append(',').append(amount(s.beginningCapital())).append('\n');
        for (StatementRow r : s.investments()) {
            sb.append(csv("Add: " + r.name())).append(',').append(amount(r.amountCents())).append('\n');
        }
        sb.append(csv(s.netIncome() >= 0
                        ? "Add: Net income" : "Less: Net loss"))
                .append(',').append(amount(Math.abs(s.netIncome()))).append('\n');
        for (StatementRow r : s.withdrawals()) {
            sb.append(csv("Less: " + r.name())).append(',').append(amount(r.amountCents())).append('\n');
        }
        sb.append(csv("Capital, ending")).append(',').append(amount(s.endingCapital())).append('\n');
        return sb.toString();
    }

    /** The balance sheet as CSV (deduction amounts in parentheses). */
    public String toCsv(BalanceSheet s) {
        StringBuilder sb = new StringBuilder("Balance Sheet,Amount\n");
        for (StatementRow r : s.assets()) {
            sb.append(csv(r.name())).append(',').append(signed(r.amountCents())).append('\n');
        }
        sb.append(csv("Total assets")).append(',').append(amount(s.totalAssets())).append('\n');
        for (StatementRow r : s.liabilities()) {
            sb.append(csv(r.name())).append(',').append(signed(r.amountCents())).append('\n');
        }
        sb.append(csv("Total liabilities")).append(',').append(amount(s.totalLiabilities())).append('\n');
        sb.append(csv("Total equity, ending")).append(',').append(amount(s.totalEquity())).append('\n');
        sb.append(csv("TOTAL LIABILITIES AND EQUITY"))
                .append(',').append(amount(s.totalLiabilities() + s.totalEquity())).append('\n');
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // HTML export — all three statements, print-ready
    // ------------------------------------------------------------------

    /**
     * One self-contained HTML page carrying all three statements of a
     * period — inline CSS, no external resources, print-friendly — so "print
     * to PDF" in any browser produces the client-ready document.
     */
    public String toHtml(IncomeStatement income, EquityChange equity, BalanceSheet balance) {
        String cur = income.client().baseCurrency();
        StringBuilder sb = new StringBuilder(4096);
        sb.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n");
        sb.append("<title>").append(htmlEsc(income.client().name()))
                .append(" — Financial Statements</title>\n");
        sb.append("""
                <style>
                  body { font-family: Georgia, 'Times New Roman', serif; margin: 40px auto;
                         max-width: 720px; color: #1f2328; }
                  h1 { font-size: 22px; margin-bottom: 2px; }
                  h2 { font-size: 15px; font-weight: normal; color: #57606a; margin-top: 0; }
                  h3 { font-size: 17px; border-bottom: 2px solid #1f2328;
                       padding-bottom: 4px; margin-top: 34px; }
                  table { width: 100%; border-collapse: collapse; font-size: 14px; }
                  td { padding: 3px 8px 3px 0; }
                  td.num { text-align: right; white-space: nowrap; }
                  tr.total td { border-top: 1px solid #8c959f; font-weight: bold; }
                  tr.grand td { border-top: 3px double #1f2328; font-weight: bold; }
                  td.neg { color: #8c959f; }
                  .subtle { color: #57606a; font-size: 12px; margin-top: 28px; }
                  @media print { body { margin: 0; } }
                </style>
                </head>
                <body>
                """);
        sb.append("<h1>").append(htmlEsc(income.client().name())).append("</h1>\n");
        sb.append("<h2>Financial Statements — ").append(htmlEsc(income.period().name()))
                .append(" (").append(income.period().start()).append(" to ")
                .append(income.period().end()).append(") · amounts in ")
                .append(htmlEsc(cur)).append("</h2>\n");

        // Income statement
        sb.append("<h3>Income Statement</h3>\n<table>\n");
        for (StatementRow r : income.revenues()) {
            htmlRow(sb, r.name(), amount(r.amountCents()), "");
        }
        htmlRow(sb, "Total revenues", amount(income.totalRevenues()), "total");
        for (StatementRow r : income.expenses()) {
            htmlRow(sb, r.name(), amount(r.amountCents()), "");
        }
        htmlRow(sb, "Total expenses", amount(income.totalExpenses()), "total");
        htmlRow(sb, income.netIncome() >= 0 ? "NET INCOME" : "NET LOSS",
                amount(Math.abs(income.netIncome())), "grand");
        sb.append("</table>\n");

        // Statement of changes in equity
        sb.append("<h3>Statement of Changes in Owner's Equity</h3>\n<table>\n");
        htmlRow(sb, "Capital, beginning", amount(equity.beginningCapital()), "");
        for (StatementRow r : equity.investments()) {
            htmlRow(sb, "Add: " + r.name(), amount(r.amountCents()), "");
        }
        htmlRow(sb, equity.netIncome() >= 0 ? "Add: Net income" : "Less: Net loss",
                amount(Math.abs(equity.netIncome())), "");
        for (StatementRow r : equity.withdrawals()) {
            htmlRow(sb, "Less: " + r.name(), amount(r.amountCents()), "");
        }
        htmlRow(sb, "Capital, ending", amount(equity.endingCapital()), "grand");
        sb.append("</table>\n");

        // Balance sheet
        sb.append("<h3>Balance Sheet</h3>\n<table>\n");
        for (StatementRow r : balance.assets()) {
            htmlSignedRow(sb, r.name(), r.amountCents(), "");
        }
        htmlRow(sb, "Total assets", amount(balance.totalAssets()), "total");
        for (StatementRow r : balance.liabilities()) {
            htmlSignedRow(sb, r.name(), r.amountCents(), "");
        }
        htmlRow(sb, "Total liabilities", amount(balance.totalLiabilities()), "total");
        htmlRow(sb, "Total equity, ending", amount(balance.totalEquity()), "total");
        htmlRow(sb, "TOTAL LIABILITIES AND EQUITY",
                amount(balance.totalLiabilities() + balance.totalEquity()), "grand");
        sb.append("</table>\n");

        sb.append("<p class=\"subtle\">Generated by LedgerPro on ")
                .append(htmlEsc(nowStamp()))
                .append(" · totals in ").append(htmlEsc(cur))
                .append(" · balanced: assets ").append(amount(balance.totalAssets()))
                .append(" = liabilities ").append(amount(balance.totalLiabilities()))
                .append(" + equity ").append(amount(balance.totalEquity()))
                .append("</p>\n</body>\n</html>\n");
        return sb.toString();
    }

    private static void htmlRow(StringBuilder sb, String label, String amount, String trClass) {
        sb.append("<tr").append(trClass.isEmpty() ? "" : " class=\"" + trClass + "\"")
                .append("><td>").append(htmlEsc(label))
                .append("</td><td class=\"num\">").append(amount).append("</td></tr>\n");
    }

    private static void htmlSignedRow(StringBuilder sb, String label, long cents, String trClass) {
        String cell = cents < 0
                ? "<span class=\"neg\">(" + amount(-cents) + ")</span>"
                : amount(cents);
        sb.append("<tr").append(trClass.isEmpty() ? "" : " class=\"" + trClass + "\"")
                .append("><td>").append(htmlEsc(label))
                .append("</td><td class=\"num\">").append(cell).append("</td></tr>\n");
    }

    // ------------------------------------------------------------------
    // Small helpers
    // ------------------------------------------------------------------

    /** Exact ungrouped decimal, e.g. {@code 1234.56} — never a float. */
    private static String amount(long cents) {
        return BigDecimal.valueOf(cents, 2).toPlainString();
    }

    /** Signed amount with deduction parentheses for CSV balance sheets. */
    private static String signed(long cents) {
        return cents < 0 ? "(" + amount(-cents) + ")" : amount(cents);
    }

    /** CSV cell: quoted only when it contains a comma, quote or newline. */
    private static String csv(String raw) {
        String text = raw == null ? "" : raw;
        if (text.indexOf(',') >= 0 || text.indexOf('"') >= 0 || text.indexOf('\n') >= 0) {
            return '"' + text.replace("\"", "\"\"") + '"';
        }
        return text;
    }

    private static String htmlEsc(String raw) {
        String text = raw == null ? "" : raw;
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String nowStamp() {
        return LocalDateTime.now(ZoneOffset.UTC).withNano(0).toString().replace('T', ' ');
    }

    private Period readPeriod(Connection con, long periodId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, client_id, name, start_date, end_date, status, closed_at, locked_at"
                        + " FROM periods WHERE id = ?")) {
            ps.setLong(1, periodId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new NoSuchElementException("no period with id " + periodId);
                }
                return mapPeriod(rs);
            }
        }
    }

    private static Period mapPeriod(ResultSet rs) throws SQLException {
        return new Period(rs.getLong("id"), rs.getLong("client_id"),
                rs.getString("name"),
                java.time.LocalDate.parse(rs.getString("start_date")),
                java.time.LocalDate.parse(rs.getString("end_date")),
                "CLOSED".equals(rs.getString("status")),
                rs.getString("closed_at"), rs.getString("locked_at"));
    }

    private Client readClient(Connection con, long clientId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, code, name, base_currency, tax_id, is_setup, active, created_at"
                        + " FROM clients WHERE id = ?")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new NoSuchElementException("no client with id " + clientId);
                }
                return new Client(rs.getLong("id"), rs.getString("code"),
                        rs.getString("name"), rs.getString("base_currency"),
                        rs.getString("tax_id"), rs.getInt("is_setup") == 1,
                        rs.getInt("active") == 1, rs.getString("created_at"));
            }
        }
    }

    /**
     * The most recent stored snapshot of one kind for a period — the export
     * trail attaches to it. Empty when nothing was snapshotted yet.
     */
    public java.util.OptionalLong latestSnapshotId(long clientId, long periodId, ReportKind kind) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT id FROM report_snapshots WHERE client_id = ? AND period_id = ?"
                             + " AND kind = ? ORDER BY id DESC LIMIT 1")) {
            ps.setLong(1, clientId);
            ps.setLong(2, periodId);
            ps.setString(3, kind.name());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? java.util.OptionalLong.of(rs.getLong(1))
                        : java.util.OptionalLong.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to look up snapshot", e);
        }
    }

    /**
     * Records that a snapshot was exported (migration V4): which format
     * ('CSV', 'HTML') and which file it became. Called by the UI after the
     * file write succeeded — the export trail is part of the report's story.
     */
    public void recordExport(long snapshotId, String format, String path) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE report_snapshots SET export_format = ?, export_path = ?"
                                + " WHERE id = ?")) {
                    ps.setString(1, format);
                    ps.setString(2, path);
                    ps.setLong(3, snapshotId);
                    ps.executeUpdate();
                }
                Audit.write(con, null, null, "EXPORT_REPORT", "REPORT", snapshotId,
                        "id=%d format=%s path='%s'".formatted(snapshotId, format, path));
                con.commit();
            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to record export", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to record export", e);
        }
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // the original exception is the one worth throwing
        }
    }
}
