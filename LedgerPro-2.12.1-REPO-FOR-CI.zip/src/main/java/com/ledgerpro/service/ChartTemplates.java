package com.ledgerpro.service;

import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Side;

import java.util.List;
import java.util.Optional;

/**
 * The firm's catalog of preset charts of accounts — what a new client's chart
 * is seeded from (selectable in the New client dialog and in Chart of
 * Accounts → "Apply template…").
 *
 * <p>Three presets ship with the app:</p>
 * <ul>
 *   <li><b>MINIMAL</b> — a lean 16-account service-business chart for tiny
 *       clients that would drown in 54 accounts;</li>
 *   <li><b>STANDARD</b> — the firm's corporate chart, exactly
 *       {@link StandardChart} (delegates to it, so the two can never drift
 *       apart);</li>
 *   <li><b>DETAILED</b> — the standard chart plus 16 finer accounts (extra
 *       banks, receivables, payables, taxes-in-waiting, marketing and
 *       freight expenses, asset sale gain/loss) for clients that want
 *       granular posting.</li>
 * </ul>
 *
 * <p>This class is pure data, like {@link StandardChart}: applying a preset
 * (idempotently, per client, audited) is
 * {@link AccountService#applyChartTemplate(long, Definition)}. Which preset
 * a client was seeded from is remembered in {@code clients.chart_template}
 * (migration V2).</p>
 */
public final class ChartTemplates {

    /** One preset chart: code, display name, sales pitch, and the rows. */
    public record Definition(String code, String name, String description,
                             List<StandardChart.Row> rows) {

        /** Number of accounts in the preset (UI copy: "54 accounts"). */
        public int size() {
            return rows.size();
        }

        /** Compact combo-box rendering. */
        @Override
        public String toString() {
            return name + "  ·  " + rows.size() + " accounts";
        }
    }

    /** The lean chart: bookkeeping essentials for a small service business. */
    private static final Definition MINIMAL = new Definition(
            "MINIMAL",
            "Minimal — small service business",
            "The bookkeeping essentials: one page of accounts, enough for a "
                    + "sole proprietorship or a small service firm that files "
                    + "simple statements. Everything else can be added later.",
            List.of(
                    row("1000", "Cash on Hand", AccountType.ASSET, Side.DEBIT),
                    row("1010", "Cash in Bank — Operating", AccountType.ASSET, Side.DEBIT),
                    row("1100", "Accounts Receivable — Trade", AccountType.ASSET, Side.DEBIT),
                    row("1300", "Prepaid Expenses", AccountType.ASSET, Side.DEBIT),
                    row("1500", "Property, Plant and Equipment", AccountType.ASSET, Side.DEBIT),
                    row("1510", "Accumulated Depreciation — PP&E", AccountType.ASSET, Side.CREDIT),
                    row("2000", "Accounts Payable — Trade", AccountType.LIABILITY, Side.CREDIT),
                    row("2100", "Salaries Payable", AccountType.LIABILITY, Side.CREDIT),
                    row("3000", "Owner's Capital", AccountType.EQUITY, Side.CREDIT),
                    row("3900", "Owner's Drawings", AccountType.EQUITY, Side.DEBIT),
                    row("4000", "Service Revenue", AccountType.REVENUE, Side.CREDIT),
                    row("6000", "Salaries and Wages Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6100", "Rent Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6110", "Utilities Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6150", "Supplies Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6800", "Miscellaneous Expense", AccountType.EXPENSE, Side.DEBIT)));

    /** The firm's standard corporate chart — exactly {@link StandardChart}. */
    private static final Definition STANDARD = new Definition(
            "STANDARD",
            "Standard — corporate chart",
            "The firm's standard corporate chart: four-digit blocks, contra "
                    + "accounts included, ready for a full accounting cycle "
                    + "from journal to closing.",
            StandardChart.rows());

    /** The standard chart plus finer-grained accounts for detailed posting. */
    private static final Definition DETAILED = new Definition(
            "DETAILED",
            "Detailed — corporate chart, finer grain",
            "The standard chart plus 16 finer accounts: extra bank accounts, "
                    + "notes receivable, unearned revenue, lease liability, "
                    + "marketing/freight/recruitment expenses and asset-sale "
                    + "gain/loss — for clients that post at a fine grain.",
            merge(StandardChart.rows(), List.of(
                    row("1030", "Cash in Bank — Payroll", AccountType.ASSET, Side.DEBIT),
                    row("1050", "Cash in Bank — Savings", AccountType.ASSET, Side.DEBIT),
                    row("1120", "Accounts Receivable — Other", AccountType.ASSET, Side.DEBIT),
                    row("1130", "Notes Receivable", AccountType.ASSET, Side.DEBIT),
                    row("1900", "Other Current Assets", AccountType.ASSET, Side.DEBIT),
                    row("2150", "Interest Payable", AccountType.LIABILITY, Side.CREDIT),
                    row("2160", "Unearned Revenue", AccountType.LIABILITY, Side.CREDIT),
                    row("2400", "Lease Liability", AccountType.LIABILITY, Side.CREDIT),
                    row("4060", "Rental Income", AccountType.REVENUE, Side.CREDIT),
                    row("4070", "Commission Income", AccountType.REVENUE, Side.CREDIT),
                    row("4400", "Gain on Sale of Assets", AccountType.REVENUE, Side.CREDIT),
                    row("6020", "Training and Seminar Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6030", "Recruitment Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6170", "Marketing and Advertising Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6180", "Freight and Delivery Expense", AccountType.EXPENSE, Side.DEBIT),
                    row("6900", "Loss on Sale of Assets", AccountType.EXPENSE, Side.DEBIT))));

    private static final List<Definition> ALL = List.of(MINIMAL, STANDARD, DETAILED);

    /** Every preset, smallest first — the order the pickers show them in. */
    public static List<Definition> all() {
        return ALL;
    }

    /** Looks a preset up by its stored code ({@code clients.chart_template}). */
    public static Optional<Definition> byCode(String code) {
        if (code == null || code.isBlank()) {
            return Optional.empty();
        }
        return ALL.stream()
                .filter(d -> d.code().equalsIgnoreCase(code.trim()))
                .findFirst();
    }

    /** Merged in code order — the invariant every preset keeps. */
    private static List<StandardChart.Row> merge(List<StandardChart.Row> base,
                                                 List<StandardChart.Row> extras) {
        return java.util.stream.Stream.concat(base.stream(), extras.stream())
                .sorted(java.util.Comparator.comparing(StandardChart.Row::code))
                .toList();
    }

    private static StandardChart.Row row(String code, String name,
                                         AccountType type, Side side) {
        return new StandardChart.Row(code, name, type, side);
    }

    private ChartTemplates() {
    }
}
