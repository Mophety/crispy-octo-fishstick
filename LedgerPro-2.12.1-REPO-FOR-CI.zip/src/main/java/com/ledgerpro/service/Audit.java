package com.ledgerpro.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * The one writer of {@code audit_log} rows (migration V4 shape). Services
 * keep their own thin {@code audit(...)} helpers, but they all delegate
 * here so every row carries the structured entity links the Audit view
 * reads: what kind of thing, which one, which period.
 *
 * <p>The free-text {@code detail} column stays the human story; the
 * {@code details_json} column carries the same text as a JSON note so the
 * row is machine-readable without a parser for every historical format.</p>
 */
final class Audit {

    private Audit() {
    }

    /**
     * Writes one audit row on the caller's (already transactional) connection.
     *
     * @param clientId   owning client, null for firm-wide actions
     * @param periodId   period touched, when applicable
     * @param action     machine verb, e.g. 'CREATE_ENTRY'
     * @param entityType entity family, e.g. 'ENTRY'; null when not applicable
     * @param entityId   the entity's id, when applicable
     * @param detail     human-readable story; also stored as a JSON note
     */
    static void write(Connection con, Long clientId, Long periodId, String action,
                      String entityType, Long entityId, String detail)
            throws SQLException {
        String json = detail == null || detail.isBlank()
                ? "{}"
                : "{\"note\":" + jsonString(detail) + "}";
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO audit_log(client_id, period_id, action, entity_type,"
                        + " entity_id, detail, details_json, actor)"
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, 'local-user')")) {
            if (clientId == null) {
                ps.setNull(1, java.sql.Types.INTEGER);
            } else {
                ps.setLong(1, clientId);
            }
            if (periodId == null) {
                ps.setNull(2, java.sql.Types.INTEGER);
            } else {
                ps.setLong(2, periodId);
            }
            ps.setString(3, action);
            ps.setString(4, entityType);
            if (entityId == null) {
                ps.setNull(5, java.sql.Types.INTEGER);
            } else {
                ps.setLong(5, entityId);
            }
            ps.setString(6, detail);
            ps.setString(7, json);
            ps.executeUpdate();
        }
    }

    private static String jsonString(String raw) {
        StringBuilder out = new StringBuilder("\"");
        for (char c : raw.toCharArray()) {
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        return out.append('"').toString();
    }
}
