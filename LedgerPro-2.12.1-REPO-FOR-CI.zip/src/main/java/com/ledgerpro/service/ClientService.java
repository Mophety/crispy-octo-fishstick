package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * All reading and writing of the {@code clients} table goes through here.
 *
 * <p>Rules this service guarantees (so the UI never has to think about them):</p>
 * <ul>
 *   <li><b>Never delete.</b> Archiving sets {@code active = 0}; the audit
 *       trail and every historical entry keep pointing at the client.</li>
 *   <li><b>Every mutation is one transaction</b> that also writes an
 *       {@code audit_log} row - the audit trail is not optional.</li>
 *   <li><b>Codes are normalized</b> to trimmed uppercase and validated before
 *       they reach SQLite; the UNIQUE constraint is the backstop, this class
 *       is the front line.</li>
 * </ul>
 */
public final class ClientService {

    /** Firm-friendly limit; SQLite itself imposes none. */
    private static final int MAX_CODE_LENGTH = 12;
    private static final int MAX_NAME_LENGTH = 200;

    private final Database database;

    public ClientService(Database database) {
        this.database = database;
    }

    // ------------------------------------------------------------------
    // Queries
    // ------------------------------------------------------------------

    /**
     * Lists all clients ordered by code.
     *
     * @param includeArchived false = only active clients (the default view);
     *                         true = also the archived ones
     */
    public List<Client> list(boolean includeArchived) {
        String sql = "SELECT id, code, name, base_currency, tax_id, is_setup, active, created_at"
                + " FROM clients"
                + (includeArchived ? "" : " WHERE active = 1")
                + " ORDER BY code";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Client> result = new ArrayList<>();
            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list clients", e);
        }
    }

    /** Looks a client up by code (case-insensitive). */
    public Optional<Client> findByCode(String code) {
        String sql = "SELECT id, code, name, base_currency, tax_id, is_setup, active, created_at"
                + " FROM clients WHERE code = ?";
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, normalizeCode(code));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to look up client", e);
        }
    }

    // ------------------------------------------------------------------
    // Mutations (transactional, audited)
    // ------------------------------------------------------------------

    /**
     * Creates a client and returns the stored row.
     *
     * @throws IllegalArgumentException     blank or malformed code / name
     * @throws DuplicateClientCodeException the code is already in use
     */
    public Client create(String code, String name, String baseCurrency) {
        return create(code, name, baseCurrency, null);
    }

    /**
     * Creates a client, optionally recording which preset chart template
     * (migration V2) the client's chart was — or will be — seeded from, so
     * the Chart of Accounts view can show its provenance. The template's
     * accounts themselves are applied separately (idempotently) by
     * {@link AccountService#applyChartTemplate(long, ChartTemplates.Definition)}.
     *
     * @param chartTemplate preset code from {@link ChartTemplates#all()}, or
     *                      null / blank for an empty custom chart
     * @throws IllegalArgumentException        blank/malformed code or name, bad
     *                                         currency shape, unknown template code
     * @throws DuplicateClientCodeException    the code is already in the firm
     */
    public Client create(String code, String name, String baseCurrency,
                          String chartTemplate) {
        return create(code, name, baseCurrency, chartTemplate, "");
    }

    /**
     * Full form: also records the client's tax identification number
     * (migration V4 column, shown in the register and on reports).
     *
     * @throws IllegalArgumentException        blank/malformed code or name, bad
     *                                         currency shape, unknown template code
     * @throws DuplicateClientCodeException    the code is already in the firm
     */
    public Client create(String code, String name, String baseCurrency,
                          String chartTemplate, String taxId) {
        String validCode = normalizeCode(code);
        String validName = normalizeName(name);
        String currency = normalizeCurrency(baseCurrency);
        String template = chartTemplate == null || chartTemplate.isBlank()
                ? null : requireKnownTemplate(chartTemplate);

        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                long id;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO clients(code, name, base_currency, chart_template,"
                                + " tax_id) VALUES (?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, validCode);
                    ps.setString(2, validName);
                    ps.setString(3, currency);
                    if (template == null) {
                        ps.setNull(4, java.sql.Types.VARCHAR);
                    } else {
                        ps.setString(4, template);
                    }
                    ps.setString(5, normalizeTaxId(taxId));
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new IllegalStateException("SQLite returned no generated key");
                        }
                        id = keys.getLong(1);
                    }
                }
                Audit.write(con, id, null, "CREATE_CLIENT", "CLIENT", id,
                        "code='%s' name='%s' currency=%s chart_template=%s tax_id='%s'".formatted(
                                validCode, validName, currency, template,
                                normalizeTaxId(taxId)));
                con.commit();
                return read(con, id)
                        .orElseThrow(() -> new IllegalStateException("client vanished after insert"));

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof SQLException sx && isUniqueViolation(sx)) {
                    throw new DuplicateClientCodeException(validCode);
                }
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to create client", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to create client", e);
        }
    }

    /**
     * The preset code recorded when this client's chart was seeded
     * ({@code clients.chart_template}), or null for a custom chart.
     */
    public String chartTemplateOf(long clientId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT chart_template FROM clients WHERE id = ?")) {
            ps.setLong(1, clientId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read client chart template", e);
        }
    }

    /** Template provenance must name a shipped preset, stored uppercase. */
    private static String requireKnownTemplate(String raw) {
        String code = raw.trim().toUpperCase(java.util.Locale.ROOT);
        if (ChartTemplates.byCode(code).isEmpty()) {
            throw new IllegalArgumentException(
                    "unknown chart template '" + code + "' — pick one of the shipped presets");
        }
        return code;
    }

    /**
     * Updates an existing client's editable identity fields (2.9.0):
     * code, legal name, base currency and tax id. Data is relational — the
     * journal, periods, accounts and audit trail stay attached by id, so
     * nothing else needs cascading. The UNIQUE code constraint surfaces as
     * {@link DuplicateClientCodeException}.
     *
     * @throws NoSuchElementException no client with this id
     * @throws IllegalArgumentException the same validation {@link #create} runs
     */
    public Client update(long id, String code, String name, String baseCurrency,
                         String taxId) {
        String cleanCode = normalizeCode(code);
        String cleanName = normalizeName(name);
        String cleanCurrency = normalizeCurrency(baseCurrency);
        String cleanTaxId = normalizeTaxId(taxId);
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                Client existing = read(con, id)
                        .orElseThrow(() -> new NoSuchElementException(
                                "no client with id " + id));
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE clients SET code = ?, name = ?, base_currency = ?,"
                                + " tax_id = ? WHERE id = ?")) {
                    ps.setString(1, cleanCode);
                    ps.setString(2, cleanName);
                    ps.setString(3, cleanCurrency);
                    ps.setString(4, cleanTaxId);
                    ps.setLong(5, id);
                    ps.executeUpdate();
                }
                Audit.write(con, id, null, "UPDATE_CLIENT", "CLIENT", id,
                        "code='%s' name='%s' base_currency='%s' tax_id='%s'"
                                .formatted(cleanCode, cleanName, cleanCurrency, cleanTaxId));
                con.commit();
                return read(con, id).orElse(existing);
            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof SQLException sql && isUniqueViolation(sql)) {
                    throw new DuplicateClientCodeException(cleanCode);
                }
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to update client", e);
            }
        } catch (SQLException e) {
            if (isUniqueViolation(e)) {
                throw new DuplicateClientCodeException(cleanCode);
            }
            throw new IllegalStateException("failed to update client", e);
        }
    }

    /**
     * Archives ({@code active = false}) or restores a client.
     *
     * @throws NoSuchElementException no client with this id
     */
    public void setActive(long id, boolean active) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                String code = read(con, id)
                        .orElseThrow(() -> new NoSuchElementException(
                                "no client with id " + id)).code();
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE clients SET active = ? WHERE id = ?")) {
                    ps.setInt(1, active ? 1 : 0);
                    ps.setLong(2, id);
                    ps.executeUpdate();
                }
                Audit.write(con, id, null, active ? "RESTORE_CLIENT" : "ARCHIVE_CLIENT",
                        "CLIENT", id, "code='%s'".formatted(code));
                con.commit();

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to update client", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to update client", e);
        }
    }

    // ------------------------------------------------------------------
    // Validation / normalization helpers
    // ------------------------------------------------------------------

    /** Codes: trimmed, uppercase, 1-12 chars of A-Z, 0-9, '.' or '-'. */
    private static String normalizeCode(String raw) {
        String code = raw == null ? "" : raw.trim().toUpperCase();
        if (code.isEmpty()) {
            throw new IllegalArgumentException("client code must not be blank");
        }
        if (code.length() > MAX_CODE_LENGTH) {
            throw new IllegalArgumentException(
                    "client code must be at most " + MAX_CODE_LENGTH + " characters");
        }
        if (!code.matches("[A-Z0-9.-]+")) {
            throw new IllegalArgumentException(
                    "client code may only contain letters, digits, '.' and '-'");
        }
        return code;
    }

    /** Names: trimmed, 1-200 chars. */
    private static String normalizeName(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (name.isEmpty()) {
            throw new IllegalArgumentException("client name must not be blank");
        }
        if (name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException(
                    "client name must be at most " + MAX_NAME_LENGTH + " characters");
        }
        return name;
    }

    /** Currency: trimmed, uppercase; blank/null falls back to the firm default 'PHP'. */
    private static String normalizeCurrency(String raw) {
        String currency = raw == null ? "" : raw.trim().toUpperCase();
        if (currency.isEmpty()) {
            return "PHP";
        }
        if (!currency.matches("[A-Z]{3}")) {
            throw new IllegalArgumentException(
                    "base currency must be a 3-letter ISO 4217 code (e.g. PHP, USD)");
        }
        return currency;
    }

    // ------------------------------------------------------------------
    // Row plumbing
    // ------------------------------------------------------------------

    private static Client mapRow(ResultSet rs) throws SQLException {
        return new Client(
                rs.getLong("id"),
                rs.getString("code"),
                rs.getString("name"),
                rs.getString("base_currency"),
                rs.getString("tax_id"),
                rs.getInt("is_setup") == 1,
                rs.getInt("active") == 1,
                rs.getString("created_at"));
    }

    private static Optional<Client> read(Connection con, long id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, code, name, base_currency, tax_id, is_setup, active, created_at"
                        + " FROM clients WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        }
    }

    /**
     * Updates the client's tax identification number (migration V4).
     *
     * @throws NoSuchElementException no client with this id
     */
    public void updateTaxId(long id, String taxId) {
        String clean = normalizeTaxId(taxId);
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                String code = read(con, id)
                        .orElseThrow(() -> new NoSuchElementException(
                                "no client with id " + id)).code();
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE clients SET tax_id = ? WHERE id = ?")) {
                    ps.setString(1, clean);
                    ps.setLong(2, id);
                    ps.executeUpdate();
                }
                Audit.write(con, id, null, "UPDATE_CLIENT", "CLIENT", id,
                        "code='%s' tax_id='%s'".formatted(code, clean));
                con.commit();
            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to update client tax id", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to update client tax id", e);
        }
    }

    /**
     * Recomputes {@code clients.is_setup}: true once the client has at least
     * one account AND one period. Called by the account and period services
     * after they create the missing half.
     */
    public void refreshSetup(long clientId) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE clients SET is_setup = CASE WHEN"
                             + " EXISTS(SELECT 1 FROM accounts a WHERE a.client_id = ?)"
                             + " AND EXISTS(SELECT 1 FROM periods p WHERE p.client_id = ?)"
                             + " THEN 1 ELSE 0 END WHERE id = ?")) {
            ps.setLong(1, clientId);
            ps.setLong(2, clientId);
            ps.setLong(3, clientId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("failed to refresh client setup flag", e);
        }
    }

    /** Tax ids: trimmed, at most 32 chars, blank allowed. */
    private static String normalizeTaxId(String raw) {
        String taxId = raw == null ? "" : raw.trim();
        if (taxId.length() > 32) {
            taxId = taxId.substring(0, 32);
        }
        return taxId;
    }

    /** SQLite signals a UNIQUE breach through the message text, not a code. */
    private static boolean isUniqueViolation(SQLException e) {
        String message = e.getMessage();
        return message != null && message.contains("UNIQUE constraint failed: clients.code");
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // rollback failed: the connection is being closed right after anyway
        }
    }
}
