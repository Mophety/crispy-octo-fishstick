package com.ledgerpro.service;

/**
 * Thrown when code, type or normal side of an account that already carries
 * journal lines is about to be changed.
 *
 * <p>Posted history must never be re-classified underneath: the trial
 * balance of Phase 4 groups by the account's type at posting time. Renaming
 * stays open; structure does not. The UI should use
 * {@code AccountService.hasJournalLines(id)} to disable the frozen fields
 * before the user even tries.</p>
 */
public class AccountFrozenException extends IllegalStateException {

    private final String code;

    public AccountFrozenException(String code) {
        super("Account '" + code + "' already has journal lines — its code, type"
                + " and normal side are frozen. Only the name can be changed.");
        this.code = code;
    }

    /** The frozen account's code. */
    public String code() {
        return code;
    }
}
