package com.ledgerpro.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDate;

/**
 * The live {@link RateFetcher}: the open-source Frankfurter API
 * (<a href="https://frankfurter.dev">frankfurter.dev</a>), which serves the
 * European Central Bank's daily reference rates — including PHP.
 *
 * <p>The legacy host {@code api.frankfurter.app} now answers with a 301 to
 * {@code api.frankfurter.dev/v1}; we call the canonical host directly and
 * still follow redirects as a safety net. One endpoint shape serves both
 * "historical date" and "latest":</p>
 * <pre>
 *   GET https://api.frankfurter.dev/v1/2026-10-30?from=USD&amp;to=PHP
 *   GET https://api.frankfurter.dev/v1/latest?from=USD&amp;to=PHP
 *   {"amount":1.0,"base":"USD","date":"2026-10-30","rates":{"PHP":56.732}}
 * </pre>
 *
 * <p>{@link #parse(String, String)} is package-visible so the response shape
 * is unit-tested with canned JSON, and the HTTP layer stays thin. The live
 * round-trip is exercised by {@code com.ledgerpro.dev.FxLiveCheck} (a dev
 * tool, deliberately outside the deterministic build gate).</p>
 */
public final class FrankfurterFetcher implements RateFetcher {

    private static final String BASE_URL = "https://api.frankfurter.dev/v1";

    private static final ObjectMapper JSON = new ObjectMapper();

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    @Override
    public Result fetch(LocalDate date, String from, String to) throws Exception {
        String path = date == null ? "latest" : date.toString();
        URI uri = URI.create(BASE_URL + "/" + path + "?from=" + from + "&to=" + to);
        HttpRequest request = HttpRequest.newBuilder(uri)
                .timeout(Duration.ofSeconds(12))
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IOException(describeFailure(response));
        }
        return parse(response.body(), to);
    }

    /**
     * Parses a Frankfurter response body into a {@link Result}.
     *
     * @throws IOException the body is not the expected shape (unknown
     *                     currency, no data for the date, …)
     */
    static Result parse(String body, String to) throws IOException {
        JsonNode root;
        try {
            root = JSON.readTree(body);
        } catch (IOException e) {
            throw new IOException("Frankfurter returned a non-JSON body", e);
        }
        JsonNode rate = root.path("rates").path(to);
        if (!rate.isNumber()) {
            String message = root.path("message").asText("");
            throw new IOException("no " + to + " rate in the Frankfurter response"
                    + (message.isBlank() ? "" : ": " + message));
        }
        String date = root.path("date").asText("");
        if (date.isBlank()) {
            throw new IOException("Frankfurter response carries no date");
        }
        return new Result(LocalDate.parse(date), rate.asDouble());
    }

    /** Builds the friendliest possible line for a non-200 reply. */
    private static String describeFailure(HttpResponse<String> response) {
        String body = response.body() == null ? "" : response.body().trim();
        String message = "";
        try {
            message = JSON.readTree(body).path("message").asText("");
        } catch (Exception ignored) {
            // body was not JSON — fall back to the raw text
            message = body;
        }
        return "Frankfurter responded HTTP " + response.statusCode()
                + (message.isBlank() ? "" : " — " + message);
    }
}
