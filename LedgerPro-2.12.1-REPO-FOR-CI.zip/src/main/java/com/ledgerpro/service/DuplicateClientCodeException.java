package com.ledgerpro.service;

/**
 * Thrown when a client is created with a code that already exists.
 *
 * <p>Carried as its own type (instead of a raw {@link java.sql.SQLException})
 * so the UI can show a friendly, actionable message instead of a stack trace:
 * "Client code 'NRTH' already exists".</p>
 */
public class DuplicateClientCodeException extends IllegalStateException {

    private final String code;

    public DuplicateClientCodeException(String code) {
        super("Client code '" + code + "' already exists");
        this.code = code;
    }

    /** The offending code, normalized to uppercase. */
    public String code() {
        return code;
    }
}
