package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.FxRate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The FX-rate workstation of Phase 3: a persistent cache of rates
 * ({@code fx_rates}) fed by the live Frankfurter client or by manual entry,
 * with lookup rules the journal of Phase 4 will rely on.
 *
 * <p>Lookup semantics of {@link #latestUpTo(LocalDate, String, String)}:</p>
 * <ul>
 *   <li>exact-date row first, then the <b>newest cached row dated on or
 *       before</b> the requested date — a rate is valid until replaced;</li>
 *   <li>if the directed pair has nothing cached, the inverse pair is used
 *       with the inverted rate (1 ÷ rate); a directly cached rate always
 *       beats an inverted one;</li>
 *   <li>still nothing → {@link Optional#empty()} — the caller decides whether
 *       to fetch, ask for a manual rate, or reject the entry.</li>
 * </ul>
 *
 * <p>Every stored rate writes an {@code audit_log} row with a NULL client —
 * FX rates belong to the firm, not to any one client.</p>
 */
public final class FxRateService {

    private final Database database;
    private final RateFetcher fetcher;

    /** Live configuration: rates come from the Frankfurter API. */
    public FxRateService(Database database) {
        this(database, new FrankfurterFetcher());
    }

    /** Test configuration: inject a deterministic fetcher. */
    public FxRateService(Database database, RateFetcher fetcher) {
        this.database = database;
        this.fetcher = fetcher;
    }

    // ------------------------------------------------------------------
    // Live fetch + manual entry (both write the cache and the audit log)
    // ------------------------------------------------------------------

    /**
     * Fetches a rate from the provider and caches it under the provider's
     * effective date (a weekend request stores Friday's rate, truthfully
     * dated).
     *
     * @throws FxUnavailableException   network/timeout/provider rejection
     * @throws IllegalArgumentException malformed currency codes, or from == to
     */
    public FxRate fetchAndStore(LocalDate date, String from, String to) {
        String f = normalizeCurrency(from);
        String t = normalizeCurrency(to);
        requireDistinct(f, t);

        RateFetcher.Result result;
        try {
            result = fetcher.fetch(date, f, t);
        } catch (Exception e) {
            throw new FxUnavailableException(
                    "could not fetch " + f + " → " + t + " from Frankfurter"
                            + (date == null ? "" : " for " + date) + ": "
                            + (e.getMessage() == null ? e.toString() : e.getMessage()), e);
        }
        if (result.rate() <= 0 || !Double.isFinite(result.rate())) {
            throw new FxUnavailableException(
                    "Frankfurter returned a non-positive rate (" + result.rate() + ")");
        }
        return upsert(result.date(), f, t, result.rate(), FxRate.Source.FRANKFURTER,
                "fetched from the Frankfurter API");
    }

    /**
     * Stores a rate typed by the accountant. A manual rate intentionally
     * overrides a cached API rate for the same date and pair — it is the
     * firm's explicit word against the reference set.
     *
     * @throws IllegalArgumentException malformed currencies, from == to,
     *                                  or a non-positive/non-finite rate
     */
    public FxRate putManual(LocalDate date, String from, String to, double rate) {
        return putManual(date, from, to, rate, "");
    }

    /**
     * Stores a rate typed by the accountant together with a free-text note
     * ('year-end rate from the bank statement') — migration V4's note column.
     */
    public FxRate putManual(LocalDate date, String from, String to, double rate, String note) {
        if (date == null) {
            throw new IllegalArgumentException("rate date must not be blank");
        }
        String f = normalizeCurrency(from);
        String t = normalizeCurrency(to);
        requireDistinct(f, t);
        if (!Double.isFinite(rate) || rate <= 0) {
            throw new IllegalArgumentException(
                    "the rate must be a positive number (e.g. 56.73)");
        }
        return upsert(date, f, t, rate, FxRate.Source.MANUAL, note);
    }

    // ------------------------------------------------------------------
    // Lookups (read-only, no audit rows)
    // ------------------------------------------------------------------

    /** Exact-date cached row, if present. */
    public Optional<FxRate> findCached(LocalDate date, String from, String to) {
        if (date == null) {
            throw new IllegalArgumentException("a cached-rate lookup needs a date");
        }
        String f = normalizeCurrency(from);
        String t = normalizeCurrency(to);
        requireDistinct(f, t);
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(SELECT + " WHERE rate_date = ?"
                     + " AND quote_currency = ? AND base_currency = ?")) {
            ps.setString(1, date.toString());
            ps.setString(2, f);
            ps.setString(3, t);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to look up rate", e);
        }
    }

    /**
     * The rate to use for a date: newest cached row dated on or before it;
     * falls back to the inverse pair (inverted) when the direction itself
     * was never cached. See the class javadoc for the precedence rules.
     */
    public Optional<FxRate> latestUpTo(LocalDate date, String from, String to) {
        String f = normalizeCurrency(from);
        String t = normalizeCurrency(to);
        requireDistinct(f, t);

        Optional<FxRate> direct = newestOnOrBefore(f, t, date);
        if (direct.isPresent()) {
            return direct;
        }
        return newestOnOrBefore(t, f, date).map(FxRateService::inverted);
    }

    /** The most recently stored rows, newest first — the FX view's table. */
    public List<FxRate> listRecent(int limit) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     SELECT + " ORDER BY rate_date DESC, quote_currency, base_currency LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                List<FxRate> result = new ArrayList<>();
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
                return result;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to list rates", e);
        }
    }

    // ------------------------------------------------------------------
    // Storage
    // ------------------------------------------------------------------

    private static final String SELECT =
            "SELECT id, rate_date AS as_of_date, quote_currency AS from_cur,"
            + " base_currency AS to_cur, rate, source, fetched_at, note FROM fx_rates";

    /** Upserts one row (without a note) and returns the stored snapshot. */
    private FxRate upsert(LocalDate date, String from, String to, double rate,
                          FxRate.Source source) {
        return upsert(date, from, to, rate, source, "");
    }

    /** Upserts one row with a free-text note and returns the stored snapshot. */
    private FxRate upsert(LocalDate date, String from, String to, double rate,
                          FxRate.Source source, String note) {
        try (Connection con = database.open()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO fx_rates(base_currency, quote_currency, rate_date,"
                                + " rate, source, note)"
                                + " VALUES (?, ?, ?, ?, ?, ?)"
                                + " ON CONFLICT(base_currency, quote_currency, rate_date)"
                                + " DO UPDATE SET"
                                + " rate = excluded.rate, source = excluded.source,"
                                + " note = excluded.note,"
                                + " fetched_at = datetime('now')")) {
                    ps.setString(1, to);
                    ps.setString(2, from);
                    ps.setString(3, date.toString());
                    ps.setDouble(4, rate);
                    ps.setString(5, source.name());
                    ps.setString(6, note == null ? "" : note.trim());
                    ps.executeUpdate();
                }
                Audit.write(con, null, null, "FX_RATE_STORED", "FX_RATE", null,
                        "%s→%s@%s rate=%s source=%s".formatted(from, to, date, rate, source));
                con.commit();

            } catch (Exception e) {
                rollbackQuietly(con);
                if (e instanceof RuntimeException rx) {
                    throw rx;
                }
                throw new IllegalStateException("failed to store rate", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to store rate", e);
        }

        // read back so the caller sees exactly what the table now holds
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(SELECT
                     + " WHERE rate_date = ? AND quote_currency = ? AND base_currency = ?")) {
            ps.setString(1, date.toString());
            ps.setString(2, from);
            ps.setString(3, to);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to read back rate", e);
        }
        throw new IllegalStateException("stored rate vanished from fx_rates");
    }

    private Optional<FxRate> newestOnOrBefore(String from, String to, LocalDate date) {
        try (Connection con = database.open();
             PreparedStatement ps = con.prepareStatement(
                     SELECT + " WHERE quote_currency = ? AND base_currency = ? AND rate_date <= ?"
                             + " ORDER BY rate_date DESC LIMIT 1")) {
            ps.setString(1, from);
            ps.setString(2, to);
            ps.setString(3, date.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("failed to look up rate", e);
        }
    }

    /** The mirror of a cached row: same economics, opposite direction. */
    private static FxRate inverted(FxRate rate) {
        return new FxRate(0, rate.asOf(), rate.toCur(), rate.fromCur(),
                1.0 / rate.rate(), rate.source(), rate.fetchedAt(), rate.note());
    }

    // ------------------------------------------------------------------
    // Validation / row plumbing
    // ------------------------------------------------------------------

    /** Currencies: trimmed, uppercase, exactly 3 letters (ISO 4217 shape). */
    private static String normalizeCurrency(String raw) {
        String currency = raw == null ? "" : raw.trim().toUpperCase();
        if (!currency.matches("[A-Z]{3}")) {
            throw new IllegalArgumentException(
                    "currency must be a 3-letter ISO 4217 code (e.g. USD, PHP), not '" + raw + "'");
        }
        return currency;
    }

    private static void requireDistinct(String from, String to) {
        if (from.equals(to)) {
            throw new IllegalArgumentException(
                    "the two currencies must differ — a rate from a currency to itself is 1");
        }
    }

    private static FxRate mapRow(ResultSet rs) throws SQLException {
        return new FxRate(
                rs.getLong("id"),
                LocalDate.parse(rs.getString("as_of_date")),
                rs.getString("from_cur"),
                rs.getString("to_cur"),
                rs.getDouble("rate"),
                FxRate.Source.parse(rs.getString("source")),
                rs.getString("fetched_at"),
                rs.getString("note"));
    }


    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // rollback failed: the connection is being closed right after anyway
        }
    }
}
