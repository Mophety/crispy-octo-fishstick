package com.ledgerpro;

import com.ledgerpro.db.Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Command-line health check (Phase 1 core, extended in Phase 3).
 *
 * <p>Creates the SQLite database (if missing), runs all Flyway migrations,
 * then prints the journal mode, the applied migrations, the table list and
 * the workspace counts (clients, chart-of-accounts rows, cached FX rates).
 * Run it any time with:</p>
 *
 * <pre>mvn exec:java</pre>
 */
public final class DbCli {

    public static void main(String[] args) {
        Database db = new Database();

        System.out.println("LedgerPro - database check");
        System.out.println("  file      : " + db.url());
        System.out.println("  migrating : running Flyway ...");

        db.migrate(); // creates the schema if missing, upgrades if outdated

        try (Connection con = db.open()) {
            System.out.println("  journal   : "
                    + scalar(con, "PRAGMA journal_mode;")
                    + "  (WAL = crash-safe, readers never block the writer)");

            System.out.println();
            System.out.println("Applied migrations:");
            for (String row : list(con,
                    "SELECT version || '  ' || description"
                            + " FROM flyway_schema_history"
                            + " ORDER BY installed_rank")) {
                System.out.println("  " + row);
            }

            System.out.println();
            System.out.println("Tables created:");
            for (String row : list(con,
                    "SELECT name FROM sqlite_master WHERE type='table'"
                            + " AND name NOT LIKE 'sqlite_%'"
                            + " AND name != 'flyway_schema_history'"
                            + " ORDER BY name")) {
                System.out.println("  " + row);
            }

            System.out.println();
            System.out.println("Workspace counts:");
            System.out.println("  clients            : "
                    + scalar(con, "SELECT COUNT(*) FROM clients"));
            System.out.println("  accounts (all charts): "
                    + scalar(con, "SELECT COUNT(*) FROM accounts"));
            System.out.println("  cached FX rates    : "
                    + scalar(con, "SELECT COUNT(*) FROM fx_rates"));
            System.out.println("  audit rows         : "
                    + scalar(con, "SELECT COUNT(*) FROM audit_log"));

            System.out.println();
            System.out.println("Database is ready.");
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to read database summary", e);
        }
    }

    /** Runs a query that returns a single value in the first column. */
    private static String scalar(Connection con, String sql) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getString(1) : "?";
        }
    }

    /** Runs a query and collects the first column of every row. */
    private static List<String> list(Connection con, String sql) throws SQLException {
        List<String> rows = new ArrayList<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                rows.add(rs.getString(1));
            }
        }
        return rows;
    }

    private DbCli() {
        // utility class - no instances
    }
}
