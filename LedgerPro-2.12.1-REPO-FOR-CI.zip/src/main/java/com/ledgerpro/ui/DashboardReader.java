package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Period;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * The dashboard's ONE read pass (2.12.1, the C1/C2 correctness fix).
 *
 * <p>Extracted from DashboardView's private SQL so it can be regression
 * tested without JavaFX. Two accounting defects lived there:</p>
 *
 * <ul>
 *   <li><b>C1 — the proof.</b> The old query read only NORMAL and
 *       ADJUSTING entries and proved {@code assets = liabilities +
 *       equity}, which is the equation for a <i>closed</i> period. For an
 *       open period the equation is {@code assets = liabilities + equity
 *       accounts + current-period net income}; leaving net income out made
 *       a perfectly balanced ledger read OUT OF BALANCE whenever the
 *       period had income. The read now includes REVERSING entries (a
 *       voided entry plus its reversal nets to zero — the worksheet and
 *       trial balance already worked this way) and the proof uses the full
 *       equation. When the period IS closed the closing entries are
 *       excluded by the same filter the worksheet uses, so the proof keeps
 *       net income out — exactly the report's arithmetic, no
 *       double-count.</li>
 *   <li><b>C2 — the amounts.</b> The recent-entries amount was
 *       {@code SUM(COALESCE(debit, credit))} over every line of the entry,
 *       which is both sides of the double entry — twice the entry's
 *       amount. The Journal's Amount column shows total debits (one side),
 *       so the dashboard now does too, and the "their volume" figure is
 *       computed with the same rule.</li>
 * </ul>
 *
 * <p>Everything else the old read produced — monthly revenue/expense
 * series, expense composition by account name, posted/draft/voided counts,
 * the last eight entries of the client — is produced unchanged, on one
 * connection, exactly as before.</p>
 */
final class DashboardReader {

    private final Database database;

    DashboardReader(Database database) {
        this.database = database;
    }

    /**
     * Reads the aggregates of one period (one connection for everything).
     *
     * @param clientId the working client (the recent-entries read is
     *                 client-scoped, not period-scoped)
     * @param periodId the selected period
     * @param closed   true when the period is closed — closing entries are
     *                 then excluded (they never existed in the dashboard's
     *                 filter before either; the flag only tightens the
     *                 equation, not the rows)
     */
    com.ledgerpro.ui.DashboardView.ClientAggregates read(long clientId, long periodId, boolean closed) {
        com.ledgerpro.ui.DashboardView.ClientAggregates agg = new com.ledgerpro.ui.DashboardView.ClientAggregates();
        agg.periodClosed = closed;
        try (Connection con = database.open()) {
            // (a) monthly revenue/expense series + expense composition +
            //     the type routing, from the posted lines of the period.
            //     2.12.1: REVERSING joins NORMAL and ADJUSTING — the voided
            //     entry and its reversal net to zero, the same filter the
            //     worksheet and the trial balance already use. CLOSING is
            //     still excluded: a closed period's income was already
            //     folded into equity by its closing entries.
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT substr(e.entry_date, 1, 7) AS month,"
                            + " a.type AS type, a.name AS name,"
                            + " SUM(COALESCE(l.debit_cents, 0)) AS dr,"
                            + " SUM(COALESCE(l.credit_cents, 0)) AS cr"
                            + " FROM journal_entries e"
                            + " JOIN journal_lines l ON l.entry_id = e.id"
                            + " JOIN accounts a ON a.id = l.account_id"
                            + " WHERE e.period_id = ? AND e.posted = 1"
                            + " AND e.type IN ('NORMAL','REVERSING','ADJUSTING')"
                            + " GROUP BY month, a.id"
                            + " ORDER BY month")) {
                ps.setLong(1, periodId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String month = rs.getString("month");
                        long dr = rs.getLong("dr");
                        long cr = rs.getLong("cr");
                        switch (com.ledgerpro.model.AccountType.parse(rs.getString("type"))) {
                            case REVENUE -> agg.revenueByMonth.merge(month, cr - dr,
                                    Long::sum);
                            case EXPENSE -> {
                                agg.expenseByMonth.merge(month, dr - cr, Long::sum);
                                agg.expenseByName.merge(rs.getString("name"), dr - cr,
                                        Long::sum);
                            }
                            case ASSET -> agg.assets += dr - cr;
                            case LIABILITY -> agg.liabilities += cr - dr;
                            case EQUITY -> agg.equity += cr - dr;
                        }
                    }
                }
            }

            // (b) entry counts of the working period (posted / draft / voided)
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT e.posted, (e.void_of_id IS NOT NULL) AS voided,"
                            + " COUNT(*) AS n FROM journal_entries e"
                            + " WHERE e.period_id = ? GROUP BY e.posted, voided")) {
                ps.setLong(1, periodId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int n = rs.getInt("n");
                        if (rs.getInt("voided") == 1) {
                            agg.voided += n;
                        } else if (rs.getInt("posted") == 1) {
                            agg.posted += n;
                        } else {
                            agg.draft += n;
                        }
                    }
                }
            }

            // (c) the last eight entries of the CLIENT (newest first).
            //     2.12.1 (C2): the amount is total DEBITS — one side of the
            //     double entry, the same figure the Journal tab's Amount
            //     column shows. The old COALESCE(debit, credit) summed both
            //     sides and read doubled.
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT id, entry_no, entry_date, memo, posted, void_of_id,"
                            + " COALESCE((SELECT SUM(l.debit_cents) FROM journal_lines l"
                            + "           WHERE l.entry_id = e.id), 0) AS amount"
                            + " FROM journal_entries e"
                            + " WHERE e.client_id = ?"
                            + " ORDER BY entry_date DESC, entry_no DESC LIMIT 8")) {
                ps.setLong(1, clientId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        boolean voided = rs.getLong("void_of_id") != 0;
                        boolean posted = rs.getInt("posted") == 1;
                        String status = voided ? "Voided" : posted ? "Posted" : "Draft";
                        agg.recents.add(new DashboardView.RecentEntry(
                                rs.getLong("id"),
                                rs.getInt("entry_no"),
                                LocalDate.parse(rs.getString("entry_date")),
                                rs.getString("memo") == null ? "" : rs.getString("memo"),
                                rs.getLong("amount"),
                                status));
                    }
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("the dashboard read failed", e);
        }
        return agg;
    }
}
