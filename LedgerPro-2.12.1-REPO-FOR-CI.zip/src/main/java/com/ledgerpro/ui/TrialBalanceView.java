package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;
import com.ledgerpro.model.TbStage;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;

import java.util.List;

/**
 * The trial balance of a period at one of the three checkpoints of the
 * accounting cycle (Phase 4): unadjusted, adjusted, post-closing.
 *
 * <p>The whole point of a trial balance is making the double-entry equation
 * <b>visible</b>: the grand totals line shows debits and credits, and states
 * plainly whether they match. "Snapshot…" freezes the current table into
 * the {@code tb_snapshots} audit trail — the record of every report the
 * firm ever produced.</p>
 */
public final class TrialBalanceView extends VBox implements Refreshable {

    private final JournalService journalService;
    private final PeriodService periodService;
    private final ObservableValue<Client> activeClient;

    private final ComboBox<Period> periodBox = new ComboBox<>();
    private final ComboBox<TbStage> stageBox = new ComboBox<>();
    private final Button snapshotButton = new Button("Snapshot…");
    private final Button csvButton = new Button("Export CSV…");
    private final TableView<JournalService.TrialBalanceRow> table = new TableView<>();
    private final Label banner = new Label();
    private final Label totalsLine = new Label();
    private final Label footer = new Label();

    private Client client;
    private List<Period> periods = List.of();
    private JournalService.TrialBalance current;

    private final VBox emptyState = buildEmptyState();
    private final VBox workArea = buildWorkArea();

    public TrialBalanceView(JournalService journalService, PeriodService periodService,
                            ObservableValue<Client> activeClient) {
        this.journalService = journalService;
        this.periodService = periodService;
        this.activeClient = activeClient;
        setSpacing(12);

        getChildren().addAll(emptyState, workArea);
        // fill the window: whichever of the two states is visible grows to
        // the full content height instead of leaving dead space below
        VBox.setVgrow(emptyState, Priority.ALWAYS);
        VBox.setVgrow(workArea, Priority.ALWAYS);
        showEmptyState(true);

        client = activeClient.getValue();
        activeClient.addListener((obs, old, now) -> {
            client = now;
            refresh();
        });
    }

    // ------------------------------------------------------------------
    // Layout
    // ------------------------------------------------------------------

    private static VBox buildEmptyState() {
        // 2.12.0: the shared empty-state builder — one look for
        // every view (glyph, title, hint), themed and density-aware
        return (VBox) EmptyState.of(
                "⚖",
                "Pick a client in the top bar — the trial balance of their periods opens here.",
                "A trial balance needs a period with posted entries.").node();
    }

    private VBox buildWorkArea() {
        Label periodCaption = new Label("Period:");
        periodCaption.getStyleClass().add("lp-muted");
        periodBox.setPrefWidth(240);
        periodBox.valueProperty().addListener((obs, old, now) -> reload());

        Label stageCaption = new Label("Stage:");
        stageCaption.getStyleClass().add("lp-muted");
        stageBox.getItems().addAll(TbStage.values());
        stageBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(TbStage stage) {
                return stage == null ? "" : stage.label;
            }

            @Override
            public TbStage fromString(String text) {
                return TbStage.parse(text);
            }
        });
        stageBox.getSelectionModel().selectFirst();   // unadjusted
        stageBox.valueProperty().addListener((obs, old, now) -> reload());

        snapshotButton.getStyleClass().add("lp-compact-btn");
        snapshotButton.setOnAction(e -> snapshot());
        csvButton.getStyleClass().add("lp-compact-btn");
        csvButton.setTooltip(new Tooltip(
                "Writes the trial balance exactly as shown — account, type,"
                        + " debit and credit — with the totals row."));
        csvButton.setOnAction(e -> exportCsv());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox toolbar = new HBox(10, periodCaption, periodBox, stageCaption, stageBox,
                spacer, csvButton, snapshotButton);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        buildTable();

        banner.getStyleClass().add("lp-card-note");
        banner.setWrapText(true);
        totalsLine.getStyleClass().add("lp-card-note");
        footer.getStyleClass().add("lp-muted");

        VBox area = new VBox(12, banner, toolbar, table, totalsLine, footer);
        VBox.setVgrow(table, Priority.ALWAYS);
        area.setVisible(false);
        area.setManaged(false);
        return area;
    }

    private void buildTable() {
        table.setPlaceholder(new Label("Nothing posted in this period for this stage yet."));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<JournalService.TrialBalanceRow, String> code = new TableColumn<>("Code");
        code.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().account().code()));
        code.setPrefWidth(80);
        code.getStyleClass().add("lp-col-strong");

        TableColumn<JournalService.TrialBalanceRow, String> name = new TableColumn<>("Account");
        name.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().account().name()));
        name.setPrefWidth(360);

        TableColumn<JournalService.TrialBalanceRow, String> type = new TableColumn<>("Type");
        type.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().account().type().label
                        + (c.getValue().account().contra() ? " · contra" : "")));
        type.setPrefWidth(120);

        debitColumn = new TableColumn<>("Debit");
        debitColumn.setPrefWidth(150);
        debitColumn.setCellValueFactory(c ->
                new SimpleObjectProperty<>(c.getValue().debitCents()));
        debitColumn.setCellFactory(col -> new MoneyCell<>());

        creditColumn = new TableColumn<>("Credit");
        creditColumn.setPrefWidth(150);
        creditColumn.setCellValueFactory(c ->
                new SimpleObjectProperty<>(c.getValue().creditCents()));
        creditColumn.setCellFactory(col -> new MoneyCell<>());

        table.getColumns().addAll(code, name, type, debitColumn, creditColumn);
    }

    private TableColumn<JournalService.TrialBalanceRow, Long> debitColumn;
    private TableColumn<JournalService.TrialBalanceRow, Long> creditColumn;

    private void showEmptyState(boolean empty) {
        emptyState.setVisible(empty);
        emptyState.setManaged(empty);
        workArea.setVisible(!empty);
        workArea.setManaged(!empty);
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        if (client == null) {
            showEmptyState(true);
            return;
        }
        showEmptyState(false);
        banner.setText("Trial balance — " + client.code() + " · " + client.name()
                + " · reports in " + client.baseCurrency());
        debitColumn.setText("Debit (" + client.baseCurrency() + ")");
        creditColumn.setText("Credit (" + client.baseCurrency() + ")");

        periods = periodService.list(client.id());
        Period previous = periodBox.getValue();
        periodBox.getItems().setAll(periods);
        Period stillThere = previous == null ? null
                : periods.stream().filter(p -> p.id() == previous.id()).findFirst().orElse(null);
        periodBox.setValue(stillThere != null ? stillThere
                : (!periods.isEmpty() ? periods.getLast() : null));
        reload();
    }

    /**
     * 2.12.0: the trial balance as CSV — the rows exactly as shown plus a
     * totals line, amounts as base-currency cents integers (same convention
     * as the journal export).
     */
    private void exportCsv() {
        if (client == null || current == null || current.rows().isEmpty()) {
            javafx.scene.control.Alert info = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.INFORMATION,
                    "Nothing to export — the trial balance is empty.",
                    ButtonType.OK);
            info.setHeaderText(null);
            info.showAndWait();
            return;
        }
        String suggested = "trial-balance-" + client.code() + "-"
                + java.time.LocalDate.now().format(
                        java.time.format.DateTimeFormatter.BASIC_ISO_DATE) + ".csv";
        javafx.stage.FileChooser chooser = new javafx.stage.FileChooser();
        chooser.setTitle("Export trial balance CSV");
        chooser.setInitialFileName(suggested);
        chooser.getExtensionFilters().add(
                new javafx.stage.FileChooser.ExtensionFilter("CSV files", "*.csv"));
        java.io.File target = chooser.showSaveDialog(
                getScene() == null ? null : getScene().getWindow());
        if (target == null) {
            return;
        }
        try (java.io.BufferedWriter out = java.nio.file.Files.newBufferedWriter(
                target.toPath(), java.nio.charset.StandardCharsets.UTF_8)) {
            out.write("Code,Account,Type,Debit (" + client.baseCurrency()
                    + "),Credit (" + client.baseCurrency() + ")");
            out.write("\r\n");
            for (com.ledgerpro.service.JournalService.TrialBalanceRow row
                    : current.rows()) {
                out.write(String.join(",",
                        csv(row.account().code()),
                        csv(row.account().name()),
                        csv(row.account().type().label),
                        csv(Long.toString(row.debitCents())),
                        csv(Long.toString(row.creditCents()))));
                out.write("\r\n");
            }
            out.write(String.join(",",
                    "TOTAL", "", "",
                    csv(Long.toString(current.totalDebitCents())),
                    csv(Long.toString(current.totalCreditCents()))));
            out.write("\r\n");
        } catch (java.io.IOException e) {
            ClientsView.errorAlert(new IllegalStateException(
                    "The CSV could not be written (" + e.getMessage() + ")."));
            return;
        }
        javafx.scene.control.Alert info = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.INFORMATION,
                "Exported " + current.rows().size() + " accounts to "
                        + target.getAbsolutePath() + ".",
                ButtonType.OK);
        info.setHeaderText("Exported");
        info.showAndWait();
    }

    /** CSV quoting: wrap in quotes, double embedded quotes. */
    private static String csv(String field) {
        String clean = field == null ? "" : field;
        boolean needsQuotes = clean.contains(",") || clean.contains("\"")
                || clean.contains("\n") || clean.contains("\r");
        String escaped = clean.replace("\"", "\"\"");
        return needsQuotes ? "\"" + escaped + "\"" : escaped;
    }

    private void reload() {
        if (client == null) {
            return;
        }
        Period period = periodBox.getValue();
        TbStage stage = stageBox.getValue();
        if (period == null || stage == null) {
            table.getItems().clear();
            totalsLine.setText("");
            footer.setText("Create a period and post entries in the journal first.");
            return;
        }

        current = journalService.trialBalance(period.id(), stage);
        table.setItems(FXCollections.observableArrayList(current.rows()));

        List<String> included = stage.includes.stream()
                .sorted()
                .map(t -> t.label)
                .toList();
        totalsLine.setText("Totals — debits " + Money.format(current.totalDebitCents())
                + "   ·   credits " + Money.format(current.totalCreditCents())
                + "   ·   " + (current.balanced()
                ? "debits equal credits ✓" : "OUT OF BALANCE — investigate immediately"));
        totalsLine.getStyleClass().setAll(current.balanced() ? "lp-status-ok" : "lp-dialog-error");
        footer.setText(period.name() + " (" + period.start() + " … " + period.end() + ")"
                + (period.closed() ? " · CLOSED" : " · open")
                + " · " + current.rows().size() + " accounts with activity · counts "
                + String.join(", ", included)
                + (stage.includes.contains(com.ledgerpro.model.EntryType.REVERSING)
                ? " — voiding mirrors cancel their originals" : "")
                + " · snapshotted rows are immutable in the audit trail");
    }

    // ------------------------------------------------------------------
    // Snapshot
    // ------------------------------------------------------------------

    private void snapshot() {
        Period period = periodBox.getValue();
        TbStage stage = stageBox.getValue();
        if (period == null || stage == null || current == null) {
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Freeze this " + stage.label.toLowerCase() + " trial balance of '"
                        + period.name() + "' into the audit trail?\n\n"
                        + "The snapshot is immutable — it records exactly what the firm"
                        + " reported, and when.",
                ButtonType.OK, ButtonType.CANCEL);
        confirm.setTitle("Snapshot trial balance");
        confirm.setHeaderText(null);
        if (getScene() != null) {
            confirm.initOwner(getScene().getWindow());
        }
        if (confirm.showAndWait().filter(ButtonType.OK::equals).isEmpty()) {
            return;
        }
        try {
            long id = journalService.snapshotTrialBalance(period.id(), stage);
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    "Snapshot #" + id + " stored — " + current.rows().size()
                            + " accounts, totals " + Money.format(current.totalDebitCents())
                            + " / " + Money.format(current.totalCreditCents()) + ".",
                    ButtonType.OK);
            done.setTitle("Trial balance snapshotted");
            done.setHeaderText(null);
            if (getScene() != null) {
                done.initOwner(getScene().getWindow());
            }
            done.showAndWait();
        } catch (RuntimeException e) {
            ClientsView.errorAlert(e);
        }
    }
}
