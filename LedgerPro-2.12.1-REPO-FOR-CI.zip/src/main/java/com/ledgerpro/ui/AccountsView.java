package com.ledgerpro.ui;

import com.ledgerpro.model.Account;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Client;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ChartTemplates;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.StandardChart;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TableRow;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The chart of accounts of the working client (Phase 3): searchable,
 * filterable register of accounts, add/edit dialogs with contra support,
 * one-click application of the firm's {@link StandardChart}, and
 * deactivate/restore — never delete.
 *
 * <p>The view scopes itself to the shell's working client. With no client
 * selected it shows an honest empty state instead of an empty table; the
 * moment a client is picked in the top bar, the listener swaps the work area
 * in. Rows are cached on every {@link #refresh()}; typing in the search box
 * or changing filters only re-filters the cache.</p>
 */
public final class AccountsView extends VBox implements Refreshable {

    private final AccountService service;
    private final ClientService clientService;
    private final ObservableValue<Client> activeClient;

    private final TextField search = new TextField();
    private final ComboBox<AccountType> typeFilter = new ComboBox<>();
    private final CheckBox showInactive = new CheckBox("Show inactive");
    private final TableView<Account> table = new TableView<>();
    private final Button editButton = new Button("Edit…");
    private final Button toggleButton = new Button();
    private final Label banner = new Label();
    private final Label footer = new Label();

    /** The client whose chart is on screen (null = empty state). */
    private Client client;
    private List<Account> allRows = List.of();

    private final VBox emptyState = buildEmptyState();
    private final VBox workArea = buildWorkArea();

    public AccountsView(AccountService service, ClientService clientService,
                        ObservableValue<Client> activeClient) {
        this.service = service;
        this.clientService = clientService;
        this.activeClient = activeClient;
        setSpacing(12);

        getChildren().addAll(emptyState, workArea);
        // fill the window: whichever of the two states is visible grows to
        // the full content height instead of leaving dead space below
        VBox.setVgrow(emptyState, Priority.ALWAYS);
        VBox.setVgrow(workArea, Priority.ALWAYS);
        showEmptyState(true);

        // pick up a working client that was selected BEFORE this view was
        // built (deep links, tooling), then track every later change
        this.client = activeClient.getValue();
        activeClient.addListener((obs, old, now) -> {
            client = now;
            refresh();
        });
    }

    // ------------------------------------------------------------------
    // Layout: empty state vs. work area
    // ------------------------------------------------------------------

    private static VBox buildEmptyState() {
        // 2.12.0: the shared empty-state builder — one look for
        // every view (glyph, title, hint), themed and density-aware
        return (VBox) EmptyState.of(
                "☰",
                "Pick a client in the top bar — their chart of accounts opens here, ready to fill from the firm's standard chart or account by account.",
                "The journal, ledgers and trial balance of Phase 4 all draw from this chart.").node();
    }

    private VBox buildWorkArea() {
        Button newAccount = new Button("New account…");
        newAccount.getStyleClass().add("lp-compact-btn");
        newAccount.setOnAction(e -> offerNewAccount());

        editButton.getStyleClass().add("lp-compact-btn");
        editButton.setDisable(true);
        editButton.setOnAction(e -> offerEditSelected());

        toggleButton.getStyleClass().add("lp-compact-btn");
        toggleButton.setDisable(true);
        toggleButton.setOnAction(e -> toggleSelected());

        Button applyTemplate = new Button("Apply template…");
        applyTemplate.getStyleClass().add("lp-compact-btn");
        applyTemplate.setOnAction(e -> offerApplyTemplate());

        search.setPromptText("Search code or name…");
        search.setPrefWidth(200);

        typeFilter.setPromptText("All types");
        typeFilter.getItems().add(null);   // the "All types" choice
        typeFilter.getItems().addAll(AccountType.values());
        typeFilter.setConverter(new javafx.util.StringConverter<>() {
            @Override
            public String toString(AccountType type) {
                return type == null ? "All types" : type.label;
            }

            @Override
            public AccountType fromString(String text) {
                for (AccountType type : AccountType.values()) {
                    if (type.label.equals(text)) {
                        return type;
                    }
                }
                return null;
            }
        });
        typeFilter.getSelectionModel().selectFirst();   // "All types"

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox toolbar = new HBox(10, newAccount, editButton, toggleButton, applyTemplate,
                spacer, showInactive, typeFilter, search);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        buildTable();

        banner.getStyleClass().add("lp-card-note");

        VBox area = new VBox(12, banner, toolbar, table, footer);
        VBox.setVgrow(table, Priority.ALWAYS);
        area.setVisible(false);
        area.setManaged(false);
        return area;
    }

    private void buildTable() {
        table.setPlaceholder(new Label("This chart is empty — start with"
                + " “Apply template…” or add accounts one by one."));

        TableColumn<Account, String> code = new TableColumn<>("Code");
        code.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().code()));
        code.setPrefWidth(90);
        code.getStyleClass().add("lp-col-strong");

        TableColumn<Account, String> name = new TableColumn<>("Name");
        name.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().name()));
        name.setPrefWidth(430);

        TableColumn<Account, String> type = new TableColumn<>("Type");
        type.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().type().label));
        type.setPrefWidth(110);

        TableColumn<Account, String> side = new TableColumn<>("Normal side");
        side.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().normalSide().label
                        + (c.getValue().contra() ? "  ·  contra" : "")));
        side.setPrefWidth(140);
        side.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    getStyleClass().remove("lp-contra");
                } else if (item.endsWith("contra")) {
                    setText(item);
                    getStyleClass().add("lp-contra");
                } else {
                    setText(item);
                    getStyleClass().remove("lp-contra");
                }
            }
        });

        TableColumn<Account, String> status = new TableColumn<>("Status");
        status.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().active() ? "Active" : "Inactive"));
        status.setPrefWidth(100);
        status.setCellFactory(StatusText.cell());

        table.getColumns().addAll(code, name, type, side, status);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.getSelectionModel().selectedItemProperty().addListener(
                (obs, old, now) -> updateActionButtons());
        table.setRowFactory(view -> {
            TableRow<Account> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    offerEdit(row.getItem());
                }
            });
            return row;
        });

        MenuItem edit = new MenuItem("Edit…");
        edit.disableProperty().bind(editButton.disableProperty());
        edit.setOnAction(e -> offerEditSelected());
        MenuItem toggle = new MenuItem();
        toggle.textProperty().bind(toggleButton.textProperty());
        toggle.disableProperty().bind(toggleButton.disableProperty());
        toggle.setOnAction(e -> toggleSelected());
        table.setContextMenu(new ContextMenu(edit, toggle));

        search.textProperty().addListener((obs, old, now) -> applyFilter());
        showInactive.selectedProperty().addListener((obs, old, now) -> applyFilter());
        typeFilter.valueProperty().addListener((obs, old, now) -> applyFilter());
    }

    private void showEmptyState(boolean empty) {
        emptyState.setVisible(empty);
        emptyState.setManaged(empty);
        workArea.setVisible(!empty);
        workArea.setManaged(!empty);
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        if (client == null) {
            showEmptyState(true);
            return;
        }
        showEmptyState(false);
        String provenance = "";
        String templateCode = clientService == null
                ? null : clientService.chartTemplateOf(client.id());
        if (templateCode != null) {
            provenance = " · chart seeded from the " + templateCode + " template";
        }
        banner.setText("Chart of accounts — " + client.code() + " · " + client.name()
                + " · reports in " + client.baseCurrency() + provenance);
        allRows = service.list(client.id(), true);
        applyFilter();
    }

    private void applyFilter() {
        String needle = search.getText() == null ? "" : search.getText().trim().toLowerCase();
        AccountType wanted = typeFilter.getValue();
        boolean withInactive = showInactive.isSelected();

        ObservableList<Account> visible = FXCollections.observableArrayList(
                allRows.stream()
                        .filter(a -> withInactive || a.active())
                        .filter(a -> wanted == null || a.type() == wanted)
                        .filter(a -> needle.isEmpty()
                                || a.code().toLowerCase().contains(needle)
                                || a.name().toLowerCase().contains(needle))
                        .toList());

        Account previous = table.getSelectionModel().getSelectedItem();
        table.setItems(visible);
        if (previous != null) {
            visible.stream()
                    .filter(a -> a.id() == previous.id())
                    .findFirst()
                    .ifPresent(a -> table.getSelectionModel().select(a));
        }

        long active = allRows.stream().filter(Account::active).count();
        long inactive = allRows.size() - active;
        long contra = allRows.stream().filter(Account::contra).count();
        footer.setText(visible.size() + " shown · " + active + " active · " + inactive
                + " inactive · " + contra + " contra — accounts are never deleted,"
                + " only deactivated");
        footer.getStyleClass().add("lp-muted");
        updateActionButtons();
    }

    private void updateActionButtons() {
        Account selected = table.getSelectionModel().getSelectedItem();
        editButton.setDisable(selected == null);
        if (selected == null) {
            toggleButton.setText("Deactivate / restore");
            toggleButton.setDisable(true);
        } else if (selected.active()) {
            toggleButton.setText("Deactivate “" + selected.code() + "”");
            toggleButton.setDisable(false);
        } else {
            toggleButton.setText("Restore “" + selected.code() + "”");
            toggleButton.setDisable(false);
        }
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    private void offerNewAccount() {
        if (client == null) {
            return;
        }
        AccountDialog dialog = new AccountDialog(service, client.id());
        if (getScene() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        Optional<Account> result = dialog.showAndWait();
        result.ifPresent(created -> {
            refresh();
            selectByCode(created.code());
        });
    }

    private void offerEditSelected() {
        Account selected = table.getSelectionModel().getSelectedItem();
        if (selected != null) {
            offerEdit(selected);
        }
    }

    private void offerEdit(Account account) {
        AccountDialog dialog = new AccountDialog(service, account, client.id());
        if (getScene() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        Optional<Account> result = dialog.showAndWait();
        result.ifPresent(updated -> {
            refresh();
            selectByCode(updated.code());
        });
    }

    private void toggleSelected() {
        Account selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            return;
        }
        boolean deactivating = selected.active();

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                (deactivating ? "Deactivate" : "Restore") + " account “"
                        + selected.code() + " — " + selected.name() + "”?",
                ButtonType.OK, ButtonType.CANCEL);
        confirm.setHeaderText(null);
        confirm.setTitle(deactivating ? "Deactivate account" : "Restore account");
        if (deactivating) {
            confirm.setContentText(confirm.getContentText()
                    + "\n\nNothing is deleted: history and the audit trail stay intact;"
                    + " the account simply drops out of the journal pickers.");
        }
        if (confirm.showAndWait().filter(ButtonType.OK::equals).isEmpty()) {
            return;
        }

        try {
            service.setActive(selected.id(), !deactivating);
        } catch (RuntimeException e) {
            ClientsView.errorAlert(e);
            return;
        }
        refresh();
    }

    private void offerApplyTemplate() {
        if (client == null) {
            return;
        }
        ChartTemplateDialog picker = new ChartTemplateDialog(
                client.code() + " — " + client.name());
        if (getScene() != null) {
            picker.initOwner(getScene().getWindow());
        }
        Optional<ChartTemplates.Definition> chosen = picker.showAndWait();
        if (chosen.isEmpty()) {
            return;
        }
        ChartTemplates.Definition template = chosen.orElseThrow();

        Set<String> existing = allRows.stream()
                .map(Account::code)
                .collect(Collectors.toSet());
        long missing = template.rows().stream()
                .filter(row -> !existing.contains(row.code()))
                .count();

        if (missing == 0) {
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    "This chart already covers the whole " + template.code()
                            + " template — nothing to add.",
                    ButtonType.OK);
            done.setHeaderText(null);
            done.setTitle("Chart template");
            done.showAndWait();
            return;
        }

        try {
            int inserted = service.applyChartTemplate(client.id(), template);
            refresh();
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    "Added " + inserted + " account" + (inserted == 1 ? "" : "s")
                            + " from the " + template.code() + " template to "
                            + client.code() + "'s chart of accounts.\n\nExisting"
                            + " accounts were left untouched — applying is idempotent.",
                    ButtonType.OK);
            done.setHeaderText(null);
            done.setTitle("Template applied");
            done.showAndWait();
        } catch (RuntimeException e) {
            ClientsView.errorAlert(e);
        }
    }

    /** Re-selects a row after create/edit so the user sees what they did. */
    private void selectByCode(String code) {
        table.getItems().stream()
                .filter(a -> a.code().equals(code))
                .findFirst()
                .ifPresent(a -> table.getSelectionModel().select(a));
    }
}
