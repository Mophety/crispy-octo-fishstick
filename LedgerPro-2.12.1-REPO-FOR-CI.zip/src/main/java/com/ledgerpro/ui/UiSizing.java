package com.ledgerpro.ui;

import javafx.collections.ListChangeListener;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Labeled;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Region;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

/**
 * Size helpers of the em-based design system (2.12.1) — for the few
 * controls whose width cannot be expressed in CSS because it depends on
 * the TEXT they will show.
 *
 * <p>Everything on the dashboard and the journal is sized in em, so the
 * Text 130% scale never truncates a fixed pixel width. Combo boxes and
 * table columns are the two exceptions: their useful width is the width
 * of the longest string they must display, which only Java can measure.</p>
 */
final class UiSizing {

    private UiSizing() {
    }

    // ------------------------------------------------------------------
    // Measuring
    // ------------------------------------------------------------------

    /**
     * The effective text size (px) of a node: its own font, else the
     * nearest ancestor's, else the ROOT's CSS-resolved font, else the
     * platform default. 1 em.
     *
     * <p>3.0 (the P3-S0 fix): the old walk fell back to
     * {@code Font.getDefault()} — the JVM's platform default (13 px
     * here), NOT the text scale the responsive-text system applies to
     * the scene root as a CSS {@code -fx-font-size} style. Measured
     * headless: at 130% UiScale the root style is 18.2 px, a label in
     * the scene resolves 18.2 px, but the ancestor walk returned 13 px
     * — every em-based breakpoint (ResponsiveGrid's column wrap) sat at
     * the platform default, not the user's chosen text size. The fix:
     * when no ancestor carries an explicit font, resolve the ROOT's
     * CSS font (its style is set by installResponsiveText / UiScale
     * bind); only when the node has no scene at all do we fall back to
     * the platform default.</p>
     */
    static double em(Node node) {
        for (Node current = node; current != null; current = current.getParent()) {
            Font font = null;
            // Only text-bearing nodes carry a font (a plain Region does not)
            if (current instanceof Labeled labeled) {
                font = labeled.getFont();
            } else if (current instanceof Text text) {
                font = text.getFont();
            }
            if (font != null) {
                return font.getSize();
            }
        }
        // nothing on the ancestor chain carries a font: the root's
        // CSS-resolved size IS the em (it carries the UiScale style)
        Node root = node;
        while (root.getParent() != null) {
            root = root.getParent();
        }
        // the root's style (set by installResponsiveText) names its font
        // size directly: "-fx-font-size: 18.20px;" — parse it instead of
        // getFont() (a Pane reports the inherited default, not its style)
        String style = root.getStyle();
        if (style != null && !style.isBlank()) {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("-fx-font-size:\\s*([0-9.]+)px").matcher(style);
            if (m.find()) {
                return Double.parseDouble(m.group(1));
            }
        }
        if (root instanceof Labeled labeled && labeled.getFont() != null) {
            return labeled.getFont().getSize();
        }
        if (root instanceof Text text && text.getFont() != null) {
            return text.getFont().getSize();
        }
        return Font.getDefault().getSize();
    }

    /** The advance width of {@code text} in {@code font} (no scene needed). */
    static double textWidth(String text, Font font) {
        Text probe = new Text(text == null ? "" : text);
        probe.setFont(font == null ? Font.getDefault() : font);
        Bounds bounds = probe.getBoundsInLocal();
        return bounds == null ? 0 : bounds.getWidth();
    }

    /** {@link #textWidth} of the longest of {@code texts} (0 for none). */
    static double widest(Font font, Iterable<String> texts) {
        double widest = 0;
        for (String text : texts) {
            widest = Math.max(widest, textWidth(text, font));
        }
        return widest;
    }

    /** The same typeface at the same size in bold (strong table cells). */
    static Font bold(Font font) {
        return Font.font(font.getFamily(), FontWeight.BOLD, font.getSize());
    }

    // ------------------------------------------------------------------
    // Regions
    // ------------------------------------------------------------------

    /**
     * A region that never shrinks below what it wants to be: min = pref.
     * Inside an {@code HBox} every shrinkable child loses width in equal
     * steps when the row is too narrow — this turns shrinking off for the
     * children that must keep their full label.
     */
    static void keepSize(Region region) {
        region.setMinWidth(Region.USE_PREF_SIZE);
    }

    /**
     * A table view whose viewport shows WHOLE rows (2.12.1, P3-S3): the
     * control's max height snaps to floor(available-height / row-height)
     * rows plus the header, so the last visible row is never cut
     * mid-row. Re-measures whenever the table's height changes.
     */
    static <S> void snapRowViewport(javafx.scene.control.TableView<S> table) {
        table.heightProperty().addListener((obs, old, now) -> snapRows(table));
    }

    private static <S> void snapRows(javafx.scene.control.TableView<S> table) {
        if (table.getHeight() <= 0) {
            return;
        }
        javafx.scene.Node header = table.lookup(".column-header-background");
        javafx.scene.control.TableRow<?> anyRow =
                table.lookupAll(".table-row-cell").stream()
                        .filter(n -> n instanceof javafx.scene.control.TableRow<?>)
                        .map(n -> (javafx.scene.control.TableRow<?>) n)
                        .findFirst().orElse(null);
        if (anyRow == null || anyRow.getHeight() <= 0) {
            return;   // no rows laid out yet
        }
        double headerH = header == null ? 0 : header.getBoundsInParent().getHeight();
        if (headerH <= 0) {
            return;   // header not laid out yet
        }
        double rowH = anyRow.getHeight();
        double inner = table.getHeight() - headerH;
        if (inner <= 0) {
            return;
        }
        int rows = Math.max(1, (int) Math.floor(inner / rowH));
        double snapped = rows * rowH + headerH;
        if (Math.abs(snapped - table.getMaxHeight()) > 0.01) {
            table.setMaxHeight(snapped);
        }
    }

    // ------------------------------------------------------------------
    // Combo boxes
    // ------------------------------------------------------------------

    /**
     * Sizes a combo box to its WIDEST item (never past {@code maxEm} ×
     * the text size): the selected value is always readable in full, the
     * box never stretches with the window, and it never ellipsizes a
     * period or a client name. The items list may change later — the cell
     * re-measures on every layout.
     *
     * @param combo the box to size (its converter must be set)
     * @param maxEm the cap, in em of the box's own font
     */
    static <T> void fitWidestItem(ComboBox<T> combo, double maxEm) {
        WidestItemCell<T> cell = new WidestItemCell<>(combo, maxEm);
        combo.setButtonCell(cell);
        keepSize(combo);
        combo.getItems().addListener((ListChangeListener<T>) change -> {
            combo.requestLayout();
            cell.requestLayout();
        });
    }

    /** The button cell of a widest-item combo box. */
    private static final class WidestItemCell<T> extends ListCell<T> {

        private final ComboBox<T> combo;
        private final double maxEm;

        WidestItemCell(ComboBox<T> combo, double maxEm) {
            this.combo = combo;
            this.maxEm = maxEm;
        }

        @Override
        protected void updateItem(T item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty || item == null ? "" : textOf(item));
        }

        private String textOf(T item) {
            return combo.getConverter() == null
                    ? String.valueOf(item) : combo.getConverter().toString(item);
        }

        private double textWidth() {
            Font font = getFont() == null ? Font.getDefault() : getFont();
            double widest = 0;
            for (T item : combo.getItems()) {
                widest = Math.max(widest, UiSizing.textWidth(textOf(item), font));
            }
            return Math.min(widest, font.getSize() * maxEm);
        }

        @Override
        protected double computePrefWidth(double height) {
            return snapSizeX(textWidth()) + snappedLeftInset() + snappedRightInset();
        }

        @Override
        protected double computeMinWidth(double height) {
            return computePrefWidth(height);
        }
    }
}
