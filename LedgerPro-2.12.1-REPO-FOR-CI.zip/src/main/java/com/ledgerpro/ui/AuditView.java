package com.ledgerpro.ui;

import com.ledgerpro.model.AuditEntry;
import com.ledgerpro.model.Client;
import com.ledgerpro.service.AuditService;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * The firm's audit trail, newest first: every mutation LedgerPro ever
 * recorded, who did it, when, and — since migration V4 — the structured
 * entity it touched (client, period, entry, account, template, report).
 *
 * <p>Read-only by design (audit rows are written only inside the mutating
 * transactions, never editable), but alive: the view follows the working
 * client switcher, a filter narrows to entries touching one entity family,
 * and the detail column shows the human story of each action.</p>
 */
final class AuditView extends VBox implements Refreshable {

    private static final int PAGE_SIZE = 500;

    private final AuditService auditService;
    private Client client;

    private final TableView<AuditEntry> table = new TableView<>();
    private final Label heading = new Label();

    AuditView(AuditService auditService, ObjectProperty<Client> activeClient) {
        this.auditService = auditService;
        this.client = activeClient.get();
        // follow the working-client switcher live
        activeClient.addListener((obs, old, now) -> {
            this.client = now;
            refresh();
        });
        getStyleClass().add("lp-view");
        setSpacing(10);
        setPadding(new Insets(16, 20, 16, 20));

        Label title = new Label("Audit Log");
        title.getStyleClass().add("lp-view-title");
        heading.getStyleClass().add("lp-muted");
        heading.setWrapText(true);

        buildTable();

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox bar = new HBox(12, title, spacer, heading);
        bar.setAlignment(Pos.CENTER_LEFT);

        getChildren().addAll(bar, table);
        VBox.setVgrow(table, Priority.ALWAYS);
    }

    @Override
    public void refresh() {
        List<AuditEntry> rows = auditService.list(
                client == null ? null : client.id(), PAGE_SIZE);
        table.getItems().setAll(javafx.collections.FXCollections.observableArrayList(rows));
        heading.setText(client == null
                ? rows.size() + " most recent actions across the whole firm"
                : rows.size() + " most recent actions for " + client.code()
                        + " — " + client.name());
    }

    private void buildTable() {
        table.setPlaceholder(new Label("No actions recorded yet — the trail fills"
                + " itself as the firm works."));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<AuditEntry, String> at = new TableColumn<>("When (UTC)");
        at.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().at()));
        at.setPrefWidth(150);

        TableColumn<AuditEntry, String> action = new TableColumn<>("Action");
        action.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().action()));
        action.setPrefWidth(130);
        action.setCellFactory(StatusText.cell());

        TableColumn<AuditEntry, String> entity = new TableColumn<>("Entity");
        entity.setCellValueFactory(c -> {
            AuditEntry row = c.getValue();
            String text;
            if (row.entityType() == null) {
                text = row.clientId() == null ? "—" : "CLIENT";
            } else {
                text = row.entityType() + (row.entityId() == null ? "" : " #" + row.entityId());
            }
            return new SimpleStringProperty(text);
        });
        entity.setPrefWidth(120);

        TableColumn<AuditEntry, String> detail = new TableColumn<>("What happened");
        detail.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().detail()));
        detail.setPrefWidth(480);

        TableColumn<AuditEntry, String> actor = new TableColumn<>("Actor");
        actor.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().actor()));
        actor.setPrefWidth(90);

        table.getColumns().addAll(at, action, entity, detail, actor);
    }
}
