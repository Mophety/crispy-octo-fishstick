package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.model.FxRate;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.FxUnavailableException;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

/**
 * The firm's FX-rate workstation (Phase 3): fetch reference rates from the
 * Frankfurter API (ECB data) into the persistent cache, type manual rates
 * when the API has no answer, and browse everything cached so far.
 *
 * <p>Rates cached here are the ones the Phase-4 journal will silently use
 * for multi-currency entries — this view is where the accountant checks and,
 * when needed, overrides them. The default target currency follows the
 * working client's base currency, because that is the conversion direction
 * the journal will need.</p>
 */
public final class FxView extends VBox implements Refreshable {

    /** Keeps the browse table meaningful without loading thousands of rows. */
    private static final int BROWSE_LIMIT = 400;

    private final FxRateService service;

    private final ComboBox<String> fromBox = new ComboBox<>();
    private final ComboBox<String> toBox = new ComboBox<>();
    private final DatePicker datePicker = new DatePicker(LocalDate.now());
    private final TableView<FxRate> table = new TableView<>();
    private final Label status = new Label();
    private final Label footer = new Label();

    public FxView(FxRateService service, ObservableValue<Client> activeClient) {
        this.service = service;
        setSpacing(12);

        Label heading = new Label("Fetch a reference rate for a date, or type one"
                + " manually — everything lands in the persistent cache the"
                + " journal will read.");
        heading.getStyleClass().add("lp-card-note");
        heading.setWrapText(true);

        fromBox.getItems().addAll(Currencies.COMMON);
        toBox.getItems().addAll(Currencies.COMMON);
        fromBox.setConverter(Currencies.upperCasing());
        toBox.setConverter(Currencies.upperCasing());
        fromBox.setEditable(true);
        toBox.setEditable(true);
        fromBox.setPromptText("From");
        toBox.setPromptText("To");
        fromBox.setPrefWidth(110);
        toBox.setPrefWidth(110);
        fromBox.getSelectionModel().select("USD");
        toBox.getSelectionModel().select("PHP");

        // The journal converts INTO the client's base currency — make that
        // the default target whenever a working client is picked.
        activeClient.addListener((obs, old, now) -> {
            if (now != null) {
                toBox.setValue(now.baseCurrency());
            }
        });
        if (activeClient.getValue() != null) {
            toBox.setValue(activeClient.getValue().baseCurrency());
        }

        // A rate dated in the future cannot exist yet.
        datePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isAfter(LocalDate.now()));
            }
        });
        datePicker.setPrefWidth(150);
        datePicker.setPromptText("empty = latest");

        Button fetchButton = new Button("Fetch from Frankfurter");
        fetchButton.getStyleClass().add("lp-compact-btn");
        fetchButton.setOnAction(e -> fetchRate());

        Button manualButton = new Button("Add manual rate…");
        manualButton.getStyleClass().add("lp-compact-btn");
        manualButton.setOnAction(e -> offerManualRate());

        // Swapping direction is a one-click question.
        Button swap = new Button("⇄");
        swap.getStyleClass().add("lp-compact-btn");
        swap.setOnAction(e -> swapPair());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox toolbar = new HBox(10, fromBox, swap, toBox, datePicker, fetchButton,
                spacer, manualButton);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        status.setWrapText(true);
        status.setMinHeight(18);   // reserve one line so the layout never jumps

        buildTable();

        footer.setText("Rates come from the European Central Bank's daily reference set"
                + " via the open-source Frankfurter API and stay cached offline."
                + " A manual rate deliberately overrides the API for its date and pair"
                + " — Phase 4's journal reads this cache for multi-currency entries.");
        footer.getStyleClass().add("lp-muted");
        footer.setWrapText(true);

        getChildren().addAll(heading, toolbar, status, table, footer);
        VBox.setVgrow(table, Priority.ALWAYS);
    }

    // ------------------------------------------------------------------
    // Table
    // ------------------------------------------------------------------

    private void buildTable() {
        table.setPlaceholder(new Label("Nothing cached yet — fetch a rate above or add"
                + " one manually."));

        TableColumn<FxRate, String> date = new TableColumn<>("Date");
        date.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().asOf().toString()));
        date.setPrefWidth(110);
        date.getStyleClass().add("lp-col-strong");

        TableColumn<FxRate, String> pair = new TableColumn<>("Pair");
        pair.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().pair()));
        pair.setPrefWidth(130);

        TableColumn<FxRate, String> rate = new TableColumn<>("Rate");
        rate.setCellValueFactory(c -> new SimpleStringProperty(
                formatRate(c.getValue().rate())));
        rate.setPrefWidth(110);

        TableColumn<FxRate, String> source = new TableColumn<>("Source");
        source.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().source() == FxRate.Source.MANUAL ? "Manual" : "Frankfurter"));
        source.setPrefWidth(120);
        source.setCellFactory(StatusText.cell());

        TableColumn<FxRate, String> fetched = new TableColumn<>("Fetched at");
        fetched.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().fetchedAt()));
        fetched.setPrefWidth(180);

        table.getColumns().addAll(date, pair, rate, source, fetched);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    private void swapPair() {
        String from = fromBox.getValue();
        fromBox.setValue(toBox.getValue());
        toBox.setValue(from);
    }

    private void fetchRate() {
        LocalDate date = datePicker.getValue();   // null = latest
        try {
            FxRate stored = service.fetchAndStore(date, fromBox.getValue(), toBox.getValue());
            status.setText("✔  " + stored.pair() + " @ " + stored.asOf()
                    + " = " + formatRate(stored.rate()) + " — cached"
                    + (date == null || date.equals(stored.asOf())
                    ? "" : " (latest trading day on or before " + date + ")"));
            status.getStyleClass().setAll("lp-status-ok");
            refresh();
        } catch (FxUnavailableException e) {
            status.setText("✗  " + e.getMessage()
                    + " — add a manual rate instead if this pair is real for the firm.");
            status.getStyleClass().setAll("lp-dialog-error");
        } catch (IllegalArgumentException e) {
            status.setText("✗  " + e.getMessage());
            status.getStyleClass().setAll("lp-dialog-error");
        }
    }

    private void offerManualRate() {
        ManualRateDialog dialog = new ManualRateDialog(service,
                fromBox.getValue(), toBox.getValue(), datePicker.getValue());
        if (getScene() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        dialog.showAndWait().ifPresent(stored -> {
            status.setText("✔  " + stored.pair() + " @ " + stored.asOf()
                    + " = " + formatRate(stored.rate()) + " — stored as a manual rate,"
                    + " overriding any API value for that date.");
            status.getStyleClass().setAll("lp-status-ok");
            refresh();
        });
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        List<FxRate> recent = service.listRecent(BROWSE_LIMIT);
        table.setItems(FXCollections.observableArrayList(recent));
    }

    /** ECB reference rates carry 4 significant decimals; show exactly 4. */
    private static String formatRate(double rate) {
        return String.format(Locale.ROOT, "%.4f", rate);
    }
}
