package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.service.AdjTemplateService;
import javafx.geometry.Insets;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

/**
 * Picks a recurring adjustment template to prefill the new-entry form with —
 * the client's own templates first, then the ones shared firm-wide.
 *
 * <p>The preview below the list shows the selected template's lines (codes,
 * Dr/Cr, amounts, memos) so the accountant can tell DEP_SL from ACC_SAL at a
 * glance before committing.</p>
 */
final class LoadTemplateDialog extends Dialog<AdjTemplateService.Template> {

    LoadTemplateDialog(AdjTemplateService service, Client client) {
        setTitle("Load a recurring template");
        setHeaderText("Prefill a new entry for " + client.code()
                + " — " + client.name());

        ButtonType load = new ButtonType("Load template", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(load, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());

        java.util.List<AdjTemplateService.Template> templates =
                new java.util.ArrayList<>(service.list(client.id(), client.code()));
        templates.removeIf(t -> !t.isActive());   // inactive ones stay in the DB, not the picker

        ListView<AdjTemplateService.Template> list = new ListView<>(
                javafx.collections.FXCollections.observableArrayList(templates));
        list.setPrefHeight(150);
        list.setCellFactory(view -> new ListCell<>() {
            @Override
            protected void updateItem(AdjTemplateService.Template item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null
                        : (item.shared() ? "◇  " : "◆  ") + item.toString());
            }
        });
        if (!templates.isEmpty()) {
            list.getSelectionModel().selectFirst();
        }

        Label preview = new Label();
        preview.getStyleClass().add("lp-card-note");
        preview.setWrapText(true);
        preview.setMinHeight(72);   // room for a full preview without jumping

        list.getSelectionModel().selectedItemProperty().addListener((obs, old, now) ->
                preview.setText(now == null ? "" : previewText(now)));
        if (!templates.isEmpty()) {
            preview.setText(previewText(templates.getFirst()));
        }

        Region spacer = new Region();
        Label hint = new Label("◆ this client   ◇ shared firm-wide · loading keeps"
                + " everything editable — dates and amounts are yours to adjust"
                + " before saving.");
        hint.getStyleClass().add("lp-muted");
        hint.setWrapText(true);

        VBox content = new VBox(12, list, preview, spacer, hint);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        VBox.setVgrow(spacer, Priority.ALWAYS);
        getDialogPane().setContent(content);

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE
                .equals(buttonType.getButtonData())
                ? list.getSelectionModel().getSelectedItem() : null);
    }

    private static String previewText(AdjTemplateService.Template template) {
        StringBuilder sb = new StringBuilder(template.name()).append(" — ")
                .append(template.lines().size()).append(" lines:\n");
        boolean anyFormula = false;
        long fixedDr = 0;
        long fixedCr = 0;
        for (AdjTemplateService.TemplateLine line : template.lines()) {
            sb.append("  ").append(line.accountCode())
                    .append("  ").append("DR".equals(line.side()) ? "Dr " : "Cr ")
                    .append(line.isFormula() ? line.value() + "  [formula]"
                            : Money.format(line.fixedCents()))
                    .append(line.memo() == null ? "" : "  · " + line.memo())
                    .append('\n');
            if (line.isFormula()) {
                anyFormula = true;
            } else if ("DR".equals(line.side())) {
                fixedDr += line.fixedCents();
            } else {
                fixedCr += line.fixedCents();
            }
        }
        if (template.description() != null && !template.description().isBlank()) {
            sb.append("  ").append(template.description()).append('\n');
        }
        if (!template.isActive()) {
            sb.append("  (inactive — shown for reference)\n");
        }
        if (anyFormula) {
            sb.append("  Fixed lines total ").append(Money.format(fixedDr))
                    .append(" / ").append(Money.format(fixedCr))
                    .append(" — formula lines are evaluated against this period's"
                            + " balances when loaded.");
        } else {
            sb.append("  Total ").append(Money.format(template.totalCents()))
                    .append(" each side");
        }
        return sb.toString();
    }
}
