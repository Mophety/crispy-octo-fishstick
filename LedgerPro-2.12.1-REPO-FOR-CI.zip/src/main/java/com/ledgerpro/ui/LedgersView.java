package com.ledgerpro.ui;

import com.ledgerpro.model.Account;
import com.ledgerpro.model.Client;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.JournalService;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * The general ledger of one account (Phase 4): every posted line across all
 * of the working client's periods, oldest first, with the running balance
 * signed in the account's normal direction.
 *
 * <p>Contra accounts work naturally here — 'Accumulated Depreciation' is an
 * ASSET whose balance grows on the credit side, exactly as recorded in the
 * chart. Deactivated accounts stay selectable: their history does not
 * disappear when the account drops out of the pickers.</p>
 */
public final class LedgersView extends VBox implements Refreshable {

    private final AccountService accountService;
    private final JournalService journalService;
    private final ObservableValue<Client> activeClient;

    private final ComboBox<Account> accountBox = new ComboBox<>();
    private final TableView<JournalService.LedgerRow> table = new TableView<>();
    private final Label banner = new Label();
    private final Label footer = new Label();
    /** The last read ledger rows (2.12.0 — the CSV export writes these). */
    private List<JournalService.LedgerRow> rows = List.of();
    private Account account;

    private Client client;
    private List<Account> accounts = List.of();

    private final VBox emptyState = buildEmptyState();
    private final VBox workArea = buildWorkArea();

    public LedgersView(AccountService accountService, JournalService journalService,
                       ObservableValue<Client> activeClient) {
        this.accountService = accountService;
        this.journalService = journalService;
        this.activeClient = activeClient;
        setSpacing(12);

        getChildren().addAll(emptyState, workArea);
        // fill the window: whichever of the two states is visible grows to
        // the full content height instead of leaving dead space below
        VBox.setVgrow(emptyState, Priority.ALWAYS);
        VBox.setVgrow(workArea, Priority.ALWAYS);
        showEmptyState(true);

        client = activeClient.getValue();
        activeClient.addListener((obs, old, now) -> {
            client = now;
            refresh();
        });
    }

    // ------------------------------------------------------------------
    // Layout
    // ------------------------------------------------------------------

    private static VBox buildEmptyState() {
        // 2.12.0: the shared empty-state builder — one look for
        // every view (glyph, title, hint), themed and density-aware
        return (VBox) EmptyState.of(
                "❮❯",
                "Pick a client in the top bar, then an account — its general ledger opens here.",
                "Only posted lines appear; drafts carry no ledger effect.").node();
    }

    private VBox buildWorkArea() {
        Label caption = new Label("Account:");
        caption.getStyleClass().add("lp-muted");
        accountBox.setPrefWidth(430);
        accountBox.setPromptText("pick an account…");
        accountBox.valueProperty().addListener((obs, old, now) -> reloadLedger());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button csvButton = new Button("Export CSV…");
        csvButton.getStyleClass().add("lp-compact-btn");
        csvButton.setTooltip(new Tooltip(
                "Writes this account's posted lines and running balance to a"
                        + " CSV file — amounts as base-currency cents integers."));
        csvButton.setOnAction(e -> exportCsv());

        HBox toolbar = new HBox(10, caption, accountBox, spacer, csvButton);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        buildTable();

        banner.getStyleClass().add("lp-card-note");
        banner.setWrapText(true);
        footer.getStyleClass().add("lp-muted");

        VBox area = new VBox(12, banner, toolbar, table, footer);
        VBox.setVgrow(table, Priority.ALWAYS);
        area.setVisible(false);
        area.setManaged(false);
        return area;
    }

    private void buildTable() {
        table.setPlaceholder(new Label("No posted lines for this account — recorded"
                + " drafts do not count until posted."));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<JournalService.LedgerRow, String> date = new TableColumn<>("Date");
        date.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().date().toString()));
        date.setPrefWidth(104);

        TableColumn<JournalService.LedgerRow, Integer> no = new TableColumn<>("Entry");
        no.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().entryNo()));
        no.setPrefWidth(70);
        no.getStyleClass().add("lp-col-strong");

        TableColumn<JournalService.LedgerRow, String> type = new TableColumn<>("Type");
        type.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().type().label));
        type.setPrefWidth(94);

        TableColumn<JournalService.LedgerRow, String> memo = new TableColumn<>("Memo");
        memo.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().memo() == null ? "" : c.getValue().memo()));
        memo.setPrefWidth(330);

        debitColumn = new TableColumn<>("Debit");
        debitColumn.setPrefWidth(130);
        debitColumn.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().debitCents()));
        debitColumn.setCellFactory(col -> new MoneyCell<>());

        creditColumn = new TableColumn<>("Credit");
        creditColumn.setPrefWidth(130);
        creditColumn.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().creditCents()));
        creditColumn.setCellFactory(col -> new MoneyCell<>());

        balanceColumn = new TableColumn<>("Balance");
        balanceColumn.setPrefWidth(140);
        balanceColumn.getStyleClass().add("lp-col-strong");
        balanceColumn.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().balanceCents()));
        balanceColumn.setCellFactory(col -> new MoneyCell<>());

        table.getColumns().addAll(date, no, type, memo, debitColumn, creditColumn,
                balanceColumn);
    }

    private TableColumn<JournalService.LedgerRow, Long> debitColumn;
    private TableColumn<JournalService.LedgerRow, Long> creditColumn;
    private TableColumn<JournalService.LedgerRow, Long> balanceColumn;

    private void showEmptyState(boolean empty) {
        emptyState.setVisible(empty);
        emptyState.setManaged(empty);
        workArea.setVisible(!empty);
        workArea.setManaged(!empty);
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        if (client == null) {
            showEmptyState(true);
            return;
        }
        showEmptyState(false);
        banner.setText("General ledger — " + client.code() + " · " + client.name()
                + " · one account at a time · amounts in " + client.baseCurrency());
        debitColumn.setText("Debit (" + client.baseCurrency() + ")");
        creditColumn.setText("Credit (" + client.baseCurrency() + ")");
        balanceColumn.setText("Balance (" + client.baseCurrency() + ")");

        accounts = accountService.list(client.id(), true);
        Account previous = accountBox.getValue();
        accountBox.getItems().setAll(accounts);
        Account stillThere = previous == null ? null
                : accounts.stream().filter(a -> a.id() == previous.id()).findFirst().orElse(null);
        accountBox.setValue(stillThere);
        if (accountBox.getValue() == null && !accounts.isEmpty()) {
            // default to the first account that actually has posted lines —
            // an empty ledger of 'Cash on Hand' is nobody's first question
            java.util.Set<Long> active = journalService.accountIdsWithPostedLines(client.id());
            accounts.stream().filter(a -> active.contains(a.id())).findFirst()
                    .ifPresentOrElse(accountBox::setValue,
                            () -> accountBox.setValue(accounts.getFirst()));
        } else {
            reloadLedger();
        }
    }

    private void reloadLedger() {
        Account account = accountBox.getValue();
        this.account = account;
        if (client == null || account == null) {
            table.getItems().clear();
            return;
        }
        banner.setText("General ledger — " + account.code() + " — " + account.name()
                + " · " + account.type().label + " · normal side " + account.normalSide().label
                + (account.contra() ? " · contra" : "")
                + (account.active() ? "" : " · INACTIVE (history preserved)")
                + " · " + client.code() + " reports in " + client.baseCurrency());

        rows = journalService.ledger(client.id(), account.id());
        table.setItems(FXCollections.observableArrayList(rows));

        long dr = rows.stream().mapToLong(r -> r.debitCents() == null ? 0 : r.debitCents()).sum();
        long cr = rows.stream().mapToLong(r -> r.creditCents() == null ? 0 : r.creditCents()).sum();
        long closing = rows.isEmpty() ? 0 : rows.getLast().balanceCents();
        footer.setText(rows.size() + " posted lines · movement Dr " + Money.format(dr)
                + " / Cr " + Money.format(cr) + " · closing balance " + Money.format(closing)
                + " " + client.baseCurrency() + " ("
                + (closing >= 0 ? account.normalSide().label : account.normalSide().opposite().label)
                + "-normal)");
    }

    /**
     * 2.12.0: the account's ledger as CSV — date, entry, type, memo,
     * debit, credit, running balance; totals in the footer row.
     */
    private void exportCsv() {
        if (client == null || account == null || rows.isEmpty()) {
            javafx.scene.control.Alert info = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.INFORMATION,
                    "Nothing to export — this account has no posted lines.",
                    ButtonType.OK);
            info.setHeaderText(null);
            info.showAndWait();
            return;
        }
        String suggested = "ledger-" + client.code() + "-" + account.code() + "-"
                + java.time.LocalDate.now().format(
                        java.time.format.DateTimeFormatter.BASIC_ISO_DATE) + ".csv";
        javafx.stage.FileChooser chooser = new javafx.stage.FileChooser();
        chooser.setTitle("Export ledger CSV");
        chooser.setInitialFileName(suggested);
        chooser.getExtensionFilters().add(
                new javafx.stage.FileChooser.ExtensionFilter("CSV files", "*.csv"));
        java.io.File target = chooser.showSaveDialog(
                getScene() == null ? null : getScene().getWindow());
        if (target == null) {
            return;
        }
        long dr = rows.stream().mapToLong(r -> r.debitCents() == null ? 0 : r.debitCents()).sum();
        long cr = rows.stream().mapToLong(r -> r.creditCents() == null ? 0 : r.creditCents()).sum();
        try (java.io.BufferedWriter out = java.nio.file.Files.newBufferedWriter(
                target.toPath(), java.nio.charset.StandardCharsets.UTF_8)) {
            out.write("Date,Entry,Type,Memo,Debit (" + client.baseCurrency()
                    + "),Credit (" + client.baseCurrency() + "),Balance ("
                    + client.baseCurrency() + ")");
            out.write("\r\n");
            for (JournalService.LedgerRow row : rows) {
                out.write(String.join(",",
                        csv(row.date().toString()),
                        csv(Integer.toString(row.entryNo())),
                        csv(row.type().label),
                        csv(row.memo() == null ? "" : row.memo()),
                        csv(row.debitCents() == null ? "" : Long.toString(row.debitCents())),
                        csv(row.creditCents() == null ? "" : Long.toString(row.creditCents())),
                        csv(Long.toString(row.balanceCents()))));
                out.write("\r\n");
            }
            out.write(String.join(",",
                    "TOTAL", "", "", "",
                    csv(Long.toString(dr)), csv(Long.toString(cr)),
                    csv(rows.isEmpty() ? "0" : Long.toString(rows.getLast().balanceCents()))));
            out.write("\r\n");
        } catch (java.io.IOException e) {
            ClientsView.errorAlert(new IllegalStateException(
                    "The CSV could not be written (" + e.getMessage() + ")."));
            return;
        }
        javafx.scene.control.Alert info = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.INFORMATION,
                "Exported " + rows.size() + " posted lines to "
                        + target.getAbsolutePath() + ".",
                ButtonType.OK);
        info.setHeaderText("Exported");
        info.showAndWait();
    }

    /** CSV quoting: wrap in quotes, double embedded quotes. */
    private static String csv(String field) {
        String clean = field == null ? "" : field;
        boolean needsQuotes = clean.contains(",") || clean.contains("\"")
                || clean.contains("\n") || clean.contains("\r");
        String escaped = clean.replace("\"", "\"\"");
        return needsQuotes ? "\"" + escaped + "\"" : escaped;
    }
}
