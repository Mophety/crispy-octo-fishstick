package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Window;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

/**
 * The firm's client register: searchable table, new-client dialog,
 * archive/restore - never delete.
 *
 * <p>Rows are cached in {@link #allRows} on every {@link #refresh()}; typing
 * in the search box or toggling "show archived" only re-filters the cached
 * list, so keystrokes cost no database round trip.</p>
 */
public final class ClientsView extends VBox implements Refreshable {

    private final ClientService service;
    private final AccountService accountService;

    /** Notified after any mutation so the shell's switcher stays in sync. */
    private final Runnable onClientsChanged;

    private final TextField search = new TextField();
    private final CheckBox showArchived = new CheckBox("Show archived");
    private final TableView<Client> table = new TableView<>();
    private final Button archiveButton = new Button();
    private final Button editButton = new Button("Edit…");
    private final Label footer = new Label();

    private List<Client> allRows = List.of();

    public ClientsView(ClientService service, Runnable onClientsChanged) {
        this(service, null, onClientsChanged);
    }

    /** Variant with the account service the new-client dialog seeds charts
     * through; tests may omit it (no chart seeding in that flow). */
    public ClientsView(ClientService service, AccountService accountService,
                        Runnable onClientsChanged) {
        this.service = service;
        this.accountService = accountService;
        this.onClientsChanged = onClientsChanged;
        setSpacing(12);

        buildToolbar();
        buildTable();

        search.textProperty().addListener((obs, old, now) -> applyFilter());
        showArchived.selectedProperty().addListener((obs, old, now) -> applyFilter());

        getChildren().addAll(toolbar(), table, footer);
        VBox.setVgrow(table, Priority.ALWAYS);
    }

    // ------------------------------------------------------------------
    // Toolbar
    // ------------------------------------------------------------------

    private HBox toolbarHBox;

    private void buildToolbar() {
        Button newClient = new Button("New client…");
        newClient.getStyleClass().add("lp-compact-btn");
        newClient.setOnAction(e -> offerNewClient());

        editButton.getStyleClass().add("lp-compact-btn");
        editButton.setDisable(true);
        editButton.setTooltip(new Tooltip(
                "Change the selected client's code, name, currency or tax ID —"
                        + " the books, periods and audit trail stay attached."));
        editButton.setOnAction(e -> editSelected());

        archiveButton.getStyleClass().add("lp-compact-btn");
        archiveButton.setDisable(true);
        archiveButton.setOnAction(e -> toggleSelected());

        search.setPromptText("Search code or name…");
        search.setPrefWidth(260);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        toolbarHBox = new HBox(10, newClient, editButton, archiveButton, spacer,
                showArchived, search);
        toolbarHBox.setAlignment(Pos.CENTER_LEFT);
    }

    private HBox toolbar() {
        return toolbarHBox;
    }

    // ------------------------------------------------------------------
    // Table
    // ------------------------------------------------------------------

    private void buildTable() {
        table.setPlaceholder(new Label("No clients yet — create the firm's first client"
                + " with “New client…”."));

        TableColumn<Client, String> code = new TableColumn<>("Code");
        code.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().code()));
        code.setPrefWidth(90);
        code.getStyleClass().add("lp-col-strong");

        TableColumn<Client, String> name = new TableColumn<>("Name");
        name.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().name()));
        name.setPrefWidth(430);

        TableColumn<Client, String> currency = new TableColumn<>("Base currency");
        currency.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().baseCurrency()));
        currency.setPrefWidth(120);

        TableColumn<Client, String> status = new TableColumn<>("Status");
        status.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().active() ? "Active" : "Archived"));
        status.setPrefWidth(110);
        status.setCellFactory(StatusText.cell());

        TableColumn<Client, String> created = new TableColumn<>("Created");
        created.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().createdAt()));
        created.setPrefWidth(170);

        table.getColumns().addAll(code, name, currency, status, created);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.getSelectionModel().selectedItemProperty().addListener(
                (obs, old, now) -> {
                    updateArchiveButton();
                    editButton.setDisable(now == null);
                });
        // 2.9.0: double-click opens the edit form — the natural gesture for
        // "change something about this client"
        table.setRowFactory(view -> {
            javafx.scene.control.TableRow<Client> row = new javafx.scene.control.TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    editClient(row.getItem());
                }
            });
            return row;
        });

        MenuItem toggle = new MenuItem();
        toggle.textProperty().bind(archiveButton.textProperty());
        toggle.disableProperty().bind(archiveButton.disableProperty());
        toggle.setOnAction(e -> toggleSelected());

        // 2.9.0: the context menu carries Edit too
        MenuItem edit = new MenuItem("Edit…");
        edit.disableProperty().bind(editButton.disableProperty());
        edit.setOnAction(e -> editSelected());
        table.setContextMenu(new ContextMenu(edit, toggle));
    }

    private void updateArchiveButton() {
        Client selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            archiveButton.setText("Archive / restore");
            archiveButton.setDisable(true);
        } else if (selected.active()) {
            archiveButton.setText("Archive “" + selected.code() + "”");
            archiveButton.setDisable(false);
        } else {
            archiveButton.setText("Restore “" + selected.code() + "”");
            archiveButton.setDisable(false);
        }
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        allRows = service.list(true);
        applyFilter();
    }

    /** Rebuilds the visible rows from the cache + current filter settings. */
    private void applyFilter() {
        String needle = search.getText() == null ? "" : search.getText().trim().toLowerCase();
        boolean archived = showArchived.isSelected();

        ObservableList<Client> visible = FXCollections.observableArrayList(
                allRows.stream()
                        .filter(c -> archived || c.active())
                        .filter(c -> needle.isEmpty()
                                || c.code().toLowerCase().contains(needle)
                                || c.name().toLowerCase().contains(needle))
                        .toList());

        Client previous = table.getSelectionModel().getSelectedItem();
        table.setItems(visible);
        if (previous != null) {
            visible.stream()
                    .filter(c -> c.id() == previous.id())
                    .findFirst()
                    .ifPresent(c -> table.getSelectionModel().select(c));
        }

        long active = allRows.stream().filter(Client::active).count();
        long totalArchived = allRows.size() - active;
        footer.setText(visible.size() + " shown · " + active + " active · "
                + totalArchived + " archived — clients are never deleted, only archived");
        footer.getStyleClass().add("lp-muted");
        updateArchiveButton();
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    private void offerNewClient() {
        Window owner = getScene() == null ? null : getScene().getWindow();
        offerNewClientDialog(service, accountService, owner, created -> {
            refresh();
            onClientsChanged.run();
        });
    }

    /** 2.9.0: opens the edit form on the selected client. */
    private void editSelected() {
        Client selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            return;
        }
        editClient(selected);
    }

    /** The edit form itself — shared by the button, the menu and the double-click. */
    private void editClient(Client selected) {
        ClientDialog dialog = new ClientDialog(service, accountService, selected);
        Window owner = getScene() == null ? null : getScene().getWindow();
        if (owner != null) {
            dialog.initOwner(owner);
        }
        Optional<Client> result = dialog.showAndWait();
        result.ifPresent(updated -> {
            refresh();
            onClientsChanged.run();
            // keep the edited client visible-selected afterwards
            table.getItems().stream()
                    .filter(c -> c.id() == updated.id())
                    .findFirst()
                    .ifPresent(c -> table.getSelectionModel().select(c));
        });
    }

    private void toggleSelected() {
        Client selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            return;
        }
        boolean archiving = selected.active();

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                (archiving ? "Archive" : "Restore") + " client “" + selected.code()
                        + " — " + selected.name() + "”?",
                ButtonType.OK, ButtonType.CANCEL);
        confirm.setHeaderText(null);
        confirm.setTitle(archiving ? "Archive client" : "Restore client");
        if (archiving) {
            confirm.setContentText(confirm.getContentText()
                    + "\n\nNothing is deleted: history and audit trail stay intact;"
                    + " the client simply leaves the active lists.");
        }
        if (confirm.showAndWait().filter(ButtonType.OK::equals).isEmpty()) {
            return;
        }

        try {
            service.setActive(selected.id(), !archiving);
        } catch (RuntimeException e) {
            errorAlert(e);
            return;
        }
        refresh();
        onClientsChanged.run();
    }

    static void errorAlert(Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR,
                e.getMessage() == null ? e.toString() : e.getMessage(), ButtonType.OK);
        alert.setHeaderText(null);
        alert.setTitle("LedgerPro");
        alert.showAndWait();
    }

    /**
     * Shared implementation behind the Clients toolbar button and the shell's
     * top-bar button: opens the new-client dialog (with its starting-chart
     * template picker), calls back on success.
     */
    static void offerNewClientDialog(ClientService service, AccountService accountService,
                                      Window owner, Consumer<Client> onCreated) {
        ClientDialog dialog = new ClientDialog(service, accountService);
        if (owner != null) {
            dialog.initOwner(owner);
        }
        Optional<Client> result = dialog.showAndWait();
        result.ifPresent(onCreated);
    }
}
