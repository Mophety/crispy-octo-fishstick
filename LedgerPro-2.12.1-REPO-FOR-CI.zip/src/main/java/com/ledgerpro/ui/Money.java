package com.ledgerpro.ui;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.util.Locale;

/**
 * Money as the journal UI shows and reads it: integer cents in, integer
 * cents out — the UI never touches floating point for amounts (golden
 * rule 2).
 *
 * <p>Formatting is the firm's market convention: comma grouping, dot
 * decimal, exactly two fraction digits ('1,234.56'). Parsing accepts the
 * same shape with or without grouping ('1234.56', '1,234.56', '0.5'); more
 * than two fraction digits rounds half-up; negatives and garbage are
 * rejected with a message the dialogs can show verbatim.</p>
 *
 * <p><b>2.5.0:</b> grouping and zero display are user settings (Settings →
 * Money): grouping toggles '1,234,567.89' vs '1234567.89'; zero display
 * toggles '0.00' vs blank — the paper-sheet convention stays the default.
 * Both default from {@link Prefs} once on class init; the Settings dialog
 * flips them live.</p>
 */
public final class Money {

    private static final DecimalFormatSymbols SYMBOLS =
            DecimalFormatSymbols.getInstance(Locale.US);

    /**
     * Formatter caches (2.10.0): every visible money cell used to build a
     * fresh DecimalFormat per paint pass — the register repaints hundreds
     * of cells, and each construction re-compiles the pattern. One
     * thread-confined instance per pattern now serves the whole render
     * thread (the FX Application Thread). The instances are used only for
     * format(), which keeps no parse state between calls.
     */
    private static final ThreadLocal<DecimalFormat> GROUPED =
            ThreadLocal.withInitial(() -> new DecimalFormat("#,##0.00", SYMBOLS));
    private static final ThreadLocal<DecimalFormat> PLAIN =
            ThreadLocal.withInitial(() -> new DecimalFormat("#0.00", SYMBOLS));
    private static final ThreadLocal<DecimalFormat> ALWAYS_GROUPED =
            ThreadLocal.withInitial(() -> new DecimalFormat("#,##0.00", SYMBOLS));

    /** Thousands grouping in {@link #format} — set from Settings (live). */
    private static volatile boolean grouping = Prefs.DEFAULT_MONEY_GROUPED;

    /** Whether zero renders as '0.00' instead of blank — Settings (live). */
    private static volatile boolean zeroShown = Prefs.DEFAULT_ZERO_SHOWN;

    private Money() {
    }

    /** Turns comma grouping of displayed amounts on or off (live). */
    public static void setGrouping(boolean value) {
        grouping = value;
    }

    public static boolean isGrouping() {
        return grouping;
    }

    /** Turns explicit '0.00' rendering on or off (blank is the default). */
    public static void setZeroShown(boolean value) {
        zeroShown = value;
    }

    public static boolean isZeroShown() {
        return zeroShown;
    }

    /** Formats base-currency cents as '1,234.56' (or '1234.56'). */
    public static String format(long cents) {
        if (cents == 0 && !zeroShown) {
            return "";
        }
        return (grouping ? GROUPED : PLAIN).get().format(BigDecimal.valueOf(cents, 2));
    }

    /**
     * Formats with grouping ALWAYS ON — totals lines, footers and the
     * like benefit from grouping even when the table rows are ungrouped.
     */
    public static String formatGrouped(long cents) {
        if (cents == 0 && !zeroShown) {
            return "";
        }
        return ALWAYS_GROUPED.get().format(BigDecimal.valueOf(cents, 2));
    }

    /** Formats a rate like '56.732' — trailing zeros trimmed, never scientific. */
    public static String rate(double rate) {
        return BigDecimal.valueOf(rate).stripTrailingZeros().toPlainString();
    }

    /**
     * Parses a typed amount into cents.
     *
     * @throws IllegalArgumentException blank, negative or malformed input —
     *                                  with a message safe to show the user
     */
    public static long parseCents(String raw) {
        String text = raw == null ? "" : raw.trim().replace(",", "");
        if (text.isEmpty()) {
            throw new IllegalArgumentException("an amount must be typed");
        }
        BigDecimal value;
        try {
            value = new BigDecimal(text);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "'" + raw.trim() + "' is not a valid amount — try e.g. 1,250.50");
        }
        if (value.signum() < 0) {
            throw new IllegalArgumentException("amounts must be positive — use the"
                    + " Debit/Credit column to pick the side");
        }
        return value.movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact();
    }

    /** True when the text parses as a non-negative amount (for live validation). */
    public static boolean isParsable(String raw) {
        try {
            parseCents(raw);
            return true;
        } catch (IllegalArgumentException | ArithmeticException e) {
            return false;
        }
    }
}
