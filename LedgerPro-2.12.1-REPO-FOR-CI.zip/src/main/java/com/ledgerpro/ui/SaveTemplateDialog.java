package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.service.AdjTemplateService;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;

/**
 * Saves the current entry's lines as a recurring adjustment template: a code,
 * a name, an optional description — and, since migration V4, an amount
 * <b>source</b> per line.
 *
 * <p>Every line starts as a FIXED amount copied from the entry, but any line
 * can be switched to a FORMULA over the period's ledger — {@code 5% * BAL(1100)},
 * {@code BAL(1430) * 10% / 12} — which is evaluated against the client's
 * adjusted trial balance every time the template is loaded. That is what makes
 * a template recurring in the accountant's sense: the depreciation follows the
 * asset balance, the accrual follows the expense, without re-typing.</p>
 *
 * <p>The lines themselves are shown (and their amounts/formulas edited) above
 * the form so the accountant sees exactly what is being remembered.
 * Validation is the service's: a duplicate code in the same scope, a malformed
 * formula or any balance complaint surface inline and keep the dialog open.</p>
 */
final class SaveTemplateDialog extends Dialog<AdjTemplateService.Template> {

    private final TextField codeField = new TextField();
    private final TextField nameField = new TextField();
    private final TextField descriptionField = new TextField();
    private final CheckBox sharedBox = new CheckBox("Shared with every client");
    private final Label errorLabel = new Label();

    private final AdjTemplateService service;
    private final Client client;
    private final List<EditableLine> lines;
    private AdjTemplateService.Template saved;

    /** One editable line of the would-be template. */
    private static final class EditableLine {
        final String accountCode;
        final String side;            // "DR" / "CR"
        final String memo;
        final ComboBox<String> sourceBox = new ComboBox<>();
        final TextField valueField = new TextField();

        EditableLine(String accountCode, String side, long fixedCents, String memo) {
            this.accountCode = accountCode;
            this.side = side;
            this.memo = memo;
            sourceBox.getItems().addAll("Fixed amount", "Formula");
            sourceBox.getSelectionModel().selectFirst();
            sourceBox.setPrefWidth(110);
            valueField.setText(Money.format(fixedCents));
            valueField.setPrefWidth(170);
            valueField.setPromptText("1250.00 or 5% * BAL(1100)");
            sourceBox.valueProperty().addListener((obs, old, now) -> {
                boolean formula = "Formula".equals(now);
                if (formula && Money.isParsable(valueField.getText())) {
                    valueField.setText("");   // a formula rarely starts from a number
                }
                valueField.setPromptText(formula
                        ? "e.g. 5% * BAL(1100), BAL(1430) * 10% / 12"
                        : "1250.00");
            });
        }

        boolean formula() {
            return "Formula".equals(sourceBox.getValue());
        }

        AdjTemplateService.TemplateLine toTemplateLine(int lineNo) {
            return new AdjTemplateService.TemplateLine(lineNo, accountCode, side,
                    formula() ? AdjTemplateService.FORMULA : AdjTemplateService.FIXED,
                    valueField.getText().trim(), memo);
        }
    }

    SaveTemplateDialog(AdjTemplateService service, Client client,
                       String suggestedName,
                       List<AdjTemplateService.TemplateLine> seedLines) {
        this.service = service;
        this.client = client;
        this.lines = new ArrayList<>();
        for (AdjTemplateService.TemplateLine line : seedLines) {
            long cents = line.isFormula() ? 0 : line.fixedCents();
            lines.add(new EditableLine(line.accountCode(), line.side(), cents, line.memo()));
        }

        setTitle("Save as recurring template");
        setHeaderText("Remember these " + lines.size() + " lines as a reusable"
                + " adjustment template for " + client.code());

        ButtonType save = new ButtonType("Save template", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(save, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());
        getDialogPane().setPrefWidth(560);

        codeField.setPromptText("e.g. DEP_SL");
        codeField.setPrefColumnCount(12);
        nameField.setPromptText("e.g. Monthly depreciation — straight line");
        nameField.setText(suggestedName == null ? "" : suggestedName);
        descriptionField.setPromptText("optional — shown in the template picker");
        errorLabel.getStyleClass().add("lp-dialog-error");
        errorLabel.setWrapText(true);
        errorLabel.setMinHeight(34);

        VBox linesBox = new VBox(8, headerRow());
        for (EditableLine line : lines) {
            HBox row = new HBox(8,
                    fixedLabel(line.accountCode, 70),
                    fixedLabel(line.side, 26),
                    line.sourceBox,
                    line.valueField);
            row.setAlignment(Pos.CENTER_LEFT);
            linesBox.getChildren().add(row);
        }
        Label formulaHint = new Label("Formulas evaluate against the period's adjusted"
                + " trial balance when the template is loaded: BAL(code) is the account's"
                + " net balance, DR/CR(code) its gross movements. Percentages and"
                + " + - * / arithmetic work.");
        formulaHint.getStyleClass().add("lp-muted");
        formulaHint.setWrapText(true);
        linesBox.getStyleClass().add("lp-card");
        linesBox.setPadding(new Insets(10, 12, 10, 12));

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.addRow(0, new Label("Template code:"), codeField);
        form.addRow(1, new Label("Template name:"), nameField);
        form.addRow(2, new Label("Description:"), descriptionField);
        form.addRow(3, new Label(""), sharedBox);
        ColumnConstraints labels = new ColumnConstraints(110);
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(labels, fields);

        VBox content = new VBox(12, linesBox, formulaHint, form, errorLabel);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        getDialogPane().setContent(content);

        javafx.scene.Node saveButton = getDialogPane().lookupButton(save);
        saveButton.disableProperty().bind(Bindings.createBooleanBinding(
                () -> codeField.getText().isBlank() || nameField.getText().isBlank(),
                codeField.textProperty(), nameField.textProperty()));

        saveButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            try {
                List<AdjTemplateService.TemplateLine> out = new ArrayList<>();
                for (int i = 0; i < lines.size(); i++) {
                    out.add(lines.get(i).toTemplateLine(i + 1));
                }
                saved = service.save(sharedBox.isSelected() ? null : client.id(),
                        codeField.getText(), nameField.getText(),
                        descriptionField.getText(), out);
            } catch (IllegalArgumentException e) {
                errorLabel.setText("✗  " + e.getMessage());
                event.consume();
            }
        });

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE
                .equals(buttonType.getButtonData()) ? saved : null);
    }

    private static HBox headerRow() {
        Label account = new Label("Account");
        Label side = new Label("");
        Label source = new Label("Amount");
        Label value = new Label("Amount / formula");
        account.getStyleClass().add("lp-card-title");
        source.getStyleClass().add("lp-card-title");
        value.getStyleClass().add("lp-card-title");
        HBox header = new HBox(8, account, side, source, value);
        ((Region) header.getChildren().get(0)).setPrefWidth(70);
        ((Region) header.getChildren().get(1)).setPrefWidth(26);
        ((Region) header.getChildren().get(2)).setPrefWidth(110);
        return header;
    }

    private static Label fixedLabel(String text, double width) {
        Label label = new Label(text);
        label.setPrefWidth(width);
        label.setMinWidth(width);
        label.setAlignment(Pos.CENTER_LEFT);
        return label;
    }
}
