package com.ledgerpro.ui;

import javafx.geometry.Pos;
import javafx.scene.control.TableCell;

/**
 * Table cell for a nullable cents column: right-aligned, exactly two
 * decimals, blank for the null side. One class, every money table in the
 * Phase-4 views.
 */
final class MoneyCell<S> extends TableCell<S, Long> {

    MoneyCell() {
        setAlignment(Pos.CENTER_RIGHT);
    }

    @Override
    protected void updateItem(Long item, boolean empty) {
        super.updateItem(item, empty);
        setText(empty || item == null ? null : Money.format(item));
    }
}
