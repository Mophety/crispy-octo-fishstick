package com.ledgerpro.ui;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

/**
 * The one empty-state builder every view shares (2.12.0 design system).
 *
 * <p>Every view's no-client / no-data panel used to roll its own VBox with
 * hand-tuned spacing and three different class combinations. This builder
 * keeps the paper-document language — centered, calm, a glyph, a one-line
 * title, a hint that says what to do next, and an optional action button —
 * through the shared {@code lp-empty-*} classes, so a theme or density
 * change re-tints and re-spaces all of them at once.</p>
 */
public final class EmptyState {

    private final VBox box;

    private EmptyState(VBox box) {
        this.box = box;
    }

    /** A centered empty state: glyph, title, hint (all optional except title). */
    public static EmptyState of(String glyph, String title, String hint) {
        VBox inner = new VBox(8);
        inner.getStyleClass().add("lp-empty");
        inner.setAlignment(Pos.CENTER);
        if (glyph != null && !glyph.isBlank()) {
            Label g = new Label(glyph);
            g.getStyleClass().add("lp-empty-glyph");
            inner.getChildren().add(g);
        }
        Label t = new Label(title);
        t.getStyleClass().add("lp-empty-title");
        t.setWrapText(true);
        t.setMaxWidth(480);
        t.setAlignment(Pos.CENTER);
        inner.getChildren().add(t);
        if (hint != null && !hint.isBlank()) {
            Label h = new Label(hint);
            h.getStyleClass().add("lp-empty-hint");
            // 2.12.1 (P4-S6): the hint WRAPS — the dump showed 'Th...'
            // (the clipped hint) on a 1100px window; the CSS allowed
            // wrap but the label itself never set it
            h.setWrapText(true);
            h.setMaxWidth(480);
            h.setAlignment(Pos.CENTER);
            inner.getChildren().add(h);
        }

        Region top = new Region();
        Region bottom = new Region();
        VBox.setVgrow(top, Priority.ALWAYS);
        VBox.setVgrow(bottom, Priority.ALWAYS);
        VBox outer = new VBox(top, inner, bottom);
        outer.setAlignment(Pos.CENTER);
        return new EmptyState(outer);
    }

    /** Adds the action button (e.g. "New client…") under the hint. */
    public EmptyState action(Button button) {
        VBox inner = (VBox) ((VBox) box.getChildren().get(1));
        inner.getChildren().add(button);
        return this;
    }

    /** The node to add to the view's children. */
    public javafx.scene.Node node() {
        return box;
    }
}
