package com.ledgerpro.ui;

/**
 * Every view of the LedgerPro shell, in navigation order.
 *
 * <p>The {@code phase} field is the single source of truth for both the
 * navigation (views of a future phase render as honest placeholders) and the
 * roadmap card on the dashboard. Phase 0 means "shipped".</p>
 */
public enum ViewId {

    // ---- Workspace ------------------------------------------------------
    DASHBOARD("Dashboard", 0,
            ""),
    CLIENTS("Clients", 0,
            ""),
    COA("Chart of Accounts", 0,
            ""),
    FX_RATES("FX Rates", 0,
            ""),

    // ---- Accounting cycle -----------------------------------------------
    JOURNAL("Journal", 0,
            ""),
    LEDGERS("Ledgers", 0,
            ""),
    TRIAL_BALANCE("Trial Balance", 0,
            ""),
    WORKSHEET("Worksheet", 0,
            ""),
    REPORTS("Reports", 0,
            ""),

    // ---- Firm -----------------------------------------------------------
    AUDIT("Audit Log", 0,
            "");

    /** Title shown in the sidebar button and the top bar. */
    public final String title;

    /** The phase this view ships in; 0 = already shipped. */
    public final int phase;

    /** One-sentence scope description used by placeholders and the roadmap. */
    public final String blurb;

    ViewId(String title, int phase, String blurb) {
        this.title = title;
        this.phase = phase;
        this.blurb = blurb;
    }

    /** True once the view has a real implementation in this build. */
    public boolean isShipped() {
        return phase == 0;
    }
}
