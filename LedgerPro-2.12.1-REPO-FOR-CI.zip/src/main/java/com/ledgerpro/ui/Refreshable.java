package com.ledgerpro.ui;

import javafx.scene.Node;

/**
 * Views implement this so the shell can ask them to re-read fresh data from
 * the database every time they become visible.
 *
 * <p>Phase 2 keeps all queries on the JavaFX thread - a local SQLite file
 * answers in microseconds. If that ever stops being true (network DB, huge
 * journals), swapping this synchronous refresh for a background task is a
 * localized change.</p>
 */
public interface Refreshable {

    /** Re-reads everything the view displays. Called on each navigation. */
    void refresh();
}
