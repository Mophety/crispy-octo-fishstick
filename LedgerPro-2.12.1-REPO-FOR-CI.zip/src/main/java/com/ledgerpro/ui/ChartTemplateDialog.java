package com.ledgerpro.ui;

import com.ledgerpro.service.ChartTemplates;
import javafx.geometry.Insets;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

/**
 * Picks one of the firm's preset charts of accounts ({@link ChartTemplates})
 * for a client that already exists — Chart of Accounts → "Apply template…".
 *
 * <p>Each row shows the preset's name and account count; the description
 * below the list updates with the selection. The application is idempotent,
 * so re-applying a preset adds only the accounts still missing.</p>
 */
final class ChartTemplateDialog extends Dialog<ChartTemplates.Definition> {

    ChartTemplateDialog(String clientLabel) {
        setTitle("Apply a chart template");
        setHeaderText("Seed " + clientLabel + "'s chart of accounts");

        ButtonType apply = new ButtonType("Apply template", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(apply, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());

        ListView<ChartTemplates.Definition> list = new ListView<>(
                javafx.collections.FXCollections.observableArrayList(ChartTemplates.all()));
        list.setPrefHeight(120);
        list.setCellFactory(view -> new ListCell<>() {
            @Override
            protected void updateItem(ChartTemplates.Definition item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.toString());
            }
        });
        ChartTemplates.Definition standard =
                ChartTemplates.byCode("STANDARD").orElseThrow();
        list.getSelectionModel().select(standard);

        Label note = new Label();
        note.getStyleClass().add("lp-card-note");
        note.setWrapText(true);
        note.setMinHeight(56);   // reserve room: no layout jump while browsing

        list.getSelectionModel().selectedItemProperty().addListener((obs, old, now) -> {
            if (now == null) {
                note.setText("");
            } else {
                note.setText(now.description());
            }
        });
        note.setText(standard.description());

        Region spacer = new Region();

        Label howItWorks = new Label("Applying is idempotent: accounts whose codes already"
                + " exist stay untouched, only the missing ones are added.");
        howItWorks.getStyleClass().add("lp-muted");
        howItWorks.setWrapText(true);

        VBox content = new VBox(12, list, note, spacer, howItWorks);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        VBox.setVgrow(spacer, Priority.ALWAYS);
        getDialogPane().setContent(content);

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE
                .equals(buttonType.getButtonData())
                ? list.getSelectionModel().getSelectedItem() : null);
    }
}
