package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.WorksheetService;
import com.ledgerpro.service.WorksheetService.WorksheetFormat;
import com.ledgerpro.service.WorksheetService.Worksheet;
import com.ledgerpro.service.WorksheetService.WorksheetRow;
import com.ledgerpro.service.PeriodService;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.util.StringConverter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * The accounting worksheet of Phase 5 — the firm's internal working paper.
 *
 * <p>Every account of the period carries its unadjusted balance, its
 * adjustments and its adjusted balance, and the adjusted amount is sorted
 * into exactly one pair of statement columns: income statement, changes in
 * owner's equity (13-column format) or balance sheet. Below the account rows
 * sit the paper sheet's own rows — TOTAL Unadjusted, TOTAL Adjustments,
 * TOTAL Adjusted Trial Balance, NET INCOME, TOTAL Changes in Owner's Equity,
 * ENDING CAPITAL, TOTAL Balance Sheet and the grand TOTALS — each in its own
 * column group, each balancing, exactly the way the paper prints them.</p>
 *
 * <p>The grid is wide on purpose: it is a 13-column working paper. The table
 * menu (the + button in the header) hides column groups; the Columns box
 * switches between the 13-column sheet and the classic 10-column format
 * that folds equity into the balance sheet.</p>
 */
public final class WorksheetView extends VBox implements Refreshable {

    private final WorksheetService worksheetService;
    private final PeriodService periodService;
    private final ObservableValue<Client> activeClient;

    private final ComboBox<Period> periodBox = new ComboBox<>();
    private final ComboBox<WorksheetFormat> formatBox = new ComboBox<>();
    private final Button csvButton = new Button("Export CSV…");
    private final Button snapshotButton = new Button("Snapshot…");
    private final TableView<GridRow> table = new TableView<>();
    private final Label banner = new Label();
    private final Label totalsLine = new Label();
    private final Label footer = new Label();

    /** The Changes in Owner's Equity column group — always populated; the
     *  10-column format prints without it but keeps its cells live. */
    private TableColumn<GridRow, Long> soceDrColumn;
    private TableColumn<GridRow, Long> soceCrColumn;
    private TableColumn<GridRow, Long> soceGroup;

    private Client client;
    private List<Period> periods = List.of();
    private Worksheet current;

    private final VBox emptyState = buildEmptyState();
    private final VBox workArea = buildWorkArea();

    public WorksheetView(WorksheetService worksheetService, PeriodService periodService,
                         ObservableValue<Client> activeClient) {
        this.worksheetService = worksheetService;
        this.periodService = periodService;
        this.activeClient = activeClient;
        setSpacing(12);

        getChildren().addAll(emptyState, workArea);
        // fill the window: whichever of the two states is visible grows to
        // the full content height instead of leaving dead space below
        VBox.setVgrow(emptyState, Priority.ALWAYS);
        VBox.setVgrow(workArea, Priority.ALWAYS);
        showEmptyState(true);

        client = activeClient.getValue();
        activeClient.addListener((obs, old, now) -> {
            client = now;
            refresh();
        });
    }

    // ------------------------------------------------------------------
    // Layout
    // ------------------------------------------------------------------

    private static VBox buildEmptyState() {
        // 2.12.0: the shared empty-state builder — one look for
        // every view (glyph, title, hint), themed and density-aware
        return (VBox) EmptyState.of(
                "▦",
                "Pick a client in the top bar — the worksheet of their periods opens here.",
                "A worksheet needs a period with posted entries — adjustments included.").node();
    }

    private VBox buildWorkArea() {
        Label periodCaption = new Label("Period:");
        periodCaption.getStyleClass().add("lp-muted");
        periodBox.setPrefWidth(310);
        periodBox.valueProperty().addListener((obs, old, now) -> reload());

        Label formatCaption = new Label("Columns:");
        formatCaption.getStyleClass().add("lp-muted");
        formatBox.getItems().addAll(WorksheetFormat.values());
        formatBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(WorksheetFormat format) {
                return format == null ? "" : format.label;
            }

            @Override
            public WorksheetFormat fromString(String text) {
                return WorksheetFormat.parse(text);
            }
        });
        formatBox.getSelectionModel().selectLast();   // 13-column
        formatBox.valueProperty().addListener((obs, old, now) -> reload());

        csvButton.getStyleClass().add("lp-compact-btn");
        csvButton.setOnAction(e -> exportCsv());
        snapshotButton.getStyleClass().add("lp-compact-btn");
        snapshotButton.setOnAction(e -> snapshot());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox toolbar = new HBox(10, periodCaption, periodBox, formatCaption, formatBox,
                spacer, csvButton, snapshotButton);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        buildTable();
        installPaperOrderSorting();

        banner.getStyleClass().add("lp-card-note");
        banner.setWrapText(true);
        totalsLine.getStyleClass().add("lp-card-note");
        footer.getStyleClass().add("lp-muted");
        footer.setWrapText(true);

        VBox area = new VBox(12, banner, toolbar, table, totalsLine, footer);
        VBox.setVgrow(table, Priority.ALWAYS);
        area.setVisible(false);
        area.setManaged(false);
        return area;
    }

    private void buildTable() {
        table.setPlaceholder(new Label("Nothing posted in this period yet."));
        table.setTableMenuButtonVisible(true);
        // 2.8.0: dragging a header's edge now actually resizes — see
        // installUserResize for why the stock policy was a no-op here
        installUserResize();
        table.setRowFactory(view -> {
            TableRow<GridRow> row = new TableRow<>();
            row.itemProperty().addListener((obs, old, now) -> {
                row.getStyleClass().removeAll("lp-row-total", "lp-row-grand");
                if (now != null) {
                    if (now.kind() == RowKind.GRAND) {
                        row.getStyleClass().add("lp-row-grand");
                    } else if (now.kind() != RowKind.ACCOUNT) {
                        row.getStyleClass().add("lp-row-total");
                    }
                }
            });
            return row;
        });

        TableColumn<GridRow, String> code = new TableColumn<>("Code");
        code.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().code()));
        code.setPrefWidth(70);
        code.getStyleClass().add("lp-col-strong");

        TableColumn<GridRow, String> account = new TableColumn<>("Account");
        account.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().label()));
        account.setPrefWidth(270);
        account.setMinWidth(200);

        TableColumn<GridRow, Long> unadjDr = moneyColumn("Dr");
        TableColumn<GridRow, Long> unadjCr = moneyColumn("Cr");
        TableColumn<GridRow, Long> unadj = group("Unadjusted TB", unadjDr, unadjCr);

        TableColumn<GridRow, Long> adjDr = moneyColumn("Dr");
        TableColumn<GridRow, Long> adjCr = moneyColumn("Cr");
        TableColumn<GridRow, Long> adj = group("Adjustments", adjDr, adjCr);

        TableColumn<GridRow, Long> atbDr = moneyColumn("Dr");
        TableColumn<GridRow, Long> atbCr = moneyColumn("Cr");
        TableColumn<GridRow, Long> atb = group("Adjusted TB", atbDr, atbCr);

        TableColumn<GridRow, Long> isDr = moneyColumn("Dr");
        TableColumn<GridRow, Long> isCr = moneyColumn("Cr");
        TableColumn<GridRow, Long> is = group("Income Statement", isDr, isCr);

        soceDrColumn = moneyColumn("Dr");
        soceCrColumn = moneyColumn("Cr");
        soceGroup = group("Changes in Equity", soceDrColumn, soceCrColumn);

        TableColumn<GridRow, Long> bsDr = moneyColumn("Dr");
        TableColumn<GridRow, Long> bsCr = moneyColumn("Cr");
        TableColumn<GridRow, Long> bs = group("Balance Sheet", bsDr, bsCr);

        table.getColumns().addAll(code, account, unadj, adj, atb, is, soceGroup, bs);

        // wire the money columns to the grid cells
        cellFactory(unadjDr, r -> r.unadjDr());
        cellFactory(unadjCr, r -> r.unadjCr());
        cellFactory(adjDr, r -> r.adjDr());
        cellFactory(adjCr, r -> r.adjCr());
        cellFactory(atbDr, r -> r.atbDr());
        cellFactory(atbCr, r -> r.atbCr());
        cellFactory(isDr, r -> r.isDr());
        cellFactory(isCr, r -> r.isCr());
        cellFactory(soceDrColumn, r -> r.soceDr());
        cellFactory(soceCrColumn, r -> r.soceCr());
        cellFactory(bsDr, r -> r.bsDr());
        cellFactory(bsCr, r -> r.bsCr());
    }

    private static TableColumn<GridRow, Long> moneyColumn(String caption) {
        TableColumn<GridRow, Long> column = new TableColumn<>(caption);
        column.setPrefWidth(120);
        column.setMinWidth(96);
        column.setCellFactory(col -> new MoneyCell<>());
        column.setSortable(true);
        return column;
    }

    // ------------------------------------------------------------------
    // 2.8.0: user column resizing that actually resizes
    // ------------------------------------------------------------------

    /**
     * Why the worksheet's header drags did nothing: the leaf money columns
     * sit inside GROUP columns (Unadjusted TB, Adjustments, …), and the
     * stock resize policies re-flow columns to fit the table's fixed width
     * — with every leaf pinned by minWidth 96 and a table already wider
     * than the sum of pref widths, a drag's delta is absorbed by the
     * policy and never lands on any column. The fix: commit drag deltas
     * directly to the dragged leaf's prefWidth (see hookHeaderResize) and
     * keep the stock UNCONSTRAINED policy for the normal relayout, so the
     * user's chosen widths are what the table lays out by.
     */
    private void installUserResize() {
        // UNCONSTRAINED (the default) lays out columns at their own
        // prefWidths, which the drag-commit updates — exactly what a
        // resized worksheet should do
        table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        // The drag commit lives on the header nodes: hooked once the skin
        // lays out (the same lazy hook the 3-state sort uses).
        table.widthProperty().addListener((obs, old, now) -> {
            if (table.getWidth() > 0) {
                hookHeaderResize();
            }
        });
    }

    /**
     * Arms the drag-commit on every leaf header: at press the handler
     * remembers where the drag began (x, and the column's width at that
     * moment); at drag it commits startWidth + (mouseX − startX) to the
     * leaf's prefWidth — an ABSOLUTE target recomputed per event, so the
     * column tracks the mouse exactly and no incremental drift piles up.
     * Only drags that BEGIN in the header's right-edge zone (7 px) resize;
     * presses elsewhere keep their meaning (sorting).
     */
    private void hookHeaderResize() {
        for (TableColumn<GridRow, ?> column : allLeafColumns()) {
            javafx.scene.Node header = findHeader(column);
            if (header == null || header.getProperties().containsKey("lp-resize")) {
                continue;
            }
            header.getProperties().put("lp-resize", Boolean.TRUE);
            final double[] startX = {0};
            final double[] startWidth = {0};
            header.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_PRESSED,
                    event -> {
                        javafx.geometry.Bounds b = header.getLayoutBounds();
                        startX[0] = event.getX();
                        startWidth[0] = column.getWidth();
                        // remember whether this press is a resize grab
                        header.getProperties().put("lp-grab",
                                event.getX() >= b.getMaxX() - 7);
                    });
            header.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_DRAGGED,
                    event -> {
                        if (!Boolean.TRUE.equals(header.getProperties().get("lp-grab"))
                                || !event.isPrimaryButtonDown()) {
                            return;
                        }
                        double target = startWidth[0] + (event.getX() - startX[0]);
                        applyResize(column, target);
                    });
        }
    }

    /** Commits an absolute target width to the leaf column (min honored). */
    private void applyResize(TableColumn<GridRow, ?> column, double target) {
        column.setPrefWidth(Math.max(column.getMinWidth(), target));
        // keep the group's prefWidth tracking its children so a later
        // relayout doesn't un-do the user's choice
        TableColumn<GridRow, ?> parent = owningGroup(column);
        if (parent != null) {
            double childSum = 0;
            for (TableColumn<GridRow, ?> child : parent.getColumns()) {
                childSum += child.getWidth();
            }
            parent.setPrefWidth(childSum);
        }
    }

    /** The group column that owns a leaf, or null for a root column. */
    private TableColumn<GridRow, ?> owningGroup(TableColumn<GridRow, ?> leaf) {
        for (TableColumn<GridRow, ?> column : table.getColumns()) {
            if (column.getColumns().contains(leaf)) {
                return column;
            }
        }
        return null;
    }

    private static TableColumn<GridRow, Long> group(String caption,
                                                    TableColumn<GridRow, Long> dr,
                                                    TableColumn<GridRow, Long> cr) {
        TableColumn<GridRow, Long> group = new TableColumn<>(caption);
        group.getColumns().addAll(dr, cr);
        return group;
    }

    private static void cellFactory(TableColumn<GridRow, Long> column,
                                    java.util.function.Function<GridRow, Long> getter) {
        column.setCellValueFactory(c -> new SimpleObjectProperty<>(getter.apply(c.getValue())));
    }

    // ------------------------------------------------------------------
    // Sorting: asc -> desc -> the paper's own order (2.5.0)
    // ------------------------------------------------------------------

    /**
     * The worksheet's three-state sort cycle. JavaFX's stock header click
     * toggles only ASCENDING <-> DESCENDING forever: once a column was
     * sorted, clearing the arrow left a table that never returned to the
     * working paper's own row order. Every column here cycles a third state
     * — UNSORTED — that restores the paper's layout exactly (account rows
     * by code, then the sheet's special rows in their fixed order).
     *
     * <p>The policy keeps the special rows (TOTAL…, NET INCOME, ENDING
     * CAPITAL, TOTALS) BELOW the account rows whatever the sort: they are
     * the sheet's cross-foot, not account rows, and a sorted view that
     * interleaves "NET INCOME" between cash and supplies reads wrong.</p>
     */
    private void installPaperOrderSorting() {
        // The three-state cycle: each leaf column's header click walks
        // ASCENDING -> DESCENDING -> UNSORTED (the paper's own order) instead
        // of JavaFX's two-state flip. Intercepting the header's mouse press
        // BEFORE the stock toggling lets us clear the sort on the third
        // click, which restores the working paper's row order and removes
        // the header arrow — the exact stuck-sort complaint this fixes.
        java.util.List<TableColumn<GridRow, ?>> leaves = allLeafColumns();
        for (TableColumn<GridRow, ?> column : leaves) {
            column.setSortable(true);
        }

        // the policy: special rows stay BELOW the account rows whatever the
        // active sort (they are the sheet's cross-foot, not account rows),
        // and an empty sort order = the paper's own layout
        table.setSortPolicy(view -> {
            java.util.List<TableColumn<GridRow, ?>> order = view.getSortOrder();
            if (order.isEmpty()) {
                view.getItems().sort(paperOrder());
                return true;
            }
            java.util.Comparator<GridRow> base = null;
            for (TableColumn<GridRow, ?> column : order) {
                java.util.Comparator<GridRow> one = comparatorFor(column);
                if (one == null) {
                    continue;
                }
                if (column.getSortType() == TableColumn.SortType.DESCENDING) {
                    one = one.reversed();
                }
                base = base == null ? one : base.thenComparing(one);
            }
            java.util.Comparator<GridRow> full = base == null
                    ? paperOrder() : base.thenComparing(paperOrder());
            view.getItems().sort(full);
            return true;
        });

        // THE CYCLE: intercept each header's mouse press. The header nodes
        // exist once the table skin lays out, so hook lazily on width (the
        // columns arrive together) and once only.
        table.widthProperty().addListener((obs, old, now) -> {
            if (table.getWidth() > 0) {
                hookHeaderCycle();
            }
        });
    }

    /**
     * Arms the asc -> desc -> unsorted cycle on every leaf header. Each
     * header gets ONE mouse-press filter: when the column is already
     * DESCENDING, the next press clears the sort entirely instead of
     * flipping back to ascending — that is the third state, and with it
     * the grid returns to the paper's own order (arrow gone).
     */
    private void hookHeaderCycle() {
        for (TableColumn<GridRow, ?> column : allLeafColumns()) {
            javafx.scene.Node header = findHeader(column);
            if (header == null || header.getProperties().containsKey("lp-3state")) {
                continue;
            }
            header.getProperties().put("lp-3state", Boolean.TRUE);
            header.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_PRESSED,
                    event -> {
                        if (event.isPrimaryButtonDown()) {
                            if (column.getSortType()
                                    == TableColumn.SortType.DESCENDING) {
                                // third click: unwind to the paper's order
                                column.setSortType(null);
                                table.getSortOrder().remove(column);
                                table.sort();
                                event.consume();
                            }
                        }
                    });
        }
    }

    /**
     * Locates a leaf column's header node through the PUBLIC skin API:
     * TableViewSkin.getNestedColumnHeaders() walks the group headers down
     * to the leaf headers, and each (public, concrete) TableColumnHeader
     * exposes its column and its own node-ness — the mouse filter goes
     * straight on it.
     */
    /**
     * Locates the column-header node a leaf column owns, through the public
     * scene-graph API: every column header carries style class
     * "column-header", and each exposes its column through the public
     * {@code TableColumnHeader.getTableColumn()} accessor.
     */
    @SuppressWarnings("unchecked")
    private javafx.scene.Node findHeader(TableColumn<GridRow, ?> column) {
        for (javafx.scene.Node node : table.lookupAll(".column-header")) {
            if (node instanceof javafx.scene.control.skin.TableColumnHeader header
                    && column.equals(header.getTableColumn())) {
                return header;
            }
        }
        return null;
    }

    /** Every leaf column of the worksheet grid (the Dr/Cr cells). */
    private java.util.List<TableColumn<GridRow, ?>> allLeafColumns() {
        java.util.List<TableColumn<GridRow, ?>> leaves = new java.util.ArrayList<>();
        for (TableColumn<GridRow, ?> column : table.getColumns()) {
            if (column.getColumns().isEmpty()) {
                leaves.add(column);
            } else {
                for (TableColumn<GridRow, ?> sub : column.getColumns()) {
                    leaves.add(sub);
                }
            }
        }
        return leaves;
    }

    /** The paper's own order: account rows by code, then the special rows. */
    private java.util.Comparator<GridRow> paperOrder() {
        return java.util.Comparator
                .comparingInt((GridRow r) -> specialRank(r.kind()))
                .thenComparing(r -> r.code() == null ? "zzzz" : r.code())
                .thenComparing(r -> r.label() == null ? "" : r.label());
    }

    /** ACCOUNT=0 … the special rows follow the sheet's print order. */
    private static int specialRank(RowKind kind) {
        return switch (kind) {
            case ACCOUNT -> 0;
            case NET_INCOME, TOTAL, ENDING_CAPITAL -> 1;
            case GRAND -> 2;
        };
    }

    /** A comparator for one column, from its cell values (nulls last). */
    /**
     * A comparator for one column, read from its cell values (nulls last).
     * Raw-typed by nature: worksheet cells mix Long and String values.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private java.util.Comparator<GridRow> comparatorFor(TableColumn<GridRow, ?> column) {
        java.util.function.Function<GridRow, Object> value = row -> {
            var observable = column.getCellObservableValue(row);
            return observable == null ? null : observable.getValue();
        };
        return new java.util.Comparator<GridRow>() {
            @Override
            public int compare(GridRow a, GridRow b) {
                Object left = value.apply(a);
                Object right = value.apply(b);
                if (left == null && right == null) {
                    return 0;
                }
                if (left == null) {
                    return 1;    // nulls last
                }
                if (right == null) {
                    return -1;
                }
                if (left instanceof java.lang.Number ln
                        && right instanceof java.lang.Number rn) {
                    return Double.compare(ln.doubleValue(), rn.doubleValue());
                }
                return left.toString().compareToIgnoreCase(right.toString());
            }
        };
    }

    private void showEmptyState(boolean empty) {
        emptyState.setVisible(empty);
        emptyState.setManaged(empty);
        workArea.setVisible(!empty);
        workArea.setManaged(!empty);
    }

    // ------------------------------------------------------------------
    // Grid rows — the account rows plus the paper sheet's own rows
    // ------------------------------------------------------------------

    private enum RowKind { ACCOUNT, TOTAL, NET_INCOME, ENDING_CAPITAL, GRAND }

    private record GridRow(RowKind kind, String code, String label,
                           Long unadjDr, Long unadjCr, Long adjDr, Long adjCr,
                           Long atbDr, Long atbCr, Long isDr, Long isCr,
                           Long soceDr, Long soceCr, Long bsDr, Long bsCr) {
    }

    /** Zero reads as blank, the way the paper columns read. */
    private static Long blankIfZero(long cents) {
        return cents == 0 ? null : cents;
    }

    private List<GridRow> buildRows(Worksheet w) {
        boolean equityColumns = w.format() == WorksheetFormat.COLUMNS_13;
        List<GridRow> rows = new java.util.ArrayList<>();

        for (WorksheetRow r : w.rows()) {
            rows.add(new GridRow(RowKind.ACCOUNT, r.account().code(), r.account().name(),
                    blankIfZero(r.unadjDr()), blankIfZero(r.unadjCr()),
                    blankIfZero(r.adjDr()), blankIfZero(r.adjCr()),
                    blankIfZero(r.atbDr()), blankIfZero(r.atbCr()),
                    blankIfZero(r.isDr()), blankIfZero(r.isCr()),
                    blankIfZero(r.soceDr()), blankIfZero(r.soceCr()),
                    blankIfZero(r.bsDr()), blankIfZero(r.bsCr())));
        }

        long ni = w.netIncome();
        long niDr = Math.max(ni, 0);
        long niCr = Math.max(-ni, 0);
        long ec = w.endingCapital();
        long ecDr = Math.max(ec, 0);
        long ecCr = Math.max(-ec, 0);

        rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Unadjusted",
                w.totals().unadjDr(), w.totals().unadjCr(),
                null, null, null, null, null, null, null, null, null, null));
        rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Adjustments",
                null, null, w.totals().adjDr(), w.totals().adjCr(),
                null, null, null, null, null, null, null, null));
        rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Adjusted Trial Balance",
                null, null, null, null, w.totals().atbDr(), w.totals().atbCr(),
                null, null, null, null, null, null));

        if (equityColumns) {
            rows.add(new GridRow(RowKind.NET_INCOME, null, "NET INCOME",
                    null, null, null, null, null, null,
                    blankIfZero(niDr), blankIfZero(niCr),
                    blankIfZero(niCr), blankIfZero(niDr), null, null));
            rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Income Statement",
                    null, null, null, null, null, null,
                    w.isGrandDr(), w.isGrandCr(), null, null, null, null));
            rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Changes in Owner's Equity",
                    null, null, null, null, null, null, null, null,
                    w.soceGrandDr(), w.soceGrandCr(), null, null));
            rows.add(new GridRow(RowKind.ENDING_CAPITAL, null, "ENDING CAPITAL",
                    null, null, null, null, null, null, null, null,
                    blankIfZero(ecDr), blankIfZero(ecCr),
                    blankIfZero(ecCr), blankIfZero(ecDr)));
            rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Balance Sheet",
                    null, null, null, null, null, null, null, null, null, null,
                    w.bsGrandDr(), w.bsGrandCr()));
            rows.add(new GridRow(RowKind.GRAND, null, "TOTALS",
                    w.totals().unadjDr(), w.totals().unadjCr(),
                    w.totals().adjDr(), w.totals().adjCr(),
                    w.totals().atbDr(), w.totals().atbCr(),
                    w.isGrandDr(), w.isGrandCr(),
                    w.soceGrandDr(), w.soceGrandCr(),
                    w.bsGrandDr(), w.bsGrandCr()));
        } else {
            rows.add(new GridRow(RowKind.NET_INCOME, null, "NET INCOME",
                    null, null, null, null, null, null,
                    blankIfZero(niDr), blankIfZero(niCr),
                    null, null,
                    blankIfZero(niCr), blankIfZero(niDr)));
            rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Income Statement",
                    null, null, null, null, null, null,
                    w.isGrandDr(), w.isGrandCr(), null, null, null, null));
            rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Changes in Owner's Equity",
                    null, null, null, null, null, null, null, null,
                    w.soceGrandDr(), w.soceGrandCr(), null, null));
            rows.add(new GridRow(RowKind.TOTAL, null, "TOTAL Balance Sheet",
                    null, null, null, null, null, null, null, null,
                    null, null, w.bsGrandDr(), w.bsGrandCr()));
            rows.add(new GridRow(RowKind.GRAND, null, "TOTALS",
                    w.totals().unadjDr(), w.totals().unadjCr(),
                    w.totals().adjDr(), w.totals().adjCr(),
                    w.totals().atbDr(), w.totals().atbCr(),
                    w.isGrandDr(), w.isGrandCr(),
                    w.soceGrandDr(), w.soceGrandCr(),
                    w.bsGrandDr(), w.bsGrandCr()));
        }
        return rows;
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        if (client == null) {
            showEmptyState(true);
            return;
        }
        showEmptyState(false);
        banner.setText("Worksheet — " + client.code() + " · " + client.name()
                + " · amounts in " + client.baseCurrency());

        periods = periodService.list(client.id());
        Period previous = periodBox.getValue();
        periodBox.getItems().setAll(periods);
        Period stillThere = previous == null ? null
                : periods.stream().filter(p -> p.id() == previous.id()).findFirst().orElse(null);
        periodBox.setValue(stillThere != null ? stillThere
                : (!periods.isEmpty() ? periods.getLast() : null));
        reload();
    }

    private void reload() {
        if (client == null) {
            return;
        }
        Period period = periodBox.getValue();
        WorksheetFormat format = formatBox.getValue();
        boolean equityColumns = format == WorksheetFormat.COLUMNS_13;

        // The equity columns are ALWAYS populated (the service routes equity
        // into them in both formats); the 10-column sheet only styles its
        // group caption, so the kept-visible pair reads as a reference strip
        // rather than as an active paper column.
        soceGroup.getStyleClass().remove("lp-soce-kept");
        if (!equityColumns) {
            soceGroup.getStyleClass().add("lp-soce-kept");
        }

        if (period == null || format == null) {
            table.getItems().clear();
            totalsLine.setText("");
            footer.setText("Create a period and post entries in the journal first.");
            return;
        }

        current = worksheetService.worksheet(period.id(), format);
        table.setItems(FXCollections.observableArrayList(buildRows(current)));

        totalsLine.setText("Unadjusted " + Money.format(current.totals().unadjDr())
                + " = " + Money.format(current.totals().unadjCr())
                + "   ·   adjustments " + Money.format(current.totals().adjDr())
                + " = " + Money.format(current.totals().adjCr())
                + "   ·   " + (current.netIncome() >= 0 ? "net income " : "net loss ")
                + Money.format(Math.abs(current.netIncome()))
                + "   ·   ending capital " + Money.format(current.endingCapital())
                + "   ·   " + (current.balanced()
                ? "every column group balances ✓" : "OUT OF BALANCE — investigate immediately"));
        totalsLine.getStyleClass().setAll(current.balanced() ? "lp-status-ok" : "lp-dialog-error");

        footer.setText(period.name() + " (" + period.start() + " … " + period.end() + ")"
                + (period.closed() ? " · CLOSED" : " · open")
                + " · " + current.rows().size() + " accounts with activity"
                + " · " + format.label + " format"
                + (equityColumns ? ""
                : " · the Changes-in-Equity pair stays live and populated — the"
                + " classic sheet just prints without it")
                + " · sorting cycles asc → desc → the paper's own order"
                + " · closing entries stay out of the worksheet — the post-closing"
                + " trial balance carries them"
                + " · voiding mirrors cancel in the unadjusted columns"
                + " · CSV export keeps exact ungrouped decimals");
    }

    // ------------------------------------------------------------------
    // Export + snapshot
    // ------------------------------------------------------------------

    private void exportCsv() {
        Period period = periodBox.getValue();
        if (period == null || current == null) {
            return;
        }
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Export worksheet as CSV");
        chooser.setInitialFileName("worksheet-" + client.code() + "-" + period.name()
                + "-" + current.format().label.replace("-", "") + ".csv");
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV file", "*.csv"));
        java.io.File target = chooser.showSaveDialog(
                getScene() == null ? null : getScene().getWindow());
        if (target == null) {
            return;
        }
        try {
            Files.writeString(Path.of(target.toURI()),
                    worksheetService.toCsv(current), StandardCharsets.UTF_8);
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    "Worksheet exported:\n" + target.getAbsolutePath()
                            + "\n\nAmounts are exact ungrouped decimals — a spreadsheet"
                            + " ingests them losslessly.",
                    ButtonType.OK);
            done.setTitle("Worksheet exported");
            done.setHeaderText(null);
            if (getScene() != null) {
                done.initOwner(getScene().getWindow());
            }
            done.showAndWait();
        } catch (IOException | RuntimeException e) {
            ClientsView.errorAlert(e instanceof RuntimeException rx
                    ? rx : new IllegalStateException("could not write the file: " + e));
        }
    }

    private void snapshot() {
        Period period = periodBox.getValue();
        if (period == null || current == null) {
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Freeze this " + current.format().label + " worksheet of '"
                        + period.name() + "' into the audit trail?\n\n"
                        + "The snapshot is immutable — it records exactly the grid the"
                        + " firm produced, every column of every row, and when.",
                ButtonType.OK, ButtonType.CANCEL);
        confirm.setTitle("Snapshot worksheet");
        confirm.setHeaderText(null);
        if (getScene() != null) {
            confirm.initOwner(getScene().getWindow());
        }
        if (confirm.showAndWait().filter(ButtonType.OK::equals).isEmpty()) {
            return;
        }
        try {
            long id = worksheetService.snapshotWorksheet(period.id(), current.format());
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    "Snapshot #" + id + " stored — " + current.rows().size()
                            + " accounts, net income " + Money.format(Math.abs(current.netIncome()))
                            + ", ending capital " + Money.format(current.endingCapital()) + ".",
                    ButtonType.OK);
            done.setTitle("Worksheet snapshotted");
            done.setHeaderText(null);
            if (getScene() != null) {
                done.initOwner(getScene().getWindow());
            }
            done.showAndWait();
        } catch (RuntimeException e) {
            ClientsView.errorAlert(e);
        }
    }
}
