package com.ledgerpro.ui;

import com.ledgerpro.model.Account;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Side;
import com.ledgerpro.service.AccountFrozenException;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.DuplicateAccountCodeException;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;

import java.util.Optional;

/**
 * Modal form for one account of the working client's chart: code, name,
 * type, normal side — the last one preselected from the type but overridable,
 * which is exactly how contra accounts are registered.
 *
 * <p>Validation is layered exactly like the service:</p>
 * <ul>
 *   <li>the Save button stays disabled until code + name are non-blank;</li>
 *   <li>the normal-side combo follows the type's default until the user
 *       deliberately changes it — a live hint explains what a contra account
 *       is while it happens;</li>
 *   <li>a duplicate code is caught by the per-client UNIQUE constraint and
 *       surfaced inline — the dialog stays open, nothing half-created;</li>
 *   <li>in edit mode, an account that already carries journal lines opens
 *       with code, type and side frozen (only the name can change).</li>
 * </ul>
 */
final class AccountDialog extends Dialog<Account> {

    private final TextField codeField = new TextField();
    private final TextField nameField = new TextField();
    private final ComboBox<AccountType> typeBox = new ComboBox<>();
    private final ComboBox<Side> sideBox = new ComboBox<>();
    private final Label hintLabel = new Label();
    private final Label errorLabel = new Label();

    private final AccountService service;
    private final Account editing;      // null = create mode
    private Account saved;

    /** Create mode. */
    AccountDialog(AccountService service, long clientId) {
        this(service, null, clientId);
    }

    /** Edit mode: {@code editing} is the stored row to update. */
    AccountDialog(AccountService service, Account editing, long clientId) {
        this.service = service;
        this.editing = editing;

        setTitle(editing == null ? "New account" : "Edit account");
        setHeaderText(editing == null
                ? "Add an account to this client's chart of accounts"
                : editing.code() + " — " + editing.name());

        ButtonType save = new ButtonType(
                editing == null ? "Add account" : "Save changes",
                ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(save, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());

        typeBox.getItems().addAll(AccountType.values());
        typeBox.setConverter(typeConverter());
        sideBox.getItems().addAll(Side.values());
        sideBox.setConverter(sideConverter());
        codeField.setPromptText("e.g. 1010");
        nameField.setPromptText("e.g. Cash in Bank — Operating");
        errorLabel.getStyleClass().add("lp-dialog-error");
        errorLabel.setWrapText(true);
        errorLabel.setMinHeight(34);   // reserve space so the layout never jumps
        hintLabel.getStyleClass().add("lp-card-note");
        hintLabel.setWrapText(true);

        // ---- prefill (edit mode) BEFORE listeners, so defaults don't
        //      overwrite the stored contra side
        if (editing == null) {
            typeBox.getSelectionModel().select(AccountType.ASSET);
            sideBox.getSelectionModel().select(Side.DEBIT);
        } else {
            codeField.setText(editing.code());
            nameField.setText(editing.name());
            typeBox.getSelectionModel().select(editing.type());
            sideBox.getSelectionModel().select(editing.normalSide());
        }

        // ---- structure freeze: once posting has begun only the name moves
        boolean frozen = editing != null && service.hasJournalLines(editing.id());
        if (frozen) {
            codeField.setDisable(true);
            typeBox.setDisable(true);
            sideBox.setDisable(true);
            Label frozenNote = new Label("This account already carries journal lines:"
                    + " code, type and normal side are frozen — only the name can"
                    + " change. Posted history is never re-classified.");
            frozenNote.getStyleClass().add("lp-card-note");
            frozenNote.setWrapText(true);
            getDialogPane().setExpandableContent(frozenNote);
            getDialogPane().setExpanded(true);
        }

        // type change re-defaults the side (the user can still override)
        typeBox.valueProperty().addListener((obs, old, now) -> {
            if (now != null && !frozen) {
                sideBox.getSelectionModel().select(now.defaultSide());
            }
            updateHint();
        });
        sideBox.valueProperty().addListener((obs, old, now) -> updateHint());
        updateHint();

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.addRow(0, new Label("Code:"), codeField);
        form.addRow(1, new Label("Name:"), nameField);
        form.addRow(2, new Label("Type:"), typeBox);
        form.addRow(3, new Label("Normal side:"), sideBox);
        form.addRow(4, new Label(""), hintLabel);
        ColumnConstraints labels = new ColumnConstraints();
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(labels, fields);

        VBox content = new VBox(12, form, errorLabel);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        setOnShown(e -> codeField.requestFocus());
        getDialogPane().setContent(content);

        // Save unlocks only when both required fields are filled.
        javafx.scene.Node saveButton = getDialogPane().lookupButton(save);
        saveButton.disableProperty().bind(Bindings.createBooleanBinding(
                () -> codeField.getText().isBlank() || nameField.getText().isBlank()
                        || typeBox.getValue() == null || sideBox.getValue() == null,
                codeField.textProperty(), nameField.textProperty(),
                typeBox.valueProperty(), sideBox.valueProperty()));

        // Validate + persist BEFORE the dialog is allowed to close.
        saveButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            try {
                saved = editing == null
                        ? service.create(clientId, codeField.getText(), nameField.getText(),
                                typeBox.getValue(), sideBox.getValue())
                        : service.update(editing.id(), codeField.getText(), nameField.getText(),
                                typeBox.getValue(), sideBox.getValue());
            } catch (DuplicateAccountCodeException e) {
                errorLabel.setText("✗  " + e.getMessage()
                        + ". Codes identify accounts everywhere — pick another.");
                event.consume();
            } catch (AccountFrozenException e) {
                errorLabel.setText("✗  " + e.getMessage());
                event.consume();
            } catch (IllegalArgumentException e) {
                errorLabel.setText("✗  " + e.getMessage());
                event.consume();
            }
        });

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE.equals(buttonType.getButtonData())
                ? saved : null);
    }

    // ------------------------------------------------------------------
    // Contra-account hint
    // ------------------------------------------------------------------

    private void updateHint() {
        AccountType type = typeBox.getValue();
        Side side = sideBox.getValue();
        if (type == null || side == null) {
            hintLabel.setText("");
            return;
        }
        if (side == type.defaultSide()) {
            hintLabel.setText(type.label + " accounts normally increase with a "
                    + side.label + ".");
            hintLabel.getStyleClass().setAll("lp-card-note");
        } else {
            hintLabel.setText("Contra account: a " + type.label.toLowerCase()
                    + " that increases with a " + side.label
                    + " — like 'Accumulated Depreciation'.");
            hintLabel.getStyleClass().setAll("lp-contra");
        }
    }

    private static StringConverter<AccountType> typeConverter() {
        return new StringConverter<>() {
            @Override
            public String toString(AccountType type) {
                return type == null ? "" : type.label + " — " + sideMark(type.defaultSide()) + "+";
            }

            @Override
            public AccountType fromString(String text) {
                for (AccountType type : AccountType.values()) {
                    if (toString(type).equals(text)) {
                        return type;
                    }
                }
                return null;
            }
        };
    }

    private static StringConverter<Side> sideConverter() {
        return new StringConverter<>() {
            @Override
            public String toString(Side side) {
                return side == null ? "" : side.label + " (+)";
            }

            @Override
            public Side fromString(String text) {
                for (Side side : Side.values()) {
                    if (toString(side).equals(text)) {
                        return side;
                    }
                }
                return null;
            }
        };
    }

    private static String sideMark(Side side) {
        return side == Side.DEBIT ? "Dr" : "Cr";
    }
}
