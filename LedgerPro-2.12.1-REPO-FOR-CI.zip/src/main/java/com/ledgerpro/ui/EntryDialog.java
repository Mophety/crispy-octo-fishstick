package com.ledgerpro.ui;

import com.ledgerpro.model.Account;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.FxRate;
import com.ledgerpro.model.JournalEntry;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AdjTemplateService;
import com.ledgerpro.service.Formula;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The new-entry form: header fields plus a dynamic grid of Dr/Cr lines,
 * with the double-entry equation checked live as the accountant types.
 *
 * <p>Validation is layered exactly like the service:</p>
 * <ul>
 *   <li>the save buttons stay disabled until every line has an account and
 *       exactly one amount, the typed totals balance, and (for a foreign
 *       currency) a cached rate exists for the date;</li>
 *   <li>the balance line shows the running debit/credit totals and their
 *       difference — green when zero;</li>
 *   <li>service rejections surface inline and the dialog stays open —
 *       nothing half-created. The one exception: if "Save &amp; post" saves
 *       the draft but posting is refused (a race with period closing), the
 *       draft is kept and a modal notice says so.</li>
 * </ul>
 *
 * <p>Form mechanics, shaped by field testing:</p>
 * <ul>
 *   <li>the LINES area scrolls once the rows outgrow the dialog, so "+ Add
 *       line" can be clicked any number of times while the totals, the FX
 *       hint and the save buttons stay pinned and visible;</li>
 *   <li>the ✕ button on every line always works while more than two lines
 *       exist — enabled state is recomputed on EVERY add and remove, not
 *       only on removes;</li>
 *   <li>the "···" button beside each line memo is a working overflow menu:
 *       duplicate the line, clear its amounts, or remove it;</li>
 *   <li>recurring templates: "Load template…" prefills the form from a saved
 *       adjustment template (client's own or firm-shared); "Save as
 *       template…" remembers the current lines under a code for next time.</li>
 * </ul>
 */
final class EntryDialog extends Dialog<JournalEntry> {

    /** Common ISO 4217 codes; the client's base currency leads the list. */
    private static final List<String> CURRENCIES = List.of(
            "PHP", "USD", "EUR", "GBP", "JPY", "CNY", "SGD", "HKD", "AUD",
            "CAD", "CHF", "KRW", "MYR", "THB", "IDR", "VND", "TWD", "INR", "AED");

    private final Client client;
    private final List<Period> openPeriods;
    private final List<Account> accounts;
    private final FxRateService fxService;
    private final JournalService journalService;
    private final AdjTemplateService adjService;

    private final DatePicker datePicker = new DatePicker();
    private final ComboBox<EntryType> typeBox = new ComboBox<>();
    private final ComboBox<Period> periodBox = new ComboBox<>();
    private final ComboBox<String> currencyBox = new ComboBox<>();
    private final TextField referenceField = new TextField();
    private final TextField memoField = new TextField();
    private final Label fxInfo = new Label();
    private final Label errorLabel = new Label();
    private final Label debitTotal = new Label("0.00");
    private final Label creditTotal = new Label("0.00");
    private final Label balanceLine = new Label();

    private final VBox linesBox = new VBox(8);
    private final List<LineRow> lineRows = new ArrayList<>();

    /**
     * Whether the LINES alone make a saveable entry: at least two rows, every
     * row complete (an account plus exactly one well-formed amount) and the
     * debit total equal to the credit total. Updated by {@link #updateTotals()}
     * — which fires on EVERY keystroke, account pick, add and remove — so the
     * save buttons unlock the instant the last needed digit is typed.
     */
    private final SimpleBooleanProperty linesValid = new SimpleBooleanProperty(false);

    /**
     * The FX rate that WILL be used for a foreign-currency entry, resolved
     * once per date / period / currency change (never per keystroke — that
     * would hit the SQLite cache on every digit) and null when unusable.
     */
    private FxRate fxRate;

    /** Scrolls ONLY the lines: header, totals and buttons stay pinned. */
    private final ScrollPane linesScroll = new ScrollPane(linesBox);

    /** Visible lines area grows to this, then scrolls instead. */
    private static final double MAX_LINES_HEIGHT = 340;

    /** Hard floor: the lines area can never collapse below this, whatever
     *  the dialog's layout math thinks of its content today. */
    private static final double MIN_LINES_HEIGHT = 170;

    /** Comfortable row height — one line is a full edit row, not a sliver. */
    private static final double LINE_ROW_HEIGHT = 44;

    private JournalEntry created;

    /** Recurring template the form was prefilled from, if any (provenance). */
    private Long loadedTemplateId;

    /**
     * 2.12.0 duplicate-entry constructor: same shape as the plain one, but
     * the form opens prefilled with an existing entry's type, memo and
     * lines (date lands on TODAY, reference cleared — a duplicate is a new
     * business event, not a re-post of the old date).
     */
    EntryDialog(Client client, List<Period> openPeriods, Period preferred,
                List<Account> activeAccounts, FxRateService fxService,
                JournalService journalService, AdjTemplateService adjService,
                JournalEntry source, List<JournalService.LineRow> sourceLines) {
        this(client, openPeriods, preferred, activeAccounts, fxService,
                journalService, adjService);
        typeBox.setValue(source.type());
        memoField.setText(source.memo() == null ? "" : source.memo());
        if (source.currency() != null) {
            currencyBox.setValue(source.currency());
        }
        // rebuild the lines from the source (the ctor added two blanks)
        lineRows.clear();
        linesBox.getChildren().clear();
        for (JournalService.LineRow row : sourceLines) {
            LineRow fresh = addLine();
            fresh.accountBox.setValue(row.account());
            long dr = row.line().debitCents();
            long cr = row.line().creditCents();
            if (dr > 0) {
                fresh.debitField.setText(Money.format(dr));
            }
            if (cr > 0) {
                fresh.creditField.setText(Money.format(cr));
            }
            fresh.memoField.setText(row.line().memo() == null ? "" : row.line().memo());
        }
        updateTotals();
        scrollToLastRow();
        errorLabel.setText("Duplicating entry #" + source.entryNo()
                + " — check the date and amounts, then save.");
        errorLabel.getStyleClass().setAll("lp-muted");
    }

    EntryDialog(Client client, List<Period> openPeriods, Period preferred,
                List<Account> activeAccounts, FxRateService fxService,
                JournalService journalService, AdjTemplateService adjService) {
        this.client = client;
        this.openPeriods = openPeriods;
        this.accounts = List.copyOf(activeAccounts);
        this.fxService = fxService;
        this.journalService = journalService;
        this.adjService = adjService;

        setTitle("New journal entry");
        setHeaderText("Record a double entry for " + client.code() + " — "
                + client.name() + " (reports in " + client.baseCurrency() + ")");

        ButtonType saveDraft = new ButtonType("Save draft", ButtonBar.ButtonData.OTHER);
        ButtonType savePost = new ButtonType("Save & post", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(saveDraft, savePost, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());
        getDialogPane().setPrefWidth(840);
        // 2.9.0: the entry window is RESIZABLE — grab any edge or corner and
        // stretch it; a long entry gets a taller lines area (the scroll pane
        // takes every extra pixel), a wide one roomier columns. The floor
        // keeps the guaranteed area: header + two lines + totals visible.
        UiStartup.makeResizable(this, 860, 560);

        addLine();
        addLine();

        errorLabel.getStyleClass().add("lp-dialog-error");
        errorLabel.setWrapText(true);
        errorLabel.setMinHeight(34);

        VBox totals = new VBox(4);
        HBox totalsRow = new HBox(18);
        totalsRow.setAlignment(Pos.CENTER_LEFT);
        Label drCaption = new Label("Debits:");
        Label crCaption = new Label("Credits:");
        debitTotal.getStyleClass().add("lp-col-strong");
        creditTotal.getStyleClass().add("lp-col-strong");
        totalsRow.getChildren().addAll(drCaption, debitTotal, crCaption, creditTotal,
                new Region());
        HBox.setHgrow((Region) totalsRow.getChildren().getLast(), Priority.ALWAYS);
        balanceLine.setWrapText(true);
        totals.getChildren().addAll(totalsRow, balanceLine);
        totals.getStyleClass().add("lp-card");
        totals.setPadding(new Insets(8, 10, 8, 10));

        VBox content = new VBox(12, headerPane(), linesHeader(), linesScroll,
                templateBar(), totals, fxInfo, errorLabel);
        content.setMinWidth(780);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges

        // ONLY the lines scroll: "+ Add line" can add any number of rows
        // without pushing the totals, the FX hint or the buttons off-screen.
        // The scroll area's preferred height tracks the rows' natural height
        // up to a cap, so the dialog grows with a few lines and then stops;
        // the MIN floor keeps the area generous whatever the layout thinks.
        linesScroll.setFitToWidth(true);
        linesScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        linesScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        linesScroll.setMinHeight(MIN_LINES_HEIGHT);
        linesScroll.getStyleClass().add("lp-dialog-scroll");
        getDialogPane().setContent(content);
        // 2.9.0: a live re-fit while the user stretches the resizable
        // dialog — the lines area absorbs the extra height as it happens
        getDialogPane().sceneProperty().addListener((obs, oldScene, newScene) ->
                trackWindowHeight(newScene));
        trackWindowHeight(getDialogPane().getScene());
        updateLinesScrollHeight();

        javafx.scene.Node postButton = getDialogPane().lookupButton(savePost);
        javafx.scene.Node draftButton = getDialogPane().lookupButton(saveDraft);
        // linesValid is the piece the original binding missed: without it the
        // buttons only re-evaluated when the date, period or currency changed,
        // so a fully typed, balanced entry kept its buttons dim until the
        // accountant poked some unrelated header field. Now every keystroke,
        // account pick, add and remove re-evaluates them — the "Save & post"
        // button lights up the moment the entry balances.
        postButton.disableProperty().bind(Bindings.createBooleanBinding(
                this::invalid, datePicker.valueProperty(), periodBox.valueProperty(),
                currencyBox.valueProperty(), linesValid));
        draftButton.disableProperty().bind(postButton.disableProperty());

        postButton.addEventFilter(javafx.event.ActionEvent.ACTION, event ->
                save(true, event));
        draftButton.addEventFilter(javafx.event.ActionEvent.ACTION, event ->
                save(false, event));

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE
                .equals(buttonType.getButtonData())
                || ButtonBar.ButtonData.OTHER.equals(buttonType.getButtonData())
                ? created : null);

        // initial state
        datePicker.setValue(guessDefaultDate(preferred));
        updateFxInfo();
        updateTotals();
        focusFirstLine();
    }

    // ------------------------------------------------------------------
    // Header
    // ------------------------------------------------------------------

    private GridPane headerPane() {
        typeBox.getItems().addAll(EntryType.values());
        typeBox.getItems().removeIf(t -> !t.userSelectable());
        typeBox.getSelectionModel().selectFirst();
        typeBox.setConverter(new javafx.util.StringConverter<>() {
            @Override
            public String toString(EntryType type) {
                return type == null ? "" : type.label;
            }

            @Override
            public EntryType fromString(String text) {
                return EntryType.parse(text);
            }
        });

        periodBox.getItems().addAll(openPeriods);
        if (!openPeriods.isEmpty()) {
            periodBox.getSelectionModel().selectFirst();
        }

        currencyBox.getItems().add(client.baseCurrency());
        for (String code : CURRENCIES) {
            if (!code.equals(client.baseCurrency())) {
                currencyBox.getItems().add(code);
            }
        }
        currencyBox.setEditable(true);
        currencyBox.getSelectionModel().selectFirst();
        currencyBox.setPrefWidth(90);

        datePicker.valueProperty().addListener((obs, old, now) -> {
            clampDateToPeriod();
            updateFxInfo();
        });
        periodBox.valueProperty().addListener((obs, old, now) -> {
            clampDateToPeriod();
            updateFxInfo();
        });
        currencyBox.valueProperty().addListener((obs, old, now) -> updateFxInfo());

        memoField.setPromptText("e.g. Consulting revenue — Q1 retainer");
        referenceField.setPromptText("e.g. OR-2026-114, INV-88");

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.addRow(0, new Label("Date:"), datePicker, new Label("Type:"), typeBox);
        form.addRow(1, new Label("Period:"), periodBox, new Label("Currency:"), currencyBox);
        form.addRow(2, new Label("Reference:"), referenceField);
        form.addRow(3, new Label("Memo:"), memoField);
        ColumnConstraints c0 = new ColumnConstraints(95);
        ColumnConstraints c1 = new ColumnConstraints(210);
        ColumnConstraints c2 = new ColumnConstraints(60);
        ColumnConstraints c3 = new ColumnConstraints(180);
        form.getColumnConstraints().addAll(c0, c1, c2, c3);
        GridPane.setColumnSpan(memoField, 3);
        return form;
    }

    /** A sensible default date: today if inside the period, else its start. */
    private LocalDate guessDefaultDate(Period preferred) {
        if (preferred != null) {
            return preferred.contains(LocalDate.now())
                    ? LocalDate.now() : preferred.start();
        }
        return LocalDate.now();
    }

    /** Keeps the picked date inside the picked period (both inclusive). */
    private void clampDateToPeriod() {
        Period period = periodBox.getValue();
        LocalDate date = datePicker.getValue();
        if (period != null && date != null) {
            if (date.isBefore(period.start())) {
                datePicker.setValue(period.start());
            } else if (date.isAfter(period.end())) {
                datePicker.setValue(period.end());
            }
        }
    }

    // ------------------------------------------------------------------
    // FX preview
    // ------------------------------------------------------------------

    private boolean foreignCurrency() {
        String value = currencyBox.getValue();
        return value != null && !value.isBlank()
                && !value.trim().equalsIgnoreCase(client.baseCurrency());
    }

    /** The rate that WILL be used, or null when none is cached. */
    private FxRate resolvedRate() {
        if (!foreignCurrency() || datePicker.getValue() == null) {
            return null;
        }
        try {
            return fxService.latestUpTo(datePicker.getValue(),
                    currencyBox.getValue().trim(), client.baseCurrency()).orElse(null);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private void updateFxInfo() {
        // Resolve (and cache) the rate that WILL be used: invalid() reads the
        // cache, so the save buttons' binding — re-evaluated per keystroke —
        // never hits the SQLite FX cache. The cache refreshes exactly when
        // the date / period / currency listeners call this method.
        fxRate = resolvedRate();
        if (!foreignCurrency()) {
            fxInfo.setText("Recording in the client's base currency " + client.baseCurrency()
                    + " — no conversion.");
            fxInfo.getStyleClass().setAll("lp-muted");
            return;
        }
        if (fxRate == null) {
            fxInfo.setText("No cached " + currencyBox.getValue().trim() + "→"
                    + client.baseCurrency() + " rate on or before " + datePicker.getValue()
                    + " — fetch or store one in the FX Rates view first.");
            fxInfo.getStyleClass().setAll("lp-dialog-error");
            return;
        }
        fxInfo.setText("1 " + fxRate.fromCur() + " = " + Money.rate(fxRate.rate()) + " "
                + fxRate.toCur() + " · cached " + fxRate.asOf() + " (" + fxRate.source().name()
                + ") — typed amounts post to the ledger in " + client.baseCurrency()
                + "; any rounding residual is absorbed by the largest line.");
        fxInfo.getStyleClass().setAll("lp-muted");
        fxInfo.setWrapText(true);
    }

    // ------------------------------------------------------------------
    // Lines
    // ------------------------------------------------------------------

    private HBox linesHeader() {
        Label account = new Label("Account");
        Label debit = new Label("Debit");
        Label credit = new Label("Credit");
        Label memo = new Label("Line memo");
        Label actions = new Label("");
        account.getStyleClass().add("lp-card-title");
        debit.getStyleClass().add("lp-card-title");
        credit.getStyleClass().add("lp-card-title");
        memo.getStyleClass().add("lp-card-title");
        HBox header = new HBox(8, account, debit, credit, memo, actions);
        header.setPadding(new Insets(0, 0, 2, 0));
        sizeLineRow(header);
        return header;
    }

    private void sizeLineRow(HBox row) {
        ((Region) row.getChildren().get(0)).setPrefWidth(300);
        ((Region) row.getChildren().get(0)).setMinWidth(250);
        ((Region) row.getChildren().get(1)).setPrefWidth(120);
        ((Region) row.getChildren().get(2)).setPrefWidth(120);
        ((Region) row.getChildren().get(3)).setPrefWidth(150);
        ((Region) row.getChildren().get(3)).setMinWidth(80);
        if (row.getChildren().size() > 4) {
            ((Region) row.getChildren().get(4)).setPrefWidth(30);
        }
        if (row.getChildren().size() > 5) {
            ((Region) row.getChildren().get(5)).setPrefWidth(30);
        }
    }

    /** The bar under the lines: add a line, or load/save a recurring template. */
    private HBox templateBar() {
        javafx.scene.control.Hyperlink addLine = new javafx.scene.control.Hyperlink("+ Add line");
        addLine.setOnAction(e -> addLine());
        addLine.setPadding(new Insets(0, 0, 0, 2));

        Button loadTemplate = new Button("Load template…");
        loadTemplate.getStyleClass().add("lp-compact-btn");
        loadTemplate.setOnAction(e -> loadTemplate());

        Button saveTemplate = new Button("Save as template…");
        saveTemplate.getStyleClass().add("lp-compact-btn");
        saveTemplate.setOnAction(e -> saveTemplate());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox bar = new HBox(14, addLine, loadTemplate, saveTemplate, spacer);
        bar.setAlignment(Pos.CENTER_LEFT);
        return bar;
    }

    private LineRow addLine() {
        return addLine(null, null);
    }

    /** Adds a line, optionally prefilled (template load); returns the row. */
    private LineRow addLine(Account account, AdjTemplateService.AppliedLine prefill) {
        LineRow row = new LineRow();
        lineRows.add(row);
        linesBox.getChildren().add(row);
        if (account != null) {
            row.accountBox.setValue(account);
        }
        if (prefill != null) {
            if (prefill.debitCents() != null) {
                row.debitField.setText(Money.format(prefill.debitCents()));
            }
            if (prefill.creditCents() != null) {
                row.creditField.setText(Money.format(prefill.creditCents()));
            }
            if (prefill.memo() != null) {
                row.memoField.setText(prefill.memo());
            }
        }
        updateRemoveButtons();
        updateTotals();
        updateLinesScrollHeight();
        scrollToLastRow();
        return row;
    }

    /**
     * 2.12.0 keyboard-first: when the dialog lands, focus goes to the first
     * line's account combo — the field every entry starts from — so
     * type-to-search works without a mouse click.
     */
    private void focusFirstLine() {
        setOnShown(e -> {
            if (!lineRows.isEmpty()) {
                LineRow first = lineRows.getFirst();
                first.accountBox.requestFocus();
            }
        });
    }

    /** Keeps the newest line in view after "+ Add line" or a duplicate. */
    private void scrollToLastRow() {
        javafx.application.Platform.runLater(() ->
                linesScroll.setVvalue(1.0));
    }

    /**
     * ONE place that decides whether the ✕ buttons (and the matching menu
     * item) may fire: at least two lines must remain on the form. Called on
     * EVERY add and remove — the original bug was recomputing this only in
     * the remove handler, so buttons stayed disabled after "+ Add line".
     */
    private void updateRemoveButtons() {
        boolean lock = lineRows.size() <= 2;
        for (LineRow row : lineRows) {
            row.remove.setDisable(lock);
            row.removeItem.setDisable(lock);
        }
    }

    /** One editable line of the entry. */
    private final class LineRow extends HBox {

        final ComboBox<Account> accountBox = new ComboBox<>();
        final TextField debitField = new TextField();
        final TextField creditField = new TextField();
        final TextField memoField = new TextField();
        final Button remove = new Button("✕");
        final MenuItem removeItem = new MenuItem("Remove this line");
        final MenuItem duplicateItem = new MenuItem("Duplicate this line");
        final MenuItem clearItem = new MenuItem("Clear amounts");

        LineRow() {
            super(8);
            accountBox.getItems().addAll(accounts);
            accountBox.setPrefWidth(300);
            accountBox.setMinWidth(250);
            accountBox.setPromptText("pick an account…");

            debitField.setPrefWidth(120);
            debitField.setPromptText("0.00");
            creditField.setPrefWidth(120);
            creditField.setPromptText("0.00");
            memoField.setPrefWidth(150);
            memoField.setMinWidth(80);
            memoField.setPromptText("optional note");

            // A line is a full edit row — never a sliver one scrollbar tick
            // tall. The pref/min pair guarantees it under every platform
            // theme, and the spacing between rows keeps them readable.
            setMinHeight(LINE_ROW_HEIGHT);
            setPrefHeight(LINE_ROW_HEIGHT);
            setMaxHeight(LINE_ROW_HEIGHT + 6);

            // the "···" overflow menu beside the line memo — always live:
            // duplicate, clear amounts, remove (gated by the two-line rule)
            MenuButton more = new MenuButton("···");
            more.getStyleClass().add("lp-compact-btn");
            more.setPrefWidth(34);
            more.setPopupSide(javafx.geometry.Side.BOTTOM);
            duplicateItem.setOnAction(e -> duplicateRow(LineRow.this));
            clearItem.setOnAction(e -> {
                debitField.clear();
                creditField.clear();
                updateTotals();
            });
            removeItem.setOnAction(e -> removeRow(LineRow.this));
            more.getItems().addAll(duplicateItem, clearItem, new javafx.scene.control.SeparatorMenuItem(), removeItem);

            remove.getStyleClass().add("lp-compact-btn");
            remove.setPrefWidth(30);
            remove.setOnAction(e -> removeRow(LineRow.this));

            debitField.textProperty().addListener((obs, old, now) -> {
                if (!now.isBlank() && !creditField.getText().isBlank()) {
                    // clearing the credit fires ITS listener, which recomputes —
                    // returning here keeps one recompute per keystroke, not two
                    creditField.setText("");
                    return;
                }
                updateTotals();
            });
            creditField.textProperty().addListener((obs, old, now) -> {
                if (!now.isBlank() && !debitField.getText().isBlank()) {
                    debitField.setText("");
                    return;
                }
                updateTotals();
            });
            accountBox.valueProperty().addListener((obs, old, now) -> updateTotals());

            getChildren().addAll(accountBox, debitField, creditField, memoField, more, remove);
            setAlignment(Pos.CENTER_LEFT);
        }

        /**
         * One glance at the row's text: parsed once, answering completeness,
         * malformedness and the two totals together — the single source every
         * live check (totals, balance line, save-button enablement) reads.
         */
        private record RowState(boolean complete, boolean malformed,
                                long debitCents, long creditCents) {}

        RowState state() {
            String debit = debitField.getText();
            String credit = creditField.getText();
            boolean hasDebit = debit != null && !debit.isBlank();
            boolean hasCredit = credit != null && !credit.isBlank();
            boolean debitMalformed = hasDebit && !Money.isParsable(debit);
            boolean creditMalformed = hasCredit && !Money.isParsable(credit);
            boolean malformed = debitMalformed || creditMalformed;
            long dr = 0;
            long cr = 0;
            if (!malformed) {
                if (hasDebit) {
                    dr = Money.parseCents(debit);
                }
                if (hasCredit) {
                    cr = Money.parseCents(credit);
                }
            }
            boolean oneSide = hasDebit ^ hasCredit;
            return new RowState(accountBox.getValue() != null && oneSide && !malformed,
                    malformed, dr, cr);
        }

        /**
         * 2.12.0 inline validation: toggles the danger border on exactly
         * the fields whose text does not parse. Called once per recompute
         * from {@link #updateTotals()} — no extra parsing, and a field
         * that becomes valid again clears its own flag.
         */
        void markInvalidAmounts(boolean malformed) {
            String debit = debitField.getText();
            String credit = creditField.getText();
            boolean debitBad = malformed && debit != null && !debit.isBlank()
                    && !Money.isParsable(debit);
            boolean creditBad = malformed && credit != null && !credit.isBlank()
                    && !Money.isParsable(credit);
            debitField.getStyleClass().remove("lp-field-invalid");
            creditField.getStyleClass().remove("lp-field-invalid");
            if (debitBad) {
                debitField.getStyleClass().add("lp-field-invalid");
            }
            if (creditBad) {
                creditField.getStyleClass().add("lp-field-invalid");
            }
        }

        boolean complete() {
            return state().complete();
        }

        Optional<JournalService.NewLine> toNewLine() {
            if (!complete()) {
                return Optional.empty();
            }
            String debit = debitField.getText();
            String credit = creditField.getText();
            Long debitCents = debit != null && !debit.isBlank()
                    ? Money.parseCents(debit) : null;
            Long creditCents = credit != null && !credit.isBlank()
                    ? Money.parseCents(credit) : null;
            return Optional.of(new JournalService.NewLine(
                    accountBox.getValue().id(), debitCents, creditCents, memoField.getText()));
        }
    }

    // ------------------------------------------------------------------
    // Line actions shared by the ✕ button and the "···" menu
    // ------------------------------------------------------------------

    private void removeRow(LineRow row) {
        lineRows.remove(row);
        linesBox.getChildren().remove(row);
        updateRemoveButtons();
        updateTotals();
        updateLinesScrollHeight();
    }

    private void duplicateRow(LineRow row) {
        LineRow copy = new LineRow();
        int index = lineRows.indexOf(row) + 1;
        lineRows.add(index, copy);
        linesBox.getChildren().add(index, copy);
        copy.accountBox.setValue(row.accountBox.getValue());
        if (row.debitField.getText() != null && !row.debitField.getText().isBlank()) {
            copy.debitField.setText(row.debitField.getText());
        }
        if (row.creditField.getText() != null && !row.creditField.getText().isBlank()) {
            copy.creditField.setText(row.creditField.getText());
        }
        if (row.memoField.getText() != null) {
            copy.memoField.setText(row.memoField.getText());
        }
        updateRemoveButtons();
        updateTotals();
        updateLinesScrollHeight();
    }

    /**
     * The lines area's preferred height: the rows' natural height while they
     * fit, the cap once they do not — the moment "+ Add line" would overflow
     * the dialog, the scrollbar takes over while totals stay pinned below.
     * Never below the floor, so the area is always worth several lines.
     *
     * <p>2.9.0: the cap STRETCHES with the dialog — a resizable entry
     * window taller than its default shows proportionally more lines before
     * scrolling kicks in (the fixed 340 cap used to letterbox a stretched
     * window). The header, totals and buttons always stay pinned because
     * only this scroll area grows.</p>
     */
    /** Wires the live re-fit of the lines area to the window's height (2.9.0). */
    private void trackWindowHeight(javafx.scene.Scene scene) {
        if (scene == null || scene.getWindow() == null) {
            return;
        }
        scene.getWindow().heightProperty().addListener((obs, old, now) ->
                updateLinesScrollHeight());
    }

    private void updateLinesScrollHeight() {
        double cap = MAX_LINES_HEIGHT;
        javafx.scene.Scene scene = getDialogPane().getScene();
        if (scene != null && scene.getWindow() instanceof javafx.stage.Stage stage
                && stage.isShowing()) {
            // every pixel the window grew past its default becomes lines
            double grown = stage.getHeight() - 620;
            if (grown > 0) {
                cap = Math.min(MAX_LINES_HEIGHT + grown, 2_000);
            }
        }
        linesScroll.setPrefHeight(Math.max(MIN_LINES_HEIGHT,
                Math.min(linesBox.prefHeight(-1) + 2, cap)));
    }

    // ------------------------------------------------------------------
    // Recurring templates
    // ------------------------------------------------------------------

    /** Opens the template picker and prefills the form with the choice. */
    private void loadTemplate() {
        LoadTemplateDialog picker = new LoadTemplateDialog(adjService, client);
        if (getDialogPane().getScene() != null) {
            picker.initOwner(getDialogPane().getScene().getWindow());
        }
        Optional<AdjTemplateService.Template> chosen = picker.showAndWait();
        chosen.ifPresent(this::applyTemplate);
    }

    private void applyTemplate(AdjTemplateService.Template template) {
        List<AdjTemplateService.AppliedLine> applied;
        try {
            // Formulas evaluate against the selected period's ADJUSTED trial
            // balance — "5% of the balance" means what the accountant sees.
            com.ledgerpro.model.TbStage stage = com.ledgerpro.model.TbStage.ADJUSTED;
            Formula.Context ctx = periodBox.getValue() == null ? null
                    : com.ledgerpro.service.JournalService.formulaContext(
                            journalService.trialBalance(periodBox.getValue().id(), stage));
            applied = adjService.instantiate(template.id(), accounts, ctx);
        } catch (IllegalArgumentException e) {
            errorLabel.setText("✗  " + e.getMessage());
            errorLabel.getStyleClass().setAll("lp-dialog-error");
            return;
        }

        lineRows.clear();
        linesBox.getChildren().clear();
        for (AdjTemplateService.AppliedLine line : applied) {
            addLine(line.account(), line);
        }

        typeBox.getSelectionModel().select(EntryType.ADJUSTING);
        if (memoField.getText() == null || memoField.getText().isBlank()) {
            memoField.setText(template.name());
        }
        loadedTemplateId = template.id();
        updateRemoveButtons();
        updateTotals();
        errorLabel.setText("✓  Template " + template.code() + " loaded — adjust the date"
                + " and amounts, then save.");
        errorLabel.getStyleClass().setAll("lp-muted");
    }

    /** Remembers the current lines under a code, via the save dialog. */
    private void saveTemplate() {
        if (lineRows.size() < 2 || lineRows.stream().anyMatch(row -> !row.complete())) {
            errorLabel.setText("✗  Every line needs an account and exactly one amount"
                    + " before the entry can be remembered as a template.");
            errorLabel.getStyleClass().setAll("lp-dialog-error");
            return;
        }
        long dr = 0;
        long cr = 0;
        for (LineRow row : lineRows) {
            if (row.debitField.getText() != null && !row.debitField.getText().isBlank()) {
                dr += Money.parseCents(row.debitField.getText());
            }
            if (row.creditField.getText() != null && !row.creditField.getText().isBlank()) {
                cr += Money.parseCents(row.creditField.getText());
            }
        }
        if (dr != cr) {
            errorLabel.setText("✗  A template must balance — debits " + Money.format(dr)
                    + " ≠ credits " + Money.format(cr) + ".");
            errorLabel.getStyleClass().setAll("lp-dialog-error");
            return;
        }

        List<AdjTemplateService.TemplateLine> lines = new ArrayList<>();
        for (LineRow row : lineRows) {
            boolean debit = row.debitField.getText() != null
                    && !row.debitField.getText().isBlank();
            lines.add(new AdjTemplateService.TemplateLine(
                    lines.size() + 1,
                    row.accountBox.getValue().code(),
                    debit ? "DR" : "CR",
                    AdjTemplateService.FIXED,
                    (debit ? row.debitField.getText() : row.creditField.getText()).trim(),
                    row.memoField.getText()));
        }

        String suggestion = memoField.getText() == null ? null : memoField.getText().trim();
        SaveTemplateDialog dialog = new SaveTemplateDialog(adjService, client,
                suggestion, lines);
        if (getDialogPane().getScene() != null) {
            dialog.initOwner(getDialogPane().getScene().getWindow());
        }
        Optional<AdjTemplateService.Template> saved = dialog.showAndWait();
        saved.ifPresent(template -> {
            errorLabel.setText("✓  Saved as template " + template.code()
                    + (template.shared() ? " (shared with every client)" : "")
                    + " — load it any time with “Load template…”.");
            errorLabel.getStyleClass().setAll("lp-muted");
        });
    }

    // ------------------------------------------------------------------
    // Live totals + validity
    // ------------------------------------------------------------------

    private void updateTotals() {
        long dr = 0;
        long cr = 0;
        boolean anyMalformed = false;
        boolean anyIncomplete = false;
        // ONE pass over the rows: each row's text is parsed once (the old
        // version re-parsed every field three times per keystroke through
        // complete(), malformedAmount() and the totals sum) and the result
        // feeds the labels, the balance line AND linesValid together.
        // 2.12.0: the same pass flags the offending FIELD inline
        // (lp-field-invalid) — the malformed row is visible at a glance,
        // not only named in the footer line.
        for (LineRow row : lineRows) {
            LineRow.RowState state = row.state();
            anyMalformed |= state.malformed();
            anyIncomplete |= !state.complete();
            dr += state.debitCents();
            cr += state.creditCents();
            row.markInvalidAmounts(state.malformed());
        }
        debitTotal.setText(Money.format(dr));
        creditTotal.setText(Money.format(cr));
        linesValid.set(lineRows.size() >= 2 && !anyIncomplete && !anyMalformed && dr == cr);

        String currency = foreignCurrency() ? currencyBox.getValue().trim() : client.baseCurrency();
        if (anyMalformed) {
            balanceLine.setText("Some amount is not a valid number — fix the highlighted"
                    + " shape (e.g. 1,250.50).");
            balanceLine.getStyleClass().setAll("lp-dialog-error");
        } else if (anyIncomplete) {
            balanceLine.setText("Every line needs an account and exactly one amount —"
                    + " amounts are in " + currency + ".");
            balanceLine.getStyleClass().setAll("lp-muted");
        } else if (dr != cr) {
            balanceLine.setText("Out of balance — debits " + Money.format(dr) + " ≠ credits "
                    + Money.format(cr) + " (difference " + Money.format(Math.abs(dr - cr))
                    + " " + currency + ").");
            balanceLine.getStyleClass().setAll("lp-dialog-error");
        } else {
            balanceLine.setText("Balanced ✓ — debits = credits = " + Money.format(dr) + " "
                    + currency + ".");
            balanceLine.getStyleClass().setAll("lp-status-ok");
        }
    }

    /**
     * Everything the save buttons require before they unlock — all of it
     * observable (the header fields plus {@link #linesValid}), so the binding
     * above keeps the buttons in lock-step with what the accountant sees.
     */
    private boolean invalid() {
        if (datePicker.getValue() == null || periodBox.getValue() == null) {
            return true;
        }
        if (!linesValid.get()) {
            return true;
        }
        return foreignCurrency() && fxRate == null;
    }

    // ------------------------------------------------------------------
    // Save
    // ------------------------------------------------------------------

    private void save(boolean post, javafx.event.ActionEvent event) {
        if (invalid()) {
            event.consume();
            return;
        }
        List<JournalService.NewLine> lines = lineRows.stream()
                .map(LineRow::toNewLine)
                .flatMap(Optional::stream)
                .toList();
        try {
            if (created == null) {
                created = journalService.createDraft(new JournalService.NewEntry(
                        client.id(),
                        periodBox.getValue().id(),
                        datePicker.getValue(),
                        typeBox.getValue(),
                        referenceField.getText(),
                        memoField.getText(),
                        foreignCurrency() ? currencyBox.getValue().trim() : null,
                        loadedTemplateId,
                        lines));
            }
            if (post && !created.posted()) {
                try {
                    created = journalService.post(created.id());
                } catch (RuntimeException e) {
                    // the draft IS saved — say so, close, let the register finish the job
                    Alert notice = new Alert(Alert.AlertType.WARNING,
                            "The draft was saved, but posting was refused:\n\n"
                                    + e.getMessage()
                                    + "\n\nThe draft sits in the journal register —"
                                    + " post it from there once this is resolved.",
                            ButtonType.OK);
                    notice.setHeaderText(null);
                    notice.setTitle("Saved as draft");
                    if (getDialogPane().getScene() != null) {
                        notice.initOwner(getDialogPane().getScene().getWindow());
                    }
                    notice.showAndWait();
                    return;   // do NOT consume: close and hand back the draft
                }
            }
        } catch (RuntimeException e) {
            errorLabel.setText("✗  " + e.getMessage());
            errorLabel.getStyleClass().setAll("lp-dialog-error");
            event.consume();
        }
    }
}
