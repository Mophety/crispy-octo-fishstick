package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ChartTemplates;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.DuplicateClientCodeException;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * Modal form for adding a client: code, legal name, base currency — and the
 * preset chart of accounts the new client starts from.
 *
 * <p>Validation is layered exactly like the service:</p>
 * <ul>
 *   <li>the Create button stays disabled until code + name are non-blank;</li>
 *   <li>malformed input (bad characters, wrong currency shape) is rejected
 *       inline with the service's own message;</li>
 *   <li>a duplicate code is caught by the UNIQUE constraint and surfaced here
 *       as an inline error — the dialog stays open, nothing half-created.</li>
 * </ul>
 *
 * <p>The chart picker offers "None" plus the firm's presets
 * ({@link ChartTemplates}); picking one seeds the client's chart the moment
 * the client is created — the accountant can prune and extend afterwards in
 * Chart of Accounts. Picking "None" leaves an empty chart to build by hand.</p>
 *
 * <p>Every input carries a one-line description right below it
 * ({@code .lp-field-hint}): what the field is for, its allowed shape and
 * where the value shows up later — so a first-time user can fill the form
 * without guessing. The hints are muted and theme-aware, so they stay
 * legible in all six looks.</p>
 */
final class ClientDialog extends Dialog<Client> {

    /** Common ISO 4217 codes for the firm's market; PHP is the default. */
    private static final List<String> CURRENCIES = List.of(
            "PHP", "USD", "EUR", "GBP", "JPY", "CNY", "SGD", "HKD", "AUD",
            "CAD", "CHF", "KRW", "MYR", "THB", "IDR", "VND", "TWD", "INR", "AED");

    /** One-line description shown under the Client code field. */
    private static final String CODE_HINT =
            "Short ID that identifies this client in lists, ledgers and reports."
                    + " 1\u201312 characters \u2014 letters, digits, '.' and '-';"
                    + " saved as UPPERCASE.";

    /** One-line description shown under the Legal name field. */
    private static final String NAME_HINT =
            "The client's registered business name, exactly as it should appear"
                    + " on statements and reports.";

    /** One-line description shown under the Tax ID field. */
    private static final String TAX_ID_HINT =
            "Optional \u2014 the client's tax identification number (e.g. TIN)."
                    + " Kept for the register; not validated.";

    /** One-line description shown under the Base currency field. */
    private static final String CURRENCY_HINT =
            "The currency this client's books are kept in. Journal entries in other"
                    + " currencies convert into it at their FX rate. Any 3-letter ISO"
                    + " 4217 code (e.g. PHP) can be typed.";

    private final TextField codeField = new TextField();
    private final TextField nameField = new TextField();
    private final TextField taxIdField = new TextField();
    private final ComboBox<String> currencyBox = new ComboBox<>();
    private final ComboBox<ChartTemplates.Definition> templateBox = new ComboBox<>();
    private final Label templateNote = new Label();
    private final Label errorLabel = new Label();

    private final ClientService service;
    private final AccountService accountService;
    private final Client editing;   // null when creating; the client when editing
    private Client created;

    ClientDialog(ClientService service, AccountService accountService) {
        this(service, accountService, null);
    }

    /**
     * 2.9.0: the EDIT mode — the form opens pre-filled with the client's
     * current identity, the title says Edit, the save button reads "Save
     * changes", and no chart template is offered (the chart is managed in
     * Chart of Accounts, not by renaming the client).
     */
    ClientDialog(ClientService service, AccountService accountService, Client edit) {
        this.service = service;
        this.accountService = accountService;
        this.editing = edit;

        boolean isEdit = edit != null;
        setTitle(isEdit ? "Edit client " + edit.code() : "New client");
        setHeaderText(isEdit
                ? "Update " + edit.code() + " — " + edit.name()
                + ". Journal entries, periods and the chart stay attached —"
                        + " nothing is re-created."
                : "Add a client to the firm's workspace");

        ButtonType create = new ButtonType(
                isEdit ? "Save changes" : "Add client", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(create, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());

        codeField.setPromptText("e.g. NRTH");
        codeField.setPrefColumnCount(10);
        nameField.setPromptText("e.g. Norte Freight Systems, Inc.");
        taxIdField.setPromptText("optional — e.g. 009-876-543-000");
        currencyBox.getItems().addAll(CURRENCIES);
        currencyBox.getSelectionModel().selectFirst();
        currencyBox.setEditable(true);
        errorLabel.getStyleClass().add("lp-dialog-error");
        errorLabel.setWrapText(true);
        errorLabel.setMinHeight(34);   // reserve space so the layout never jumps

        if (isEdit) {
            codeField.setText(edit.code());
            nameField.setText(edit.name());
            taxIdField.setText(edit.taxId() == null ? "" : edit.taxId());
            if (!CURRENCIES.contains(edit.baseCurrency())) {
                currencyBox.getItems().add(0, edit.baseCurrency());
            }
            currencyBox.getSelectionModel().select(edit.baseCurrency());
        }

        // ---- starting chart of accounts: create-mode only (2.9.0; the
        // edit form manages identity only — the chart lives in Chart of
        // Accounts) -------------------------------------------------------
        if (editing == null) {
            templateBox.getItems().add(null);   // "None — empty chart"
            templateBox.getItems().addAll(ChartTemplates.all());
            templateBox.getSelectionModel().select(
                    ChartTemplates.byCode("STANDARD").orElseThrow());
            templateBox.setConverter(new javafx.util.StringConverter<>() {
                @Override
                public String toString(ChartTemplates.Definition definition) {
                    return definition == null ? "None — empty chart" : definition.toString();
                }

                @Override
                public ChartTemplates.Definition fromString(String text) {
                    return ChartTemplates.all().stream()
                            .filter(d -> toString(d).equals(text))
                            .findFirst().orElse(null);
                }
            });
            // No fixed pref width: the picker stretches with the field column like
            // every other input, so the full option text ("Detailed — full
            // corporate chart  ·  70 accounts") is never ellipsized.
            templateBox.setMaxWidth(Double.MAX_VALUE);
            templateNote.getStyleClass().add("lp-card-note");
            templateNote.setWrapText(true);
            templateNote.setMinHeight(44);   // three lines reserved: no layout jump
            templateBox.valueProperty().addListener((obs, old, now) -> updateTemplateNote());
            updateTemplateNote();
        }

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.addRow(0, new Label("Client code:"), withHint(codeField, CODE_HINT));
        form.addRow(1, new Label("Legal name:"), withHint(nameField, NAME_HINT));
        form.addRow(2, new Label("Tax ID:"), withHint(taxIdField, TAX_ID_HINT));
        form.addRow(3, new Label("Base currency:"), withHint(currencyBox, CURRENCY_HINT));
        if (editing == null) {
            form.addRow(4, new Label("Starting chart:"), templateBox);
            form.addRow(5, new Label(""), templateNote);
        }
        form.getColumnConstraints().clear();
        javafx.scene.layout.ColumnConstraints labels = new javafx.scene.layout.ColumnConstraints();
        javafx.scene.layout.ColumnConstraints fields = new javafx.scene.layout.ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(labels, fields);

        VBox content = new VBox(12, form, errorLabel);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        getDialogPane().setContent(content);
        // 2.12.0 keyboard-first: the code field is where a new client starts
        setOnShown(e -> codeField.requestFocus());
        // 2.9.0: resizable — the edit form stretches with the window
        UiStartup.makeResizable(this, 480, 420);

        // The Create button unlocks only when both required fields are filled.
        javafx.scene.Node createButton = getDialogPane().lookupButton(create);
        createButton.disableProperty().bind(Bindings.createBooleanBinding(
                () -> codeField.getText().isBlank() || nameField.getText().isBlank(),
                codeField.textProperty(), nameField.textProperty()));

        // Validate + insert BEFORE the dialog is allowed to close.
        createButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            if (editing != null) {
                // 2.9.0 — the edit path: update the identity; a duplicate
                // code is caught by the UNIQUE constraint and shown inline
                try {
                    created = service.update(editing.id(),
                            codeField.getText(), nameField.getText(),
                            currencyBox.getValue(), taxIdField.getText());
                } catch (DuplicateClientCodeException e) {
                    errorLabel.setText("✗  " + e.getMessage()
                            + ". Pick another code — it identifies the client everywhere.");
                    event.consume();
                } catch (IllegalArgumentException e) {
                    errorLabel.setText("✗  " + e.getMessage());
                    event.consume();
                }
                return;
            }
            ChartTemplates.Definition template = templateBox.getValue();
            try {
                created = service.create(
                        codeField.getText(), nameField.getText(), currencyBox.getValue(),
                        template == null ? null : template.code(),
                        taxIdField.getText());
            } catch (DuplicateClientCodeException e) {
                errorLabel.setText("✗  " + e.getMessage()
                        + ". Pick another code — it identifies the client everywhere.");
                event.consume();
                return;
            } catch (IllegalArgumentException e) {
                errorLabel.setText("✗  " + e.getMessage());
                event.consume();
                return;
            }
            // Client row is in; seed the chart when a preset was picked. The
            // application is idempotent and cannot realistically fail after a
            // successful insert — but if it ever does, say so honestly: the
            // client exists, the template can be applied from Chart of
            // Accounts later. (accountService is null only in headless tests.)
            if (template != null && accountService != null) {
                try {
                    accountService.applyChartTemplate(created.id(), template);
                } catch (RuntimeException e) {
                    errorLabel.getStyleClass().setAll("lp-dialog-error");
                    errorLabel.setText("✗  Client " + created.code() + " was created, but the"
                            + " starting chart could not be seeded (" + e.getMessage()
                            + "). Apply it from Chart of Accounts → “Apply template…”.");
                    event.consume();
                }
            }
        });

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE.equals(buttonType.getButtonData())
                ? created : null);
    }

    /** (create mode only) */
    private void updateTemplateNote() {
        ChartTemplates.Definition definition = templateBox.getValue();
        if (definition == null) {
            templateNote.setText("The chart starts empty — add accounts one by one in"
                    + " Chart of Accounts, or apply a preset there later.");
        } else {
            templateNote.setText(definition.description() + " (" + definition.size()
                    + " accounts will be created now; prune and extend freely afterwards.)");
        }
    }

    /**
     * Wraps an input and its one-line description in a VBox so the hint sits
     * directly under the control, indented with it — not under the row label.
     * The box stretches with the column, so the input keeps its width.
     */
    private static VBox withHint(javafx.scene.control.Control input, String text) {
        Label hint = new Label(text);
        hint.getStyleClass().add("lp-field-hint");
        hint.setWrapText(true);
        return new VBox(3, input, hint);
    }
}
