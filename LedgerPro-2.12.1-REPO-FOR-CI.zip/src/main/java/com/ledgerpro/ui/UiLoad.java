package com.ledgerpro.ui;

import javafx.application.Platform;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

/**
 * One background reader for view refreshes (2.12.0 performance work).
 *
 * <p>The 2.11 codebase read EVERY view's data synchronously inside
 * {@code refresh()} on the JavaFX Application Thread — fine for a few
 * hundred rows on the dev machine, but a full-year journal in
 * ENTRY_LINES mode (one row per line) or a 13-column worksheet can spend
 * hundreds of milliseconds in SQLite, freezing every animation and menu
 * on the target 1.6 GHz dual-core machine.</p>
 *
 * <p>This helper runs the read on ONE daemon reader thread and hands the
 * result back to the FX thread; a stale result (the user switched client
 * or view mid-read) is dropped by comparing an epoch counter the caller
 * bumps on every new load:</p>
 *
 * <pre>
 *   private final AtomicLong loadEpoch = new AtomicLong();
 *   void reload() {
 *       long epoch = loadEpoch.incrementAndGet();
 *       UiLoad.async(() -&gt; service.list(id), rows -&gt; {
 *           if (epoch != loadEpoch.get()) return;   // a newer load exists
 *           table.setItems(...);
 *       });
 *   }
 * </pre>
 *
 * <p>Single thread on purpose: SQLite connections are cheap but the views
 * share one database file, and serializing reads keeps WAL contention and
 * thread count minimal on a dual-core target.</p>
 */
public final class UiLoad {

    /** The one daemon reader thread (lazy — plain-UI tests never touch it). */
    private static volatile ExecutorService reader;

    private UiLoad() {
    }

    private static ExecutorService reader() {
        ExecutorService result = reader;
        if (result == null) {
            synchronized (UiLoad.class) {
                result = reader;
                if (result == null) {
                    AtomicInteger n = new AtomicInteger();
                    ThreadFactory factory = runnable -> {
                        Thread thread = new Thread(runnable,
                                "ledgerpro-ui-reader-" + n.incrementAndGet());
                        thread.setDaemon(true);
                        return thread;
                    };
                    result = Executors.newSingleThreadExecutor(factory);
                    reader = result;
                }
            }
        }
        return result;
    }

    /**
     * Reads {@code work} off the FX thread, then applies it on the FX
     * thread. When the FX thread is gone (headless test teardown), the
     * apply is simply skipped.
     *
     * @param <T> the payload type
     */
    public static <T> void async(Supplier<T> work, java.util.function.Consumer<T> apply) {
        CompletableFuture.supplyAsync(work, reader())
                .whenComplete((payload, error) -> {
                    if (error != null) {
                        // the caller's services throw IllegalStateException
                        // on real failures; surface those through the same
                        // path a synchronous read would have used
                        if (error.getCause() instanceof RuntimeException runtime) {
                            throw runtime;
                        }
                        throw new IllegalStateException("background read failed",
                                error.getCause());
                    }
                    if (Platform.isFxApplicationThread()) {
                        apply.accept(payload);
                    } else {
                        Platform.runLater(() -> {
                            try {
                                apply.accept(payload);
                            } catch (RuntimeException e) {
                                // an apply failing after teardown (view gone)
                                // must not kill the reader thread silently —
                                // rethrow only while a toolkit still runs
                                if (Platform.isFxApplicationThread()) {
                                    throw e;
                                }
                            }
                        });
                    }
                });
    }

    /** Shuts the reader thread down (tests). */
    public static synchronized void shutdown() {
        ExecutorService result = reader;
        reader = null;
        if (result != null) {
            result.shutdownNow();
        }
    }
}
