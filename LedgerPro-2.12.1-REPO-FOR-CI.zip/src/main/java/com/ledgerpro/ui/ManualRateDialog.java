package com.ledgerpro.ui;

import com.ledgerpro.model.FxRate;
import com.ledgerpro.service.FxRateService;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.Optional;

/**
 * Modal form for one manual FX rate: date, pair, rate.
 *
 * <p>A manual rate is the firm's explicit word against the ECB reference
 * set — it deliberately overrides a cached API rate for the same date and
 * pair, which is exactly what the dialog says while it does it. Validation
 * is layered exactly like the service: the Save button stays disabled until
 * everything is filled, malformed input is rejected inline with the
 * service's own message.</p>
 */
final class ManualRateDialog extends Dialog<FxRate> {

    private final DatePicker dateField;
    private final ComboBox<String> fromBox = new ComboBox<>();
    private final ComboBox<String> toBox = new ComboBox<>();
    private final TextField rateField = new TextField();
    private final Label errorLabel = new Label();

    private final FxRateService service;
    private FxRate saved;

    ManualRateDialog(FxRateService service, String from, String to, LocalDate date) {
        this.service = service;

        setTitle("Add manual rate");
        setHeaderText("The firm's own rate, overriding the API for this date and pair");

        ButtonType save = new ButtonType("Store rate", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(save, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());

        fromBox.getItems().addAll(Currencies.COMMON);
        toBox.getItems().addAll(Currencies.COMMON);
        fromBox.setConverter(Currencies.upperCasing());
        toBox.setConverter(Currencies.upperCasing());
        fromBox.setEditable(true);
        toBox.setEditable(true);
        fromBox.setPrefWidth(110);
        toBox.setPrefWidth(110);
        fromBox.setValue(from == null || from.isBlank() ? "USD" : from.toUpperCase());
        toBox.setValue(to == null || to.isBlank() ? "PHP" : to.toUpperCase());

        dateField = new DatePicker(date == null ? LocalDate.now() : date);
        dateField.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate day, boolean empty) {
                super.updateItem(day, empty);
                setDisable(empty || day.isAfter(LocalDate.now()));
            }
        });
        dateField.setPrefWidth(150);

        rateField.setPromptText("e.g. 56.7325");
        rateField.setPrefColumnCount(10);

        errorLabel.getStyleClass().add("lp-dialog-error");
        errorLabel.setWrapText(true);
        errorLabel.setMinHeight(34);   // reserve space so the layout never jumps

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.addRow(0, new Label("Date:"), dateField);
        form.addRow(1, new Label("From:"), fromBox);
        form.addRow(2, new Label("To:"), toBox);
        form.addRow(3, new Label("Rate:"), rateField);
        form.addRow(4, new Label(""), new Label("1 “From” = rate × “To”"));
        form.getChildren().getLast().getStyleClass().add("lp-card-note");
        ColumnConstraints labels = new ColumnConstraints();
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(labels, fields);

        VBox content = new VBox(12, form, errorLabel);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        getDialogPane().setContent(content);

        javafx.scene.Node saveButton = getDialogPane().lookupButton(save);
        saveButton.disableProperty().bind(Bindings.createBooleanBinding(
                () -> dateField.getValue() == null
                        || fromBox.getValue() == null || fromBox.getValue().isBlank()
                        || toBox.getValue() == null || toBox.getValue().isBlank()
                        || rateField.getText().isBlank(),
                dateField.valueProperty(), fromBox.valueProperty(),
                toBox.valueProperty(), rateField.textProperty()));

        // Validate + persist BEFORE the dialog is allowed to close.
        saveButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            Double rate = parseRate(rateField.getText());
            if (rate == null) {
                errorLabel.setText("✗  The rate must be a number like 56.7325"
                        + " (a dot as decimal separator, more than zero).");
                event.consume();
                return;
            }
            try {
                saved = service.putManual(dateField.getValue(), fromBox.getValue(),
                        toBox.getValue(), rate);
            } catch (IllegalArgumentException e) {
                errorLabel.setText("✗  " + e.getMessage());
                event.consume();
            }
        });

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE.equals(buttonType.getButtonData())
                ? saved : null);
    }

    /** Strict-ish parse: dot decimal separator, no grouping, must be > 0. */
    private static Double parseRate(String raw) {
        try {
            double value = Double.parseDouble(raw.trim());
            return value > 0 && Double.isFinite(value) ? value : null;
        } catch (Exception e) {
            return null;
        }
    }
}
