package com.ledgerpro.ui;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;

import java.util.prefs.Preferences;

/**
 * Applies and remembers the active {@link Theme}.
 *
 * <p>One theme is active per JVM. {@link #apply} re-issues the AtlantaFX
 * user-agent stylesheet (JavaFX restyles every open scene when it changes),
 * swaps the theme's overlay stylesheet in the scene — always AFTER
 * {@code ledgerpro.css}, so an overlay may re-tint the author stylesheet —
 * and stores the choice in the user's preferences, so the next launch starts
 * in the look the accountant left.</p>
 *
 * <p>Thread note: {@code apply} touches live scenes, so it belongs on the
 * JavaFX thread — which is where every caller (scene construction, the
 * sidebar picker) already runs.</p>
 */
public final class ThemeManager {

    // 2.7.0: the theme used to live in this class's own preferences node
    // (/com/ledgerpro/ui) while every other setting lives in /ledgerpro/app —
    // Settings' Reset could never reach it. Now the canonical home is the
    // shared node; the legacy node is still READ (one-time migration), and
    // every write goes to the shared node.
    private static final Preferences LEGACY_PREFS =
            Preferences.userNodeForPackage(ThemeManager.class);
    private static final Preferences PREFS =
            Preferences.userRoot().node("ledgerpro/app");
    private static final String KEY = "ui.theme";

    private static Theme current = loadTheme();

    private static Theme loadTheme() {
        try {
            String saved = PREFS.get(KEY, null);
            if (saved == null) {
                saved = LEGACY_PREFS.get(KEY, null);
                if (saved != null) {
                    PREFS.put(KEY, saved);   // migrate once, write to the new home
                }
            }
            return Theme.parse(saved);
        } catch (RuntimeException e) {
            return Theme.defaultTheme();
        }
    }

    private ThemeManager() {
    }

    /** The theme this JVM runs in (the remembered one until first switch). */
    public static Theme current() {
        return current;
    }

    /**
     * The factory default look (Primer Light) — Settings' Reset returns to it.
     */
    public static Theme defaultTheme() {
        return Theme.defaultTheme();
    }

    /**
     * Makes {@code theme} the active look: user-agent stylesheet re-applied
     * (restyles every open scene), overlay swapped in {@code scene} when one
     * is passed, and the choice remembered for the next launch.
     *
     * <p><b>2.9.0 — the broken-look fix:</b> swapping the user-agent
     * stylesheet alone leaves already-rendered controls wearing stale
     * resolved styles in places (JavaFX keeps per-node style caches, and a
     * palette change does not always invalidate them). Every live scene is
     * therefore walked after the swap and its root node is re-applied to
     * CSS via {@code applyCss()} — a documented JavaFX idiom that clears the
     * resolved-style caches and re-runs the whole CSS pass — plus the
     * overlay list is re-asserted, so switching themes NEVER leaves a
     * half-styled window behind.</p>
     *
     * @param scene the application scene; may be null while no scene exists
     *              yet (the overlay is then attached by
     *              {@link #attachOverlay} when the scene is built)
     */
    public static void apply(Theme theme, Scene scene) {
        if (theme == null || (theme == current && scene == null)) {
            return;
        }
        current = theme;
        PREFS.put(KEY, theme.name());

        // JavaFX re-applies the user-agent stylesheet platform-wide when this
        // changes, restyling every control in every open scene.
        Application.setUserAgentStylesheet(theme.userAgentStylesheet());

        // walk every live window's scene (the argument scene first) and
        // force a full CSS re-pass on it — this is what actually clears the
        // stale styles on already-rendered controls
        if (scene != null) {
            swapOverlay(scene);
            reapplyCss(scene.getRoot());
        }
        for (javafx.stage.Window window : javafx.stage.Window.getWindows()) {
            if (window instanceof javafx.stage.Stage stage
                    && stage.getScene() != null && stage.getScene() != scene
                    && stage.isShowing()) {
                swapOverlay(stage.getScene());
                reapplyCss(stage.getScene().getRoot());
            }
        }
    }

    /**
     * Forces a full CSS re-pass over a node tree: the documented JavaFX
     * idiom (applyCss re-runs style resolution for the node and every
     * descendant, clearing resolved-style caches that a user-agent
     * stylesheet swap does not always invalidate).
     */
    private static void reapplyCss(javafx.scene.Parent root) {
        if (root == null) {
            return;
        }
        try {
            root.applyCss();
        } catch (RuntimeException ignored) {
            // a mid-layout re-apply can race with a control being swapped;
            // the next layout pass re-applies CSS anyway
        }
    }

    /**
     * Ensures the freshly built scene wears the CURRENT theme's overlay —
     * appended after the author stylesheet, never before it, so the overlay's
     * re-tints win over {@code ledgerpro.css} and the author rules still win
     * over the user-agent theme underneath.
     */
    public static void attachOverlay(Scene scene) {
        swapOverlay(scene);
    }

    private static void swapOverlay(Scene scene) {
        ObservableList<String> sheets = scene.getStylesheets();
        for (Theme theme : Theme.values()) {
            String overlay = theme.overlayUrl();
            if (overlay != null) {
                sheets.remove(overlay);
            }
        }
        String overlay = current.overlayUrl();
        if (overlay != null && !sheets.contains(overlay)) {
            sheets.add(overlay);
        }
    }
}
