package com.ledgerpro.ui;

import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.layout.Region;

/**
 * A status cell that shows a colored PILL (2.12.1): "Posted" green,
 * "Draft" amber, "Voided" red — the badge the journal's paper view already
 * used, now in every register, instead of colored plain text that sat
 * flush against the neighbouring amount ("1,889.00Posted" in the user's
 * screenshot).
 *
 * <p>The tone classes {@code lp-status-ok / -void / -draft} stay on the
 * CELL as before (the theme-safe contract the 2.11.0 tests pin), and the
 * pill itself wears the matching {@code lp-journal-pill-*} classes.</p>
 */
final class StatusCell<S> extends TableCell<S, String> {

    private static final String[] TONES = {"lp-status-ok", "lp-status-void", "lp-status-draft"};
    private static final String[] PILL_TONES = {
        "lp-journal-pill-ok", "lp-journal-pill-void", "lp-journal-pill-draft"};

    private final Label pill = new Label();

    StatusCell() {
        pill.getStyleClass().add("lp-journal-pill");
        pill.setMinWidth(Region.USE_PREF_SIZE);
        setGraphic(pill);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        setAlignment(Pos.CENTER);
    }

    @Override
    protected void updateItem(String item, boolean empty) {
        super.updateItem(item, empty);
        getStyleClass().removeAll(TONES);
        pill.getStyleClass().removeAll(PILL_TONES);
        boolean blank = empty || item == null || item.isBlank();
        pill.setText(blank ? null : item);
        pill.setVisible(!blank);
        if (blank) {
            return;
        }
        String tone = StatusText.classFor(item);       // lp-status-ok/-void/-draft
        getStyleClass().add(tone);
        pill.getStyleClass().add("lp-journal-pill-" + tone.substring("lp-status-".length()));
    }
}
