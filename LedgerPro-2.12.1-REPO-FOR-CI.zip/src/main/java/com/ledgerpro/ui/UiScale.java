package com.ledgerpro.ui;

import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.scene.Scene;

import java.util.prefs.Preferences;

/**
 * Responsive text: one font scale for the whole application, driven by the
 * window's size.
 *
 * <p>Every font size in {@code ledgerpro.css} is written in {@code em}
 * (1&nbsp;em = the root font size), and the root of the shown scene carries
 * {@code -fx-font-size} bound to this scale. JavaFX resolves an {@code em}
 * against the <b>nearest ancestor's</b> font size, so when the root grows
 * every label, button, table cell and dialog text grows with it — the same
 * mechanism a browser uses for {@code rem}-based layouts. The AtlantaFX
 * user-agent stylesheets already size their controls in relative units, so
 * the themed controls follow the root scale too.</p>
 *
 * <p>The scale itself is a smooth function of the window's height and width
 * (the geometric mean keeps a wide-but-short window from collapsing to the
 * minimum):</p>
 *
 * <pre>
 *   reference = √(width × height)          (1280×820 → 1024.5)
 *   scale     = clamp(reference / 1024.5, 0.85, 1.30)
 * </pre>
 *
 * <p>Real windows read as: the app's minimum 1024×660 at the 0.85 floor, a
 * 1280×820 or 1366×768 laptop window at ~1.0, a 1440×900 window at ~1.11,
 * and a maximized 1920×1040 window at the 1.30 ceiling (the geometric mean
 * asks for 1.38; the cap keeps maximized text at a readable-not-cartoonish
 * 130%).</p>
 *
 * <p><b>Performance notes (2.5.0)</b>: the applied scale is quantized to
 * whole percent — a 1%-wide band of window sizes shares one scale, so the
 * ~120 ms glide only plays when the scale actually changes by a step, never
 * on every pixel of a drag. When animations are off (the 2.5.0 default) the
 * value is written directly: zero timelines run during resize.</p>
 *
 * <p>A user preference can override it: AUTO (the responsive mode) or FIXED
 * (a remembered manual scale from the Settings dialog), remembered between
 * launches.</p>
 */
public final class UiScale {

    /**
     * The window size that reads as scale 1.0 — the geometric mean of the
     * 1280×820 design window (≈ 1024.5), so the design window is exactly
     * 100%.
     */
    static final double REFERENCE = Math.sqrt(1280.0 * 820.0);

    private static final double MIN_SCALE = 0.85;
    private static final double MAX_SCALE = 1.30;

    private static final String KEY_MODE = "ui.scale.mode";
    private static final String KEY_CUSTOM = "ui.scale.custom";

    /** AUTO = follow the window size; FIXED = the remembered manual scale. */
    public enum Mode { AUTO, FIXED }

    /** The applied scale — the one and only value the scene root binds to. */
    final DoubleProperty scale = new SimpleDoubleProperty(1.0);

    /** AUTO (responsive) or FIXED (manual override), remembered. */
    private Mode mode = Mode.AUTO;

    /** The remembered manual scale (only meaningful in FIXED mode). */
    private double customScale = 1.0;

    /** The scene whose size drives the AUTO scale (may be null headless). */
    private Scene watchedScene;

    /** The window of the bound scene, kept for reference (may be null). */
    private javafx.stage.Window window;

    /** Re-applies on window resizes; detached by {@link #unbind()}. */
    private ChangeListener<Number> windowListener;

    /** Prevents a feedback loop when the animated glide writes the scale. */
    private Timeline glide;

    private static UiScale instance;

    private UiScale() {
        loadPrefs();
    }

    /** The process-wide responsive-text controller (one scene per app). */
    public static synchronized UiScale getInstance() {
        if (instance == null) {
            instance = new UiScale();
        }
        return instance;
    }

    // ------------------------------------------------------------------
    // Public surface
    // ------------------------------------------------------------------

    /** The scale currently in effect (read-only view for the UI). */
    public ReadOnlyDoubleProperty scaleProperty() {
        return scale;
    }

    public double getScale() {
        return scale.get();
    }

    public Mode getMode() {
        return mode;
    }

    /** Switches between responsive AUTO and a FIXED manual scale. */
    public void setMode(Mode newMode) {
        mode = newMode;
        savePrefs();
        reapply();
    }

    /** Sets a FIXED scale (0.85…1.30, clamped) and remembers it. */
    public void setCustomScale(double value) {
        customScale = clamp(value);
        savePrefs();
        reapply();
    }

    public double getCustomScale() {
        return customScale;
    }

    /**
     * Wires the controller to a scene: from here on every scene-size change
     * re-fits the text scale (in AUTO mode). The SCENE's width/height are
     * watched (not the stage's) because they carry the real layout size —
     * a stage's width is NaN until shown, and headless captures build the
     * scene at an explicit size without any stage at all.
     */
    public void bind(Scene scene) {
        window = scene.getWindow();
        if (windowListener != null && scene != watchedScene) {
            unbind();
        }
        watchedScene = scene;
        windowListener = (obs, old, now) -> {
            if (mode == Mode.AUTO) {
                applyTarget(autoScaleFor(scene.getWidth(), scene.getHeight()));
            }
        };
        scene.widthProperty().addListener(windowListener);
        scene.heightProperty().addListener(windowListener);
        reapply();
    }

    /** Detaches the scene-size listener (used by tests and teardown). */
    public void unbind() {
        if (watchedScene != null && windowListener != null) {
            watchedScene.widthProperty().removeListener(windowListener);
            watchedScene.heightProperty().removeListener(windowListener);
        }
        window = null;
        watchedScene = null;
        windowListener = null;
    }

    /** Recomputes the scale right now (public re-entry for stage-show). */
    public void reapplyNow() {
        reapply();
    }

    // ------------------------------------------------------------------
    // The scale functions
    // ------------------------------------------------------------------

    /**
     * The responsive scale for a window size: the geometric mean of width and
     * height against the 1024.5 reference, clamped to 0.85…1.30. Pure and
     * side-effect free — the unit-testable core of this class.
     */
    public static double autoScaleFor(double width, double height) {
        if (width <= 0 || height <= 0) {
            return 1.0;   // not yet laid out — keep the design size
        }
        double reference = Math.sqrt(width * height);
        return clamp(reference / REFERENCE);
    }

    private static double clamp(double value) {
        return Math.max(MIN_SCALE, Math.min(MAX_SCALE, value));
    }

    /** Recomputes and applies the scale from the current mode. */
    private void reapply() {
        if (mode == Mode.FIXED) {
            applyTarget(customScale);
            return;
        }
        double target = watchedScene == null ? 1.0
                : autoScaleFor(watchedScene.getWidth(), watchedScene.getHeight());
        applyTarget(target);
    }

    /**
     * Applies a target scale: quantized to whole percent, then either set
     * directly (animations off — the 2.5.0 default, zero timelines run) or
     * glided over ~120 ms (view swaps read as text that breathes with the
     * resize instead of snapping). Quantizing to 1% means a drag fires the
     * glide only on actual percent steps, not per pixel.
     */
    private void applyTarget(double target) {
        double quantized = Math.round(clamp(target) * 100.0) / 100.0;
        if (quantized == scale.get()) {
            return;
        }
        if (!UiMotion.isEnabled()) {
            if (glide != null) {
                glide.stop();
                glide = null;
            }
            scale.set(quantized);
            return;
        }
        double from = scale.get();
        if (Math.abs(quantized - from) < 0.005) {
            scale.set(quantized);
            return;
        }
        if (glide != null) {
            glide.stop();
        }
        javafx.animation.Interpolator ease = javafx.animation.Interpolator.EASE_BOTH;
        glide = new Timeline(
                new javafx.animation.KeyFrame(javafx.util.Duration.ZERO,
                        new javafx.animation.KeyValue(scale, from)),
                new javafx.animation.KeyFrame(javafx.util.Duration.millis(120),
                        new javafx.animation.KeyValue(scale, quantized, ease)));
        glide.play();
    }

    // ------------------------------------------------------------------
    // Persistence
    // ------------------------------------------------------------------

    private void loadPrefs() {
        try {
            Preferences prefs = Preferences.userRoot().node("ledgerpro/app");
            String raw = prefs.get(KEY_MODE, Mode.AUTO.name());
            mode = "FIXED".equalsIgnoreCase(raw) ? Mode.FIXED : Mode.AUTO;
            customScale = clamp(prefs.getDouble(KEY_CUSTOM, 1.0));
        } catch (RuntimeException ignored) {
            // locked-down machine: defaults (AUTO, scale 1.0)
        }
    }

    private void savePrefs() {
        try {
            Preferences prefs = Preferences.userRoot().node("ledgerpro/app");
            prefs.put(KEY_MODE, mode.name());
            prefs.putDouble(KEY_CUSTOM, customScale);
        } catch (RuntimeException ignored) {
            // best effort only
        }
    }
}
