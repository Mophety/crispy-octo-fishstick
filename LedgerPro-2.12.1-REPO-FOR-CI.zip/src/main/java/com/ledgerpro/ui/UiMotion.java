package com.ledgerpro.ui;

import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.util.Duration;

/**
 * The app's motion vocabulary — every animation in LedgerPro goes through
 * one of these helpers so the whole suite shares one feel:
 *
 * <ul>
 *   <li><b>Short and eased</b> — 150–260 ms, ease-out. Motion here signals
 *       "the view changed", it never becomes the thing you wait for.</li>
 *   <li><b>Composable</b> — view swaps fade+slide; tables stagger their
 *       first rows; dialogs lift in; charts draw progressively.</li>
 *   <li><b>One switch to flatten it all</b> — a "reduce motion" preference
 *       turns every helper into a no-op. 2.5.0 DEFAULTS TO OFF: motion is
 *       strictly opt-in (Settings → Interface → Animations), persisted
 *       between launches, and the status bar carries the toggle.</li>
 * </ul>
 */
public final class UiMotion {

    /** Global on/off — persisted, flipped by Settings and the status bar. */
    private static boolean enabled = false;

    private UiMotion() {
    }

    /** Motion enabled? (Settings → Interface → Animations; default off). */
    public static boolean isEnabled() {
        return enabled;
    }

    /** Flattens (false) or restores (true) every animation below. */
    public static void setEnabled(boolean value) {
        enabled = value;
    }

    // ------------------------------------------------------------------
    // View transitions
    // ------------------------------------------------------------------

    /**
     * The arriving-view animation: a quick fade-in plus a short slide up
     * from just below — reads as the view landing in the content area.
     * Invisible (instant) when motion is off or the node is already showing.
     */
    public static void playViewEnter(Node node) {
        if (!enabled || node == null || node.getScene() == null) {
            // motion off or not attached: rest the node and skip
            if (node != null) {
                node.setOpacity(1);
                node.setTranslateY(0);
            }
            return;
        }
        // 2.7.0: the old guard also skipped when the node was "at rest"
        // (opacity 1, translateY 0) — which a resting node ALWAYS is, so the
        // view-swap animation could never start. Now the start state is set
        // explicitly and the transition always plays when motion is on.
        node.setOpacity(0);
        node.setTranslateY(14);
        ParallelTransition enter = new ParallelTransition(node,
                fade(node, 0.0, 1.0, 180),
                slideY(node, 14, 0, 220));
        enter.play();
    }

    // ------------------------------------------------------------------
    // Dialog transitions
    // ------------------------------------------------------------------

    /**
     * A dialog pane appearing: a gentle fade with a slight upward settle —
     * forms feel acknowledged rather than slammed onto the screen. No-op
     * when motion is off (which is the default).
     */
    public static void playDialogEnter(Node dialogPane) {
        if (!enabled || dialogPane == null || dialogPane.getScene() == null) {
            return;
        }
        ParallelTransition enter = new ParallelTransition(dialogPane,
                fade(dialogPane, 0.0, 1.0, 140),
                slideY(dialogPane, 10, 0, 180));
        enter.play();
    }

    // ------------------------------------------------------------------
    // Content arrivals
    // ------------------------------------------------------------------

    /**
     * A card or panel whose data just loaded: a gentle fade-in. Used by the
     * dashboard so a refresh does not read as a hard blink.
     */
    public static void playFadeIn(Node node, int millis) {
        if (!enabled || node == null) {
            if (node != null) {
                node.setOpacity(1);
            }
            return;
        }
        fade(node, 0.0, 1.0, Math.max(80, millis)).play();
    }

    /**
     * A table that just received its rows: the first visible rows fade in
     * with a tiny stagger (40 ms apart, capped) so the grid "settles" instead
     * of blinking in at once.
     */
    public static void playRowEnter(Node rowNode, int indexInView) {
        if (!enabled || rowNode == null) {
            return;
        }
        int cap = Math.min(indexInView, 8);   // beyond row 9: no perceptible stagger
        PauseTransition wait = new PauseTransition(Duration.millis(40.0 * cap));
        SequentialTransition settle = new SequentialTransition(wait,
                fade(rowNode, 0.0, 1.0, 120));
        settle.play();
    }

    /**
     * A chart whose data arrived: reveals the plot from left to right over
     * ~450 ms by animating a horizontal clip — lines and areas "draw" the way
     * paper charts do. No-op with motion off.
     */
    public static void playChartReveal(Node chartNode) {
        if (!enabled || chartNode == null || chartNode.getScene() == null) {
            return;
        }
        double w = chartNode.getLayoutBounds().getWidth();
        double h = chartNode.getLayoutBounds().getHeight();
        if (w <= 0 || h <= 0) {
            // 2.7.0: not laid out yet (the old code gave up here, which is
            // why charts never drew in) — wait for the FIRST layout pass,
            // then reveal from whatever size the chart actually settled on
            chartNode.layoutBoundsProperty().addListener(
                    new javafx.beans.value.ChangeListener<javafx.geometry.Bounds>() {
                @Override
                public void changed(javafx.beans.value.ObservableValue<? extends javafx.geometry.Bounds> obs,
                                    javafx.geometry.Bounds oldB, javafx.geometry.Bounds newB) {
                    if (newB != null && newB.getWidth() > 0 && newB.getHeight() > 0) {
                        chartNode.layoutBoundsProperty().removeListener(this);
                        playChartReveal(chartNode);
                    }
                }
            });
            return;
        }
        javafx.scene.shape.Rectangle clip = new javafx.scene.shape.Rectangle(0, 0, w, h);
        chartNode.setClip(clip);
        javafx.animation.Timeline wipe = new javafx.animation.Timeline(
                new javafx.animation.KeyFrame(Duration.ZERO,
                        new javafx.animation.KeyValue(clip.widthProperty(), 0.0)),
                new javafx.animation.KeyFrame(Duration.millis(450),
                        new javafx.animation.KeyValue(clip.widthProperty(), w,
                                javafx.animation.Interpolator.EASE_OUT)));
        wipe.setOnFinished(e -> {
            chartNode.setClip(null);
            clip.widthProperty().unbind();
        });
        wipe.play();
    }

    // ------------------------------------------------------------------
    // Building blocks
    // ------------------------------------------------------------------

    private static FadeTransition fade(Node node, double from, double to, int millis) {
        FadeTransition t = new FadeTransition(Duration.millis(Math.max(1, millis)), node);
        t.setFromValue(from);
        t.setToValue(to);
        t.setInterpolator(javafx.animation.Interpolator.EASE_OUT);
        return t;
    }

    private static TranslateTransition slideY(Node node, double fromY, double toY, int millis) {
        TranslateTransition t = new TranslateTransition(
                Duration.millis(Math.max(1, millis)), node);
        t.setFromY(fromY);
        t.setToY(toY);
        t.setInterpolator(javafx.animation.Interpolator.EASE_OUT);
        return t;
    }
}
