package com.ledgerpro.ui;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.LongProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleObjectProperty;

import java.util.prefs.Preferences;

/**
 * The app's user-preference model (2.5.0): one observable hub every panel
 * reads. Everything persists through the {@code ledgerpro/app} preferences
 * node — the SAME node the window geometry and theme already use — so
 * settings survive restarts and never touch the accounting database.
 *
 * <p>Observable properties (not plain getters) so views can listen: the
 * Journal re-reads the void-prompt flag when it flips, the shell re-shows
 * the startup view, money formatting re-renders live.</p>
 *
 * <p>Defaults in one place: animations OFF (the 2.5.0 decision — motion is
 * opt-in), money grouped (the accountant-friendly 1,234,567.89), zeros
 * blank (the paper-sheet convention), comfortable density, geometry
 * remembered, void prompt on, startup on the Dashboard, journal register
 * view (2.8.0 — the classic one-line-per-entry layout; the entry-lines
 * mode with its '# memo' continuation rows is the opt-in).</p>
 */
public class Prefs {

    /** Animations default: OFF in 2.5.0 (motion is strictly opt-in). */
    public static final boolean DEFAULT_ANIMATIONS = false;
    /** Group amounts with commas by default (1,234,567.89). */
    public static final boolean DEFAULT_MONEY_GROUPED = true;
    /** Blank zero cells by default (the paper-sheet convention). */
    public static final boolean DEFAULT_ZERO_SHOWN = false;

    /**
     * How the Journal tab lays its entries out (2.8.0; 2.10.0 flips the
     * default back).
     *
     * <ul>
     *   <li><b>REGISTER</b> — one row per entry, the classic general-
     *       journal register (No · Date · Type · Ref · Memo · Amount ·
     *       Status): uniform rows, hairline separators, plain colored
     *       status text. The default (2.10.0 — the 2.3.1 look the user
     *       prefers).</li>
     *   <li><b>ENTRY_LINES</b> — the paper bookkeeping look: every entry
     *       unfolds into its debit and credit lines, each on its own row,
     *       followed by an indented '#'-prefixed memo row; reads exactly
     *       like the manual journal an accountant keeps on paper. One
     *       toolbar toggle away (2.9.0 made it the default; 2.10.0
     *       restores the register per user feedback).</li>
     * </ul>
     */
    public enum JournalMode {
        REGISTER("Register — one line per entry (default)"),
        ENTRY_LINES("Entry lines — Dr/Cr lines with a '# memo' row");

        final String label;

        JournalMode(String label) {
            this.label = label;
        }

        /** The Settings picker text. */
        public String label() {
            return label;
        }

        /** Parses a saved value, falling back to the default. */
        public static JournalMode parse(String saved) {
            for (JournalMode mode : values()) {
                if (mode.name().equals(saved)) {
                    return mode;
                }
            }
            return REGISTER;
        }
    }

    /**
     * The factory default journal layout: the flat register (2.10.0 — the
     * journal-restoration release; the 2.3.1 design). Users who explicitly
     * chose ENTRY_LINES keep their stored preference.
     */
    public static final JournalMode DEFAULT_JOURNAL_MODE = JournalMode.REGISTER;

    /**
     * How often the live dashboard re-reads its figures (2.6.0). OFF keeps
     * the dashboard to explicit refreshes (F5 or view switches); the timed
     * rates poll while the dashboard is the visible view, on a background
     * thread. Default 15s: fast enough to feel live, gentle on the battery.
     */
    public enum DashboardRefresh {
        OFF("Off — refresh only on demand"),
        SEC5("Every 5 seconds"),
        SEC15("Every 15 seconds (default)"),
        SEC30("Every 30 seconds");

        final String label;

        DashboardRefresh(String label) {
            this.label = label;
        }

        /** The rate in seconds (0 = never). */
        public int seconds() {
            return switch (this) {
                case OFF -> 0;
                case SEC5 -> 5;
                case SEC15 -> 15;
                case SEC30 -> 30;
            };
        }

        /** Parses a saved value, falling back to the default. */
        public static DashboardRefresh parse(String saved) {
            for (DashboardRefresh rate : values()) {
                if (rate.name().equals(saved)) {
                    return rate;
                }
            }
            return SEC15;
        }
    }

    /** The factory default dashboard refresh: every 15 seconds. */
    public static final DashboardRefresh DEFAULT_DASHBOARD_REFRESH =
            DashboardRefresh.SEC15;

    private static final String KEY_ANIM = "ui.motion.enabled";
    private static final String KEY_GROUPED = "money.grouped";
    private static final String KEY_ZERO = "money.zero.shown";
    private static final String KEY_DENSITY = "ui.density.compact";
    private static final String KEY_STARTUP = "ui.startup.view";
    private static final String KEY_GEOMETRY = "window.geometry.remembered";
    private static final String KEY_VOID_PROMPT = "journal.void.prompt";
    private static final String KEY_DASHBOARD_REFRESH = "dashboard.refresh.seconds";
    private static final String KEY_LAST_CLIENT = "client.last.id";
    private static final String KEY_JOURNAL_MODE = "journal.display.mode";

    private static Prefs instance;

    private final BooleanProperty animationsEnabled =
            new SimpleBooleanProperty(this, "animationsEnabled", DEFAULT_ANIMATIONS);
    private final BooleanProperty moneyGrouped =
            new SimpleBooleanProperty(this, "moneyGrouped", DEFAULT_MONEY_GROUPED);
    private final BooleanProperty zeroShown =
            new SimpleBooleanProperty(this, "zeroShown", DEFAULT_ZERO_SHOWN);
    private final BooleanProperty compactDensity =
            new SimpleBooleanProperty(this, "compactDensity", false);
    private final BooleanProperty geometryRemembered =
            new SimpleBooleanProperty(this, "geometryRemembered", true);
    private final BooleanProperty voidPrompted =
            new SimpleBooleanProperty(this, "voidPrompted", true);
    private final ObjectProperty<JournalMode> journalMode =
            new SimpleObjectProperty<>(this, "journalMode", DEFAULT_JOURNAL_MODE);
    private final ObjectProperty<ViewId> startupView =
            new SimpleObjectProperty<>(this, "startupView", ViewId.DASHBOARD);
    private final ObjectProperty<DashboardRefresh> dashboardRefresh =
            new SimpleObjectProperty<>(this, "dashboardRefresh", DEFAULT_DASHBOARD_REFRESH);
    private final LongProperty lastClientId =
            new SimpleLongProperty(this, "lastClientId", -1);

    Prefs() {
        load();
    }

    /** The process-wide preferences hub. */
    public static synchronized Prefs getInstance() {
        if (instance == null) {
            instance = new Prefs();
        }
        return instance;
    }

    // ------------------------------------------------------------------
    // observable views (for views that listen)
    // ------------------------------------------------------------------

    public BooleanProperty animationsEnabledProperty() { return animationsEnabled; }
    public BooleanProperty moneyGroupedProperty() { return moneyGrouped; }
    public BooleanProperty zeroShownProperty() { return zeroShown; }
    public BooleanProperty compactDensityProperty() { return compactDensity; }
    public BooleanProperty geometryRememberedProperty() { return geometryRemembered; }
    public BooleanProperty voidPromptedProperty() { return voidPrompted; }
    public ObjectProperty<ViewId> startupViewProperty() { return startupView; }

    public boolean isAnimationsEnabled() { return animationsEnabled.get(); }
    public boolean isMoneyGrouped() { return moneyGrouped.get(); }
    public boolean isZeroShown() { return zeroShown.get(); }
    public boolean isCompactDensity() { return compactDensity.get(); }
    public boolean isGeometryRemembered() { return geometryRemembered.get(); }
    public boolean isVoidPrompted() { return voidPrompted.get(); }
    public ViewId startupView() { return startupView.get(); }
    public DashboardRefresh dashboardRefresh() { return dashboardRefresh.get(); }
    public ObjectProperty<DashboardRefresh> dashboardRefreshProperty() {
        return dashboardRefresh;
    }
    public JournalMode journalMode() { return journalMode.get(); }
    public ObjectProperty<JournalMode> journalModeProperty() { return journalMode; }
    public long lastClientId() { return lastClientId.get(); }
    public LongProperty lastClientIdProperty() { return lastClientId; }

    // ------------------------------------------------------------------
    // setters — persist on write
    // ------------------------------------------------------------------

    public void setAnimationsEnabled(boolean value) {
        animationsEnabled.set(value);
        put(KEY_ANIM, value);
        UiMotion.setEnabled(value);
    }

    public void setMoneyGrouped(boolean value) {
        moneyGrouped.set(value);
        put(KEY_GROUPED, value);
        Money.setGrouping(value);
    }

    public void setZeroShown(boolean value) {
        zeroShown.set(value);
        put(KEY_ZERO, value);
        Money.setZeroShown(value);
    }

    public void setCompactDensity(boolean value) {
        compactDensity.set(value);
        put(KEY_DENSITY, value);
    }

    public void setGeometryRemembered(boolean value) {
        geometryRemembered.set(value);
        put(KEY_GEOMETRY, value);
    }

    public void setVoidPrompted(boolean value) {
        voidPrompted.set(value);
        put(KEY_VOID_PROMPT, value);
    }

    public void setStartupView(ViewId view) {
        startupView.set(view);
        try {
            Preferences.userRoot().node("ledgerpro/app")
                    .put(KEY_STARTUP, view == null ? ViewId.DASHBOARD.name() : view.name());
        } catch (RuntimeException ignored) {
            // best effort only
        }
    }

    /** Sets the dashboard auto-refresh rate; the dashboard re-arms on change. */
    public void setDashboardRefresh(DashboardRefresh rate) {
        dashboardRefresh.set(rate);
        try {
            Preferences.userRoot().node("ledgerpro/app")
                    .put(KEY_DASHBOARD_REFRESH, rate.name());
        } catch (RuntimeException ignored) {
            // best effort only
        }
    }

    /** Sets the journal's display mode; the Journal re-renders on change. */
    public void setJournalMode(JournalMode mode) {
        journalMode.set(mode == null ? DEFAULT_JOURNAL_MODE : mode);
        try {
            Preferences.userRoot().node("ledgerpro/app")
                    .put(KEY_JOURNAL_MODE, journalMode.get().name());
        } catch (RuntimeException ignored) {
            // best effort only
        }
    }

    /** Remembers (or clears, -1) the last working client for the next launch. */
    public void setLastClientId(long id) {
        lastClientId.set(id);
        try {
            Preferences.userRoot().node("ledgerpro/app").put(KEY_LAST_CLIENT, String.valueOf(id));
        } catch (RuntimeException ignored) {
            // best effort only
        }
    }

    /** Restores every setting to its factory default (Settings → Reset). */
    public void resetDefaults() {
        setAnimationsEnabled(DEFAULT_ANIMATIONS);
        setMoneyGrouped(DEFAULT_MONEY_GROUPED);
        setZeroShown(DEFAULT_ZERO_SHOWN);
        setCompactDensity(false);
        setGeometryRemembered(true);
        setVoidPrompted(true);
        setStartupView(ViewId.DASHBOARD);
        setDashboardRefresh(DEFAULT_DASHBOARD_REFRESH);
        setJournalMode(DEFAULT_JOURNAL_MODE);
    }

    // ------------------------------------------------------------------
    // persistence
    // ------------------------------------------------------------------

    /** True when a preferences read/write failed (surfaced once at startup). */
    private static volatile boolean storeFailed;

    /** 2.7.0: did the preferences store misbehave this run? (Settings banner) */
    public static boolean storeFailed() {
        return storeFailed;
    }

    void load() {
        try {
            Preferences prefs = Preferences.userRoot().node("ledgerpro/app");
            animationsEnabled.set(prefs.getBoolean(KEY_ANIM, DEFAULT_ANIMATIONS));
            moneyGrouped.set(prefs.getBoolean(KEY_GROUPED, DEFAULT_MONEY_GROUPED));
            zeroShown.set(prefs.getBoolean(KEY_ZERO, DEFAULT_ZERO_SHOWN));
            compactDensity.set(prefs.getBoolean(KEY_DENSITY, false));
            geometryRemembered.set(prefs.getBoolean(KEY_GEOMETRY, true));
            voidPrompted.set(prefs.getBoolean(KEY_VOID_PROMPT, true));
            String raw = prefs.get(KEY_STARTUP, ViewId.DASHBOARD.name());
            ViewId parsed;
            try {
                parsed = ViewId.valueOf(raw);
            } catch (IllegalArgumentException e) {
                parsed = ViewId.DASHBOARD;
            }
            startupView.set(parsed);
            dashboardRefresh.set(DashboardRefresh.parse(
                    prefs.get(KEY_DASHBOARD_REFRESH, DEFAULT_DASHBOARD_REFRESH.name())));
            String lastClient = prefs.get(KEY_LAST_CLIENT, "-1");
            try {
                lastClientId.set(Long.parseLong(lastClient));
            } catch (NumberFormatException e) {
                lastClientId.set(-1);
            }
            journalMode.set(JournalMode.parse(prefs.get(KEY_JOURNAL_MODE,
                    DEFAULT_JOURNAL_MODE.name())));
        } catch (RuntimeException e) {
            // locked-down machine: keep the defaults above — but say so once
            storeFailed = true;
        }
        // mirror into the two legacy singletons so the whole app agrees
        UiMotion.setEnabled(animationsEnabled.get());
        Money.setGrouping(moneyGrouped.get());
        Money.setZeroShown(zeroShown.get());
    }

    private void put(String key, boolean value) {
        try {
            Preferences.userRoot().node("ledgerpro/app").putBoolean(key, value);
        } catch (RuntimeException e) {
            storeFailed = true;   // 2.7.0: surfaced, not silently swallowed
        }
    }
}
