package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Client;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.AdjTemplateService;
import com.ledgerpro.service.BackupService;
import com.ledgerpro.service.AuditService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.service.WorksheetService;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.StringConverter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * The persistent application frame: a navigation sidebar on the left, a top
 * bar with the working-client switcher, and a content area that swaps views.
 *
 * <p>The shell owns two pieces of shared state:</p>
 * <ul>
 *   <li>{@link #activeClientProperty()} - the client the accountant is
 *       currently working on; later phases (journal, ledgers, worksheet)
 *       will scope themselves to it.</li>
 *   <li>the {@link Refreshable} protocol - every view re-reads its data when
 *       it becomes visible, so nothing in the UI can go stale.</li>
 * </ul>
 */
public final class AppShell extends BorderPane {

    /** Navigation structure: section header followed by its views. */
    private record NavSection(String caption, ViewId[] views) {}

    private static final NavSection[] SECTIONS = {
            new NavSection("Workspace", new ViewId[]{
                    ViewId.DASHBOARD, ViewId.CLIENTS, ViewId.COA, ViewId.FX_RATES}),
            new NavSection("Accounting cycle", new ViewId[]{
                    ViewId.JOURNAL, ViewId.LEDGERS, ViewId.TRIAL_BALANCE,
                    ViewId.WORKSHEET, ViewId.REPORTS}),
            new NavSection("Firm", new ViewId[]{
                    ViewId.AUDIT}),
    };

    private final ClientService clientService;
    private final AccountService accountService;
    private final FxRateService fxService;
    private final JournalService journalService;
    private final PeriodService periodService;
    private final WorksheetService worksheetService;
    private final AdjTemplateService adjService;
    private final AuditService auditService;
    private final Database database;

    private final Map<ViewId, ToggleButton> navButtons = new EnumMap<>(ViewId.class);
    private final Map<ViewId, Node> shippedViews = new EnumMap<>(ViewId.class);
    private final StackPane content = new StackPane();
    private final Label viewTitle = new Label();
    private final ComboBox<Client> clientSwitcher = new ComboBox<>();
    private final ComboBox<Theme> themePicker = new ComboBox<>();
    private final TextFlow dbStatus = new TextFlow();
    // 2.12.1 (P4-S4): the hint line is SHORT (it lived long on the bar);
    // the full key list moved behind its Tooltip
    private final Label shortcutHint = new Label("Shortcuts: Ctrl/Cmd+N ·"
            + " Ctrl/Cmd+K · F5 — hover for the full list");
    private final Label statusBarScale = new Label();

    /** The journal view, once created — the shell's Ctrl+N opens its dialog. */
    private JournalView journalView;

    private final ObjectProperty<Client> activeClient = new SimpleObjectProperty<>(null);

    public AppShell(ClientService clientService, AccountService accountService,
                    FxRateService fxService, JournalService journalService,
                    PeriodService periodService, WorksheetService worksheetService,
                    AdjTemplateService adjService, AuditService auditService,
                    Database database) {
        this.clientService = clientService;
        this.accountService = accountService;
        this.fxService = fxService;
        this.journalService = journalService;
        this.periodService = periodService;
        this.worksheetService = worksheetService;
        this.adjService = adjService;
        this.auditService = auditService;
        this.database = database;

        setLeft(buildSidebar());
        setTop(buildTopBar());
        setCenter(content);
        setBottom(buildStatusBar());
        content.getStyleClass().add("lp-content");

        refreshClientSwitcher();
        refreshDbStatus();
        // 2.7.0: restore the last working client (or the first active one on a
        // fresh launch) so the dashboard has a client to read the moment it
        // shows — the 2.6.0 build started with none selected, which read as
        // "the dashboard is empty" even with the demo client loaded.
        selectWorkingClient(null);
        // the view the user chose in Settings (Dashboard on a fresh install)
        show(Prefs.getInstance().startupView());
    }

    /** The client the accountant is currently working on (may be null). */
    public ObjectProperty<Client> activeClientProperty() {
        return activeClient;
    }

    /**
     * Shows a view. Public so tooling (and later phases) can deep-link to a
     * view, e.g. "created a client -> jump to the clients table".
     *
     * <p>The swap is animated when motion is on: the arriving view fades in
     * and slides up a short distance, 220 ms ease-out (a no-op with motion
     * off — the 2.5.0 default — or when the view is already showing).</p>
     */
    public void show(ViewId id) {
        Node current = content.getChildren().isEmpty()
                ? null : content.getChildren().getFirst();
        Node view = shippedViews.computeIfAbsent(id, this::createView);
        boolean isSwap = current != null && current != view;
        content.getChildren().setAll(view);
        viewTitle.setText(id.title);
        navButtons.get(id).setSelected(true);
        if (view instanceof Refreshable refreshable) {
            refreshable.refresh();
        }
        if (isSwap) {
            UiMotion.playViewEnter(view);
        }
    }

    /**
     * Re-reads the visible view's data (F5, 2.6.0): the same refresh pass a
     * view switch runs, without leaving the view — the dashboard's live
     * figures on demand, a re-read of any table.
     */
    public void refreshCurrentView() {
        if (content.getChildren().isEmpty()) {
            return;
        }
        Node view = content.getChildren().getFirst();
        if (view instanceof Refreshable refreshable) {
            refreshable.refresh();
        }
    }

    /** Re-reads the client list behind the switcher, keeping the selection. */
    public void refreshClientSwitcher() {
        Client previous = clientSwitcher.getValue();
        List<Client> active = clientService.list(false);
        clientSwitcher.setItems(FXCollections.observableArrayList(active));
        Client stillThere = previous == null
                ? null
                : active.stream().filter(c -> c.id() == previous.id()).findFirst().orElse(null);
        clientSwitcher.setValue(stillThere);
        activeClient.set(stillThere);
    }

    /**
     * Selects the working client programmatically (tooling and deep links);
     * picks the remembered last working client when the argument is null,
     * falling back to the first active client (fresh install).
     */
    public void selectWorkingClient(Client client) {
        Client target = client;
        if (target == null && !clientSwitcher.getItems().isEmpty()) {
            long remembered = Prefs.getInstance().lastClientId();
            target = clientSwitcher.getItems().stream()
                    .filter(c -> c.id() == remembered)
                    .findFirst()
                    .orElseGet(() -> clientSwitcher.getItems().getFirst());
        }
        if (target != null) {
            clientSwitcher.setValue(target);   // fires the listener → activeClient
        }
    }

    /** Selects the working client by database id (tooling / deep links). */
    public void selectWorkingClientById(long clientId) {
        clientSwitcher.getItems().stream()
                .filter(c -> c.id() == clientId)
                .findFirst()
                .ifPresent(this::selectWorkingClient);
    }

    // ------------------------------------------------------------------
    // Sidebar
    // ------------------------------------------------------------------

    private VBox buildSidebar() {
        // The firm's mark: the shipped logo beside the product name.
        ImageView logo = UiIcons.logo();
        Label brand = new Label("LedgerPro");
        brand.getStyleClass().add("lp-brand");
        Label brandSub = new Label("accounting cycle suite");
        brandSub.getStyleClass().add("lp-brand-sub");
        HBox brandRow = new HBox(10, logo, brand);
        brandRow.setAlignment(Pos.CENTER_LEFT);

        ToggleGroup group = new ToggleGroup();
        VBox navBox = new VBox(2);
        for (NavSection section : SECTIONS) {
            Label header = new Label(section.caption().toUpperCase());
            header.getStyleClass().add("lp-nav-section");
            navBox.getChildren().add(header);
            for (ViewId id : section.views()) {
                ToggleButton button = new ToggleButton(id.title);
                button.getStyleClass().add("lp-nav-btn");
                button.setToggleGroup(group);
                button.setMaxWidth(Double.MAX_VALUE);
                button.setOnAction(e -> show(id));
                navButtons.put(id, button);
                navBox.getChildren().add(button);
            }
        }

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        Button settingsButton = new Button("Settings…");
        settingsButton.getStyleClass().add("lp-nav-btn");
        settingsButton.setMaxWidth(Double.MAX_VALUE);
        settingsButton.setTooltip(new Tooltip(
                "Theme, text size, density, animations, money format, startup"
                        + " view — everything applies live and is remembered"));
        settingsButton.setOnAction(e -> openSettings());

        VBox sidebar = new VBox(6, brandRow, brandSub, new Separator(), navBox,
                spacer, new Separator(), buildAppearancePicker(),
                settingsButton, dbStatus);
        sidebar.getStyleClass().add("lp-sidebar");
        VBox.setMargin(dbStatus, new Insets(6, 0, 0, 0));
        return sidebar;
    }

    // ------------------------------------------------------------------
    // Settings (2.5.0)
    // ------------------------------------------------------------------

    // ------------------------------------------------------------------
    // Status bar (bottom)
    // ------------------------------------------------------------------

    /**
     * The bottom status bar: the keyboard-shortcut hint on the left and the
     * live UI scale readout on the right. 2.7.0 removed the motion (Anim)
     * toggle that used to live here: the Settings → Interface → Animations
     * checkbox is the single control, per the audit plan (duplicated toggles
     * could also drift out of sync). The scale readout makes the responsive
     * text visible as it re-fits (small window → smaller %, maximized → larger).
     */
    private HBox buildStatusBar() {
        shortcutHint.getStyleClass().add("lp-scale-value");
        shortcutHint.setTooltip(new Tooltip("Ctrl/Cmd+1…9 switch views ·"
                + " Ctrl/Cmd+N new entry · Ctrl/Cmd+K search · F5 re-reads"
                + " the view · Esc closes dialogs · worksheet headers sort"
                + " asc → desc → the paper's own order"));
        statusBarScale.getStyleClass().add("lp-scale-value");

        UiScale uiScale = UiScale.getInstance();
        Runnable updateScale = () -> statusBarScale.setText("Text "
                + Math.round(uiScale.getScale() * 100) + "%"
                + (uiScale.getMode() == UiScale.Mode.AUTO ? " · auto" : " · pinned"));
        uiScale.scaleProperty().addListener((obs, old, now) -> updateScale.run());
        updateScale.run();

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox bar = new HBox(14, shortcutHint, spacer, statusBarScale);
        bar.getStyleClass().add("lp-statusbar");
        bar.setAlignment(Pos.CENTER_LEFT);
        return bar;
    }

    /** Opens the Settings dialog against the live scene. */
    private void openSettings() {
        SettingsDialog dialog = new SettingsDialog(getScene(), database,
                this::afterDemoDataLoaded);
        if (getScene() != null && getScene().getWindow() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        dialog.showAndWait();
        // a settings change may have flipped the density class already
        // (applied live); the status bar's readouts refresh on next layout
    }

    /**
     * The post-seed hook the Settings → Data section runs after demo books
     * land: re-read the client switcher (Northwind appears in it), pick the
     * new client up as the working one, refresh the db status strip, then
     * re-read the visible view — the same refresh a view switch runs, so
     * the demo appears without a restart.
     */
    private void afterDemoDataLoaded() {
        refreshClientSwitcher();
        selectWorkingClient(null);
        refreshDbStatus();
        refreshCurrentView();
    }

    /**
     * Same hook, public for the headless Settings demo-data check (test
     * sources) — it drives the exact flow the button's handler runs.
     */
    public void afterDemoDataLoadedPublic() {
        afterDemoDataLoaded();
    }

    // ------------------------------------------------------------------
    // Appearance (theme) picker
    // ------------------------------------------------------------------

    /**
     * The look switcher at the bottom of the sidebar: every shipped theme,
     * applied live and remembered for the next launch. Alexia's theme — the
     * deep forest-green look — lives here beside the AtlantaFX palettes.
     */
    private VBox buildAppearancePicker() {
        Label caption = new Label("APPEARANCE");
        caption.getStyleClass().add("lp-nav-section");

        themePicker.setMaxWidth(Double.MAX_VALUE);
        themePicker.getItems().setAll(Theme.values());
        themePicker.setConverter(new StringConverter<>() {
            @Override
            public String toString(Theme theme) {
                return theme == null ? "" : theme.label();
            }

            @Override
            public Theme fromString(String text) {
                return Theme.parse(text);
            }
        });
        themePicker.setValue(ThemeManager.current());
        themePicker.valueProperty().addListener((obs, old, now) -> {
            if (now != null && now != old) {
                ThemeManager.apply(now, getScene());
            }
        });

        VBox box = new VBox(4, caption, themePicker);
        VBox.setMargin(box, new Insets(6, 0, 0, 0));
        return box;
    }

    // ------------------------------------------------------------------
    // Top bar
    // ------------------------------------------------------------------

    private HBox buildTopBar() {
        viewTitle.getStyleClass().add("lp-view-title");

        Label switcherCaption = new Label("Working client:");
        switcherCaption.getStyleClass().add("lp-muted");
        clientSwitcher.setPromptText("Select a client…");
        // 2.12.1 (P4-S6): the switcher sizes to its WIDEST client
        // (capped at 26 em) — the fixed 330 px pref clipped the client
        // name at 130% text scale ("NRTH — Northwind Retail T...")
        UiSizing.fitWidestItem(clientSwitcher, 26);
        // selection → activeClient, and remembered for the next launch (2.7.0);
        // setValue(null) from refreshClientSwitcher() clears the memory too
        clientSwitcher.valueProperty().addListener((obs, old, now) -> {
            activeClient.set(now);
            Prefs.getInstance().setLastClientId(now == null ? -1 : now.id());
        });

        Button newClient = new Button("New client…");
        newClient.getStyleClass().add("lp-compact-btn");
        newClient.setOnAction(e -> ClientsView.offerNewClientDialog(
                clientService, accountService,
                getScene() == null ? null : getScene().getWindow(),
                created -> refreshClientSwitcher()));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox top = new HBox(14, viewTitle, spacer, switcherCaption, clientSwitcher, newClient);
        top.getStyleClass().add("lp-topbar");
        top.setAlignment(Pos.CENTER_LEFT);
        return top;
    }

    // ------------------------------------------------------------------
    // DB status chip
    // ------------------------------------------------------------------

    /** "dot SQLite 3.54 · WAL" - the dot is green only when all is well. */
    private void refreshDbStatus() {
        String version = "?";
        String mode = "?";
        boolean ok = true;
        try (Connection con = database.open();
             Statement st = con.createStatement()) {
            try (ResultSet rs = st.executeQuery("SELECT sqlite_version()")) {
                if (rs.next()) {
                    version = rs.getString(1);
                }
            }
            try (ResultSet rs = st.executeQuery("PRAGMA journal_mode")) {
                if (rs.next()) {
                    mode = rs.getString(1);
                }
            }
        } catch (SQLException e) {
            ok = false;
        }
        Text dot = new Text("● ");
        dot.getStyleClass().add(ok ? "lp-dot-ok" : "lp-dot-fail");
        Text text = new Text("SQLite " + version + " · " + mode.toUpperCase()
                + (ok ? "" : " — check the data folder"));
        text.getStyleClass().add("lp-db-text");
        dbStatus.getChildren().setAll(dot, text);
    }

    // ------------------------------------------------------------------
    // View factory
    // ------------------------------------------------------------------

    private Node createView(ViewId id) {
        return switch (id) {
            case DASHBOARD -> new DashboardView(clientService, database, activeClient,
                    journalService, periodService);
            case CLIENTS -> new ClientsView(clientService, accountService,
                    this::refreshClientSwitcher);
            case COA -> new AccountsView(accountService, clientService, activeClient);
            case FX_RATES -> new FxView(fxService, activeClient);
            case JOURNAL -> journalView != null ? journalView
                    : (journalView = new JournalView(journalService, periodService,
                    accountService, fxService, adjService, activeClient));
            case LEDGERS -> new LedgersView(accountService, journalService, activeClient);
            case TRIAL_BALANCE -> new TrialBalanceView(journalService, periodService,
                    activeClient);
            case WORKSHEET -> new WorksheetView(worksheetService, periodService,
                    activeClient);
            case REPORTS -> new ReportsView(worksheetService, periodService,
                    new com.ledgerpro.service.CashFlowService(database),
                    activeClient);
            case AUDIT -> new AuditView(auditService, activeClient);
            default -> new PlaceholderView(id);
        };
    }

    /**
     * Opens the command palette (Ctrl/Cmd+K, 2.12.0): one searchable list
     * over views, clients and the common actions. Everything routes through
     * the SAME hooks the sidebar uses, so a command always lands on a
     * freshly refreshed view.
     */
    public void openCommandPalette() {
        java.util.List<CommandPalette.Command> commands = new java.util.ArrayList<>();
        for (ViewId id : ViewId.values()) {
            commands.add(new CommandPalette.Command(
                    "Go to " + id.title, "View", () -> show(id)));
        }
        for (Client client : clientService.list(false)) {
            commands.add(new CommandPalette.Command(
                    "Work on " + client.code() + " — " + client.name(),
                    "Client", () -> selectWorkingClient(client)));
        }
        commands.add(new CommandPalette.Command(
                "New journal entry", "Action", this::openNewEntryDialog));
        commands.add(new CommandPalette.Command(
                "New client", "Action",
                () -> ClientsView.offerNewClientDialog(
                        clientService, accountService,
                        getScene() == null ? null : getScene().getWindow(),
                        created -> refreshClientSwitcher())));
        commands.add(new CommandPalette.Command(
                "Back up the books now", "Action", this::backupNow));
        commands.add(new CommandPalette.Command(
                "Open Settings", "Action", this::openSettings));

        javafx.stage.Stage owner = getScene() == null ? null
                : (javafx.stage.Stage) getScene().getWindow();
        CommandPalette.open(owner, commands);
    }

    /**
     * 2.12.0: one-click backup — a consistent SQLite snapshot into
     * ~/.ledgerpro/backups with a timestamped name, confirmed with the
     * path so the accountant knows exactly where the books were saved.
     */
    private void backupNow() {
        try {
            java.nio.file.Path target = new BackupService(database).backupNow();
            javafx.scene.control.Alert done = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.INFORMATION,
                    "A consistent snapshot of the whole database was written to:\n\n"
                            + target,
                    javafx.scene.control.ButtonType.OK);
            done.setHeaderText("Backup saved");
            done.setTitle("LedgerPro");
            if (getScene() != null && getScene().getWindow() != null) {
                done.initOwner(getScene().getWindow());
            }
            done.showAndWait();
        } catch (RuntimeException e) {
            ClientsView.errorAlert(new IllegalStateException(
                    "The backup could not be written: " + e.getMessage()));
        }
    }

    /**
     * Opens the Journal's New-entry dialog (the Ctrl/Cmd+N shortcut): jumps
     * to the journal first so the dialog lands in context.
     */
    public void openNewEntryDialog() {
        show(ViewId.JOURNAL);
        if (journalView != null) {
            journalView.offerNewEntry();
        }
    }
}
