package com.ledgerpro.ui;

import javafx.scene.chart.ValueAxis;
import javafx.scene.text.Font;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The value axis of the dashboard's money charts (2.12.1): a
 * {@link ValueAxis} for currency amounts with three things a money chart
 * needs and the stock {@code NumberAxis} (which is final) does not do.
 *
 * <ul>
 *   <li><b>Short tick labels</b> — "50k", "125k", "1.25M" instead of the
 *       stock axis's "50,000" / "1.0E7" (the scientific notation that
 *       showed up on the user's trend chart). The exact amount is one
 *       hover away on every point.</li>
 *   <li><b>Headroom in PIXELS</b> — the stock axis pads a range by 2% of
 *       its span, so a month with zero revenue sat exactly on the x-axis
 *       line and its symbol was clipped in half. This axis reserves a
 *       fixed number of pixels above the highest and below the lowest
 *       tick instead, whatever the amounts are.</li>
 *   <li><b>Ticks on round multiples only</b> — the stock axis also draws
 *       a tick at its (padded) lower bound, which is how "-2,400" could
 *       appear under an all-positive chart.</li>
 * </ul>
 *
 * <p>It is the axis's own class, not a decorator: every hook the chart
 * calls on a value axis ({@code autoRange}, {@code setRange},
 * {@code getRange}, {@code calculateTickValues}, {@code getTickMarkLabel})
 * is implemented here, and the arithmetic lives in small static methods
 * so it can be unit-tested without a toolkit.</p>
 */
final class MoneyAxis extends ValueAxis<Number> {

    /** The range an empty or all-zero period shows: 0 … 1,000, step 250. */
    private static final double NOMINAL_TOP = 1_000;
    private static final double NOMINAL_UNIT = 250;

    /** Pixels between two ticks at the base text size. */
    private static final double MIN_TICK_GAP_PX = 24;

    /** Never more than this many ticks, however tall the chart grows. */
    private static final int MAX_TICKS = 8;

    private static final DecimalFormat MILLIONS = grouped();
    private static final DecimalFormat THOUSANDS = grouped();
    private static final DecimalFormat UNITS = grouped();

    /** The range currently drawn — lower, upper, tick unit, scale. */
    record Range(double lower, double upper, double unit, double scale) {
    }

    private final double topPadding;
    private final double bottomPadding;
    private Range range = new Range(0, NOMINAL_TOP, NOMINAL_UNIT, 1);

    /**
     * @param topPadding    pixels reserved above the highest tick
     * @param bottomPadding pixels reserved below the lowest tick (0 keeps a
     *                      bar chart sitting on its baseline)
     */
    MoneyAxis(double topPadding, double bottomPadding) {
        this.topPadding = topPadding;
        this.bottomPadding = bottomPadding;
        setAutoRanging(true);
        setMinorTickCount(0);
    }

    /**
     * Chooses the range: a round tick unit with at most as many ticks as
     * fit at the current text size, bounds snapped out to that unit, then
     * the pixel headroom. Runs on every layout, so it must be cheap and
     * must not change the axis's state.
     */
    @Override
    protected Object autoRange(double minValue, double maxValue, double length,
                               double labelSize) {
        Range bounds = rangeFor(minValue, maxValue, length, getTickLabelFont().getSize(),
                topPadding, bottomPadding);
        // The scale depends on the axis's private offset, which only
        // calculateNewScale() sets — an instance method, hence called here.
        return new Range(bounds.lower(), bounds.upper(), bounds.unit(),
                calculateNewScale(length, bounds.lower(), bounds.upper()));
    }

    /** Adopts a range computed by {@link #autoRange}. */
    @Override
    protected void setRange(Object value, boolean animate) {
        Range next = (Range) value;
        range = next;
        setLowerBound(next.lower());
        setUpperBound(next.upper());
        currentLowerBound.set(next.lower());
        setScale(next.scale());
    }

    @Override
    protected Object getRange() {
        return range;
    }

    /** Round multiples of the unit inside the range — and nothing else. */
    @Override
    protected List<Number> calculateTickValues(double length, Object range) {
        List<Number> ticks = new ArrayList<>();
        for (double tick : ticksOf((Range) range)) {
            ticks.add(tick);
        }
        return ticks;
    }

    @Override
    protected List<Number> calculateMinorTickMarks() {
        return List.of();
    }

    @Override
    protected String getTickMarkLabel(Number value) {
        return compact(value.doubleValue());
    }

    // ------------------------------------------------------------------
    // The arithmetic (static: unit-tested without a toolkit)
    // ------------------------------------------------------------------

    /**
     * The range for a data span on an axis of {@code axisLength} pixels.
     * {@code tickFontPx} is the tick-label text size (ticks are kept far
     * enough apart for it); {@code length} is the axis length as the chart
     * hands it over (its sign only matters to the scale).
     */
    static Range rangeFor(double minValue, double maxValue, double length,
                          double tickFontPx, double topPadding, double bottomPadding) {
        double min = minValue;
        double max = maxValue;
        if (Double.isNaN(min) || Double.isNaN(max) || max < min) {
            min = 0;                                  // no data yet
            max = 0;
        }
        double axisLength = Math.max(1, Math.abs(length));
        if (!(max - min > 0) && min >= 0 && max <= 1) {
            // nothing (or less than one currency unit) to draw: a calm
            // 0 … 1,000 ladder instead of 0 … 0.002. The scale is filled
            // in by autoRange, the only place that can compute it.
            return new Range(0, NOMINAL_TOP, NOMINAL_UNIT, 0);
        }
        if (max - min <= 0) {
            // one single value on the axis: give it a band to sit in
            double band = Math.max(Math.abs(min) * 0.1, 1);
            min -= band;
            max += band;
        }
        double tickGap = Math.max(MIN_TICK_GAP_PX, tickFontPx * 1.9);
            int maxTicks = (int) Math.floor(axisLength / tickGap);
            maxTicks = Math.max(2, Math.min(maxTicks, MAX_TICKS));
            double unit = niceUnit((max - min) / (maxTicks - 1));
            double lower = Math.floor(min / unit) * unit;
            double upper = Math.ceil(max / unit) * unit;
            if (upper - lower <= 0) {
                lower -= unit;
                upper += unit;
            }
            // pixel headroom, never more than 45% of a tick unit (so the
            // padding never opens room for a tick that is not a multiple)
            double perPixel = (upper - lower) / axisLength;
            lower -= Math.min(bottomPadding * perPixel, unit * 0.45);
            upper += Math.min(topPadding * perPixel, unit * 0.45);
        return new Range(lower, upper, unit, 0);
    }

    /** Every {@code k × unit} between the range bounds. */
    static List<Double> ticksOf(Range range) {
        List<Double> ticks = new ArrayList<>();
        long first = (long) Math.ceil(range.lower() / range.unit() - 1e-9);
        long last = (long) Math.floor(range.upper() / range.unit() + 1e-9);
        for (long k = first; k <= last; k++) {
            ticks.add(k * range.unit());
        }
        return ticks;
    }

    /**
     * The smallest "nice" step (1, 2, 2.5 or 5 × 10ⁿ) that is not smaller
     * than {@code raw}.
     */
    static double niceUnit(double raw) {
        double exponent = Math.floor(Math.log10(raw));
        double base = Math.pow(10, exponent);
        double mantissa = raw / base;
        double nice = mantissa <= 1 ? 1 : mantissa <= 2 ? 2 : mantissa <= 2.5 ? 2.5
                : mantissa <= 5 ? 5 : 10;
        return nice * base;
    }

    /** "50k", "125k", "1.25M", "2,500" — two fraction digits at most. */
    static String compact(double value) {
        double magnitude = Math.abs(value);
        if (magnitude >= 999_950) {
            return MILLIONS.format(value / 1_000_000) + "M";
        }
        if (magnitude >= 1_000) {
            return THOUSANDS.format(value / 1_000) + "k";
        }
        return UNITS.format(value);
    }

    /** Parses what {@link #compact} writes ("12.5k" → 12,500). */
    static double parseCompact(String raw) {
        String text = raw == null ? "" : raw.trim().replace(",", "");
        if (text.isEmpty()) {
            return 0;
        }
        char tail = Character.toLowerCase(text.charAt(text.length() - 1));
        double factor = tail == 'k' ? 1_000 : tail == 'm' ? 1_000_000 : 1;
        String number = factor == 1 ? text : text.substring(0, text.length() - 1);
        return Double.parseDouble(number.trim()) * factor;
    }

    /** The widest tick label the range will draw, in the given font. */
    static double widestTick(Range range, Font font) {
        double widest = 0;
        for (double tick : ticksOf(range)) {
            widest = Math.max(widest, UiSizing.textWidth(compact(tick), font));
        }
        return widest;
    }

    private static DecimalFormat grouped() {
        return new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));
    }
}
