package com.ledgerpro.ui;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

/**
 * Honest placeholder for a view of a later phase: what will live here, and
 * when. No fake grids, no "coming soon" hand-waving - the phase number and
 * scope come straight from {@link ViewId}, the same source the roadmap uses.
 */
final class PlaceholderView extends VBox {

    PlaceholderView(ViewId id) {
        setAlignment(Pos.CENTER);
        setSpacing(10);

        Label title = new Label(id.title);
        title.getStyleClass().add("lp-placeholder-title");

        Label phase = new Label("Planned — Phase " + id.phase);
        phase.getStyleClass().add("lp-placeholder-phase");

        Label blurb = new Label(id.blurb);
        blurb.getStyleClass().add("lp-placeholder-blurb");
        blurb.setWrapText(true);
        blurb.setMaxWidth(480);
        blurb.setAlignment(Pos.CENTER);

        Label note = new Label("The shell, database and client register are already live"
                + " — this view plugs into the same foundation.");
        note.getStyleClass().add("lp-muted");
        note.setWrapText(true);
        note.setMaxWidth(480);
        note.setAlignment(Pos.CENTER);

        getChildren().addAll(new Region(), title, phase, blurb, note, new Region());
        VBox.setVgrow((Region) getChildren().getFirst(), javafx.scene.layout.Priority.ALWAYS);
        VBox.setVgrow((Region) getChildren().getLast(), javafx.scene.layout.Priority.ALWAYS);
    }
}
