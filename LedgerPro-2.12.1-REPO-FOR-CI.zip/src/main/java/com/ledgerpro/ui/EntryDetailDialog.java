package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.model.JournalEntry;
import com.ledgerpro.service.AdjTemplateService;
import com.ledgerpro.service.JournalService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;

/**
 * Read-only detail of one journal entry: the header facts and the Dr/Cr
 * lines with their totals — the answer to "what exactly did this entry do?".
 *
 * <p>Recurring gold: an entry that worked once can be remembered — "Save as
 * template…" hands the lines (by account code) to {@link SaveTemplateDialog}
 * so next month's version starts one click away.</p>
 */
final class EntryDetailDialog extends Dialog<Void> {

    private final List<Label> contentExtra = new ArrayList<>();

    EntryDetailDialog(Client client, JournalService.EntrySummary summary,
                      List<JournalService.LineRow> lines, AdjTemplateService adjService) {
        JournalEntry entry = summary.entry();

        setTitle("Entry #" + entry.entryNo());
        setHeaderText(null);

        ButtonType saveTemplate = new ButtonType("Save as template…",
                ButtonBar.ButtonData.LEFT);
        getDialogPane().getButtonTypes().addAll(saveTemplate, ButtonType.CLOSE);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());

        GridPane facts = new GridPane();
        facts.setHgap(14);
        facts.setVgap(6);
        int row = 0;
        facts.addRow(row++, new Label("Date:"), value(entry.date().toString()));
        facts.addRow(row++, new Label("Type:"), value(entry.type().label));
        facts.addRow(row++, new Label("Period:"), value(summary.periodName()));
        facts.addRow(row++, new Label("Reference:"),
                value(entry.reference() == null || entry.reference().isBlank()
                        ? "—" : entry.reference()));
        facts.addRow(row++, new Label("Memo:"), value(entry.memo() == null ? "—" : entry.memo()));
        String currency = entry.currency() == null
                ? client.baseCurrency() + " (base)"
                : entry.currency() + " @ " + Money.rate(entry.fxRate()) + " → "
                        + client.baseCurrency();
        facts.addRow(row++, new Label("Currency:"), value(currency));
        String status = summary.voided() ? "Voided — cancelled by a mirrored reversing entry"
                : entry.posted() ? "Posted — ledger fact" : "Draft — not yet ledger fact";
        Label statusValue = value(status);
        statusValue.getStyleClass().add(summary.voided() ? "lp-contra" : "lp-status-ok");
        facts.addRow(row++, new Label("Status:"), statusValue);
        facts.addRow(row++, new Label("Created:"), value(entry.createdAt() + " UTC"));
        facts.addRow(row++, new Label("Posted at:"),
                value(entry.postedAt() == null ? "—" : entry.postedAt() + " UTC"));
        ColumnConstraints labels = new ColumnConstraints(80);
        ColumnConstraints values = new ColumnConstraints();
        values.setHgrow(Priority.ALWAYS);
        facts.getColumnConstraints().addAll(labels, values);

        TableView<JournalService.LineRow> table = new TableView<>();
        table.setPlaceholder(new Label("No lines — an entry always has at least two."));
        table.setPrefHeight(240);
        table.setPrefWidth(640);

        TableColumn<JournalService.LineRow, String> account = new TableColumn<>("Account");
        account.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().account().code() + " — " + c.getValue().account().name()));
        account.setPrefWidth(320);

        TableColumn<JournalService.LineRow, Long> debit = new TableColumn<>(
                "Debit (" + client.baseCurrency() + ")");
        debit.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().line().debitCents()));
        debit.setPrefWidth(130);
        debit.setCellFactory(col -> new MoneyCell<>());

        TableColumn<JournalService.LineRow, Long> credit = new TableColumn<>(
                "Credit (" + client.baseCurrency() + ")");
        credit.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().line().creditCents()));
        credit.setPrefWidth(130);
        credit.setCellFactory(col -> new MoneyCell<>());

        TableColumn<JournalService.LineRow, String> memo = new TableColumn<>("Line memo");
        memo.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().line().memo() == null ? "" : c.getValue().line().memo()));
        memo.setPrefWidth(160);

        table.getColumns().addAll(account, debit, credit, memo);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.getItems().addAll(lines);

        // Multi-currency entries: what was typed in the original currency —
        // the migration-V4 transaction-currency trail, line by line.
        boolean anyTxn = lines.stream().anyMatch(
                r -> r.line().txnCurrency() != null
                        && (r.line().txnDebitCents() != null || r.line().txnCreditCents() != null));
        if (anyTxn) {
            Label txnNote = new Label(txnText(lines));
            txnNote.getStyleClass().add("lp-card-note");
            txnNote.setWrapText(true);
            VBox.setMargin(txnNote, new Insets(0, 0, 0, 0));
            contentExtra.add(txnNote);
        }

        long totalDr = lines.stream()
                .mapToLong(r -> r.line().debitCents() == null ? 0 : r.line().debitCents()).sum();
        long totalCr = lines.stream()
                .mapToLong(r -> r.line().creditCents() == null ? 0 : r.line().creditCents()).sum();
        Label totals = new Label("Debits " + Money.format(totalDr) + "   ·   Credits "
                + Money.format(totalCr) + "   ·   "
                + (totalDr == totalCr ? "balanced ✓" : "OUT OF BALANCE"));
        totals.getStyleClass().add(totalDr == totalCr ? "lp-status-ok" : "lp-dialog-error");

        HBox totalsBar = new HBox(totals);
        totalsBar.setAlignment(Pos.CENTER_LEFT);
        totalsBar.setPadding(new Insets(6, 2, 6, 2));

        List<javafx.scene.Node> contentChildren = new ArrayList<>();
        contentChildren.add(facts);
        contentChildren.add(table);
        if (!contentExtra.isEmpty()) {
            contentChildren.add(contentExtra.getFirst());
        }
        contentChildren.add(totalsBar);
        VBox content = new VBox(12);
        content.getChildren().addAll(contentChildren);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        content.setPrefWidth(740);
        getDialogPane().setContent(content);
        // 2.9.0: resizable — the lines table gets the extra height
        UiStartup.makeResizable(this, 760, 420);

        // Remember a working entry as a recurring template: lines by account
        // code, amounts exactly as posted (base currency).
        javafx.scene.Node templateButton = getDialogPane().lookupButton(saveTemplate);
        templateButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            List<AdjTemplateService.TemplateLine> templateLines = new ArrayList<>();
            for (JournalService.LineRow lineRow : lines) {
                boolean onDebit = lineRow.line().debitCents() != null;
                templateLines.add(new AdjTemplateService.TemplateLine(
                        templateLines.size() + 1,
                        lineRow.account().code(),
                        onDebit ? "DR" : "CR",
                        AdjTemplateService.FIXED,
                        Money.format(onDebit ? lineRow.line().debitCents()
                                : lineRow.line().creditCents()),
                        lineRow.line().memo()));
            }
            SaveTemplateDialog dialog = new SaveTemplateDialog(adjService, client,
                    entry.memo(), templateLines);
            if (getDialogPane().getScene() != null) {
                dialog.initOwner(getDialogPane().getScene().getWindow());
            }
            dialog.showAndWait().ifPresent(saved -> {
                Alert done = new Alert(Alert.AlertType.INFORMATION,
                        "Saved as template " + saved.code()
                                + (saved.shared() ? " (shared with every client)."
                                : " for " + client.code() + ".")
                                + "\n\nLoad it from “New entry… → Load template…”"
                                + " any time.",
                        ButtonType.OK);
                done.setHeaderText(null);
                done.setTitle("Template saved");
                done.showAndWait();
            });
            event.consume();   // the detail stays open; CLOSE ends it
        });
    }

    private static Label value(String text) {
        Label label = new Label(text);
        label.setWrapText(true);
        label.getStyleClass().add("lp-col-strong");
        return label;
    }

    /** The typed amounts in the entry's original currency, one line each. */
    private static String txnText(List<JournalService.LineRow> lines) {
        StringBuilder sb = new StringBuilder("Typed in the original currency:  ");
        for (JournalService.LineRow r : lines) {
            long cents = r.line().txnDebitCents() != null
                    ? r.line().txnDebitCents() : r.line().txnCreditCents();
            if (cents == 0 && r.line().txnDebitCents() == null
                    && r.line().txnCreditCents() == null) {
                continue;
            }
            sb.append(r.account().code()).append(" ")
                    .append(r.line().txnDebitCents() != null ? "Dr " : "Cr ")
                    .append(Money.format(cents)).append(" ")
                    .append(r.line().txnCurrency()).append("   ·   ");
        }
        sb.append("(converted at the cached rate snapshotted on the entry)");
        return sb.toString();
    }
}
