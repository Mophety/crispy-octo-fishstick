package com.ledgerpro.ui;

import java.net.URL;
import java.util.Objects;

/**
 * The looks LedgerPro can wear. Every theme pairs an AtlantaFX user-agent
 * stylesheet (the part that styles every standard JavaFX control) with an
 * optional overlay stylesheet of LedgerPro's own that re-tints the palette
 * on top of it.
 *
 * <p>Switching happens at runtime from the sidebar's "Appearance" picker —
 * {@link ThemeManager#apply} re-applies the user-agent stylesheet live, swaps
 * the overlay and remembers the choice, so the app comes back in the same
 * look next launch.</p>
 *
 * <ul>
 *   <li><b>Primer Light</b> — the original LedgerPro look (GitHub-ish light);
 *       the default, and what a fresh install starts with.</li>
 *   <li><b>Primer Dark</b> — the same design language for late-night closing
 *       runs.</li>
 *   <li><b>Nord Light / Nord Dark</b> — the calm, low-contrast Nord palette
 *       many accountants keep their editor in.</li>
 *   <li><b>Dracula</b> — the well-known purple dark scheme.</li>
 *   <li><b>Alexia's theme</b> — the deep forest-green suite look, sampled
 *       pixel by pixel from Alexia's screenshots of the running app: dark
 *       green sidebar with green-filled navigation pills, near-black-green
 *       content area, lighter green cards and tables, and green primary
 *       buttons with white labels.</li>
 * </ul>
 */
public enum Theme {

    /** The original LedgerPro look — light, GitHub-ish. The default. */
    PRIMER_LIGHT("Primer Light", new atlantafx.base.theme.PrimerLight(), null),

    /** Primer's dark twin for late-night closing runs. */
    PRIMER_DARK("Primer Dark", new atlantafx.base.theme.PrimerDark(), null),

    /** Nord's calm, low-contrast light palette. */
    NORD_LIGHT("Nord Light", new atlantafx.base.theme.NordLight(), null),

    /** Nord's calm, low-contrast dark palette (2.12.0: AA overlay lifts muted ink). */
    NORD_DARK("Nord Dark", new atlantafx.base.theme.NordDark(),
            "/css/theme-nord-dark-aa.css"),

    /** The well-known purple dark scheme. */
    DRACULA("Dracula", new atlantafx.base.theme.Dracula(), null),

    /**
     * Alexia's theme — the deep forest-green look from her screenshots:
     * green nav pills on a near-black sidebar, green cards and tables on a
     * dark-green page, green primary buttons with white text.
     */
    ALEXIA("Alexia's theme", new atlantafx.base.theme.PrimerDark(),
            "/css/theme-alexia.css");

    private final String label;
    private final atlantafx.base.theme.Theme userAgent;
    private final String overlayPath;

    Theme(String label, atlantafx.base.theme.Theme userAgent, String overlayPath) {
        this.label = label;
        this.userAgent = userAgent;
        this.overlayPath = overlayPath;
    }

    /** The name shown in the Appearance picker. */
    public String label() {
        return label;
    }

    /** The AtlantaFX user-agent stylesheet URL for this theme. */
    public String userAgentStylesheet() {
        return userAgent.getUserAgentStylesheet();
    }

    /**
     * The overlay stylesheet URL to append AFTER ledgerpro.css, or null when
     * the plain AtlantaFX palette is the whole theme. The resource is
     * verified at construction time so a typo fails loudly at startup, not
     * silently at first paint.
     */
    public String overlayUrl() {
        if (overlayPath == null) {
            return null;
        }
        URL url = Objects.requireNonNull(Theme.class.getResource(overlayPath),
                "theme overlay stylesheet not found on the classpath: " + overlayPath);
        return url.toExternalForm();
    }

    /** Parses a saved theme name; null (or anything unknown) -> the default. */
    public static Theme parse(String saved) {
        if (saved != null) {
            for (Theme theme : values()) {
                if (theme.name().equals(saved)) {
                    return theme;
                }
            }
        }
        return PRIMER_LIGHT;
    }

    /** The factory default look (Primer Light). */
    public static Theme defaultTheme() {
        return PRIMER_LIGHT;
    }
}
