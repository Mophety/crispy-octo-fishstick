package com.ledgerpro.ui;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The command palette (2.12.0) — Ctrl/Cmd+K from anywhere.
 *
 * <p>A keyboard-first search over everything navigable: views, clients,
 * and the common actions (new entry, new client, new period, export,
 * backup). Typing filters; Enter runs the highlighted command; Up/Down
 * walk the list; Esc closes. The palette is a lightweight undecorated
 * stage centered over the app window — no dialog chrome, one text field,
 * one list, the same flat styling as the rest of 2.12.0.</p>
 *
 * <p>Everything it runs goes through the SAME hooks the sidebar and views
 * use ({@link AppShell#show}, client selection, dialogs), so a command
 * can never bypass a refresh path.</p>
 */
final class CommandPalette {

    /** One runnable entry in the palette. */
    record Command(String title, String group, Runnable action) {

        /** Lowercased match target: title + group. */
        String haystack() {
            return (title + " " + group).toLowerCase(Locale.ROOT);
        }
    }

    private final Stage stage;
    private final TextField field = new TextField();
    private final ListView<Command> list = new ListView<>();
    private final List<Command> all;

    private CommandPalette(Stage owner, List<Command> commands) {
        this.all = List.copyOf(commands);

        stage = new Stage(StageStyle.UNDECORATED);
        stage.initOwner(owner);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("LedgerPro command palette");

        field.setPromptText("Search views, clients and actions…");
        field.getStyleClass().add("lp-palette-field");
        list.setCellFactory(view -> new CommandCell());
        list.getStyleClass().add("lp-palette-list");
        VBox.setVgrow(list, Priority.ALWAYS);

        Label hint = new Label("↑↓ choose · Enter run · Esc close");
        hint.getStyleClass().add("lp-palette-hint");

        VBox box = new VBox(4, field, list, hint);
        box.getStyleClass().add("lp-palette");
        box.setPadding(new Insets(6));
        box.setPrefWidth(520);
        box.setPrefHeight(360);

        StackPane root = new StackPane(box);
        root.setPadding(new Insets(0));
        StackPane.setAlignment(box, Pos.TOP_CENTER);
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        // the palette inherits the app's author stylesheet + theme overlay
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().addAll(owner.getScene().getStylesheets());
        }
        stage.setScene(scene);

        field.textProperty().addListener((obs, old, now) -> refill(now));
        field.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.DOWN) {
                list.requestFocus();
                if (!list.getItems().isEmpty()) {
                    list.getSelectionModel().selectFirst();
                }
                event.consume();
            } else if (event.getCode() == KeyCode.ESCAPE) {
                close();
                event.consume();
            }
        });
        list.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                runSelected();
                event.consume();
            } else if (event.getCode() == KeyCode.ESCAPE) {
                close();
                event.consume();
            } else if (event.getCode() == KeyCode.BACK_SPACE
                    || event.getCharacter() != null && !event.getCharacter().isBlank()) {
                // keep typing from the list: bounce back to the field
                field.requestFocus();
                field.end();
            }
        });
        list.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                runSelected();
            }
        });

        refill("");
        Platform.runLater(field::requestFocus);
    }

    /** Opens the palette over {@code owner} with the given commands. */
    static void open(Stage owner, List<Command> commands) {
        CommandPalette palette = new CommandPalette(owner, commands);
        // center over the owner
        if (owner != null) {
            palette.stage.setX(owner.getX() + (owner.getWidth() - 520) / 2);
            palette.stage.setY(owner.getY() + Math.max(40, owner.getHeight() * 0.18));
        }
        palette.stage.showAndWait();
    }

    private void refill(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<Command> hits = new ArrayList<>();
        for (Command command : all) {
            if (q.isEmpty() || command.haystack().contains(q)) {
                hits.add(command);
            }
        }
        list.getItems().setAll(hits);
        if (!hits.isEmpty()) {
            list.getSelectionModel().selectFirst();
        }
    }

    private void runSelected() {
        Command chosen = list.getSelectionModel().getSelectedItem();
        if (chosen == null) {
            return;
        }
        stage.close();
        try {
            chosen.action().run();
        } catch (RuntimeException e) {
            // a command failing must not leave the palette half-open: it
            // is already closed, surface the error like the views do
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.WARNING,
                    "The command could not run:\n\n" + e.getMessage(),
                    javafx.scene.control.ButtonType.OK);
            alert.setHeaderText(null);
            alert.showAndWait();
        }
    }

    private void close() {
        stage.close();
    }

    /** The palette's one row: title bold-left, group muted-right. */
    private static final class CommandCell extends ListCell<Command> {
        @Override
        protected void updateItem(Command item, boolean empty) {
            super.updateItem(item, empty);
            getStyleClass().setAll("lp-palette-list-cell");
            if (empty || item == null) {
                setText(null);
                setGraphic(null);
            } else {
                Label title = new Label(item.title());
                title.getStyleClass().add("lp-col-strong");
                Label group = new Label(item.group());
                group.getStyleClass().add("lp-muted");
                group.getStyleClass().add("lp-legend-text");
                javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
                javafx.scene.layout.HBox.setHgrow(spacer, Priority.ALWAYS);
                javafx.scene.layout.HBox row =
                        new javafx.scene.layout.HBox(10, title, spacer, group);
                row.setAlignment(Pos.CENTER_LEFT);
                setText(null);
                setGraphic(row);
            }
        }
    }
}
