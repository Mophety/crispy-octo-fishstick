package com.ledgerpro.ui;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Region;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.util.prefs.Preferences;

/**
 * Startup quality-of-life wiring that is not view-specific:
 *
 * <ul>
 *   <li><b>Window geometry memory</b> — size, position and maximized state
 *       are remembered on close and restored on the next launch, so a user
 *       who works maximized starts maximized. A remembered geometry that no
 *       longer fits any attached screen (monitor removed, resolution
 *       changed) is discarded and the default centered window is used.</li>
 *   <li><b>Keyboard navigation</b> — Ctrl/Cmd+1…9 jump straight to the nine
 *       sidebar views in navigation order, and Ctrl/Cmd+N opens the New
 *       Entry dialog of the Journal view (the most-used action in the app).
 *       Shortcuts fire only when no dialog is open and no text field has
 *       focus, so they never swallow typing.</li>
 *   <li><b>Dialog accelerators</b> — every dialog pane in the app gets
 *       Esc = cancel/close and Ctrl/Cmd+Enter = fire the default button,
 *       the two muscle-memory keys of desktop forms.</li>
 *   <li><b>Responsive text</b> — the scene root's font size is bound to the
 *       {@link UiScale} controller so all em-sized text re-fits the window.</li>
 * </ul>
 *
 * <p>JavaFX 21 with Java 21+ on Linux/macOS: see the javadoc of
 * {@link Stage#setMaximized} — the property works on all desktop platforms.</p>
 */
public final class UiStartup {

    private static final String KEY_X = "window.x";
    private static final String KEY_Y = "window.y";
    private static final String KEY_W = "window.width";
    private static final String KEY_H = "window.height";
    private static final String KEY_MAX = "window.maximized";

    private UiStartup() {
    }

    /** Restores remembered size/position/maximized state, if it still fits a screen. */
    public static void applyRememberedGeometry(Stage stage, String prefsNode) {
        try {
            Preferences prefs = Preferences.userRoot().node(prefsNode);
            double w = prefs.getDouble(KEY_W, 0);
            double h = prefs.getDouble(KEY_H, 0);
            if (w >= 400 && h >= 300) {
                double x = prefs.getDouble(KEY_X, Double.NaN);
                double y = prefs.getDouble(KEY_Y, Double.NaN);
                boolean onScreen = false;
                if (!Double.isNaN(x) && !Double.isNaN(y)) {
                    // valid only if at least a quarter of the window would be
                    // visible on some attached monitor
                    for (Screen screen : Screen.getScreens()) {
                        Rectangle2D bounds = screen.getVisualBounds();
                        if (bounds.intersects(x, y, w, h)
                                && x + w * 0.75 > bounds.getMinX()
                                && y + h * 0.75 > bounds.getMinY()) {
                            onScreen = true;
                            break;
                        }
                    }
                }
                if (onScreen) {
                    stage.setX(x);
                    stage.setY(y);
                } else {
                    // center on the primary screen
                    Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
                    x = bounds.getMinX() + (bounds.getWidth() - w) / 2;
                    y = bounds.getMinY() + (bounds.getHeight() - h) / 2;
                    stage.setX(Math.max(x, bounds.getMinX()));
                    stage.setY(Math.max(y, bounds.getMinY()));
                }
                stage.setWidth(w);
                stage.setHeight(h);
                if (prefs.getBoolean(KEY_MAX, false)) {
                    stage.setMaximized(true);
                }
            }
        } catch (RuntimeException ignored) {
            // preferences unavailable (locked-down machine): default window
        }
    }

    /** Saves geometry whenever it changes; the last normal state wins. */
    public static void attachGeometrySaver(Stage stage, String prefsNode) {
        ChangeListener<Number> save = (obs, old, now) -> saveGeometry(stage, prefsNode);
        stage.xProperty().addListener(save);
        stage.yProperty().addListener(save);
        stage.widthProperty().addListener(save);
        stage.heightProperty().addListener(save);
        // maximized changes fire before x/y/width settle — defer one pulse
        // so the saved values are the normal ones, not the transition ones
        stage.maximizedProperty().addListener((obs, old, now) ->
                Platform.runLater(() -> saveGeometry(stage, prefsNode)));
    }

    private static void saveGeometry(Stage stage, String prefsNode) {
        if (stage.isMaximized() || stage.isIconified()) {
            // keep the last normal bounds, not the maximized ones
            return;
        }
        try {
            Preferences prefs = Preferences.userRoot().node(prefsNode);
            if (!Double.isNaN(stage.getX()) && !Double.isNaN(stage.getY())) {
                prefs.putDouble(KEY_X, stage.getX());
                prefs.putDouble(KEY_Y, stage.getY());
            }
            prefs.putDouble(KEY_W, stage.getWidth());
            prefs.putDouble(KEY_H, stage.getHeight());
            prefs.putBoolean(KEY_MAX, stage.isMaximized());
        } catch (RuntimeException ignored) {
            // best effort only
        }
    }

    /**
     * Installs the global shortcuts on the scene: Ctrl/Cmd+1…9 view
     * navigation, Ctrl/Cmd+N new entry.
     */
    // ------------------------------------------------------------------
    // Dialog accelerators — Esc closes, Ctrl/Cmd+Enter saves
    // ------------------------------------------------------------------

    /**
     * Two muscle-memory keys for every dialog form: Esc closes the dialog
     * (same as Cancel), and Ctrl/Cmd+Enter fires the default button (the
     * save/post action). Called once from each dialog's constructor with its
     * own pane — the pane sees every key its scene delivers, so this works
     * no matter which control has focus, and never leaks to the main scene.
     */
    public static void wireDialogAccelerators(DialogPane pane) {
        pane.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.ESCAPE
                    && !(event.getTarget() instanceof javafx.scene.control.ComboBox)) {
                // combo popups deliver their own Esc handling to the combo
                // box itself; hiding here would swallow an open dropdown
                javafx.stage.Window window =
                        pane.getScene() == null ? null : pane.getScene().getWindow();
                if (window != null) {
                    window.hide();
                    event.consume();
                }
                return;
            }
            if (new KeyCodeCombination(KeyCode.ENTER,
                    KeyCombination.SHORTCUT_DOWN).match(event)) {
                for (ButtonType type : pane.getButtonTypes()) {
                    Button button = (Button) pane.lookupButton(type);
                    if (button != null && button.isDefaultButton()) {
                        button.fire();
                        event.consume();
                        return;
                    }
                }
            }
        });
    }

    /**
     * Wraps a dialog's content in the borderless scrolling surface the
     * forms use ({@code .lp-dialog-scroll}): a tall form breathes at the
     * edges instead of being boxed in, and never grows past the screen.
     */
    public static void makeScrollable(DialogPane pane, javafx.scene.Node content) {
        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.getStyleClass().add("lp-dialog-scroll");
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        pane.contentProperty().addListener((obs, old, now) -> {
            if (now == content) {
                pane.setContent(scroll);
            }
        });
        pane.setContent(scroll);
    }

    /**
     * Makes a dialog RESIZABLE (2.9.0): the entry form and every other
     * big form can now be grabbed by any edge/corner and stretched — a
     * tall form gets more breathing room, a wide one more columns of
     * space. The dialog's buttons stay pinned at the bottom of the pane
     * (DialogPane's own layout), and the content keeps its minimums, so
     * shrinking stays sane.
     *
     * <p>Passing min sizes matters: without them a resizable dialog can be
     * dragged down to a useless sliver. The minimums below fit the entry
     * form's guaranteed-visible area (header + two lines + totals); forms
     * with less content can pass smaller values.</p>
     */
    public static void makeResizable(Dialog<?> dialog, double minWidth, double minHeight) {
        dialog.setResizable(true);
        DialogPane pane = dialog.getDialogPane();
        // the pane carries the minimums; the stage follows its pane's size
        pane.setMinWidth(minWidth);
        pane.setMinHeight(minHeight);
        // a stretch should grow the CONTENT, not letterbox it: the pane's
        // content node re-lays out inside the bigger window
        javafx.scene.Node content = pane.getContent();
        if (content instanceof Region region) {
            region.setPrefWidth(Region.USE_COMPUTED_SIZE);
            region.setMaxWidth(Double.MAX_VALUE);
            region.setMaxHeight(Double.MAX_VALUE);
        }
        // keep the look: the header area stays, and the resize affordance
        // is the platform's own cursor (standard on Windows/Linux; macOS
        // dialogs resize from edges like any window)
    }

    // ------------------------------------------------------------------
    // Responsive text — the root font rides UiScale
    // ------------------------------------------------------------------

    /**
     * Binds the scene root's font size to the {@link UiScale} controller and
     * starts the controller following the scene's size: every stylesheet
     * size is in em, so this one binding scales all text, and every scene
     * resize re-fits it. Called from {@code App.buildScene}, so headless
     * captures (no stage) scale exactly like the launched app.
     */
    public static void installResponsiveText(Scene scene) {
        UiScale uiScale = UiScale.getInstance();
        scene.getRoot().styleProperty().bind(
                javafx.beans.binding.Bindings.format("-fx-font-size: %.2fpx;",
                        uiScale.scaleProperty().multiply(14.0)));
        uiScale.bind(scene);
    }

    /**
     * After the stage shows: re-applies once so the remembered maximized
     * state and the settled window size are reflected (the bind itself
     * lives on the scene and works with or without a stage).
     */
    public static void bindResponsiveTextToStage(Stage stage) {
        UiScale.getInstance().reapplyNow();
    }

    public static void installShortcuts(Scene scene, AppShell shell) {
        KeyCode[] digits = {
                KeyCode.DIGIT1, KeyCode.DIGIT2, KeyCode.DIGIT3,
                KeyCode.DIGIT4, KeyCode.DIGIT5, KeyCode.DIGIT6,
                KeyCode.DIGIT7, KeyCode.DIGIT8, KeyCode.DIGIT9};
        ViewId[] order = ViewId.values();

        scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getTarget() instanceof javafx.scene.control.TextInputControl) {
                return;   // never steal typing from inputs
            }
            for (int i = 0; i < digits.length && i < order.length; i++) {
                if (new KeyCodeCombination(digits[i],
                        KeyCombination.SHORTCUT_DOWN).match(event)) {
                    shell.show(order[i]);
                    event.consume();
                    return;
                }
            }
            // Ctrl/Cmd+K: the command palette (2.12.0) — views, clients
            // and common actions, searchable
            if (new KeyCodeCombination(KeyCode.K,
                    KeyCombination.SHORTCUT_DOWN).match(event)) {
                shell.openCommandPalette();
                event.consume();
                return;
            }
            if (new KeyCodeCombination(KeyCode.N,
                    KeyCombination.SHORTCUT_DOWN).match(event)) {
                // 2.12.0: one refresh, not two — openNewEntryDialog itself
                // shows the journal view first; the old extra show() here
                // re-ran the whole refresh pass for nothing
                shell.openNewEntryDialog();
                event.consume();
                return;
            }
            // F5 = re-read the visible view (2.6.0): the dashboard's live
            // refresh on demand, and the same gesture every table view
            // already knows from the browser world
            if (event.getCode() == KeyCode.F5) {
                shell.refreshCurrentView();
                event.consume();
            }
        });
    }
}
