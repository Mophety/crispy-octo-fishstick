package com.ledgerpro.ui;

import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.service.WorksheetService;
import com.ledgerpro.service.WorksheetService.BalanceSheet;
import com.ledgerpro.service.WorksheetService.EquityChange;
import com.ledgerpro.service.WorksheetService.IncomeStatement;
import com.ledgerpro.service.WorksheetService.ReportKind;
import com.ledgerpro.service.WorksheetService.StatementRow;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * The financial statements of Phase 5 — what the whole cycle has been
 * building toward, read as a narrative instead of a grid.
 *
 * <p>Three tabs: the single-step income statement, the statement of changes
 * in owner's equity (beginning capital, investments, net income, withdrawals,
 * ending capital) and the balance sheet (assets, liabilities, ending
 * equity). Every tab ends in a plain-language proof line — net income
 * reconciles the income statement, the ending capital reconciles the equity
 * story, assets equal liabilities plus equity — so a misstatement announces
 * itself instead of hiding in a column.</p>
 *
 * <p>Deduction lines (accumulated depreciation, allowances, withdrawals)
 * render in parentheses and muted ink, exactly the "less:" lines of the
 * firm's paper statements. "Snapshot…" freezes the current tab into the
 * {@code report_snapshots} audit trail; "Export CSV…" carries the current
 * statement to a spreadsheet; "Export HTML…" writes one self-contained,
 * print-ready page of all three statements — print to PDF from any browser
 * and it is the client-ready document.</p>
 */
public final class ReportsView extends VBox implements Refreshable {

    private final WorksheetService worksheetService;
    private final PeriodService periodService;
    private final ObservableValue<Client> activeClient;

    private final ComboBox<Period> periodBox = new ComboBox<>();
    private final Button csvButton = new Button("Export CSV…");
    private final Button htmlButton = new Button("Export HTML…");
    private final Button snapshotButton = new Button("Snapshot…");
    private final Label banner = new Label();
    private final Label footer = new Label();

    private final TableView<Line> isTable = new TableView<>();
    private final TableView<Line> soceTable = new TableView<>();
    private final TableView<Line> bsTable = new TableView<>();
    private final TableView<Line> cfTable = new TableView<>();
    private final Label isNote = new Label();
    private final Label soceNote = new Label();
    private final Label bsNote = new Label();
    private final Label cfNote = new Label();

    private Client client;
    private List<Period> periods = List.of();
    private IncomeStatement currentIs;
    private EquityChange currentSoce;
    private BalanceSheet currentBs;
    private com.ledgerpro.service.CashFlowService.CashFlowStatement currentCf;
    private final com.ledgerpro.service.CashFlowService cashFlowService;

    private final VBox emptyState = buildEmptyState();
    private final VBox workArea = buildWorkArea();

    public ReportsView(WorksheetService worksheetService, PeriodService periodService,
                       com.ledgerpro.service.CashFlowService cashFlowService,
                       ObservableValue<Client> activeClient) {
        this.worksheetService = worksheetService;
        this.periodService = periodService;
        this.cashFlowService = cashFlowService;
        this.activeClient = activeClient;
        setSpacing(12);

        getChildren().addAll(emptyState, workArea);
        // fill the window: whichever of the two states is visible grows to
        // the full content height instead of leaving dead space below
        VBox.setVgrow(emptyState, Priority.ALWAYS);
        VBox.setVgrow(workArea, Priority.ALWAYS);
        showEmptyState(true);

        client = activeClient.getValue();
        activeClient.addListener((obs, old, now) -> {
            client = now;
            refresh();
        });
    }

    // ------------------------------------------------------------------
    // Layout
    // ------------------------------------------------------------------

    private static VBox buildEmptyState() {
        // 2.12.0: the shared empty-state builder — one look for
        // every view (glyph, title, hint), themed and density-aware
        return (VBox) EmptyState.of(
                "▤",
                "Pick a client in the top bar — their financial statements open here.",
                "The statements need a period with posted entries; adjustments give them their final shape.").node();
    }

    private VBox buildWorkArea() {
        Label periodCaption = new Label("Period:");
        periodCaption.getStyleClass().add("lp-muted");
        periodBox.setPrefWidth(310);
        periodBox.valueProperty().addListener((obs, old, now) -> reload());

        csvButton.getStyleClass().add("lp-compact-btn");
        csvButton.setOnAction(e -> exportCsv());
        htmlButton.getStyleClass().add("lp-compact-btn");
        htmlButton.setOnAction(e -> exportHtml());
        snapshotButton.getStyleClass().add("lp-compact-btn");
        snapshotButton.setOnAction(e -> snapshot());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox toolbar = new HBox(10, periodCaption, periodBox, spacer,
                csvButton, htmlButton, snapshotButton);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        buildTable(isTable);
        buildTable(soceTable);
        buildTable(bsTable);
        buildTable(cfTable);

        banner.getStyleClass().add("lp-card-note");
        banner.setWrapText(true);
        for (Label note : new Label[]{isNote, soceNote, bsNote, cfNote}) {
            note.getStyleClass().add("lp-card-note");
            note.setWrapText(true);
        }
        footer.getStyleClass().add("lp-muted");
        footer.setWrapText(true);

        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabs.getTabs().addAll(
                tab("Income Statement", isTable, isNote),
                tab("Changes in Equity", soceTable, soceNote),
                tab("Balance Sheet", bsTable, bsNote),
                tab("Cash Flow", cfTable, cfNote));
        VBox.setVgrow(tabs, Priority.ALWAYS);

        VBox area = new VBox(12, banner, toolbar, tabs, footer);
        area.setVisible(false);
        area.setManaged(false);
        return area;
    }

    private static Tab tab(String title, TableView<Line> table, Label note) {
        VBox box = new VBox(10, table, note);
        VBox.setVgrow(table, Priority.ALWAYS);
        Tab tab = new Tab(title, box);
        tab.setClosable(false);
        return tab;
    }

    private void buildTable(TableView<Line> table) {
        table.setPlaceholder(new Label("Nothing posted in this period yet."));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.setRowFactory(view -> {
            TableRow<Line> row = new TableRow<>();
            row.itemProperty().addListener((obs, old, now) -> {
                row.getStyleClass().removeAll("lp-row-total", "lp-row-section");
                if (now != null) {
                    if (now.section()) {
                        row.getStyleClass().add("lp-row-section");
                    } else if (now.strong()) {
                        row.getStyleClass().add("lp-row-total");
                    }
                }
            });
            return row;
        });

        TableColumn<Line, String> line = new TableColumn<>("Line");
        line.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().label()));
        line.setPrefWidth(520);

        TableColumn<Line, Long> amount = new TableColumn<>("Amount");
        amount.setPrefWidth(170);
        amount.setCellFactory(col -> new SignedMoneyCell<>());
        amount.setCellValueFactory(c ->
                new SimpleObjectProperty<>(c.getValue().amount()));

        table.getColumns().addAll(line, amount);
    }

    private void showEmptyState(boolean empty) {
        emptyState.setVisible(empty);
        emptyState.setManaged(empty);
        workArea.setVisible(!empty);
        workArea.setManaged(!empty);
    }

    // ------------------------------------------------------------------
    // Statement lines
    // ------------------------------------------------------------------

    /** One printable line: a caption, maybe an amount, maybe emphasis. */
    private record Line(String label, Long amount, boolean strong, boolean section) {

        static Line row(String label, long amount) {
            return new Line(label, amount, false, false);
        }

        static Line deduction(String label, long amount) {
            return new Line(label, -amount, false, false);
        }

        static Line strong(String label, long amount) {
            return new Line(label, amount, true, false);
        }

        static Line section(String label) {
            return new Line(label, null, false, true);
        }
    }

    private List<Line> incomeLines(IncomeStatement s) {
        List<Line> lines = new ArrayList<>();
        lines.add(Line.section("REVENUES"));
        for (StatementRow r : s.revenues()) {
            lines.add(Line.row(r.name(), r.amountCents()));
        }
        lines.add(Line.strong("Total revenues", s.totalRevenues()));
        lines.add(Line.section("EXPENSES"));
        for (StatementRow r : s.expenses()) {
            lines.add(Line.row(r.name(), r.amountCents()));
        }
        lines.add(Line.strong("Total expenses", s.totalExpenses()));
        lines.add(Line.strong(s.netIncome() >= 0 ? "NET INCOME" : "NET LOSS",
                Math.abs(s.netIncome())));
        return lines;
    }

    private List<Line> equityLines(EquityChange s) {
        List<Line> lines = new ArrayList<>();
        lines.add(Line.row("Capital, beginning of period", s.beginningCapital()));
        for (StatementRow r : s.investments()) {
            lines.add(Line.row("Add: " + r.name(), r.amountCents()));
        }
        lines.add(Line.row(s.netIncome() >= 0 ? "Add: Net income" : "Less: Net loss",
                Math.abs(s.netIncome())));
        for (StatementRow r : s.withdrawals()) {
            lines.add(Line.deduction("Less: " + r.name(), r.amountCents()));
        }
        lines.add(Line.strong("Capital, end of period", s.endingCapital()));
        return lines;
    }

    /** 2.7.0: the statement of cash flows, indirect method. */
    private List<Line> cashFlowLines(
            com.ledgerpro.service.CashFlowService.CashFlowStatement s) {
        List<Line> lines = new ArrayList<>();
        lines.add(Line.section("OPERATING ACTIVITIES (indirect)"));
        for (com.ledgerpro.service.CashFlowService.FlowRow r : s.operating()) {
            lines.add(r.amountCents() >= 0
                    ? Line.row(r.caption(), r.amountCents())
                    : Line.deduction(r.caption(), -r.amountCents()));
        }
        lines.add(Line.strong("Net cash from operating", s.operatingTotal()));
        lines.add(Line.section("INVESTING ACTIVITIES"));
        for (com.ledgerpro.service.CashFlowService.FlowRow r : s.investing()) {
            lines.add(r.amountCents() >= 0
                    ? Line.row(r.caption(), r.amountCents())
                    : Line.deduction(r.caption(), -r.amountCents()));
        }
        lines.add(Line.strong("Net cash from investing", s.investingTotal()));
        lines.add(Line.section("FINANCING ACTIVITIES"));
        for (com.ledgerpro.service.CashFlowService.FlowRow r : s.financing()) {
            lines.add(r.amountCents() >= 0
                    ? Line.row(r.caption(), r.amountCents())
                    : Line.deduction(r.caption(), -r.amountCents()));
        }
        lines.add(Line.strong("Net cash from financing", s.financingTotal()));
        lines.add(Line.strong("NET MOVEMENT IN CASH", s.netMovement()));
        lines.add(Line.row("Cash, beginning of period", s.cashStart()));
        lines.add(Line.strong("Cash, end of period", s.cashEnd()));
        return lines;
    }

    private List<Line> balanceLines(BalanceSheet s) {
        List<Line> lines = new ArrayList<>();
        lines.add(Line.section("ASSETS"));
        for (StatementRow r : s.assets()) {
            lines.add(Line.row(r.name(), r.amountCents()));
        }
        lines.add(Line.strong("Total assets", s.totalAssets()));
        lines.add(Line.section("LIABILITIES"));
        for (StatementRow r : s.liabilities()) {
            lines.add(Line.row(r.name(), r.amountCents()));
        }
        lines.add(Line.strong("Total liabilities", s.totalLiabilities()));
        lines.add(Line.section("EQUITY"));
        lines.add(Line.strong("Total equity, ending", s.totalEquity()));
        lines.add(Line.strong("TOTAL LIABILITIES AND EQUITY",
                s.totalLiabilities() + s.totalEquity()));
        return lines;
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        if (client == null) {
            showEmptyState(true);
            return;
        }
        showEmptyState(false);
        banner.setText("Financial statements — " + client.code() + " · " + client.name()
                + " · amounts in " + client.baseCurrency());
        isTable.getColumns().getFirst().setText("Income statement line");
        soceTable.getColumns().getFirst().setText("Equity line");
        bsTable.getColumns().getFirst().setText("Balance sheet line");
        for (TableView<Line> t : new TableView[]{isTable, soceTable, bsTable}) {
            t.getColumns().get(1).setText("Amount (" + client.baseCurrency() + ")");
        }

        periods = periodService.list(client.id());
        Period previous = periodBox.getValue();
        periodBox.getItems().setAll(periods);
        Period stillThere = previous == null ? null
                : periods.stream().filter(p -> p.id() == previous.id()).findFirst().orElse(null);
        periodBox.setValue(stillThere != null ? stillThere
                : (!periods.isEmpty() ? periods.getLast() : null));
        reload();
    }

    private void reload() {
        if (client == null) {
            return;
        }
        Period period = periodBox.getValue();
        if (period == null) {
            isTable.getItems().clear();
            soceTable.getItems().clear();
            bsTable.getItems().clear();
            cfTable.getItems().clear();
            isNote.setText("");
            soceNote.setText("");
            bsNote.setText("");
            cfNote.setText("");
            footer.setText("Create a period and post entries in the journal first.");
            return;
        }

        currentIs = worksheetService.incomeStatement(period.id());
        currentSoce = worksheetService.equityChange(period.id());
        currentBs = worksheetService.balanceSheet(period.id());
        currentCf = cashFlowService.statement(period.id());

        isTable.setItems(FXCollections.observableArrayList(incomeLines(currentIs)));
        soceTable.setItems(FXCollections.observableArrayList(equityLines(currentSoce)));
        bsTable.setItems(FXCollections.observableArrayList(balanceLines(currentBs)));
        cfTable.setItems(FXCollections.observableArrayList(cashFlowLines(currentCf)));

        isNote.setText((currentIs.netIncome() >= 0 ? "Net income " : "Net loss ")
                + Money.format(Math.abs(currentIs.netIncome()))
                + " = revenues " + Money.format(currentIs.totalRevenues())
                + " − expenses " + Money.format(currentIs.totalExpenses()) + " ✓");
        isNote.getStyleClass().setAll("lp-status-ok");

        soceNote.setText("Beginning " + Money.format(currentSoce.beginningCapital())
                + " + investments " + Money.format(invested(currentSoce))
                + (currentSoce.netIncome() >= 0 ? " + net income " : " − net loss ")
                + Money.format(Math.abs(currentSoce.netIncome()))
                + " − withdrawals " + Money.format(withdrawn(currentSoce))
                + " = ending " + Money.format(currentSoce.endingCapital())
                + (currentSoce.addsUp() ? " ✓" : " — DOES NOT ADD UP"));
        soceNote.getStyleClass().setAll(currentSoce.addsUp()
                ? "lp-status-ok" : "lp-dialog-error");

        bsNote.setText("Total assets " + Money.format(currentBs.totalAssets())
                + " = liabilities " + Money.format(currentBs.totalLiabilities())
                + " + equity " + Money.format(currentBs.totalEquity())
                + (currentBs.balanced() ? " ✓" : " — OUT OF BALANCE"));
        bsNote.getStyleClass().setAll(currentBs.balanced()
                ? "lp-status-ok" : "lp-dialog-error");

        cfNote.setText("Net movement " + Money.format(currentCf.netMovement())
                + " = cash end " + Money.format(currentCf.cashEnd())
                + " − cash beginning " + Money.format(currentCf.cashStart())
                + (currentCf.reconciles() ? " ✓ reconciles to the cash accounts"
                : " — DOES NOT RECONCILE"));
        cfNote.getStyleClass().setAll(currentCf.reconciles()
                ? "lp-status-ok" : "lp-dialog-error");

        footer.setText(period.name() + " (" + period.start() + " … " + period.end() + ")"
                + (period.closed() ? " · CLOSED" : " · open")
                + " · the statements read the posted journal exactly as the worksheet"
                + " routed it · contra accounts are the deduction lines in parentheses"
                + " · snapshots are immutable in the audit trail"
                + " · HTML export prints to PDF from any browser");
    }

    private static long invested(EquityChange s) {
        return s.investments().stream().mapToLong(StatementRow::amountCents).sum();
    }

    private static long withdrawn(EquityChange s) {
        return s.withdrawals().stream().mapToLong(StatementRow::amountCents).sum();
    }

    // ------------------------------------------------------------------
    // Exports + snapshot
    // ------------------------------------------------------------------

    private void exportCsv() {
        if (currentIs == null || periodBox.getValue() == null) {
            return;
        }
        String csv = switch (currentTabKind()) {
            case INCOME_STATEMENT -> worksheetService.toCsv(currentIs);
            case SOCE -> worksheetService.toCsv(currentSoce);
            case BALANCE_SHEET -> worksheetService.toCsv(currentBs);
            default -> worksheetService.toCsv(currentIs);
        };
        writeToFile("Export " + currentTabTitle() + " as CSV",
                statementFile(".csv"), csv, "Statement exported");
    }

    private void exportHtml() {
        if (currentIs == null || periodBox.getValue() == null) {
            return;
        }
        String html = worksheetService.toHtml(currentIs, currentSoce, currentBs);
        writeToFile("Export all three statements as HTML",
                statementsFile(".html"), html, "Statements exported");
    }

    private void writeToFile(String title, String initialName, String content,
                             String doneTitle) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle(title);
        chooser.setInitialFileName(initialName);
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(
                initialName.endsWith(".csv") ? "CSV file" : "HTML document",
                initialName.endsWith(".csv") ? "*.csv" : "*.html"));
        java.io.File target = chooser.showSaveDialog(
                getScene() == null ? null : getScene().getWindow());
        if (target == null) {
            return;
        }
        try {
            Files.writeString(Path.of(target.toURI()), content, StandardCharsets.UTF_8);
            recordExport(target, initialName.endsWith(".csv") ? "CSV" : "HTML");
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    (initialName.endsWith(".html")
                            ? "Statements exported — one self-contained page:\n"
                            : "Statement exported:\n")
                            + target.getAbsolutePath()
                            + (initialName.endsWith(".html")
                            ? "\n\nOpen it in any browser and print to PDF for the"
                            + " client-ready document."
                            : "\n\nAmounts are exact ungrouped decimals."),
                    ButtonType.OK);
            done.setTitle(doneTitle);
            done.setHeaderText(null);
            if (getScene() != null) {
                done.initOwner(getScene().getWindow());
            }
            done.showAndWait();
        } catch (IOException | RuntimeException e) {
            ClientsView.errorAlert(e instanceof RuntimeException rx
                    ? rx : new IllegalStateException("could not write the file: " + e));
        }
    }

    private void snapshot() {
        Period period = periodBox.getValue();
        if (period == null || currentIs == null) {
            return;
        }
        ReportKind kind = currentTabKind();
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Freeze the " + currentTabTitle().toLowerCase() + " of '" + period.name()
                        + "' into the audit trail?\n\n"
                        + "The snapshot is immutable — it records exactly the statement"
                        + " the firm produced, line by line, and when.",
                ButtonType.OK, ButtonType.CANCEL);
        confirm.setTitle("Snapshot " + currentTabTitle());
        confirm.setHeaderText(null);
        if (getScene() != null) {
            confirm.initOwner(getScene().getWindow());
        }
        if (confirm.showAndWait().filter(ButtonType.OK::equals).isEmpty()) {
            return;
        }
        try {
            long id = worksheetService.snapshotStatement(period.id(), kind);
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    "Snapshot #" + id + " stored — " + currentTabTitle() + ", period "
                            + period.name() + ".",
                    ButtonType.OK);
            done.setTitle("Statement snapshotted");
            done.setHeaderText(null);
            if (getScene() != null) {
                done.initOwner(getScene().getWindow());
            }
            done.showAndWait();
        } catch (RuntimeException e) {
            ClientsView.errorAlert(e);
        }
    }

    private String currentTabTitle() {
        return switch (currentTabKind()) {
            case INCOME_STATEMENT -> "Income Statement";
            case SOCE -> "Statement of Changes in Equity";
            case BALANCE_SHEET -> "Balance Sheet";
            default -> "Report";
        };
    }

    private ReportKind currentTabKind() {
        // the visible tab of the (single) TabPane in the work area
        TabPane tabs = (TabPane) workArea.getChildren().stream()
                .filter(node -> node instanceof TabPane).findFirst().orElseThrow();
        String selected = tabs.getSelectionModel().getSelectedItem().getText();
        return switch (selected) {
            case "Income Statement" -> ReportKind.INCOME_STATEMENT;
            case "Changes in Equity" -> ReportKind.SOCE;
            case "Balance Sheet" -> ReportKind.BALANCE_SHEET;
            default -> ReportKind.INCOME_STATEMENT;
        };
    }

    private String statementFile(String suffix) {
        return currentTabKind().name().toLowerCase() + "-"
                + client.code() + "-" + periodBox.getValue().name() + suffix;
    }

    private String statementsFile(String suffix) {
        return "statements-" + client.code() + "-" + periodBox.getValue().name() + suffix;
    }

    /**
     * Migration-V4 export trail: the file that just left the app is recorded
     * against the latest snapshot of the same kind (snapshotted now when
     * none exists — an export is a point-in-time report by definition).
     */
    private void recordExport(java.io.File target, String format) {
        Client client = activeClient.getValue();
        Period period = periodBox.getValue();
        if (client == null || period == null) {
            return;
        }
        try {
            final ReportKind kind = "HTML".equals(format)
                    ? ReportKind.BALANCE_SHEET        // the HTML page is all three
                    : currentTabKind();
            long snapshotId = worksheetService.latestSnapshotId(client.id(), period.id(), kind)
                    .orElseGet(() -> "HTML".equals(format)
                            ? worksheetService.snapshotStatement(period.id(), kind)
                            : snapshotForCurrentTab(period.id()));
            worksheetService.recordExport(snapshotId, format, target.getAbsolutePath());
        } catch (RuntimeException ignored) {
            // the export itself succeeded; the bookkeeping about it is best-effort
        }
    }

    private long snapshotForCurrentTab(long periodId) {
        return worksheetService.snapshotStatement(periodId, currentTabKind());
    }
}
