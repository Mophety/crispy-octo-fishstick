package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The working dashboard (2.5.0; 2.6.0 LIVE): the state of the WORKING CLIENT
 * at a glance — the summaries and graphs an accountant actually opens
 * first, kept CURRENT by a background refresh.
 *
 * <ul>
 *   <li><b>Summary cards</b> — net income (revenue − expenses, the period's
 *       own figures), assets, liabilities and equity from the posted-line
 *       routing, plus the entry counts of the working period
 *       (posted/draft/voided).</li>
 *   <li><b>Charts</b> — a monthly revenue vs expense line chart; an
 *       expense-composition pie; an assets = liabilities + equity balance
 *       bar chart (the balance-sheet proof drawn as bars).</li>
 *   <li><b>Recent entries</b> — the last eight journal entries of the
 *       client; double-click shows the entry's lines.</li>
 * </ul>
 *
 * <p><b>2.6.0 — real-time:</b> the dashboard re-reads its figures on a
 * background timer (Settings → Workspace → Dashboard live refresh: off /
 * 5s / 15s / 30s, default 15s). The reads run OFF the JavaFX thread, so
 * the UI never stutters while SQLite works, and the results land on the FX
 * thread in one pass. The timer runs only while the dashboard is the
 * VISIBLE view (paused on hide), and a refresh-in-flight flag prevents
 * pile-ups if a read outlives its interval. A live stamp in the header row
 * shows when the figures were last read, and a Refresh button forces one
 * now.</p>
 *
 * <p><b>2.6.0 — interactable:</b> the period selector combo picks which of
 * the client's periods the cards and charts describe (default: the
 * newest); every summary card is a deep link — NET INCOME and ENTRIES open
 * the journal, ASSETS the balance-sheet report view — with a hand cursor
 * and hover styling so they read as clickable; recent entries still
 * double-click into their lines.</p>
 *
 * <p>When no client is selected the view shows the workspace overview it
 * always showed (the getting-started checklist), so the first-run
 * experience is unchanged.</p>
 *
 * <p><b>Performance:</b> all aggregate numbers come from ONE database
 * connection per refresh — the monthly series, the type routing and the
 * entry counts ride a single SQL pass over the period's posted lines. The
 * background thread also skips the workspace-overview stat reads while the
 * client dashboard is showing (they only matter to the no-client
 * state).</p>
 */
public final class DashboardView extends VBox implements Refreshable {

    /** Cards never shrink below this, so long notes wrap instead of
     *  collapsing the card to a one-character column. */
    private static final double CARD_MIN_WIDTH = 195;
    private static final double PANEL_MIN_WIDTH = 300;

    private final ClientService clientService;
    private final Database database;
    private final ObservableValue<Client> activeClient;
    private final JournalService journalService;
    private final PeriodService periodService;

    /** 2.12.1: the C1/C2-corrected aggregates read (see its class doc). */
    private DashboardReader reader;

    private final Label dbValue = new Label();
    private final Label dbNote = new Label();
    private final Label clientsValue = new Label();
    private final Label clientsNote = new Label();
    private final Label workingValue = new Label();
    private final Label workingNote = new Label();
    private final Label stepClients = new Label();
    private final Label stepCoa = new Label();
    private final Label stepJournal = new Label();
    private final Label stepReports = new Label();

    // client-scoped summary cards
    private final Label netIncomeValue = new Label();
    private final Label netIncomeNote = new Label();
    private final Label assetsValue = new Label();
    private final Label assetsNote = new Label();
    private final Label equityValue = new Label();
    private final Label equityNote = new Label();
    private final Label entriesValue = new Label();
    private final Label entriesNote = new Label();

    // the 2.6.0 live header row: period selector, live stamp, refresh
    private final ComboBox<Period> periodBox = new ComboBox<>();
    private final Label liveStamp = new Label();
    private final Button refreshButton = new Button("Refresh");

    /** 2.12.1 (C1): the BALANCED / OUT OF BALANCE chip on the ASSETS card. */
    private final Label balanceChip = new Label("—");

    // charts — built lazily by buildClientDashboard, which runs from a
    // FIELD INITIALIZER (before the constructor body)
    private LineChart<String, Number> trendChart;
    private PieChart expensePie;
    private javafx.scene.layout.VBox pieLegend;
    private StackedBarChart<String, Number> balanceBars;

    // 2.9.0: the numbers row under each chart caption — totals read
    // straight off the graph, no hovering needed
    private Label trendCaption;
    private Label pieCaption;
    private Label balanceCaption;
    private Label recentCaption;

    // recent entries
    private final TableView<RecentEntry> recentTable = new TableView<>();

    /** The empty workspace overview (kept from the earlier dashboard). */
    private final VBox workspaceOverview = buildWorkspaceOverview();

    /** The client dashboard: cards + charts + recent entries. */
    private final VBox clientDashboard = buildClientDashboard();

    // real-time state ----------------------------------------------------

    /** The client the live figures describe (null = overview shown). */
    private Client liveClient;
    /** The period the live figures describe (chosen in the selector). */
    private Period livePeriod;
    /** True while a background read is in flight (prevents pile-ups). */
    private final AtomicBoolean refreshInFlight = new AtomicBoolean(false);
    /** The background refresh daemon, one thread for the view's life. */
    private final java.util.concurrent.ScheduledExecutorService liveTimer =
            java.util.concurrent.Executors.newSingleThreadScheduledExecutor(runnable -> {
                Thread thread = new Thread(runnable, "dashboard-live-refresh");
                thread.setDaemon(true);
                return thread;
            });
    /** The scheduling handle of the current rate (re-armed on pref change). */
    private volatile java.util.concurrent.ScheduledFuture<?> liveHandle;

    public DashboardView(ClientService clientService, Database database,
                         ObservableValue<Client> activeClient,
                         JournalService journalService,
                         PeriodService periodService) {
        this.clientService = clientService;
        this.database = database;
        this.activeClient = activeClient;
        this.journalService = journalService;
        this.periodService = periodService;
        this.reader = new DashboardReader(database);
        setSpacing(16);

        getChildren().add(workspaceOverview);

        activeClient.addListener((obs, old, now) -> updateWorkingClient(now));

        // the refresh rate is a Settings choice: re-arm the timer when it
        // changes, and arm once now that the view is built
        Prefs.getInstance().dashboardRefreshProperty().addListener(
                (obs, old, now) -> rearmLiveTimer());
        rearmLiveTimer();

        // refresh-on-show: the view re-reads whenever the shell shows it
        // (view switches and deep links from other views); when it leaves the
        // scene the timer stands down so a late tick cannot land a runLater
        // on a dead view (2.7.0 hygiene fix)
        sceneProperty().addListener((obs, old, now) -> {
            if (now != null && liveClient != null) {
                refreshLive();
            } else if (now == null) {
                java.util.concurrent.ScheduledFuture<?> prior = liveHandle;
                if (prior != null) {
                    prior.cancel(false);
                }
            }
        });

        refresh();
    }

    @Override
    public void refresh() {
        // The foreground pass (startup, client switches): reads the
        // workspace-overview stats and the client list synchronously — these
        // are tiny queries — then hands the client dashboard to the
        // background refresh path.
        boolean overviewVisible = liveClient == null;
        if (overviewVisible) {
            try (Connection con = database.open()) {
                readDatabaseStats(con);
                updateCoaStep(con);
                updateJournalStep(con);
                updateReportsStep(con);
            } catch (SQLException e) {
                dbValue.setText("unavailable");
                dbNote.setText(e.getMessage());
                stepCoa.getStyleClass().setAll("lp-step-todo");
                stepJournal.getStyleClass().setAll("lp-step-todo");
                stepReports.getStyleClass().setAll("lp-step-todo");
            }
        }

        List<Client> all = clientService.list(true);
        long active = all.stream().filter(Client::active).count();
        long archived = all.size() - active;
        clientsValue.setText(active + " active");
        clientsNote.setText(archived == 0
                ? "no archived clients"
                : archived + " archived · never deleted");

        boolean hasClients = active > 0;
        stepClients.setText((hasClients ? "✔  " : "○  ") + "Create the firm's clients"
                + (hasClients ? " — done" : ""));
        stepClients.getStyleClass().setAll(hasClients ? "lp-step-done" : "lp-step-todo");

        updateWorkingClient(activeClient.getValue());
    }

    // ------------------------------------------------------------------
    // The two dashboard states
    // ------------------------------------------------------------------

    /** Swaps between the workspace overview (no client) and the client dashboard. */
    private void updateWorkingClient(Client now) {
        workingValue.setText(now == null ? "none" : now.code() + " — " + now.name());
        workingNote.setText(now == null
                ? "pick a client in the top bar to work on"
                : "base currency " + now.baseCurrency()
                + (now.taxId() == null || now.taxId().isBlank() ? "" : " · " + now.taxId()));
        if (now == null) {
            liveClient = null;
            livePeriod = null;
            getChildren().setAll(workspaceOverview);
            return;
        }
        // 2.7.0: the live-refresh path reads liveClient — assign it BEFORE the
        // first read or the dashboard shows cards with no figures behind them
        // (the 2.6.0 defect). A client switch also drops the stale period so
        // the read re-picks the new client's latest period.
        liveClient = now;
        livePeriod = null;
        // 2.9.0: wipe the previous client's figures the INSTANT the switch
        // happens — the charts, the cards and the recent-entries table are
        // blanked synchronously, so the new client's own read (which may be
        // one timer tick away) paints over empty panels, never over the old
        // client's ghost. The period selector resets too, so the read picks
        // the new client's latest period instead of matching the old one's id.
        periodBox.getSelectionModel().clearSelection();
        periodBox.getItems().clear();
        clearClientPanels();
        getChildren().setAll(clientDashboard);
        // the arriving dashboard fades in gently (no-op with motion off)
        UiMotion.playFadeIn(clientDashboard, 240);
        refreshLive();
    }

    /**
     * Blanks every client-scoped panel (2.9.0, the ghost-chart fix's second
     * half): dash the values, clear all three charts' series and the recent
     * table. Runs on the FX thread at switch time.
     */
    private void clearClientPanels() {
        netIncomeValue.setText("—");
        netIncomeValue.getStyleClass().setAll("lp-card-value");
        netIncomeNote.setText("reading " + liveClient.code() + "…");
        assetsValue.setText("—");
        assetsNote.setText("");
        equityValue.setText("—");
        equityNote.setText("");
        entriesValue.setText("—");
        entriesNote.setText("");
        for (XYChart.Series<String, Number> series : trendChart.getData()) {
            series.getData().clear();
        }
        expensePie.getData().clear();
        for (XYChart.Series<String, Number> series : balanceBars.getData()) {
            series.getData().clear();
        }
        recentTable.getItems().clear();
    }

    // ------------------------------------------------------------------
    // Real-time refresh (2.6.0)
    // ------------------------------------------------------------------

    /**
     * (Re-)arms the background timer for the current refresh-rate setting:
     * OFF leaves it disarmed (the dashboard refreshes on show, on client or
     // period switches, and on the Refresh button); a timed rate polls
     * while the dashboard is the visible view. Re-arming cancels any prior
     * handle first, so a Settings change never stacks two timers.
     */
    private void rearmLiveTimer() {
        java.util.concurrent.ScheduledFuture<?> prior = liveHandle;
        if (prior != null) {
            prior.cancel(false);
        }
        int seconds = Prefs.getInstance().dashboardRefresh().seconds();
        if (seconds <= 0) {
            liveHandle = null;
            liveStamp.setText("live: off — Refresh or F5 re-reads");
            return;
        }
        liveStamp.setText("live: every " + seconds + "s");
        liveHandle = liveTimer.scheduleWithFixedDelay(
                this::tickRefresh, seconds, seconds,
                java.util.concurrent.TimeUnit.SECONDS);
    }

    /**
     * One timer tick: reads ONLY when the dashboard is visible and no read
     * is already in flight (a slow read never piles the next one on top).
     */
    private void tickRefresh() {
        if (liveClient == null || !isShowing()) {
            return;
        }
        refreshLive();
    }

    /** True when this view is the visible child of the shell's content. */
    private boolean isShowing() {
        return getScene() != null && getScene().getWindow() != null
                && getScene().getWindow().isShowing();
    }

    /**
     * The live refresh pass: one background-thread read of everything the
     * client dashboard shows, then a single hop to the JavaFX thread to
     * apply it. The working client and the chosen period are captured
     * first, so a mid-read client switch just orphans the result instead
     * of painting a stale client's figures.
     *
     * <p><b>2.9.0 — the ghost-chart fix:</b> when a read is already in
     * flight (the 15s timer tick racing a client switch), the switch's own
     * refresh used to be silently DROPPED — and with live refresh Off it
     * never re-ran, so the previous client's line chart stayed on screen
     * indefinitely. A dropped refresh is now latched in {@link
     * #pendingRefresh} and re-run the moment the in-flight read lands, so
     * a client switch ALWAYS repaints the dashboard with the new client's
     * figures (or its empty state) — never the old client's ghost.</p>
     */
    private void refreshLive() {
        Client client = liveClient;
        if (client == null) {
            return;
        }
        if (!refreshInFlight.compareAndSet(false, true)) {
            pendingRefresh.set(true);   // a read is running; run ours right after
            return;
        }
        try {
            // the periods list rides the read too, so a period created in
            // the Journal view appears in the selector without a view switch
            List<Period> periods = periodService.list(client.id());
            Period selected = periodBox.getValue();
            Period period = selected == null
                    ? (periods.isEmpty() ? null : periods.getLast())
                    : matchPeriod(periods, selected.id());
            // 2.12.1 (C1/C2): the aggregates read moved to DashboardReader —
            // REVERSING entries included, amounts as total debits — so the
            // dashboard agrees with the worksheet and the Journal tab.
            ClientAggregates agg = period == null
                    ? new ClientAggregates()
                    : reader.read(client.id(), period.id(), period.closed());

            Platform.runLater(() -> {
                try {
                    if (liveClient == null || liveClient.id() != client.id()) {
                        return;   // the client switched mid-read: drop it
                    }
                    applyLive(periods, period, agg);
                } finally {
                    refreshInFlight.set(false);
                    if (pendingRefresh.compareAndSet(true, false)) {
                        refreshLive();   // the latch: never lose a client-switch read
                    }
                }
            });
        } catch (RuntimeException e) {
            refreshInFlight.set(false);
            pendingRefresh.set(false);
            Platform.runLater(() -> dbValue.setText("unavailable"));
        }
    }

    /** A refresh was requested while one ran; re-run it when that lands. */
    private final AtomicBoolean pendingRefresh = new AtomicBoolean(false);

    /** Applies one finished read on the JavaFX thread. */
    private void applyLive(List<Period> periods, Period period, ClientAggregates agg) {
        // the selector reflects the client's periods without losing a choice
        if (!samePeriods(periodBox.getItems(), periods)) {
            periodBox.getItems().setAll(periods);
        }
        if (period == null) {
            periodBox.getSelectionModel().clearSelection();
            showEmptyDashboard();
            stamp("no period yet");
            return;
        }
        if (periodBox.getValue() == null
                || periodBox.getValue().id() != period.id()) {
            periodBox.setValue(period);
        }
        fillCards(agg, period);
        fillTrendChart(agg);
        fillExpensePie(agg);
        fillBalanceBars(agg);
        recentTable.setItems(FXCollections.observableArrayList(agg.recents));
        // 2.9.0: the recent-entries card's numbers line — the count and the
        // posted volume of the client's newest entries
        // 2.12.1 (C2): one definition of "their volume" — total debits of
        // the posted recents, the same figure the Journal tab sums into its
        // own posted-volume footer figure.
        long recentPosted = agg.recents.stream()
                .filter(r -> "Posted".equals(r.status())).count();
        long recentVolume = agg.recents.stream()
                .filter(r -> "Posted".equals(r.status()))
                .mapToLong(RecentEntry::amountCents).sum();
        recentCaption.setText(agg.recents.isEmpty()
                ? "No entries yet for this client."
                : agg.recents.size() + " most recent · " + recentPosted + " posted"
                        + (recentVolume > 0 ? " · their volume "
                                + Money.formatGrouped(recentVolume) : ""));
        stamp(null);

        // animate the charts' new data when motion is on (no-op otherwise)
        UiMotion.playChartReveal(trendChart);
        UiMotion.playChartReveal(balanceBars);
    }

    /** The empty-state pass: a client with no periods yet. */
    private void showEmptyDashboard() {
        netIncomeValue.setText("—");
        netIncomeValue.getStyleClass().setAll("lp-card-value");
        netIncomeNote.setText("no period yet — create one in the Journal view");
        assetsValue.setText("—");
        assetsNote.setText("the balance-sheet routing needs a period");
        equityValue.setText("—");
        equityNote.setText("the equity routing needs a period");
        entriesValue.setText("0");
        entriesNote.setText("nothing posted, nothing drafted");
        trendChart.getData().get(0).getData().clear();
        trendChart.getData().get(1).getData().clear();
        expensePie.getData().clear();
        balanceBars.getData().get(0).getData().clear();
        balanceBars.getData().get(1).getData().clear();
        recentTable.setItems(FXCollections.observableArrayList());
        trendCaption.setText("");
        pieCaption.setText("");
        balanceCaption.setText("");
    }

    /** The live stamp in the header row ("updated 14:02:31"). */
    private void stamp(String note) {
        liveStamp.setText((note == null ? "updated " : note + " · ")
                + LocalDateTime.now().format(
                        DateTimeFormatter.ofPattern("HH:mm:ss")));
    }

    // ------------------------------------------------------------------
    // The client dashboard
    // ------------------------------------------------------------------

    private VBox buildClientDashboard() {
        // the charts exist before any card references them (this method
        // runs from a field initializer — the constructor has not run yet)
        trendChart = buildTrendChart();
        expensePie = buildExpensePie();
        balanceBars = buildBalanceBars();
        // the caption labels too: chartCard reads their style class right
        // here, so they must exist before the cards below are built
        trendCaption = new Label();
        pieCaption = new Label();
        balanceCaption = new Label();
        recentCaption = new Label();
        Label heading = new Label("Working client overview");
        heading.getStyleClass().add("lp-heading");

        // the 2.6.0 live header row: period selector + live stamp + refresh
        // 2.12.1 (P3-S1): the period combo no longer stretches — its
        // MAX_VALUE width + hgrow fed a layout feedback loop (a combo
        // as wide as its container reports a preferred width as wide as
        // the container, the row grows, the combo grows again). Now it
        // sizes to its WIDEST period item, capped at 22 em, and the
        // spacer after it absorbs the free width instead.
        periodBox.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(Period period) {
                return period == null ? "" : period.name()
                        + " (" + period.start().getYear() + ")";
            }
            @Override public Period fromString(String s) { return null; }
        });
        UiSizing.fitWidestItem(periodBox, 22);
        periodBox.valueProperty().addListener((obs, old, now) -> {
            if (now != null && liveClient != null
                    && (livePeriod == null || livePeriod.id() != now.id())) {
                livePeriod = now;
                refreshLive();
            }
        });
        Label periodCaption = new Label("Period:");
        periodCaption.getStyleClass().add("lp-muted");

        liveStamp.getStyleClass().add("lp-scale-value");
        liveStamp.setTooltip(new javafx.scene.control.Tooltip(
                "The figures re-read on the timer you set in Settings →"
                        + " Workspace → Dashboard live refresh."));

        refreshButton.getStyleClass().add("lp-compact-btn");
        refreshButton.setTooltip(new javafx.scene.control.Tooltip(
                "Re-read every card and chart now (also F5)."));
        refreshButton.setOnAction(e -> refreshLive());

        // 2.12.1 (P3-S1): the flexible spacer pushes stamp + button to
        // the right AND absorbs the row's spare width (the combo no
        // longer does). The caption, the live stamp and the Refresh
        // button keep their full label — minWidth = pref, they can
        // never be squeezed into ellipsis.
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        UiSizing.keepSize(periodCaption);
        UiSizing.keepSize(liveStamp);
        UiSizing.keepSize(refreshButton);
        HBox headerRow = new HBox(10, periodCaption, periodBox, spacer,
                liveStamp, refreshButton);
        headerRow.setAlignment(Pos.CENTER_LEFT);
        VBox.setMargin(headerRow, new javafx.geometry.Insets(0, 0, -8, 0));

        // 2.12.1 (P3-S2): the KPI cards re-flow instead of squeezing —
        // a ResponsiveGrid of equal-width cells that drops to 3/2/1
        // columns as the window narrows (the old HBox shrank all four
        // cards in equal steps until their text wrapped into tall
        // columns). 30 em is the readable minimum for a KPI card.
        ResponsiveGrid cards = new ResponsiveGrid(4, 30);
        cards.setHgap(14);
        cards.setVgap(14);
        cards.setCells(java.util.List.of(
                clickableCard("NET INCOME (period)", netIncomeValue, netIncomeNote,
                        () -> jump(ViewId.JOURNAL)),
                balanceAssetsCard(),
                equityCard(),
                clickableCard("ENTRIES", entriesValue, entriesNote,
                        () -> jump(ViewId.JOURNAL))));

        // 2.12.1 (P2-S2): the pie card — disc left, custom legend right,
        // the disc given every pixel the card has (BorderPane centers it)
        javafx.scene.layout.BorderPane piePane = new javafx.scene.layout.BorderPane(
                expensePie);
        piePane.setRight(pieLegend);
        BorderPane.setMargin(pieLegend, new javafx.geometry.Insets(0, 0, 0, 8));
        BorderPane.setAlignment(expensePie, Pos.CENTER);
        // 2.12.1 (P3-S2): the chart pair re-flows too — two equal
        // columns when the window is wide, one stacked column below
        // ~34 em (a card that can hold a readable chart + legend).
        ResponsiveGrid charts = new ResponsiveGrid(2, 34);
        charts.setHgap(14);
        charts.setVgap(14);
        charts.setCells(java.util.List.of(
                chartCard("Revenue vs expenses by month", trendCaption, trendChart),
                chartCard("Expense composition", pieCaption, piePane)));
        // 2.11.0 (carried over): the chart rows share the window's extra
        // height inside the scrolling page (see below)
        VBox.setVgrow(charts, Priority.ALWAYS);

        ResponsiveGrid lower = new ResponsiveGrid(2, 34);
        lower.setHgap(14);
        lower.setVgap(14);
        lower.setCells(java.util.List.of(
                chartCard("The balance-sheet proof: assets = liabilities + equity",
                        balanceCaption, balanceBars),
                buildRecentEntriesCard()));
        VBox.setVgrow(lower, Priority.ALWAYS);

        VBox box = new VBox(16, heading, headerRow, cards, charts, lower);
        // the cards settle in with a gentle fade on first show (a no-op when
        // motion is off — the default)
        UiMotion.playFadeIn(cards, 240);

        // 2.12.1 (P3-S2): the page SCROLLS. The dashboard's natural
        // height (header + cards + 300px trend row + 280px lower row)
        // exceeded a 1280x820 window and cut the lower row mid-card;
        // at 1100x700 it cut far worse. A fitToWidth ScrollPane keeps
        // the page's width pinned to the viewport (no horizontal
        // scrollbar, the grids still re-flow) and scrolls vertically
        // whenever the content is taller than the window.
        ScrollPane page = new ScrollPane(box);
        page.setFitToWidth(true);
        page.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        page.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        page.getStyleClass().add("lp-page-scroll");
        // the charts keep their 2.11.0 height caps; vgrow inside the
        // scrolling column lets the rows share the page's natural height
        return new VBox(page);
    }

    /** Deep-links to a view (the card shortcuts). */
    private void jump(ViewId view) {
        if (getScene() != null && getScene().getRoot() instanceof AppShell shell) {
            shell.show(view);
        }
    }

    /** The monthly revenue-vs-expense line chart. */
    private LineChart<String, Number> buildTrendChart() {
        CategoryAxis months = new CategoryAxis();
        // 2.12.1 (P2-S1): no "Month" axis title — every month tick already
        // says what it is, the title only spent axis width.
        MoneyAxis money = new MoneyAxis(10, 6);
        LineChart<String, Number> chart = new LineChart<>(months, money);
        // 2.12.1 (P2-S1): our own fixed-size circle symbols — see
        // dataPoint(). setCreateSymbols stays on (the chart draws its own
        // invisible placeholder region per point; our node rides inside).
        chart.setCreateSymbols(true);
        chart.setLegendVisible(true);
        // 2.8.0: animated when the Animations preference is on — new data
        // slides in; the chart itself stays still otherwise. Interactivity:
        // hover tooltips on every data symbol (value + month), and a
        // click on a symbol deep-links to the Journal.
        chart.setAnimated(UiMotion.isEnabled());
        chart.setMinHeight(300);
        // 2.11.0: a HEIGHT CAP — vgrow ALWAYS on the card row let one chart
        // absorb the whole window height on tall screens (the user's
        // balance bars rendered 612 logical px tall). 420 is comfortable
        // for a 12-month trend without becoming a column.
        chart.setMaxHeight(420);
        chart.setMaxWidth(Double.MAX_VALUE);
        // 2.12.1 (P2-S1): the card-level class the semantic series colors
        // and the transparent stock-symbol rule key off
        chart.getStyleClass().add("lp-chart-trend");
        XYChart.Series<String, Number> revenue = new XYChart.Series<>();
        revenue.setName("Revenue");
        XYChart.Series<String, Number> expenses = new XYChart.Series<>();
        expenses.setName("Expenses");
        chart.getData().addAll(revenue, expenses);
        return chart;
    }

    /** The expense-composition pie. */
    private PieChart buildExpensePie() {
        PieChart pie = new PieChart();
        // 2.12.1 (P2-S2): no in-chart title (the card title says it),
        // no slice labels (they collided on small slices) — the pie is
        // the picture; name, amount and share live in the right-hand
        // legend and in each slice's hover tooltip.
        pie.setTitle("");
        pie.setLabelsVisible(false);
        pie.setLegendVisible(false);
        // the legend we own: name + amount + % rows on the pie's right
        pieLegend = new javafx.scene.layout.VBox(4);
        pieLegend.getStyleClass().add("lp-pie-legend");
        // 2.8.0: animated slices + hover tooltips (share %) + click jumps to
        // the Journal of the same client
        pie.setAnimated(UiMotion.isEnabled());
        // 2.11.0: the pie was the smallest thing on the dashboard (280 min
        // width, no growth share) while the bar chart below grew without
        // bound. Now: 300 min width, a 420 cap like its siblings, and a
        // preferred width that tracks its card so the disc stays square-ish
        // as the window widens.
        pie.setMinHeight(240);
        pie.setMinWidth(240);
        pie.setMaxHeight(Double.MAX_VALUE);
        pie.setMaxWidth(Double.MAX_VALUE);
        // 2.12.1 (P2-S2): the pie now FILLS the card (vgrow on the chart
        // node inside a border pane) instead of a fixed 300 pref.
        return pie;
    }

    /**
     * The balance-sheet proof as a STACKED bar chart (2.12.1, P2-S3):
     * one bar for Assets; the other bar stacks Liabilities, Equity
     * accounts and — while the period is open — current-period net
     * income, so the two bars stand at the same height exactly when
     * the corrected equation holds. No in-chart title: the card title
     * already says "assets = liabilities + equity"; the MoneyAxis side
     * labels are the same compact money ticks as the trend chart.
     */
    private StackedBarChart<String, Number> buildBalanceBars() {
        CategoryAxis sides = new CategoryAxis();
        MoneyAxis money = new MoneyAxis(14, 0);
        StackedBarChart<String, Number> chart = new StackedBarChart<>(sides, money);
        // 2.12.1 (P2-S3): the in-chart "Balance sheet" title duplicated
        // the card's — removed.
        chart.setLegendVisible(true);
        // 2.8.0: animated bars + hover tooltips + click deep-links to Reports
        chart.setAnimated(UiMotion.isEnabled());
        chart.setCategoryGap(40);
        // the class the semantic series colors below key off
        chart.getStyleClass().add("lp-chart-balance");
        XYChart.Series<String, Number> left = new XYChart.Series<>();
        left.setName("Assets");
        XYChart.Series<String, Number> liabilities = new XYChart.Series<>();
        liabilities.setName("Liabilities");
        XYChart.Series<String, Number> equity = new XYChart.Series<>();
        equity.setName("Equity");
        XYChart.Series<String, Number> income = new XYChart.Series<>();
        income.setName("Net income (open)");
        chart.getData().addAll(left, liabilities, equity, income);
        chart.setMinHeight(280);
        // 2.11.0: the balance proof is a two-column bar pair — it never
        // needed the height a trend line does, but it was the chart that
        // grew unboundedly on the user's tall screen. Capped at 360.
        chart.setMaxHeight(360);
        chart.setMaxWidth(Double.MAX_VALUE);
        return chart;
    }

    /** The recent-entries mini table (double-click opens the entry's lines). */
    private VBox buildRecentEntriesCard() {
        // 2.12.1 (P3-S3): FULL dates ("2026-03-05", not "Mar 5"), full
        // "#" numbers and full amounts — the old em-short pref widths
        // plus a fixed policy is what ellipsized "120,000..." mid-amount.
        // Columns size to their content; the amount cell is the
        // house MoneyCell (CENTER_RIGHT → right-aligned figures).
        TableColumn<RecentEntry, String> when = new TableColumn<>("Date");
        when.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().date().format(DateTimeFormatter.ISO_LOCAL_DATE)));
        when.setMinWidth(90);
        when.setPrefWidth(90);   // fixed: an ISO date never varies

        TableColumn<RecentEntry, String> no = new TableColumn<>("#");
        no.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                "#" + c.getValue().entryNo()));
        no.setMinWidth(56);
        no.setPrefWidth(56);     // fixed: "#1234" never varies
        no.getStyleClass().add("lp-col-strong");

        TableColumn<RecentEntry, String> memo = new TableColumn<>("Memo");
        memo.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().memo()));
        memo.setMinWidth(160);

        TableColumn<RecentEntry, Long> amount = new TableColumn<>("Amount");
        amount.setCellValueFactory(c -> new javafx.beans.property.SimpleObjectProperty<>(
                c.getValue().amountCents()));
        amount.setMinWidth(120);
        amount.getStyleClass().add("lp-col-strong");
        amount.setCellFactory(col -> new MoneyCell<>());

        TableColumn<RecentEntry, String> status = new TableColumn<>("Status");
        status.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().status()));
        status.setMinWidth(88);
        status.setPrefWidth(88);   // fixed: "Posted"/"Voided" never vary

        recentTable.getColumns().addAll(when, no, memo, amount, status);
        // flex the memo column over the remaining width; every other
        // column keeps its content width — nothing ellipsizes
        recentTable.setColumnResizePolicy(
                javafx.scene.control.TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        recentTable.setPlaceholder(new Label("No entries yet — the journal's New"
                + " Entry dialog is one Ctrl/Cmd+N away."));
        recentTable.setRowFactory(view -> {
            javafx.scene.control.TableRow<RecentEntry> row =
                    new javafx.scene.control.TableRow<>();
            row.setCursor(Cursor.HAND);
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    showEntryDetail(row.getItem());
                }
            });
            return row;
        });
        VBox.setVgrow(recentTable, Priority.ALWAYS);
        recentTable.setMinHeight(240);
        recentTable.setMaxWidth(Double.MAX_VALUE);
        // 2.12.1 (P3-S3): the table's height snaps to whole rows — the
        // viewport clamps to floor(available/rowHeight) rows so the last
        // visible row is never cut mid-row, the scroll step is exactly
        // one row.
        UiSizing.snapRowViewport(recentTable);

        return chartCard("Recent journal entries (double-click for the lines)",
                recentCaption, recentTable);
    }

    /** The entry's own Dr/Cr lines in a plain detail dialog. */
    private void showEntryDetail(RecentEntry entry) {
        List<JournalService.LineRow> lines = journalService.lines(entry.entryId());
        StringBuilder body = new StringBuilder("Entry #" + entry.entryNo()
                + " · " + entry.date() + " · " + entry.status() + "\n\n");
        for (var line : lines) {
            body.append(String.format("%-6s %-30s %14s %14s%n",
                    line.account().code(),
                    line.account().name(),
                    line.line().debitCents() == null ? ""
                            : Money.formatGrouped(line.line().debitCents()),
                    line.line().creditCents() == null ? ""
                            : Money.formatGrouped(line.line().creditCents())));
        }
        body.append("\n").append(lines.isEmpty()
                ? "(no lines)" : "total " + Money.formatGrouped(entry.amountCents()));
        Alert detail = new Alert(Alert.AlertType.INFORMATION,
                body.toString(), ButtonType.OK);
        detail.setTitle("Entry #" + entry.entryNo());
        detail.setHeaderText(entry.memo().isBlank() ? null : entry.memo());
        if (getScene() != null && getScene().getWindow() != null) {
            detail.initOwner(getScene().getWindow());
        }
        detail.showAndWait();
    }

    /**
     * The ASSETS card (2.12.1, C1): the balance-sheet proof chip rides the
     * caption row. The card still deep-links to the Reports view.
     */
    private VBox balanceAssetsCard() {
        HBox caption = new HBox(8, new Label("ASSETS"), balanceChip);
        caption.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(caption, Priority.ALWAYS);
        VBox box = clickableCard2(caption, assetsValue, assetsNote,
                () -> jump(ViewId.REPORTS));
        return box;
    }

    /**
     * The EQUITY card (2.12.1, C1): value = ending equity (equity accounts
     * + current-period net income when the period is open; just the equity
     * accounts when it is closed, because the closing entries already
     * folded the income in). The subtitle carries the breakdown.
     */
    private VBox equityCard() {
        return clickableCard2(new Label("EQUITY"), equityValue, equityNote,
                () -> jump(ViewId.REPORTS));
    }

    /** clickableCard variant with a Node caption (2.12.1, C1). */
    private static VBox clickableCard2(Node caption, Label value, Label note,
                                       Runnable target) {
        VBox box = card2(caption, value, note);
        box.getStyleClass().add("lp-card-link");
        box.setCursor(Cursor.HAND);
        box.setFocusTraversable(true);
        box.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_CLICKED,
                event -> target.run());
        box.setOnKeyPressed(event -> {
            if (event.getCode() == javafx.scene.input.KeyCode.SPACE
                    || event.getCode() == javafx.scene.input.KeyCode.ENTER) {
                target.run();
                event.consume();
            }
        });
        return box;
    }

    /** card() variant with a Node caption (2.12.1, C1). */
    private static VBox card2(Node caption, Label value, Label note) {
        if (caption instanceof Label label) {
            label.getStyleClass().add("lp-card-title");
        }
        value.getStyleClass().add("lp-card-value");
        note.getStyleClass().add("lp-card-note");
        note.setWrapText(true);
        // 2.12.1 (P3-S4): the note keeps a two-line floor — a long
        // subtitle wraps to exactly two lines, no more, so all four
        // cards in the grid row stay the same height
        note.setMinHeight(Region.USE_COMPUTED_SIZE);
        VBox box = new VBox(4, caption, value, note);
        box.getStyleClass().add("lp-card");
        box.setMinWidth(CARD_MIN_WIDTH);
        // fill the grid row's height (cards align, tops and bottoms)
        VBox.setVgrow(box, Priority.ALWAYS);
        return box;
    }

    /** A card: small caption, big value, one-line note. */
    private static VBox card(String caption, Label value, Label note) {
        Label title = new Label(caption);
        title.getStyleClass().add("lp-card-title");
        value.getStyleClass().add("lp-card-value");
        note.getStyleClass().add("lp-card-note");
        note.setWrapText(true);
        VBox box = new VBox(4, title, value, note);
        box.getStyleClass().add("lp-card");
        box.setMinWidth(CARD_MIN_WIDTH);
        VBox.setVgrow(box, Priority.ALWAYS);
        return box;
    }

    /**
     * A summary card that deep-links somewhere (2.6.0): hand cursor, hover
     * lift (CSS {@code .lp-card-link}), click jumps. The keyboard gets it
     * too — focus travels in order and Space/Enter activate.
     */
    private static VBox clickableCard(String caption, Label value, Label note,
                                       Runnable target) {
        VBox box = card(caption, value, note);
        box.getStyleClass().add("lp-card-link");
        box.setCursor(Cursor.HAND);
        box.setFocusTraversable(true);
        box.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_CLICKED,
                event -> target.run());
        box.setOnKeyPressed(event -> {
            if (event.getCode() == javafx.scene.input.KeyCode.SPACE
                    || event.getCode() == javafx.scene.input.KeyCode.ENTER) {
                target.run();
                event.consume();
            }
        });
        return box;
    }

    /** A chart card: caption, the totals line, then the chart node itself. */
    private static VBox chartCard(String caption, Label numbersLine, Node chart) {
        Label title = new Label(caption);
        title.getStyleClass().add("lp-chart-title");
        title.setWrapText(true);
        numbersLine.getStyleClass().add("lp-card-note");
        numbersLine.setWrapText(true);
        numbersLine.setMinHeight(16);   // reserved: the card never jumps when
                                        // the numbers land after the read
        VBox box = new VBox(8, title, numbersLine, chart);
        box.getStyleClass().add("lp-chart-card");
        box.setMinWidth(PANEL_MIN_WIDTH);
        VBox.setVgrow(chart, Priority.ALWAYS);
        return box;
    }

    // ------------------------------------------------------------------
    // The read pass — ONE connection for everything (background thread)
    // ------------------------------------------------------------------

    private void fillCards(ClientAggregates agg, Period period) {
        long netIncome = agg.totalRevenue() - agg.totalExpenses();
        netIncomeValue.setText((netIncome >= 0 ? "" : "(")
                + Money.formatGrouped(Math.abs(netIncome))
                + (netIncome >= 0 ? "" : ")"));
        netIncomeValue.getStyleClass().setAll("lp-card-value",
                netIncome >= 0 ? "lp-step-done" : "lp-dialog-error");
        netIncomeNote.setText("revenue " + Money.formatGrouped(agg.totalRevenue())
                + " − expenses " + Money.formatGrouped(agg.totalExpenses())
                + " · " + period.name());

        // 2.12.1 (C1): the proof for an OPEN period is
        //   assets = liabilities + equity accounts + current-period net income
        // (net income is assets the entity earned but has not yet moved into
        // an equity account). For a CLOSED period the closing entries already
        // folded the income into equity, so the plain equation holds and
        // adding net income again would double-count. The chip only says
        // OUT OF BALANCE when the corrected equation fails.
        boolean closed = agg.periodClosed;
        long rightSide = agg.liabilities + agg.equity + (closed ? 0 : netIncome);
        boolean holds = agg.assets == rightSide;
        assetsValue.setText(Money.formatGrouped(agg.assets));
        assetsNote.setText("liabilities " + Money.formatGrouped(agg.liabilities)
                + " · equity accounts " + Money.formatGrouped(agg.equity)
                + (closed ? "" : " · net income " + Money.formatGrouped(netIncome))
                + (closed ? " · closed period" : " · open period"));
        balanceChip.setText(holds ? "BALANCED" : "OUT OF BALANCE");
        balanceChip.getStyleClass().setAll(
                holds ? "lp-chip-ok" : "lp-chip-fail");

        // 2.12.1 (C1): ending equity, with the breakdown in the subtitle.
        // Open period: capital-side equity accounts + net income to date.
        // Closed period: the equity accounts alone carry it.
        long endingEquity = agg.equity + (closed ? 0 : netIncome);
        equityValue.setText(Money.formatGrouped(endingEquity));
        equityNote.setText(closed
                ? "equity accounts " + Money.formatGrouped(agg.equity)
                        + " · closed period — income already folded in"
                : "equity accounts " + Money.formatGrouped(agg.equity)
                        + " + net income " + Money.formatGrouped(netIncome)
                        + " (period open)");

        entriesValue.setText(String.valueOf(agg.posted));
        entriesNote.setText((agg.draft == 0 ? "no drafts" : agg.draft + " drafts")
                + (agg.voided == 0 ? " · nothing voided" : " · " + agg.voided + " voided"));
    }

    private void fillTrendChart(ClientAggregates agg) {
        XYChart.Series<String, Number> revenue = trendChart.getData().get(0);
        XYChart.Series<String, Number> expenses = trendChart.getData().get(1);
        revenue.getData().clear();
        expenses.getData().clear();
        for (String month : agg.months()) {
            long revenueCents = agg.revenueByMonth.getOrDefault(month, 0L);
            long expenseCents = agg.expenseByMonth.getOrDefault(month, 0L);
            revenue.getData().add(dataPoint(month, revenueCents,
                    "Revenue in " + month, ViewId.JOURNAL, true));
            expenses.getData().add(dataPoint(month, expenseCents,
                    "Expenses in " + month, ViewId.JOURNAL, false));
        }
        // 2.9.0: the chart caption carries the numbers themselves — total
        // revenue, total expenses and the margin, so the graph reads
        // without hovering anything
        trendCaption.setText(agg.months().isEmpty()
                ? "No posted revenue or expenses yet in this period."
                : "Totals — revenue " + Money.formatGrouped(agg.totalRevenue())
                        + " · expenses " + Money.formatGrouped(agg.totalExpenses())
                        + " · margin " + Money.formatGrouped(
                                Math.abs(agg.totalRevenue() - agg.totalExpenses()))
                        + (agg.totalRevenue() >= agg.totalExpenses() ? " (" : " (−")
                        + percent(agg.netIncome(), agg.totalRevenue()) + ")");
        // 2.8.0: keep the animation flag current with the preference — a
        // Settings flip re-arms live without a restart
        trendChart.setAnimated(UiMotion.isEnabled());
    }

    /** {@code part/whole} as a rounded percent string ("37%"). */
    private static String percent(long part, long whole) {
        if (whole == 0) {
            return "0%";
        }
        return Math.round(part * 100.0 / whole) + "%";
    }

    /**
     * One line-chart point (2.8.0): a numeric value with an interactive
     * symbol — hover shows the exact figure, click deep-links to a view.
     * 2.12.1 (P2-S1): the symbol is a SMALL FIXED-SIZE CIRCLE (8 px,
     * never scaled by the text size — the old 2.9.0 label-under-dot grew
     * with UiScale and crowded the chart), and the VALUE is on hover only
     * (Tooltip with the full PHP amount; the compact printed labels are
     * gone — the caption row carries the totals).
     */
    private XYChart.Data<String, Number> dataPoint(String month, long cents,
                                                   String tooltip, ViewId target,
                                                   boolean revenueSide) {
        javafx.scene.shape.Circle dot = new javafx.scene.shape.Circle(4);
        dot.getStyleClass().addAll("lp-point-dot",
                revenueSide ? "chart-series-0-dot" : "chart-series-1-dot");
        javafx.scene.layout.StackPane symbol = new javafx.scene.layout.StackPane(dot);
        symbol.getStyleClass().add("lp-point-hitbox");

        XYChart.Data<String, Number> point =
                new XYChart.Data<>(month, cents / 100.0);
        point.setNode(symbol);
        javafx.scene.control.Tooltip tip =
                new javafx.scene.control.Tooltip(tooltip + ": "
                        + Money.formatGrouped(cents));
        javafx.scene.control.Tooltip.install(symbol, tip);
        symbol.setCursor(Cursor.HAND);
        symbol.setOnMouseClicked(event -> jump(target));
        return point;
    }

    /**
     * Compact chart-label formatting (2.9.0): "12.5M" for millions,
     * "980k" for thousands, plain "42" below — keeps the label short
     * enough that neighbors don't collide.
     */
    private static String compact(long cents) {
        double units = cents / 100.0;
        if (Math.abs(units) >= 1_000_000) {
            return stripTrailingZeros(String.format("%.1fM", units / 1_000_000));
        }
        if (Math.abs(units) >= 10_000) {
            return stripTrailingZeros(String.format("%.0fk", units / 1_000));
        }
        if (Math.abs(units) >= 1_000) {
            return stripTrailingZeros(String.format("%.1fk", units / 1_000));
        }
        return stripTrailingZeros(String.format("%.0f", units));
    }

    private static String stripTrailingZeros(String raw) {
        return raw.contains(".") ? raw.replaceAll("0+$", "").replaceAll("\\.$", "") : raw;
    }

    private void fillExpensePie(ClientAggregates agg) {
        expensePie.getData().clear();
        // 2.12.1 (P2-S2): slices UNDER 3% of total expenses fold into
        // "Other" (a sliver nobody can read or hit); everything 3%+ shows.
        // Order stays largest-first, which PieChart keeps on the disc.
        long totalExpenses = agg.totalExpenses();
        List<java.util.Map.Entry<String, Long>> bySize = agg.expenseByName.entrySet()
                .stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .toList();
        long other = 0;
        for (var entry : bySize) {
            if (totalExpenses > 0
                    && entry.getValue() * 100.0 / totalExpenses >= 3.0) {
                expensePie.getData().add(pieSlice(entry.getKey(), entry.getValue(),
                        totalExpenses));
            } else {
                other += entry.getValue();
            }
        }
        if (other > 0) {
            expensePie.getData().add(pieSlice("Other", other, totalExpenses));
        }
        expensePie.setAnimated(UiMotion.isEnabled());
        // the right-side legend: one row per slice (color dot, name,
        // amount, %) — read without hovering anything
        pieLegend.getChildren().clear();
        for (int i = 0; i < expensePie.getData().size(); i++) {
            PieChart.Data slice = expensePie.getData().get(i);
            long cents = Math.round(slice.getPieValue() * 100);
            javafx.scene.layout.HBox row = pieLegendRow(i, slice.getName(), cents,
                    totalExpenses);
            pieLegend.getChildren().add(row);
            // the legend dot takes the slice's OWN fill, whatever the
            // theme rendered — set once the slice node exists (a pulse
            // later). Falls back to the CSS dot tint if anything reads
            // null before layout.
            slice.nodeProperty().addListener((obs, oldNode, sliceNode) ->
                    copySliceColor(sliceNode, row));
            if (slice.getNode() != null) {
                copySliceColor(slice.getNode(), row);
            }
        }
        // 2.9.0: the caption carries the headline numbers — how much was
        // spent in total, across how many accounts, and the top slice
        long top = bySize.isEmpty() ? 0 : bySize.getFirst().getValue();
        String topName = bySize.isEmpty() ? "" : bySize.getFirst().getKey();
        pieCaption.setText(bySize.isEmpty()
                ? "No posted expenses in this period yet."
                : "Total expenses " + Money.formatGrouped(totalExpenses)
                        + " across " + agg.expenseByName.size() + " accounts · largest: "
                        + topName + " (" + Money.formatGrouped(top) + ", "
                        + percent(top, totalExpenses) + ")");
    }

    /**
     * One pie slice (2.8.0): hover highlights it and shows the account,
     * the amount and its share of total expenses; a click deep-links to
     * the Journal where the account's entries live. 2.9.0: the slice's
     * visible label carries the amount too, not just the account name.
     */
    private PieChart.Data pieSlice(String account, long cents, long totalExpenses) {
        // 2.12.1 (P2-S2): the slice NAME is the bare account — the share
        // and amount live in the legend row and the hover tooltip
        PieChart.Data slice = new PieChart.Data(account, cents / 100.0);
        slice.nodeProperty().addListener((obs, old, node) -> {
            if (node != null) {
                String fullShare = totalExpenses <= 0 ? "—"
                        : Math.round(cents * 1000.0 / totalExpenses) / 10.0 + "%";
                javafx.scene.control.Tooltip tip = new javafx.scene.control.Tooltip(
                        account + "\n" + Money.formatGrouped(cents)
                                + " · " + fullShare + " of expenses");
                javafx.scene.control.Tooltip.install(node, tip);
                node.setCursor(Cursor.HAND);
                node.setOnMouseClicked(event -> jump(ViewId.JOURNAL));
                // hover: the slice grows slightly — reads as "this slice
                // is the one you're on"; leaves at rest on exit
                node.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_ENTERED,
                        e -> {
                            node.setScaleX(1.03);
                            node.setScaleY(1.03);
                        });
                node.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_EXITED,
                        e -> {
                            node.setScaleX(1.0);
                            node.setScaleY(1.0);
                        });
            }
        });
        return slice;
    }

    /** One custom pie-legend row (2.12.1, P2-S2): color dot + name,
     * amount + share — mirrors the slice order top to bottom. */
    private javafx.scene.layout.HBox pieLegendRow(int colorIndex, String name,
                                                  long cents, long totalExpenses) {
        javafx.scene.layout.Region dot = new javafx.scene.layout.Region();
        dot.getStyleClass().add("lp-pie-legend-dot");
        Label label = new Label(name);
        label.getStyleClass().add("lp-pie-legend-name");
        Label figures = new Label(Money.formatGrouped(cents) + "  ·  "
                + percent(cents, totalExpenses));
        figures.getStyleClass().add("lp-pie-legend-fig");
        javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        javafx.scene.layout.HBox row = new javafx.scene.layout.HBox(6, dot, label,
                spacer, figures);
        row.getStyleClass().add("lp-pie-legend-row");
        return row;
    }

    /** The legend row's dot gets the slice node's own painted fill —
     * whatever the active theme gave that slice (2.12.1, P2-S2). */
    private void copySliceColor(Node sliceNode, javafx.scene.layout.HBox row) {
        if (sliceNode == null || row.getChildren().isEmpty()) {
            return;
        }
        Node dot = row.getChildren().getFirst();
        try {
            var background = ((javafx.scene.layout.Region) sliceNode).getBackground();
            if (background == null) {
                return;   // CSS has not applied yet — the dot keeps its tint
            }
            var fills = background.getFills();
            if (!fills.isEmpty()) {
                javafx.scene.paint.Paint paint = fills.getFirst().getFill();
                if (paint != null && !(paint instanceof javafx.scene.paint.ImagePattern)) {
                    dot.setStyle("-fx-background-color: " + web(paint) + ";");
                }
            }
        } catch (ClassCastException notARegion) {
            // slice node not a Region — keep the CSS fallback tint
        }
    }

    /** A Paint as a CSS web color (works for flat colors; gradients fall
     *  back to the CSS tint). */
    private static String web(javafx.scene.paint.Paint paint) {
        if (paint instanceof javafx.scene.paint.Color c) {
            return String.format("#%02x%02x%02x",
                    (int) Math.round(c.getRed() * 255),
                    (int) Math.round(c.getGreen() * 255),
                    (int) Math.round(c.getBlue() * 255));
        }
        return "-color-accent-emphasis";
    }

    private void fillBalanceBars(ClientAggregates agg) {
        XYChart.Series<String, Number> left = balanceBars.getData().get(0);
        XYChart.Series<String, Number> liabilities = balanceBars.getData().get(1);
        XYChart.Series<String, Number> equity = balanceBars.getData().get(2);
        XYChart.Series<String, Number> income = balanceBars.getData().get(3);
        left.getData().clear();
        liabilities.getData().clear();
        equity.getData().clear();
        income.getData().clear();
        long netIncome = agg.netIncome();
        // 2.12.1 (P2-S3): the right bar STACKS the three parts —
        // liabilities, equity accounts and (while the period is open)
        // net income — so the bar heights themselves are the proof:
        // both bars top out at the same tick exactly when the corrected
        // equation holds. A closed period's income is already folded
        // into equity, so its series stays empty (its legend entry
        // drops with it).
        left.getData().add(dataPoint("Position", agg.assets,
                "Assets", ViewId.REPORTS, true));
        liabilities.getData().add(dataPoint("Position", agg.liabilities,
                "Liabilities", ViewId.REPORTS, false));
        equity.getData().add(dataPoint("Position", agg.equity,
                "Equity accounts", ViewId.REPORTS, false));
        if (!agg.periodClosed) {
            income.getData().add(dataPoint("Position", Math.max(netIncome, 0L),
                    "Net income (open period)", ViewId.REPORTS, false));
        }
        balanceBars.setAnimated(UiMotion.isEnabled());
        // 2.9.0: the equation itself, with the numbers — the proof reads
        // right off the card (2.12.1: net income on the right side)
        balanceCaption.setText("Assets " + Money.formatGrouped(agg.assets)
                + " = liabilities " + Money.formatGrouped(agg.liabilities)
                + " + equity accounts " + Money.formatGrouped(agg.equity)
                + (agg.periodClosed ? " (closed period"
                        : " + net income " + Money.formatGrouped(netIncome)
                        + " (open period")
                + (agg.balanceHolds() ? ") · proof holds ✓" : ") · OUT OF BALANCE"));
    }

    // ------------------------------------------------------------------
    // The aggregates of one refresh (one SQL pass' worth of state)
    // ------------------------------------------------------------------

    /** The pure read+roll-up of one refresh — unit-tested without JavaFX. */
    static final class ClientAggregates {
        final java.util.TreeMap<String, Long> revenueByMonth = new java.util.TreeMap<>();
        final java.util.TreeMap<String, Long> expenseByMonth = new java.util.TreeMap<>();
        final java.util.TreeMap<String, Long> expenseByName = new java.util.TreeMap<>();
        long assets;
        long liabilities;
        long equity;
        /** 2.12.1 (C1): the period's closed flag rides the aggregates so
         *  the proof and the equity card can pick the right equation. */
        boolean periodClosed;
        int posted;
        int draft;
        int voided;
        final List<RecentEntry> recents = new ArrayList<>();

        void addRevenue(String month, long cents) {
            revenueByMonth.merge(month, cents, Long::sum);
        }

        void addExpense(String month, long cents) {
            expenseByMonth.merge(month, cents, Long::sum);
        }

        long totalRevenue() {
            return revenueByMonth.values().stream().mapToLong(Long::longValue).sum();
        }

        long totalExpenses() {
            return expenseByMonth.values().stream().mapToLong(Long::longValue).sum();
        }

        List<String> months() {
            java.util.TreeSet<String> all = new java.util.TreeSet<>();
            all.addAll(revenueByMonth.keySet());
            all.addAll(expenseByMonth.keySet());
            return new ArrayList<>(all);
        }

        long netIncome() {
            return totalRevenue() - totalExpenses();
        }

        /**
         * 2.12.1 (C1): the corrected accounting equation. Open period:
         * {@code assets == liabilities + equity + net income}; closed
         * period: the closing entries folded the income into equity
         * already, so {@code assets == liabilities + equity}.
         */
        boolean balanceHolds() {
            return assets == liabilities + equity + (periodClosed ? 0 : netIncome());
        }
    }

    /** One row of the recent-entries table. */
    record RecentEntry(long entryId, int entryNo, LocalDate date, String memo,
                       long amountCents, String status) {
    }

    // ------------------------------------------------------------------
    // The workspace overview (no working client) — the earlier dashboard
    // ------------------------------------------------------------------

    private VBox buildWorkspaceOverview() {
        Label heading = new Label("Workspace overview");
        heading.getStyleClass().add("lp-heading");

        HBox cards = new HBox(14,
                card("DATABASE", dbValue, dbNote),
                card("CLIENTS", clientsValue, clientsNote),
                phaseCard(),
                card("WORKING CLIENT", workingValue, workingNote));
        for (Node c : cards.getChildren()) {
            HBox.setHgrow(c, Priority.ALWAYS);
        }

        HBox lower = buildLowerRow();
        // fill the window: the checklist/roadmap row absorbs every spare
        // vertical pixel so a maximized window has no dead band at the bottom
        VBox.setVgrow(lower, Priority.ALWAYS);
        lower.setAlignment(Pos.TOP_LEFT);

        return new VBox(16, heading, cards, lower);
    }

    private HBox buildLowerRow() {
        VBox checklist = buildChecklist();
        VBox roadmap = buildRoadmap();
        HBox row = new HBox(14, checklist, roadmap);
        for (Node c : row.getChildren()) {
            HBox.setHgrow(c, Priority.ALWAYS);
        }
        checklist.setMinWidth(PANEL_MIN_WIDTH);
        roadmap.setMinWidth(PANEL_MIN_WIDTH);
        return row;
    }

    private VBox buildChecklist() {
        Label title = new Label("GETTING STARTED");
        title.getStyleClass().add("lp-card-title");
        VBox card = new VBox(8, title, stepClients, stepCoa, stepJournal, stepReports);
        card.getStyleClass().add("lp-card");
        VBox.setVgrow(card, Priority.ALWAYS);
        return card;
    }

    private VBox buildRoadmap() {
        Label title = new Label("DELIVERY ROADMAP");
        title.getStyleClass().add("lp-card-title");
        Label phases = new Label(
                "Phase 1 — database foundation (done)\n"
                        + "Phase 2 — the app shell + clients (done)\n"
                        + "Phase 3 — chart of accounts + FX (done)\n"
                        + "Phase 4 — journal + posting (done)\n"
                        + "Phase 5 — worksheet + statements (done)\n"
                        + "Phase 6 — polish + shipping (done)");
        phases.getStyleClass().add("lp-card-note");
        phases.setWrapText(true);
        VBox card = new VBox(8, title, phases);
        card.getStyleClass().add("lp-card");
        VBox.setVgrow(card, Priority.ALWAYS);
        return card;
    }

    private VBox phaseCard() {
        Label title = new Label("BUILD");
        title.getStyleClass().add("lp-card-title");
        Label value = new Label("Phase 6 — shipping");
        value.getStyleClass().add("lp-card-value");
        Label note = new Label(
                "the accounting cycle is complete end-to-end; maintenance and"
                        + " polish releases from here");
        note.getStyleClass().add("lp-card-note");
        note.setWrapText(true);
        VBox card = new VBox(4, title, value, note);
        card.getStyleClass().add("lp-card");
        card.setMinWidth(CARD_MIN_WIDTH);
        return card;
    }

    // the stat-card reads below stayed as they were, one connection shared
    private void readDatabaseStats(Connection con) {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA journal_mode")) {
            String mode = rs.next() ? rs.getString(1) : "?";
            dbValue.setText(mode.equalsIgnoreCase("wal") ? "SQLite · WAL" : "SQLite · " + mode);
        } catch (SQLException e) {
            dbValue.setText("unavailable");
        }
        dbNote.setText("~/.ledgerpro/ledgerpro.db · Flyway migrations applied");
    }

    private void updateCoaStep(Connection con) {
        boolean done = countRows(con, "accounts") > 0;
        stepCoa.setText((done ? "✔  " : "○  ") + "Give the client a chart of accounts"
                + (done ? " — done" : ""));
        stepCoa.getStyleClass().setAll(done ? "lp-step-done" : "lp-step-todo");
    }

    private void updateJournalStep(Connection con) {
        boolean done = countRows(con, "journal_entries") > 0;
        stepJournal.setText((done ? "✔  " : "○  ") + "Record journal entries"
                + (done ? " — done" : ""));
        stepJournal.getStyleClass().setAll(done ? "lp-step-done" : "lp-step-todo");
    }

    private void updateReportsStep(Connection con) {
        boolean done = countRows(con, "report_snapshots") > 0;
        stepReports.setText((done ? "✔  " : "○  ") + "Produce the statements"
                + (done ? " — done" : " — worksheet → statements → snapshot"));
        stepReports.getStyleClass().setAll(done ? "lp-step-done" : "lp-step-todo");
    }

    private long countRows(Connection con, String table) {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) {
            return rs.next() ? rs.getLong(1) : 0;
        } catch (SQLException e) {
            return 0;
        }
    }

    // small helpers -------------------------------------------------------

    /** Finds the same-id period in a fresh list (ids are stable). */
    private static Period matchPeriod(List<Period> periods, long id) {
        for (Period period : periods) {
            if (period.id() == id) {
                return period;
            }
        }
        return null;
    }

    /** True when the two period lists carry the same ids in the same order. */
    private static boolean samePeriods(
            javafx.collections.ObservableList<Period> left, List<Period> right) {
        if (left == null || left.size() != right.size()) {
            return false;
        }
        for (int i = 0; i < right.size(); i++) {
            if (left.get(i).id() != right.get(i).id()) {
                return false;
            }
        }
        return true;
    }
}
