package com.ledgerpro.ui;

import javafx.util.StringConverter;

import java.util.List;

/**
 * The ISO 4217 codes the firm meets in practice — one shared list behind the
 * client dialog's base-currency box and the FX view's pair pickers.
 *
 * <p>Every picker is editable, so an exotic currency can still be typed; the
 * list is only the convenient majority. It covers the whole Frankfurter/ECB
 * reference set (so anything auto-completable here is also fetchable
 * there).</p>
 */
final class Currencies {

    static final List<String> COMMON = List.of(
            "PHP", "USD", "EUR", "GBP", "JPY", "CNY", "SGD", "HKD", "AUD",
            "CAD", "CHF", "KRW", "MYR", "THB", "IDR", "VND", "TWD", "INR",
            "AED", "NZD", "SEK", "NOK", "DKK", "PLN", "CZK", "HUF", "BRL",
            "MXN", "ZAR", "ILS", "TRY", "BGN", "RON", "ISK");

    private Currencies() {
    }

    /**
     * Uppercases whatever the user typed into an editable combo
     * ('usd' → 'USD'), so the value is ready for the services' ISO checks.
     */
    static StringConverter<String> upperCasing() {
        return new StringConverter<>() {
            @Override
            public String toString(String code) {
                return code == null ? "" : code;
            }

            @Override
            public String fromString(String text) {
                return text == null ? "" : text.trim().toUpperCase();
            }
        };
    }
}
