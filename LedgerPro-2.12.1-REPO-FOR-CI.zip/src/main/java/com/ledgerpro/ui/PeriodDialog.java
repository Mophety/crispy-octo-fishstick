package com.ledgerpro.ui;

import com.ledgerpro.model.Period;
import com.ledgerpro.service.DuplicatePeriodNameException;
import com.ledgerpro.service.PeriodService;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.time.LocalDate;

/**
 * Modal form for creating an accounting period: name plus the inclusive
 * date range.
 *
 * <p>Validation is layered exactly like the service: the button stays
 * disabled until name + both dates are present; service rejections
 * (duplicate name, overlapping range, end before start) surface inline and
 * the dialog stays open — nothing half-created.</p>
 */
final class PeriodDialog extends Dialog<Period> {

    private final TextField nameField = new TextField();
    private final DatePicker startPicker = new DatePicker();
    private final DatePicker endPicker = new DatePicker();
    private final Label errorLabel = new Label();

    private final PeriodService service;
    private final long clientId;
    private Period created;

    PeriodDialog(PeriodService service, long clientId) {
        this.service = service;
        this.clientId = clientId;

        setTitle("New period");
        setHeaderText("An accounting period of this client — entries live inside one");

        ButtonType create = new ButtonType("Create period", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(create, ButtonType.CANCEL);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(getDialogPane());

        nameField.setPromptText("e.g. FY2026 or 2026-10");
        int year = LocalDate.now().getYear();
        startPicker.setValue(LocalDate.of(year, 1, 1));
        endPicker.setValue(LocalDate.of(year, 12, 31));
        startPicker.setPromptText("inclusive first day");
        endPicker.setPromptText("inclusive last day");
        errorLabel.getStyleClass().add("lp-dialog-error");
        errorLabel.setWrapText(true);
        errorLabel.setMinHeight(34);

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.addRow(0, new Label("Name:"), nameField);
        form.addRow(1, new Label("Starts (incl.):"), startPicker);
        form.addRow(2, new Label("Ends (incl.):"), endPicker);
        ColumnConstraints labels = new ColumnConstraints();
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(labels, fields);

        VBox content = new VBox(12, form, errorLabel);
        content.setPadding(new Insets(4, 20, 0, 20));   // breathe at the edges
        getDialogPane().setContent(content);

        javafx.scene.Node createButton = getDialogPane().lookupButton(create);
        createButton.disableProperty().bind(Bindings.createBooleanBinding(
                () -> nameField.getText().isBlank()
                        || startPicker.getValue() == null
                        || endPicker.getValue() == null,
                nameField.textProperty(), startPicker.valueProperty(),
                endPicker.valueProperty()));

        createButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            try {
                created = service.create(clientId, nameField.getText(),
                        startPicker.getValue(), endPicker.getValue());
            } catch (DuplicatePeriodNameException | IllegalArgumentException e) {
                errorLabel.setText("✗  " + e.getMessage());
                event.consume();
            }
        });

        setResultConverter(buttonType -> ButtonBar.ButtonData.OK_DONE
                .equals(buttonType.getButtonData()) ? created : null);
    }
}
