package com.ledgerpro.ui;

import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;

/**
 * One status-cell factory for every table (2.12.0 design system).
 *
 * <p>The 2.11 codebase styled status text with inline {@code setStyle}
 * calls in four views (accounts, audit, clients, FX). Inline styles do not
 * re-resolve when {@link ThemeManager} swaps the user-agent stylesheet, so
 * a theme switch could leave a status cell wearing the previous theme's
 * color. This helper maps a status string to a <b>CSS class</b>
 * ({@code lp-status-*}) so the scene's stylesheets stay the single source
 * of truth — the same rule the journal's register already followed.</p>
 *
 * <p>Mappings (deterministic, plain text only):</p>
 * <ul>
 *   <li>{@code lp-status-void}   — destructive outcomes (void, delete,
 *       deactivate, archive)</li>
 *   <li>{@code lp-status-ok}     — constructive outcomes (active, create,
 *       post, store, restore, close, import)</li>
 *   <li>{@code lp-status-draft}  — neutral/informational (everything else,
 *       including Manual FX rates)</li>
 * </ul>
 */
public final class StatusText {

    private StatusText() {
    }

    /** The CSS class a status string wears in a table cell. */
    public static String classFor(String status) {
        if (status == null) {
            return "lp-status-draft";
        }
        String s = status.trim();
        if (s.equals("Inactive") || s.equals("Archived")) {
            return "lp-status-draft";
        }
        if (s.startsWith("VOID") || s.contains("DEACTIVATE")
                || s.contains("ARCHIVE") || s.contains("DELETE")
                || s.equals("Voided")) {
            return "lp-status-void";
        }
        if (s.equals("Active") || s.startsWith("CREATE") || s.startsWith("POST")
                || s.startsWith("STORE") || s.startsWith("RESTORE")
                || s.startsWith("CLOSE") || s.startsWith("IMPORT")
                || s.equals("Posted")) {
            return "lp-status-ok";
        }
        return "lp-status-draft";
    }

    /**
     * A cell factory that renders {@code column}'s strings through the
     * {@code lp-status-*} classes. The class list is set with
     * {@code setAll} so a recycled cell never keeps the previous row's
     * class.
     */
    public static <S> javafx.util.Callback<TableColumn<S, String>, TableCell<S, String>>
    cell() {
        return col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                getStyleClass().setAll("table-cell",
                        empty || item == null ? "lp-status-draft" : classFor(item));
            }
        };
    }
}
