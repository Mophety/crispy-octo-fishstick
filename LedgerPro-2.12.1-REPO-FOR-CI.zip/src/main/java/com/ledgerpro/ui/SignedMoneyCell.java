package com.ledgerpro.ui;

import javafx.geometry.Pos;
import javafx.scene.control.TableCell;

/**
 * Table cell for a signed cents column on the statements: right-aligned,
 * two decimals, deductions (contra assets, withdrawals) in parentheses and
 * muted ink — the "less:" lines every paper statement carries.
 */
final class SignedMoneyCell<S> extends TableCell<S, Long> {

    SignedMoneyCell() {
        setAlignment(Pos.CENTER_RIGHT);
    }

    @Override
    protected void updateItem(Long item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            setText(null);
            getStyleClass().remove("lp-neg");
            return;
        }
        if (item < 0) {
            setText("(" + Money.format(-item) + ")");
            if (!getStyleClass().contains("lp-neg")) {
                getStyleClass().add("lp-neg");
            }
        } else {
            setText(Money.format(item));
            getStyleClass().remove("lp-neg");
        }
    }
}
