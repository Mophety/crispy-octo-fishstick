package com.ledgerpro.ui;

import com.ledgerpro.model.Account;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.JournalEntry;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.AdjTemplateService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * The double-entry journal of the working client (Phase 4; 2.10.0 — the
 * journal-restoration release): the register of every entry — drafts,
 * posted entries and voided ones — plus the posting and voiding machinery.
 *
 * <p><b>Two display modes</b> (the toolbar toggle; persisted; REGISTER is
 * the 2.10.0 default — the flat 2.3.1 design the user prefers; the paper
 * journal stays one toggle away):</p>
 * <ul>
 *   <li><b>REGISTER</b> — one row per entry: No · Date · Type · Ref ·
 *       Memo · Period · FX · Amount · Status. Uniform rows with hairline
 *       separators, plain colored status text — the classic clean
 *       general-journal register.</li>
 *   <li><b>ENTRY_LINES</b> — the paper bookkeeping look. Each entry unfolds
 *       into its debit and credit lines, one row per line with the
 *       account's code and name in the account column, the amount in the
 *       Dr or Cr column — and after the last line an indented row that
 *       starts with '#' carrying the entry's memo, exactly the way a
 *       manual journal notes the explanation under the lines. The
 *       row group reads as one entry: No/Date/Status print only on the
 *       first row, and selecting any row of the group selects the entry.</li>
 * </ul>
 *
 * <p><b>2.10.0 — the 2.3.1 register restored:</b> the register rows drop
 * the 2.8.0 zebra stripes, hover fills and status pills — uniform white
 * rows, the table skin's own hairlines, and plain palette-colored status
 * text, exactly the 2.3.1 cell factory. The 2.7.0 voided dimming stays.
 * The zebra/hover/pill CSS rules remain in ledgerpro.css for the paper
 * mode's status pills.</p>
 *
 * <p><b>2.10.0 — filters and the live footer:</b> a search box (memo, ref,
 * entry-no prefix) and a status filter (All/Draft/Posted/Voided) compose
 * with the period filter over the cached rows — no database round trip —
 * and the footer statistics describe the FILTERED set, so the counts
 * always match what is on screen. Export CSV writes the filtered register
 * to a file; Enter opens the selected entry's lines; F5 reloads.</p>
 *
 * <p>Scope and rules made visible here:</p>
 * <ul>
 *   <li>entries are listed newest first, filtered by period when one is
 *       picked;</li>
 *   <li><b>Post</b> turns a draft into ledger fact (it then feeds ledgers,
 *       trial balances and, in Phase 5, the worksheet);</li>
 *   <li><b>Void</b> never deletes anything: a mirrored reversing entry is
 *       recorded and posted, cancelling the original line by line — the
 *       register keeps both so the story stays auditable;</li>
 *   <li>creating an entry needs at least one OPEN period and an active chart;
 *       the toolbar buttons say so instead of failing silently.</li>
 * </ul>
 */
public final class JournalView extends VBox implements Refreshable {

    private final JournalService journalService;
    private final PeriodService periodService;
    private final AccountService accountService;
    private final FxRateService fxService;
    private final AdjTemplateService adjService;
    private final ObservableValue<Client> activeClient;

    private final ComboBox<Period> periodFilter = new ComboBox<>();
    private final TableView<JournalService.EntrySummary> table = new TableView<>();
    // 2.12.0: lookup id for the headless responsiveness check
    private final TableView<JournalRow> linesTable = new TableView<>();
    private final Button newEntryButton = new Button("New entry…");
    private final Button newPeriodButton = new Button("New period…");
    private final Button postButton = new Button("Post");
    private final Button voidButton = new Button("Void…");
    private final Button closeButton = new Button("Close Period…");
    private final Button detailButton = new Button("View lines…");
    private final Button duplicateButton = new Button("Duplicate…");
    private final Button layoutButton = new Button();
    // 2.12.1 (P4-S3): a thin vertical divider between toolbar groups
    private static Region groupDivider() {
        Region divider = new Region();
        divider.getStyleClass().add("lp-toolbar-divider");
        // keep its own size: a 1px wide, button-height rule
        divider.setMinWidth(1);
        divider.setPrefWidth(1);
        return divider;
    }
    private final Button exportButton = new Button("Export CSV…");
    private final Label banner = new Label();
    private final Label footer = new Label();

    // 2.10.0: the filter controls — search (memo/ref/entry-no prefix) and
    // status (All/Draft/Posted/Voided), composing with the period filter
    // over the cached rows; keystrokes cost no database round trip.
    private final TextField search = new TextField();
    private final ComboBox<String> statusFilter = new ComboBox<>();
    private static final String STATUS_ALL = "All statuses";

    private Client client;
    private List<Period> periods = List.of();
    private List<JournalService.EntrySummary> allRows = List.of();
    /** The VISIBLE (filtered) rows — the footer statistics describe these. */
    private List<JournalService.EntrySummary> visibleRows = List.of();
    /** Line rows grouped by entry id, for the ENTRY_LINES mode. */
    private Map<Long, List<JournalService.LineRow>> linesByEntry = Map.of();
    /** 2.10.0: entry id → summary, built once per reload (O(1) lookups). */
    private Map<Long, JournalService.EntrySummary> summaryById = Map.of();

    /**
     * 2.12.0: bumped on every reload start — a background read that lands
     * after a newer reload began is dropped, so a client switch mid-read
     * can never paint the previous client's rows.
     */
    private final java.util.concurrent.atomic.AtomicLong loadEpoch =
            new java.util.concurrent.atomic.AtomicLong();

    private final VBox emptyState = buildEmptyState();
    // 2.12.1 (P4-S6): em bands per column — re-applied when the table
    // gains a scene or the text scale changes (see buildRegisterColumns)
    private final java.util.Map<TableColumn<JournalService.EntrySummary, ?>, double[]> emBands =
            new java.util.LinkedHashMap<>();

    private void reszeEmBands() {
        double em = UiSizing.em(table);
        for (var entry : emBands.entrySet()) {
            entry.getKey().setMinWidth(em * entry.getValue()[0]);
            entry.getKey().setMaxWidth(em * entry.getValue()[1]);
        }
    }

    private final VBox workArea = buildWorkArea();

    private com.ledgerpro.service.ClosingService closingService;

    public JournalView(JournalService journalService, PeriodService periodService,
                       AccountService accountService, FxRateService fxService,
                       AdjTemplateService adjService,
                       ObservableValue<Client> activeClient) {
        this.journalService = journalService;
        this.periodService = periodService;
        this.accountService = accountService;
        this.fxService = fxService;
        this.adjService = adjService;
        this.activeClient = activeClient;
        setSpacing(12);

        getChildren().addAll(emptyState, workArea);
        // fill the window: whichever of the two states is visible grows to
        // the full content height instead of leaving dead space below
        VBox.setVgrow(emptyState, Priority.ALWAYS);
        VBox.setVgrow(workArea, Priority.ALWAYS);
        showEmptyState(true);

        client = activeClient.getValue();
        activeClient.addListener((obs, old, now) -> {
            client = now;
            refresh();
        });

        // 2.8.0: the layout setting re-renders the tab live
        Prefs.getInstance().journalModeProperty().addListener(
                (obs, old, now) -> applyJournalMode());
    }

    // ------------------------------------------------------------------
    // Layout
    // ------------------------------------------------------------------

    private static VBox buildEmptyState() {
        // 2.12.0: the shared empty-state builder — one look for
        // every view (glyph, title, hint), themed and density-aware
        return (VBox) EmptyState.of(
                "⌘",
                "Pick a client in the top bar — their journal opens here: periods, entries, posting and voiding.",
                "The ledgers and trial balance views read exactly what gets posted here.").node();
    }

    private VBox buildWorkArea() {
        newEntryButton.getStyleClass().add("lp-compact-btn");
        newEntryButton.setOnAction(e -> offerNewEntry());

        newPeriodButton.getStyleClass().add("lp-compact-btn");
        newPeriodButton.setOnAction(e -> offerNewPeriod());

        postButton.getStyleClass().add("lp-compact-btn");
        postButton.setDisable(true);
        postButton.setOnAction(e -> postSelected());

        voidButton.getStyleClass().add("lp-compact-btn");
        voidButton.setDisable(true);
        voidButton.setOnAction(e -> voidSelected());

        detailButton.getStyleClass().add("lp-compact-btn");
        detailButton.setDisable(true);
        detailButton.setOnAction(e -> showDetail(selectedEntry()));

        periodFilter.setPromptText("All periods");
        periodFilter.setPrefWidth(210);
        periodFilter.valueProperty().addListener((obs, old, now) -> reloadTable());

        // 2.10.0: search — memo, reference or entry-no prefix, live on typed
        // text over the cached rows (no database round trip per keystroke)
        search.setPromptText("Search memo, ref or #…");
        search.setPrefWidth(200);   // 2.11.0: flexible — hgrow widens it
        search.setTooltip(new Tooltip(
                "Filters the entries on screen: memo text, reference text, or an"
                        + " entry-number prefix (type '12' for entry 12, 120, …)."
                        + " Composes with the period and status filters."));
        search.textProperty().addListener((obs, old, now) -> applyFilters());

        // 2.10.0: status filter — All / Draft / Posted / Voided
        statusFilter.getStyleClass().add("lp-journal-status-filter");
        statusFilter.getItems().addAll(STATUS_ALL, "Draft", "Posted", "Voided");
        statusFilter.getSelectionModel().selectFirst();
        statusFilter.setTooltip(new Tooltip(
                "Show only entries in the picked status; composes with the"
                        + " period filter and the search box."));
        statusFilter.valueProperty().addListener((obs, old, now) -> applyFilters());

        closeButton.getStyleClass().add("lp-compact-btn");
        closeButton.setOnAction(e -> offerClosePeriod());

        // 2.10.0: CSV export of the FILTERED register
        exportButton.getStyleClass().add("lp-compact-btn");
        exportButton.setTooltip(new Tooltip(
                "Writes the entries currently on screen (after the period,"
                        + " search and status filters) to a CSV file: entry number,"
                        + " date, type, reference, memo, period, currency and rate,"
                        + " base amount, status."));
        exportButton.setOnAction(e -> exportCsv());

        // the layout toggle — one click swaps the paper journal and the flat
        // register; the choice persists like every other setting
        layoutButton.getStyleClass().add("lp-compact-btn");
        layoutButton.setTooltip(new Tooltip(
                "Register: one clean row per entry — the classic general-journal"
                        + " look. Paper journal: each entry unfolds into its Dr/Cr"
                        + " lines with the memo row underneath."));
        layoutButton.setOnAction(e -> {
            Prefs.JournalMode now = Prefs.getInstance().journalMode();
            Prefs.getInstance().setJournalMode(
                    now == Prefs.JournalMode.ENTRY_LINES
                            ? Prefs.JournalMode.REGISTER
                            : Prefs.JournalMode.ENTRY_LINES);
            applyJournalMode();   // instant: the other table is already built
        });
        updateLayoutButton();

        // 2.12.0: duplicate the selected entry into a prefilled New-entry
        // dialog — recurring transactions stop being retyped by hand
        duplicateButton.getStyleClass().add("lp-compact-btn");
        duplicateButton.setTooltip(new Tooltip(
                "Opens the New entry dialog prefilled with the selected"
                        + " entry's type, memo and lines — date lands on today,"
                        + " reference cleared. Check and save."));
        duplicateButton.setOnAction(e -> offerDuplicateEntry());

        // 2.11.0: the toolbar is TWO rows — the 2.10.0 single row carried
        // eight buttons plus the search box, the status combo, a caption and
        // the period combo (~1550 px at the design size), so on narrower
        // windows JavaFX ellipsized the button labels (the user's
        // screenshots show three truncated labels). Row 1: the actions.
        // Row 2: the filters, with the search box as the only flexible
        // control. Every button and combo is pinned to its computed size so
        // a label can NEVER be squeezed again.
        Button[] actions = {newEntryButton, newPeriodButton, postButton,
                voidButton, detailButton, duplicateButton, closeButton,
                layoutButton, exportButton};
        for (Button action : actions) {
            action.setMinWidth(Region.USE_COMPUTED_SIZE);
            action.setPrefWidth(Region.USE_COMPUTED_SIZE);
        }
        // 2.12.1 (P4-S3): New entry is THE primary action — the one
        // accent-filled button; every other button stays quiet
        newEntryButton.getStyleClass().add("lp-btn-primary");
        // Paper (the layout toggle) explains itself before you press it
        layoutButton.setTooltip(new Tooltip(
                "Switch the journal's layout. Register: one row per entry,"
                + " quick to scan. Paper: each entry unfolds into its Dr/Cr"
                + " lines like a printed journal page."));
        // grouped: Create | Period, then Selected entry | Output — the
        // 2.12.1 probe showed the nine-button row clipping even at
        // 1280px/130% (JavaFX rewrites the label text with '...'), so
        // the actions split into TWO rows that fit at every verified
        // size: R1 ≈ 350px, R2 ≈ 640px at 130%
        HBox actionRow = new HBox(10,
                newEntryButton, newPeriodButton, groupDivider(),
                closeButton);
        actionRow.setAlignment(Pos.CENTER_LEFT);
        HBox actionRow2 = new HBox(10,
                postButton, voidButton, detailButton, duplicateButton,
                groupDivider(), layoutButton, exportButton);
        actionRow2.setAlignment(Pos.CENTER_LEFT);

        Label periodCaption = new Label("Period:");
        search.setMinWidth(Region.USE_COMPUTED_SIZE);
        statusFilter.setMinWidth(Region.USE_COMPUTED_SIZE);
        statusFilter.setPrefWidth(Region.USE_COMPUTED_SIZE);
        periodCaption.setMinWidth(Region.USE_COMPUTED_SIZE);
        periodFilter.setMinWidth(Region.USE_COMPUTED_SIZE);
        HBox.setHgrow(search, Priority.ALWAYS);
        HBox filterRow = new HBox(10, search, statusFilter, periodCaption,
                periodFilter);
        filterRow.setAlignment(Pos.CENTER_LEFT);

        Region toolbarSpacer = new Region();
        HBox.setHgrow(toolbarSpacer, Priority.NEVER);
        VBox toolbar = new VBox(8, actionRow, actionRow2, filterRow);

        buildRegisterColumns();
        buildLinesColumns();
        applyJournalMode();

        banner.getStyleClass().add("lp-card-note");
        footer.getStyleClass().add("lp-muted");

        VBox area = new VBox(12, banner, toolbar, table, linesTable, footer);
        VBox.setVgrow(table, Priority.ALWAYS);
        VBox.setVgrow(linesTable, Priority.ALWAYS);
        area.setVisible(false);
        area.setManaged(false);
        return area;
    }

    /**
     * Swaps the visible table per the journal-mode preference. The other
     * table stays in the scene graph but unmanaged so a mode flip is an
     * instant relayout, not a rebuild. The toolbar toggle's label follows
     * the mode so it always offers the OTHER layout.
     */
    private void applyJournalMode() {
        boolean lines = Prefs.getInstance().journalMode() == Prefs.JournalMode.ENTRY_LINES;
        table.setVisible(!lines);
        table.setManaged(!lines);
        linesTable.setVisible(lines);
        linesTable.setManaged(lines);
        updateLayoutButton();
        reloadTable();
    }

    /** The toggle shows the layout you'd switch TO, not the current one. */
    private void updateLayoutButton() {
        // 2.11.0: short labels — the old "View as paper journal" wording was
        // one of the labels the single-row toolbar truncated; the tooltip
        // carries the full description
        layoutButton.setText(Prefs.getInstance().journalMode() == Prefs.JournalMode.ENTRY_LINES
                ? "Register" : "Paper");
    }

    // ------------------------------------------------------------------
    // REGISTER mode: one row per entry
    // ------------------------------------------------------------------

    private TableColumn<JournalService.EntrySummary, Long> amountColumn;

    private void buildRegisterColumns() {
        table.setId("lp-journal-register");
        // 2.12.1 (P4-S6): the em bands re-measure once the table is in a
        // scene (at build time the table has no scene, so UiSizing.em
        // fell back to the platform font and the bands were sized at
        // 13 px — clipping the Date column at 130% scale)
        table.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                reszeEmBands();
            }
        });
        UiScale.getInstance().scaleProperty().addListener((obs, o, n) ->
                reszeEmBands());
        table.setPlaceholder(new Label("No entries yet — record the first one with"
                + " “New entry…”. A period and an active chart are needed first."));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<JournalService.EntrySummary, Integer> no = new TableColumn<>("No");
        no.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().entry().entryNo()));
        // 2.12.1 (P4-S2): fixed widths in EM (via UiSizing against the
        // table's own font) so nothing important truncates at 100% text
        // scale, and TABULAR digits for No/Date/Amount so the figures
        // align down the register
        no.setMinWidth(UiSizing.em(table) * 4.2);
        no.setMaxWidth(UiSizing.em(table) * 4.6);
        emBands.put(no, new double[]{4.2, 4.6});
        no.getStyleClass().addAll("lp-col-strong", "lp-col-tabular");
        emBands.put(no, new double[]{4.2, 4.6});
        // 2.12.1 (P4-S4): sort arrows — No sorts numerically
        no.setSortable(true);
        no.setComparator(java.util.Comparator.comparingInt(
                c -> c == null ? 0 : c));

        TableColumn<JournalService.EntrySummary, String> date = new TableColumn<>("Date");
        date.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().entry().date().toString()));
        date.setMinWidth(UiSizing.em(table) * 8.4);
        date.setMaxWidth(UiSizing.em(table) * 8.8);
        emBands.put(date, new double[]{8.4, 8.8});
        date.getStyleClass().add("lp-col-tabular");
        // 2.12.1 (P4-S4): sort arrows — Date sorts chronologically
        date.setSortable(true);
        date.setComparator(java.util.Comparator.comparing(
                s -> s == null ? "" : s));

        TableColumn<JournalService.EntrySummary, String> type = new TableColumn<>("Type");
        type.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().entry().type().label));
        type.setMinWidth(UiSizing.em(table) * 7.0);
        type.setMaxWidth(UiSizing.em(table) * 7.6);
        emBands.put(type, new double[]{7.0, 7.6});

        TableColumn<JournalService.EntrySummary, String> reference = new TableColumn<>("Ref");
        reference.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().entry().reference() == null ? ""
                        : c.getValue().entry().reference()));
        reference.setMinWidth(UiSizing.em(table) * 6.0);
        reference.setMaxWidth(UiSizing.em(table) * 6.8);
        emBands.put(reference, new double[]{6.0, 6.8});

        TableColumn<JournalService.EntrySummary, String> memo = new TableColumn<>("Memo");
        memo.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().entry().memo() == null ? "" : c.getValue().entry().memo()));
        // 2.12.1 (P4-S2): the flex column (CONSTRAINED policy): takes
        // the remaining width; the cell carries a Tooltip with the FULL
        // memo so an ellipsized cell never hides the text
        memo.setMinWidth(UiSizing.em(table) * 14);
        emBands.put(memo, new double[]{14, 999});
        memo.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? "" : item);
                // 2.12.1 (P4-S2): voided memos read struck through
                boolean struck = !empty && getTableRow() != null
                        && getTableRow().getItem() != null
                        && ((JournalService.EntrySummary) getTableRow().getItem()).voided();
                getStyleClass().remove("lp-memo-voided");
                if (struck) {
                    getStyleClass().add("lp-memo-voided");
                }
                setTooltip(empty || item == null || item.isBlank() ? null
                        : new Tooltip(item));
            }
        });

        TableColumn<JournalService.EntrySummary, String> period = new TableColumn<>("Period");
        period.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().periodName()));
        period.setMinWidth(UiSizing.em(table) * 9.0);
        period.setMaxWidth(UiSizing.em(table) * 9.6);
        emBands.put(period, new double[]{9.0, 9.6});

        TableColumn<JournalService.EntrySummary, String> currency = new TableColumn<>("FX");
        currency.setCellValueFactory(c -> {
            JournalEntry entry = c.getValue().entry();
            return new SimpleStringProperty(entry.currency() == null ? "—"
                    : entry.currency() + " @ " + Money.rate(entry.fxRate()));
        });
        currency.setMinWidth(UiSizing.em(table) * 10.5);
        currency.setMaxWidth(UiSizing.em(table) * 11.2);
        emBands.put(currency, new double[]{10.5, 11.2});

        // 2.10.0: initialize the header from the working client when one is
        // already known — the first paint after a client switch showed a
        // bare "Amount" until refresh() set the currency
        amountColumn = new TableColumn<>(client != null
                ? "Amount (" + client.baseCurrency() + ")" : "Amount");
        amountColumn.setCellValueFactory(c -> new SimpleObjectProperty<>(
                c.getValue().totalBaseCents()));
        amountColumn.setMinWidth(UiSizing.em(table) * 13.0);
        amountColumn.setMaxWidth(UiSizing.em(table) * 13.6);
        emBands.put(amountColumn, new double[]{13.0, 13.6});
        amountColumn.setCellFactory(col -> new MoneyCell<>());
        // 2.11.1 (kept): the LEDGERS look — bold, success-green,
        // right-aligned (MoneyCell). 2.12.1 (P4-S2): tabular digits and
        // a right-aligned HEADER so the title sits over its figures
        amountColumn.getStyleClass().addAll("lp-col-money-strong",
                "lp-col-tabular", "lp-col-head-right");

        // 2.11.1: the Entry No column carries the ledger's strong-ink
        // treatment too (its "Entry" twin is bold there)
        no.getStyleClass().add("lp-col-strong");

        TableColumn<JournalService.EntrySummary, String> status = new TableColumn<>("Status");
        status.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().voided() ? "Voided"
                        : c.getValue().entry().posted() ? "Posted" : "Draft"));
        // 2.12.1 (P4-S2): the pill cell (Posted green / Draft amber /
        // Voided red) with left padding so an amount never touches it
        status.setMinWidth(UiSizing.em(table) * 7.4);
        status.setMaxWidth(UiSizing.em(table) * 8.0);
        emBands.put(status, new double[]{7.4, 8.0});
        status.getStyleClass().add("lp-col-status");
        status.setCellFactory(col -> new StatusCell<>());

        table.getColumns().addAll(no, date, type, reference, memo, period, currency,
                amountColumn, status);
        table.getSelectionModel().selectedItemProperty().addListener(
                (obs, old, now) -> updateActionButtons());
        table.setRowFactory(view -> {
            TableRow<JournalService.EntrySummary> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    showDetail(row.getItem());
                }
            });
            // 2.12.1 (P4-S1): the style classes are ADDED, never setAll —
            // setAll dropped "table-row-cell" itself, which removed the
            // skin's row height, padding, hover and selection styles (the
            // AtlantaFX row styling lives on that pseudo-class). The
            // per-state classes swap below keep table-row-cell first.
            row.itemProperty().addListener((obs, old, now) -> {
                var classes = row.getStyleClass();
                classes.removeAll("lp-row-voided", "lp-row-normal",
                        "lp-row-odd", "lp-row-even");
                if (now != null) {
                    // 2.8.0 zebra returns (Phase 4): every other row a
                    // slightly deeper tint so long registers scan
                    classes.add(row.getIndex() % 2 == 0
                            ? "lp-row-even" : "lp-row-odd");
                    classes.add(now.voided() ? "lp-row-voided" : "lp-row-normal");
                }
            });
            // the stripe follows the row's index, not its item (rows are
            // reused as the list scrolls — updateTableRequest keeps parity)
            row.indexProperty().addListener((obs, old, now) -> {
                var classes = row.getStyleClass();
                boolean odd = now.intValue() % 2 == 1;
                if (classes.contains("lp-row-odd") != odd) {
                    classes.removeAll("lp-row-odd", "lp-row-even");
                    classes.add(odd ? "lp-row-odd" : "lp-row-even");
                }
            });
            row.opacityProperty().unbind();
            return row;
        });

        MenuItem detail = new MenuItem("View lines…");
        detail.disableProperty().bind(detailButton.disableProperty());
        // 2.10.0: menu actions route through the mode-aware selectedEntry()
        // so a selection left in the (hidden) other table can never act
        // on the wrong entry
        detail.setOnAction(e -> showDetail(selectedEntry()));
        MenuItem post = new MenuItem("Post");
        post.disableProperty().bind(postButton.disableProperty());
        post.setOnAction(e -> postSelected());
        MenuItem voidItem = new MenuItem("Void…");
        voidItem.disableProperty().bind(voidButton.disableProperty());
        voidItem.setOnAction(e -> voidSelected());
        table.setContextMenu(new ContextMenu(detail, post, voidItem));

        // 2.10.0: Enter opens the selected entry's lines (double-click
        // unchanged); F5 forces a reload — the dashboard's own convention
        table.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                showDetail(selectedEntry());
                event.consume();
            } else if (event.getCode() == KeyCode.F5) {
                reloadTable();
                event.consume();
            }
        });
        linesTable.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                showDetail(selectedEntry());
                event.consume();
            } else if (event.getCode() == KeyCode.F5) {
                reloadTable();
                event.consume();
            }
        });
    }

    // ------------------------------------------------------------------
    // ENTRY_LINES mode: the paper journal — Dr/Cr lines + '# memo' row
    // ------------------------------------------------------------------

    /** One visual row of the ENTRY_LINES table. */
    record JournalRow(long entryId, int entryNo, String date, String memo, String status,
                      boolean firstOfEntry, boolean memoRow, String accountText,
                      Long drCents, Long crCents, String typeText, String periodName) {

        /** The entry this row belongs to (null-safe for the memo row). */
        long owner() {
            return entryId;
        }
    }

    private void buildLinesColumns() {
        linesTable.setPlaceholder(new Label("No entries yet — record the first one with"
                + " “New entry…”. A period and an active chart are needed first."));
        linesTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<JournalRow, Integer> no = new TableColumn<>("No");
        no.setCellValueFactory(c -> new SimpleObjectProperty<>(
                c.getValue().memoRow() ? null : c.getValue().entryNo()));
        no.setPrefWidth(56);
        no.getStyleClass().add("lp-col-strong");

        TableColumn<JournalRow, String> date = new TableColumn<>("Date");
        date.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().firstOfEntry() ? c.getValue().date() : ""));
        date.setPrefWidth(104);

        TableColumn<JournalRow, String> type = new TableColumn<>("Type");
        type.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().firstOfEntry() && c.getValue().typeText() != null
                        ? c.getValue().typeText() : ""));
        type.setMinWidth(UiSizing.em(table) * 7.0);
        type.setMaxWidth(UiSizing.em(table) * 7.6);

        TableColumn<JournalRow, String> account = new TableColumn<>("Account");
        account.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().memoRow() ? "#" + c.getValue().memo() : c.getValue().accountText()));
        account.setPrefWidth(400);
        account.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else if (item.startsWith("#")) {
                    Label memoLabel = new Label(item);
                    memoLabel.getStyleClass().add("lp-journal-memo");
                    memoLabel.setWrapText(true);
                    setGraphic(memoLabel);
                } else {
                    setText(item);
                    setGraphic(null);
                }
            }
        });

        TableColumn<JournalRow, Long> dr = new TableColumn<>("Debit");
        dr.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().drCents()));
        dr.setPrefWidth(130);
        dr.setCellFactory(col -> new MoneyCell<>());

        TableColumn<JournalRow, Long> cr = new TableColumn<>("Credit");
        cr.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().crCents()));
        cr.setPrefWidth(130);
        cr.setCellFactory(col -> new MoneyCell<>());

        TableColumn<JournalRow, String> period = new TableColumn<>("Period");
        period.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().firstOfEntry() && c.getValue().periodName() != null
                        ? c.getValue().periodName() : ""));
        period.setMinWidth(UiSizing.em(table) * 9.0);
        period.setMaxWidth(UiSizing.em(table) * 9.6);

        TableColumn<JournalRow, String> status = new TableColumn<>("Status");
        status.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().firstOfEntry() ? c.getValue().status() : ""));
        status.setPrefWidth(96);
        status.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.isEmpty()) {
                    setGraphic(null);
                } else {
                    Label pill = new Label(item);
                    pill.getStyleClass().setAll("lp-journal-pill",
                            switch (item) {
                                case "Posted" -> "lp-journal-pill-ok";
                                case "Voided" -> "lp-journal-pill-void";
                                default -> "lp-journal-pill-draft";
                            });
                    setGraphic(pill);
                }
            }
        });

        linesTable.getColumns().addAll(no, date, type, account, dr, cr, period, status);
        linesTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, old, now) -> updateActionButtons());
        linesTable.setRowFactory(view -> {
            TableRow<JournalRow> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    showDetail(summaryOf(row.getItem().owner()));
                }
            });
            // entry-group styling: the first line of an entry carries the
            // group's top border; the memo row carries the bottom border +
            // a paper-like tint; a voided entry dims its whole group
            row.itemProperty().addListener((obs, old, now) -> {
                // 2.12.1 (P4-S1): ADD the group classes — setAll dropped
                // "table-row-cell", losing the skin's height/padding/hover
                var classes = row.getStyleClass();
                classes.removeAll("lp-lines-first", "lp-lines-memo",
                        "lp-row-voided", "lp-row-normal");
                if (now != null) {
                    if (now.firstOfEntry()) {
                        classes.add("lp-lines-first");
                    }
                    if (now.memoRow()) {
                        classes.add("lp-lines-memo");
                    }
                    JournalService.EntrySummary summary = summaryOf(now.owner());
                    if (summary != null && summary.voided()) {
                        classes.add("lp-row-voided");
                    } else {
                        classes.add("lp-row-normal");
                    }
                }
            });
            return row;
        });

        MenuItem detail = new MenuItem("View lines…");
        detail.disableProperty().bind(detailButton.disableProperty());
        // 2.10.0: mode-aware — the hidden register's selection can't act
        detail.setOnAction(e -> showDetail(selectedEntry()));
        MenuItem post = new MenuItem("Post");
        post.disableProperty().bind(postButton.disableProperty());
        post.setOnAction(e -> postSelected());
        MenuItem voidItem = new MenuItem("Void…");
        voidItem.disableProperty().bind(voidButton.disableProperty());
        voidItem.setOnAction(e -> voidSelected());
        linesTable.setContextMenu(new ContextMenu(detail, post, voidItem));
    }

    /**
     * Builds the ENTRY_LINES rows for the loaded entries: per entry, its
     * debit lines (Dr column), credit lines (Cr column), then the
     * '# memo' continuation row. Lines list oldest-first per entry so the
     * debits read before the credits, the way paper journals print them.
     */
    private ObservableList<JournalRow> buildLinesRows(
            List<JournalService.EntrySummary> summaries) {
        ObservableList<JournalRow> rows = FXCollections.observableArrayList();
        for (JournalService.EntrySummary summary : summaries) {
            JournalEntry entry = summary.entry();
            List<JournalService.LineRow> lines = linesByEntry.getOrDefault(
                    entry.id(), List.of());
            boolean first = true;
            for (JournalService.LineRow line : lines) {
                String accountText = line.account().code() + " — " + line.account().name();
                rows.add(new JournalRow(entry.id(), entry.entryNo(),
                        entry.date().toString(), entry.memo() == null ? "" : entry.memo(),
                        statusOf(summary), first, false, accountText,
                        line.line().debitCents(), line.line().creditCents(),
                        entry.type().label, summary.periodName()));
                first = false;
            }
            // entries with no lines still print (a draft saved before its
            // lines were added): the memo row carries the entry
            rows.add(new JournalRow(entry.id(), entry.entryNo(), entry.date().toString(),
                    entry.memo() == null ? "" : entry.memo(), statusOf(summary),
                    first, true, null, null, null,
                    entry.type().label, summary.periodName()));
        }
        return rows;
    }

    private static String statusOf(JournalService.EntrySummary summary) {
        return summary.voided() ? "Voided"
                : summary.entry().posted() ? "Posted" : "Draft";
    }

    /**
     * Finds the loaded summary of an entry id (null when not loaded).
     * 2.10.0: O(1) — a map built once per reload replaced the linear scan
     * that ran per style callback and per selection lookup.
     */
    private JournalService.EntrySummary summaryOf(long entryId) {
        return summaryById.get(entryId);
    }

    private void showEmptyState(boolean empty) {
        emptyState.setVisible(empty);
        emptyState.setManaged(empty);
        workArea.setVisible(!empty);
        workArea.setManaged(!empty);
    }

    // ------------------------------------------------------------------
    // Data flow
    // ------------------------------------------------------------------

    @Override
    public void refresh() {
        if (client == null) {
            showEmptyState(true);
            // 2.10.0: no residue of the last client's text in the empty state
            banner.setText("");
            footer.setText("");
            return;
        }
        showEmptyState(false);
        // 2.12.1 (P4-S4): the formal banner — code · name · currency,
        // exactly the client's own data; the double-entry motto moved to
        // the footer (it reads better next to the counts it guards)
        banner.setText("Journal — " + client.code() + " · " + client.name()
                + " · Reports in " + client.baseCurrency());
        amountColumn.setText("Amount (" + client.baseCurrency() + ")");

        periods = periodService.list(client.id());
        Period previous = periodFilter.getValue();
        periodFilter.getItems().setAll(periods);
        // 2.10.0 stale-filter fix: when the previously selected period does
        // not exist for THIS client, clear it outright — leaving the stale
        // period selected rendered an empty combo while getValue() still
        // returned the dead period, filtering the table on an id that
        // cannot match anything until the user re-picked. clearSelection()
        // alone does NOT do this: a ComboBox keeps its value after the
        // selection model is cleared — setValue(null) is what resets it.
        if (previous == null) {
            periodFilter.setValue(null);
        } else {
            Period stillThere = periods.stream()
                    .filter(p -> p.id() == previous.id())
                    .findFirst().orElse(null);
            if (stillThere != null) {
                periodFilter.setValue(stillThere);
            } else {
                periodFilter.setValue(null);
            }
        }

        reloadTable();
    }

    /**
     * Re-reads the entries for the working client and the picked period,
     * then runs the filter pipeline. The search and status filters NEVER
     * re-read — they call {@link #applyFilters()} directly over the cached
     * rows, so typing costs no database round trip.
     */
    private void reloadTable() {
        if (client == null) {
            return;
        }
        // 2.12.0: the reads ride the shared background reader (UiLoad) —
        // a full-year register or ENTRY_LINES expansion no longer freezes
        // the FX thread on the 1.6 GHz target. The epoch guard drops any
        // read that finishes after a newer reload started (client switch,
        // F5 storm), and the client guard drops reads whose client is no
        // longer the working one.
        long clientNow = client.id();
        long periodNow = periodFilter.getValue() == null ? -1
                : periodFilter.getValue().id();
        boolean linesMode =
                Prefs.getInstance().journalMode() == Prefs.JournalMode.ENTRY_LINES;
        long epoch = loadEpoch.incrementAndGet();

        UiLoad.async(() -> {
            List<JournalService.EntrySummary> rows =
                    journalService.list(clientNow, periodNow < 0 ? null : periodNow);
            Map<Long, List<JournalService.LineRow>> lines = linesMode
                    ? journalService.linesForEntries(clientNow) : Map.of();
            Map<Long, JournalService.EntrySummary> byId = new HashMap<>();
            for (JournalService.EntrySummary summary : rows) {
                byId.put(summary.entry().id(), summary);
            }
            return new ReloadPayload(rows, lines, byId);
        }, payload -> {
            if (epoch != loadEpoch.get() || client == null || client.id() != clientNow) {
                return;   // a newer load or a client switch superseded this read
            }
            allRows = payload.rows();
            linesByEntry = payload.lines();
            summaryById = payload.byId();
            applyFilters();
        });
    }

    /** One finished background read (2.12.0). */
    private record ReloadPayload(List<JournalService.EntrySummary> rows,
                                 Map<Long, List<JournalService.LineRow>> lines,
                                 Map<Long, JournalService.EntrySummary> byId) {
    }

    /**
     * The filter pipeline (2.10.0): period (applied at read time) × search
     * text × status, over the cached rows; then the visible table, the
     * lines table, the kept selection and the footer statistics all update
     * from the filtered result in ONE pass.
     */
    private void applyFilters() {
        if (client == null) {
            return;
        }
        String needle = search.getText() == null ? "" : search.getText().trim().toLowerCase();
        String status = statusFilter.getValue();
        List<JournalService.EntrySummary> rows = new ArrayList<>(allRows);
        if (!needle.isEmpty()) {
            rows = rows.stream().filter(r -> {
                JournalEntry entry = r.entry();
                String memo = entry.memo() == null ? "" : entry.memo().toLowerCase();
                String reference = entry.reference() == null ? "" : entry.reference().toLowerCase();
                String no = Integer.toString(entry.entryNo());
                return memo.contains(needle) || reference.contains(needle)
                        || no.startsWith(needle);
            }).toList();
        }
        if (status != null && !STATUS_ALL.equals(status)) {
            rows = rows.stream().filter(r -> statusOf(r).equals(status)).toList();
        }
        visibleRows = rows;

        // the register table keeps its selection across reloads and refilters
        ObservableList<JournalService.EntrySummary> visible =
                FXCollections.observableArrayList(rows);
        JournalService.EntrySummary previous = table.getSelectionModel().getSelectedItem();
        table.setItems(visible);
        if (previous != null) {
            rows.stream()
                    .filter(r -> r.entry().id() == previous.entry().id())
                    .findFirst()
                    .ifPresent(r -> table.getSelectionModel().select(r));
        }

        // the lines table keeps its entry selection too
        JournalRow previousRow = linesTable.getSelectionModel().getSelectedItem();
        if (Prefs.getInstance().journalMode() == Prefs.JournalMode.ENTRY_LINES) {
            linesTable.setItems(buildLinesRows(rows));
            if (previousRow != null) {
                linesTable.getItems().stream()
                        .filter(r -> r.entryId() == previousRow.entryId())
                        .findFirst()
                        .ifPresent(r -> linesTable.getSelectionModel().select(r));
            }
        }

        // 2.10.0: the footer describes the FILTERED set in one pass — the
        // counts always match exactly what is on screen, and the period
        // name is appended when a period filter is active
        long drafts = 0;
        long voided = 0;
        long posted = 0;
        long postedVolume = 0;
        for (JournalService.EntrySummary row : rows) {
            if (row.voided()) {
                voided++;
            } else if (row.entry().posted()) {
                posted++;
                postedVolume += row.totalBaseCents();
            } else {
                drafts++;
            }
        }
        Period period = periodFilter.getValue();
        // 2.12.1 (P4-S4): cleaner — counts, posted volume, the period,
        // ONE closing note (was two chained tails)
        footer.setText(rows.size() + " entries · " + drafts + " draft · "
                + posted + " posted · " + voided + " voided"
                + " · posted volume " + Money.formatGrouped(postedVolume)
                + " " + client.baseCurrency()
                + (period == null ? "" : " · " + period.name())
                + " — voided entries are mirrored, never deleted");
        updateActionButtons();
    }

    /** CSV export of the FILTERED register (2.10.0). */
    private void exportCsv() {
        if (client == null || visibleRows.isEmpty()) {
            infoAlert("Nothing to export",
                    "The journal currently shows no entries — record or unfilter"
                            + " some first.");
            return;
        }
        String suggested = "journal-" + client.code() + "-"
                + LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE) + ".csv";
        javafx.stage.FileChooser chooser = new javafx.stage.FileChooser();
        chooser.setTitle("Export journal CSV");
        chooser.setInitialFileName(suggested);
        chooser.getExtensionFilters().add(
                new javafx.stage.FileChooser.ExtensionFilter("CSV files", "*.csv"));
        java.io.File target = chooser.showSaveDialog(
                getScene() == null ? null : getScene().getWindow());
        if (target == null) {
            return;
        }
        try (BufferedWriter out = Files.newBufferedWriter(
                target.toPath(), StandardCharsets.UTF_8)) {
            out.write("No,Date,Type,Ref,Memo,Period,FX,Amount ("
                    + client.baseCurrency() + "),Status");
            out.write("\r\n");
            for (JournalService.EntrySummary row : visibleRows) {
                JournalEntry entry = row.entry();
                out.write(String.join(",",
                        csv(Integer.toString(entry.entryNo())),
                        csv(entry.date().toString()),
                        csv(entry.type().label),
                        csv(entry.reference() == null ? "" : entry.reference()),
                        csv(entry.memo() == null ? "" : entry.memo()),
                        csv(row.periodName()),
                        csv(entry.currency() == null ? ""
                                : entry.currency() + " @ " + Money.rate(entry.fxRate())),
                        csv(Long.toString(row.totalBaseCents())),
                        csv(statusOf(row))));
                out.write("\r\n");
            }
        } catch (IOException e) {
            ClientsView.errorAlert(new IllegalStateException(
                    "The CSV could not be written (" + e.getMessage()
                            + "). Check the folder is writable and the file is not"
                            + " open in another program."));
            return;
        }
        infoAlert("Exported " + visibleRows.size() + " entries",
                "Written to " + target.getAbsolutePath()
                        + ".\nAmounts are base-currency cents as plain integers.");
    }

    /** CSV quoting: wrap in quotes, double embedded quotes. */
    private static String csv(String field) {
        String clean = field == null ? "" : field;
        boolean needsQuotes = clean.contains(",") || clean.contains("\"")
                || clean.contains("\n") || clean.contains("\r");
        String escaped = clean.replace("\"", "\"\"");
        return needsQuotes ? '"' + escaped + '"' : escaped;
    }

    private void updateActionButtons() {
        JournalService.EntrySummary selected = selectedEntry();
        detailButton.setDisable(selected == null);
        postButton.setDisable(selected == null || selected.entry().posted()
                || selected.voided());
        voidButton.setDisable(selected == null || !selected.entry().posted()
                || selected.voided() || selected.entry().voidOfId() != null);
    }

    /** The entry the visible table has selected, in either mode. */
    private JournalService.EntrySummary selectedEntry() {
        if (Prefs.getInstance().journalMode() == Prefs.JournalMode.ENTRY_LINES) {
            JournalRow row = linesTable.getSelectionModel().getSelectedItem();
            return row == null ? null : summaryOf(row.entryId());
        }
        return table.getSelectionModel().getSelectedItem();
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    private void offerNewPeriod() {
        if (client == null) {
            return;
        }
        PeriodDialog dialog = new PeriodDialog(periodService, client.id());
        if (getScene() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        Optional<Period> result = dialog.showAndWait();
        result.ifPresent(created -> {
            refresh();
            periodFilter.getItems().stream()
                    .filter(p -> p.id() == created.id())
                    .findFirst()
                    .ifPresent(p -> periodFilter.setValue(p));
        });
    }

    /**
     * The 2.7.0 Close Period wizard: the pre-close checklist, then the
     * closing entry drafts (generated, never auto-posted), then posting
     * and locking — the full accounting-cycle close the audit plan's
     * Sprint 2 specified. Uses the ClosingService behind a modal dialog
     * so the accountant sees each checklist row before anything happens.
     */
    private void offerClosePeriod() {
        if (client == null) {
            return;
        }
        if (closingService == null) {
            closingService = new com.ledgerpro.service.ClosingService(
                    journalService.database(), journalService,
                    accountService);
        }
        Period target = periodFilter.getValue();
        if (target == null && !periods.isEmpty()) {
            target = periods.getLast();
        }
        if (target == null) {
            infoAlert("No period to close",
                    "Create a period first — the close needs a period to zero out.");
            return;
        }
        if (target.closed()) {
            infoAlert("Period closed already",
                    "Period '" + target.name() + "' is closed. Reopen it from the"
                            + " period manager first if corrections are needed.");
            return;
        }

        java.util.List<com.ledgerpro.service.ClosingService.CheckItem> items =
                closingService.closeChecklist(target.id());
        boolean blocked = items.stream().anyMatch(i -> i.blocking() && !i.ok());
        if (blocked) {
            StringBuilder message = new StringBuilder("The close is blocked:\n\n");
            for (com.ledgerpro.service.ClosingService.CheckItem item : items) {
                if (item.blocking() && !item.ok()) {
                    message.append("  ✗ ").append(item.label())
                            .append(" — ").append(item.detail()).append("\n");
                }
            }
            message.append("\nClear these first (post or void the drafts), then close.");
            Alert alert = new Alert(Alert.AlertType.WARNING, message.toString(), ButtonType.OK);
            alert.setTitle("Close blocked");
            alert.setHeaderText(null);
            if (getScene() != null) {
                alert.initOwner(getScene().getWindow());
            }
            alert.showAndWait();
            return;
        }

        StringBuilder summary = new StringBuilder("Close '" + target.name()
                + "' (" + target.start() + " … " + target.end() + ")?\n\n");
        for (com.ledgerpro.service.ClosingService.CheckItem item : items) {
            summary.append(item.ok() ? "  ✓ " : "  ○ ")
                    .append(item.label()).append(" — ").append(item.detail()).append("\n");
        }
        summary.append("\nThe wizard generates the closing entry drafts (revenues and")
                .append(" expenses to Income Summary, its net to Retained Earnings,")
                .append(" dividends closed too), reviews them in the journal, posts them,")
                .append(" then locks the period.");

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, summary.toString(),
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Close period");
        confirm.setHeaderText(null);
        if (getScene() != null) {
            confirm.initOwner(getScene().getWindow());
        }
        if (confirm.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) {
            return;
        }

        try {
            com.ledgerpro.service.ClosingService.ClosingSet set =
                    closingService.generateAndPost(target.id());
            periodService.close(target.id());
            StringBuilder done = new StringBuilder("Period '" + target.name()
                    + "' closed.\n\n");
            done.append("Closing entries posted: ").append(set.entries().size()).append("\n");
            done.append("Net income closed to Retained Earnings: ")
                    .append(com.ledgerpro.ui.Money.format(set.netIncomeCents()))
                    .append("\n\n");
            done.append("The post-closing trial balance now shows only permanent")
                    .append(" accounts; the Income Summary account zeroed itself out.");
            Alert ok = new Alert(Alert.AlertType.INFORMATION, done.toString(), ButtonType.OK);
            ok.setTitle("Closed");
            ok.setHeaderText(null);
            if (getScene() != null) {
                ok.initOwner(getScene().getWindow());
            }
            ok.showAndWait();
            refresh();
        } catch (RuntimeException e) {
            Alert fail = new Alert(Alert.AlertType.ERROR,
                    "The close failed:\n\n" + e.getMessage(), ButtonType.OK);
            fail.setTitle("Close failed");
            fail.setHeaderText(null);
            if (getScene() != null) {
                fail.initOwner(getScene().getWindow());
            }
            fail.showAndWait();
        }
    }

    /**
     * 2.12.0: duplicates the selected entry — the New entry dialog opens
     * prefilled with the source's type, memo, currency and lines (today's
     * date, no reference). Nothing is written until the user saves.
     */
    private void offerDuplicateEntry() {
        if (client == null) {
            return;
        }
        JournalService.EntrySummary selected = selectedEntry();
        if (selected == null) {
            infoAlert("Select an entry to duplicate",
                    "Click the entry to duplicate first — the register's"
                            + " selection drives this action.");
            return;
        }
        List<Account> accounts = accountService.list(client.id(), false);
        if (accounts.isEmpty()) {
            infoAlert("The chart of accounts is empty",
                    "Duplication needs the entry's accounts to still exist.");
            return;
        }
        List<Period> open = periods.stream().filter(p -> !p.closed()).toList();
        if (open.isEmpty()) {
            infoAlert("No open period",
                    "A duplicate is a new entry, and entries live inside an open"
                            + " accounting period. Create one with “New period…” first.");
            return;
        }
        Period preferred = periodFilter.getValue() != null && !periodFilter.getValue().closed()
                ? periodFilter.getValue() : open.getFirst();
        List<JournalService.LineRow> sourceLines =
                journalService.lines(selected.entry().id());
        EntryDialog dialog = new EntryDialog(client, open, preferred, accounts,
                fxService, journalService, adjService,
                selected.entry(), sourceLines);
        if (getScene() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        Optional<JournalEntry> result = dialog.showAndWait();
        result.ifPresent(created -> {
            reloadTable();
            selectEntry(created.id());
        });
    }

    /** Opens the New entry dialog; public for the shell's Ctrl+N shortcut. */
    void offerNewEntry() {
        if (client == null) {
            return;
        }
        List<Period> open = periods.stream().filter(p -> !p.closed()).toList();
        if (open.isEmpty()) {
            infoAlert("No open period",
                    "Entries live inside an accounting period.\n\nCreate one with"
                            + " “New period…” first — e.g. the fiscal year or the current month.");
            return;
        }
        List<Account> accounts = accountService.list(client.id(), false);
        if (accounts.isEmpty()) {
            infoAlert("The chart of accounts is empty",
                    "Entries hit accounts.\n\nBuild the client's chart first — the"
                            + " “Apply template…” button in Chart of Accounts seeds a"
                            + " preset chart in one click.");
            return;
        }

        Period preferred = periodFilter.getValue() != null && !periodFilter.getValue().closed()
                ? periodFilter.getValue() : open.getFirst();
        EntryDialog dialog = new EntryDialog(client, open, preferred, accounts,
                fxService, journalService, adjService);
        if (getScene() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        Optional<JournalEntry> result = dialog.showAndWait();
        result.ifPresent(created -> {
            reloadTable();
            selectEntry(created.id());
        });
    }

    /** Selects an entry in whichever table is visible (2.8.0: both modes). */
    private void selectEntry(long entryId) {
        if (Prefs.getInstance().journalMode() == Prefs.JournalMode.ENTRY_LINES) {
            linesTable.getItems().stream()
                    .filter(r -> r.entryId() == entryId)
                    .findFirst()
                    .ifPresent(r -> {
                        linesTable.getSelectionModel().clearSelection();
                        linesTable.getSelectionModel().select(r);
                    });
        } else {
            table.getItems().stream()
                    .filter(r -> r.entry().id() == entryId)
                    .findFirst()
                    .ifPresent(r -> {
                        table.getSelectionModel().clearSelection();
                        table.getSelectionModel().select(r);
                    });
        }
    }

    private void postSelected() {
        JournalService.EntrySummary selected = selectedEntry();
        if (selected == null) {
            return;
        }
        try {
            JournalEntry posted = journalService.post(selected.entry().id());
            reloadTable();
            selectEntry(posted.id());
        } catch (RuntimeException e) {
            ClientsView.errorAlert(e);
        }
    }

    private void voidSelected() {
        JournalService.EntrySummary selected = selectedEntry();
        if (selected == null) {
            return;
        }
        JournalEntry entry = selected.entry();

        // the Settings' "Confirm before voiding" preference (on by default):
        // when off, voiding proceeds without the reason prompt
        boolean ask = Prefs.getInstance().isVoidPrompted();
        String why = "voided without a reason prompt (confirmation off in Settings)";
        if (ask) {
            TextInputDialog reason = new TextInputDialog();
            reason.setTitle("Void entry #" + entry.entryNo());
            reason.setHeaderText("Void “" + (entry.memo() == null ? "no memo" : entry.memo()) + "”?");
            reason.setContentText("Reason (kept in the audit trail):");
            reason.getEditor().setPromptText("e.g. duplicate of the October utility bill");
            if (getScene() != null) {
                reason.initOwner(getScene().getWindow());
            }
            Optional<String> typed = reason.showAndWait();
            if (typed.isEmpty()) {
                return;   // cancelled
            }
            why = typed.orElse("");
        }

        try {
            journalService.voidEntry(entry.id(), why);
            reloadTable();
        } catch (RuntimeException e) {
            ClientsView.errorAlert(e);
        }
    }

    private void showDetail(JournalService.EntrySummary summary) {
        if (summary == null) {
            return;
        }
        EntryDetailDialog dialog = new EntryDetailDialog(client, summary,
                journalService.lines(summary.entry().id()), adjService);
        if (getScene() != null) {
            dialog.initOwner(getScene().getWindow());
        }
        dialog.showAndWait();
    }

    private void infoAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        alert.setTitle(title);
        alert.setHeaderText(null);
        if (getScene() != null) {
            alert.initOwner(getScene().getWindow());
        }
        alert.showAndWait();
    }
}
