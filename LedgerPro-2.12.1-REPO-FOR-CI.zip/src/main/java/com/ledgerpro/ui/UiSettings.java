package com.ledgerpro.ui;

import javafx.scene.Scene;

/**
 * Scene-level application points of the Settings dialog (2.5.0): the pieces
 * that act on a live scene rather than a singleton flag. Kept separate so
 * views never need to know how a preference lands.
 */
public final class UiSettings {

    private static final String COMPACT_CLASS = "lp-density-compact";

    private UiSettings() {
    }

    /**
     * Applies the density choice to a live scene: compact adds the
     * {@code .lp-density-compact} root class (CSS re-spaces every paddable
     * surface), comfortable removes it.
     */
    public static void applyDensity(Scene scene, boolean compact) {
        if (scene == null || scene.getRoot() == null) {
            return;
        }
        if (compact) {
            if (!scene.getRoot().getStyleClass().contains(COMPACT_CLASS)) {
                scene.getRoot().getStyleClass().add(COMPACT_CLASS);
            }
        } else {
            scene.getRoot().getStyleClass().remove(COMPACT_CLASS);
        }
    }
}
