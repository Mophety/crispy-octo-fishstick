package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.dev.DemoData;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.Scene;

/**
 * The Settings dialog (2.5.0; 2.6.0 layout + dashboard refresh; 2.11.2 data
 * section): the app's central control room, reached from the sidebar's
 * SETTINGS button —
 *
 * <ul>
 *   <li><b>Appearance</b> — theme (the six shipped looks), text size (Auto
 *       responsive or a pinned 85%–130%), compact density, animations
 *       (default off). Every control applies LIVE: the open scene
 *       re-styles/rescales as the choice is made, so settings are felt
 *       before they are saved.</li>
 *   <li><b>Money</b> — grouping of amounts in tables and statements
 *       (1,234,567.89 vs 1234567.89) and the zero display (0.00 vs blank).</li>
 *   <li><b>Workspace</b> — the view the app opens on, whether the window
 *       remembers its geometry between launches, the confirmation prompt
 *       before voiding an entry, and how often the live dashboard
 *       re-reads its figures (2.6.0: off / 5s / 15s / 30s).</li>
 *   <li><b>Data</b> — 2.11.2: load the demo books (Northwind Retail
 *       Trading, a full FY2026 cycle) into an empty database, from here —
 *       no need to know the separate LedgerPro-demo launcher exists.</li>
 * </ul>
 *
 * <p><b>2.6.0 layout fix:</b> the pane is sized generously (min 640 wide,
 * 540 tall, up to 760×680) and the content carries real padding (24 px
 * sides, 18 top/bottom) with 14 px gaps between rows — the 2.5.0 panel sat
 * at one tight width with controls pressed against the pane's edge.</p>
 *
 * <p>All of it persists through the {@code ledgerpro/app} preferences node
 * the rest of the app already reads, so a setting survives restarts with zero
 * new infrastructure. Everything is written on change (no OK/Cancel
 * semantics to trip over — the dialog closes with Close); a Reset button
 * restores the factory defaults and re-applies them LIVE (theme, text size,
 * density all react immediately, not on next launch).</p>
 */
public final class SettingsDialog extends Dialog<Void> {

    /** Legacy entry point: a settings dialog without the data section hook. */
    public SettingsDialog(Scene ownerScene) {
        this(ownerScene, null, null);
    }

    /**
     * Full entry point (2.11.2): also carries the database behind the
     * Data section's demo-data button, and the hook the shell runs after
     * demo books land — re-read the client switcher, refresh the visible
     * view and pick the new client up.
     */
    public SettingsDialog(Scene ownerScene, Database database,
                           Runnable afterDemoSeed) {
        setTitle("Settings");
        setHeaderText(null);

        DialogPane pane = getDialogPane();
        pane.getButtonTypes().addAll(ButtonType.CLOSE);
        // Esc closes, Ctrl/Cmd+Enter fires the default button
        UiStartup.wireDialogAccelerators(pane);
        // 2.6.0: generous width so hints wrap at readable line lengths, and
        // generous height so the sections read as one composed panels
        pane.setMinWidth(640);
        pane.setMinHeight(540);
        pane.setPrefWidth(700);
        pane.setPrefHeight(620);

        VBox content = new VBox(7);
        content.setPadding(new Insets(18, 24, 18, 24));
        content.setSpacing(7);

        content.getChildren().addAll(
                section("APPEARANCE"),
                appearanceSection(ownerScene),
                new Separator(),
                section("MONEY"),
                moneySection(),
                new Separator(),
                section("WORKSPACE"),
                workspaceSection(ownerScene),
                new Separator(),
                section("DATA"),
                dataSection(database, afterDemoSeed),
                new Separator(),
                section("ABOUT THIS PANEL"),
                aboutSection());

        pane.setContent(content);
        UiStartup.makeScrollable(pane, content);
        // 2.9.0: resizable — the tall settings panel stretches with the
        // window instead of scrolling in a fixed box
        UiStartup.makeResizable(this, 720, 560);

        // the dialog itself enters gently (no-op with motion off)
        pane.sceneProperty().addListener((obs, old, now) -> {
            if (now != null) {
                UiMotion.playDialogEnter(pane);
            }
        });
    }

    // ------------------------------------------------------------------
    // section builders
    // ------------------------------------------------------------------

    private static Label section(String caption) {
        Label label = new Label(caption);
        label.getStyleClass().add("lp-settings-section");
        return label;
    }

    /** A settings row: control + one-line explanation underneath. */
    private static VBox row(String caption, Region control, String hint) {
        Label name = new Label(caption);
        name.getStyleClass().add("lp-col-strong");
        Label help = new Label(hint);
        help.getStyleClass().add("lp-field-hint");
        help.setWrapText(true);
        VBox box = new VBox(2, name, control, help);
        box.getStyleClass().add("lp-settings-row");
        VBox.setVgrow(control, Priority.NEVER);
        return box;
    }

    // ------------------------------------------------------------------
    // APPEARANCE
    // ------------------------------------------------------------------

    private VBox appearanceSection(Scene ownerScene) {
        Prefs prefs = Prefs.getInstance();

        // --- theme: applies live to the open scene
        ComboBox<Theme> themeBox = new ComboBox<>();
        themeBox.getItems().addAll(Theme.values());
        themeBox.getSelectionModel().select(ThemeManager.current());
        themeBox.setMaxWidth(Double.MAX_VALUE);
        themeBox.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(Theme theme) {
                return theme == null ? "" : theme.label();
            }
            @Override public Theme fromString(String string) { return null; }
        });
        if (ownerScene != null) {
            themeBox.valueProperty().addListener((obs, old, now) -> {
                if (now != null) {
                    ThemeManager.apply(now, ownerScene);
                }
            });
        }

        // --- text size: Auto or pinned, slider drives the live UiScale
        UiScale uiScale = UiScale.getInstance();
        ComboBox<UiScale.Mode> scaleModeBox = new ComboBox<>();
        scaleModeBox.getItems().addAll(UiScale.Mode.values());
        scaleModeBox.getSelectionModel().select(uiScale.getMode());
        scaleModeBox.setMaxWidth(Double.MAX_VALUE);
        scaleModeBox.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(UiScale.Mode mode) {
                return mode == UiScale.Mode.AUTO
                        ? "Auto — follows the window size"
                        : "Pinned — fixed size I choose";
            }
            @Override public UiScale.Mode fromString(String s) { return null; }
        });
        Slider sizeSlider = new Slider(0.85, 1.30, uiScale.getCustomScale());
        sizeSlider.setShowTickLabels(true);
        sizeSlider.setShowTickMarks(true);
        sizeSlider.setMajorTickUnit(0.15);
        sizeSlider.setMinorTickCount(2);
        sizeSlider.setSnapToPixel(false);
        sizeSlider.setMaxWidth(Double.MAX_VALUE);
        sizeSlider.setTooltip(new Tooltip(
                "Drag to pin a text size. In Auto mode a drag also switches to"
                        + " Pinned at that size (the choice is remembered)."));
        Label sizeReadout = new Label();
        sizeReadout.getStyleClass().add("lp-scale-value");
        Runnable updateSize = () -> {
            double shown = uiScale.getMode() == UiScale.Mode.AUTO
                    ? uiScale.getScale() : uiScale.getCustomScale();
            sizeReadout.setText(Math.round(shown * 100) + "%"
                    + (uiScale.getMode() == UiScale.Mode.AUTO ? " (auto now)" : " (pinned)"));
        };
        uiScale.scaleProperty().addListener((obs, old, now) -> updateSize.run());
        scaleModeBox.valueProperty().addListener((obs, old, now) -> {
            if (now != null) {
                uiScale.setMode(now);
                if (now == UiScale.Mode.FIXED) {
                    sizeSlider.setValue(uiScale.getCustomScale());
                }
                updateSize.run();
            }
        });
        sizeSlider.valueProperty().addListener((obs, old, now) -> {
            // dragging the slider means the user wants a pinned size: switch
            // modes first so the value lands in the right place (2.6.0 —
            // before, a drag in Auto mode silently wrote a pinned value
            // the UI ignored until the combo was flipped by hand)
            if (uiScale.getMode() == UiScale.Mode.AUTO) {
                scaleModeBox.getSelectionModel().select(UiScale.Mode.FIXED);
            }
            uiScale.setCustomScale(now.doubleValue());
            updateSize.run();
        });
        updateSize.run();

        // --- density: compact vs comfortable, live class on the scene root
        CheckBox densityBox = new CheckBox("Compact density");
        densityBox.setSelected(prefs.isCompactDensity());
        densityBox.selectedProperty().addListener((obs, old, now) -> {
            prefs.setCompactDensity(now);
            UiSettings.applyDensity(ownerScene, now);
        });

        // --- animations: OFF by default, persisted
        CheckBox animBox = new CheckBox("Animations");
        animBox.setSelected(UiMotion.isEnabled());
        animBox.selectedProperty().addListener((obs, old, now) -> {
            UiMotion.setEnabled(now);
            prefs.setAnimationsEnabled(now);
        });

        VBox box = new VBox(8,
                row("Theme", themeBox,
                        "Re-skins the whole application live — the six shipped looks"
                                + " (Primer Light/Dark, Nord Light/Dark, Dracula,"
                                + " Alexia's forest green)."),
                row("Text size", new VBox(4, scaleModeBox, sizeSlider, sizeReadout),
                        "Auto re-fits every text to the window (85%–130%). Pinned"
                                + " holds one chosen size through restarts — dragging"
                                + " the slider pins it at that size directly."),
                row("Density", densityBox,
                        "Compact packs rows, cards and paddings tighter — more of the"
                                + " worksheet fits a laptop screen."),
                row("Animations", animBox,
                        "View changes glide and fade (short, ease-out). Off keeps every"
                                + " transition instant — the default."));
        return box;
    }

    // ------------------------------------------------------------------
    // MONEY
    // ------------------------------------------------------------------

    private VBox moneySection() {
        Prefs prefs = Prefs.getInstance();

        CheckBox groupingBox = new CheckBox("Group thousands with commas");
        groupingBox.setSelected(prefs.isMoneyGrouped());
        groupingBox.selectedProperty().addListener((obs, old, now) -> {
            prefs.setMoneyGrouped(now);
            Money.setGrouping(now);
        });

        CheckBox zeroBox = new CheckBox("Show zeros as 0.00 (blank otherwise)");
        zeroBox.setSelected(prefs.isZeroShown());
        zeroBox.selectedProperty().addListener((obs, old, now) -> {
            prefs.setZeroShown(now);
            Money.setZeroShown(now);
        });

        return new VBox(8,
                row("Amounts in tables and statements", groupingBox,
                        "1,234,567.89 when on; 1234567.89 when off. Exports keep their"
                                + " own exact-figures format either way."),
                row("Zero amounts", zeroBox,
                        "Blank zero cells keep the worksheet reading like the paper"
                                + " sheet; 0.00 makes every zero explicit."));
    }

    // ------------------------------------------------------------------
    // WORKSPACE
    // ------------------------------------------------------------------

    private VBox workspaceSection(Scene ownerScene) {
        Prefs prefs = Prefs.getInstance();

        ComboBox<String> startupBox = new ComboBox<>();
        for (ViewId id : ViewId.values()) {
            startupBox.getItems().add(id.title);
        }
        startupBox.getSelectionModel().select(
                Math.max(0, indexOfStartup(prefs.startupView())));
        startupBox.setMaxWidth(Double.MAX_VALUE);
        startupBox.valueProperty().addListener((obs, old, now) -> {
            if (now != null) {
                for (ViewId id : ViewId.values()) {
                    if (id.title.equals(now)) {
                        prefs.setStartupView(id);
                        break;
                    }
                }
            }
        });

        // 2.8.0: the journal tab's two display modes
        ComboBox<Prefs.JournalMode> journalBox = new ComboBox<>();
        journalBox.getItems().addAll(Prefs.JournalMode.values());
        journalBox.getSelectionModel().select(prefs.journalMode());
        journalBox.setMaxWidth(Double.MAX_VALUE);
        journalBox.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(Prefs.JournalMode mode) {
                return mode == null ? "" : mode.label();
            }
            @Override public Prefs.JournalMode fromString(String s) { return null; }
        });
        journalBox.valueProperty().addListener((obs, old, now) -> {
            if (now != null) {
                prefs.setJournalMode(now);
            }
        });

        // 2.6.0: how often the live dashboard re-reads its figures
        ComboBox<Prefs.DashboardRefresh> refreshBox = new ComboBox<>();
        refreshBox.getItems().addAll(Prefs.DashboardRefresh.values());
        refreshBox.getSelectionModel().select(prefs.dashboardRefresh());
        refreshBox.setMaxWidth(Double.MAX_VALUE);
        refreshBox.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(Prefs.DashboardRefresh rate) {
                return rate == null ? "" : rate.label;
            }
            @Override public Prefs.DashboardRefresh fromString(String s) { return null; }
        });
        refreshBox.valueProperty().addListener((obs, old, now) -> {
            if (now != null) {
                prefs.setDashboardRefresh(now);
            }
        });

        CheckBox geometryBox = new CheckBox("Remember window size and position");
        geometryBox.setSelected(prefs.isGeometryRemembered());
        geometryBox.selectedProperty().addListener((obs, old, now) ->
                prefs.setGeometryRemembered(now));

        CheckBox voidPromptBox = new CheckBox("Confirm before voiding an entry");
        voidPromptBox.setSelected(prefs.isVoidPrompted());
        voidPromptBox.selectedProperty().addListener((obs, old, now) ->
                prefs.setVoidPrompted(now));

        Button resetButton = new Button("Reset all settings to defaults");
        resetButton.getStyleClass().add("lp-compact-btn");
        resetButton.setOnAction(e -> resetAll(ownerScene));

        return new VBox(8,
                row("Open on start", startupBox,
                        "The view the app shows right after launch."),
                row("Journal layout", journalBox,
                        "Register keeps one line per entry — the classic"
                                + " general-journal register and the default."
                                + " Entry lines unfolds every entry into its debit"
                                + " and credit lines with a '# memo' row under"
                                + " them — the paper bookkeeping look."),
                row("Dashboard live refresh", refreshBox,
                        "How often the client dashboard re-reads its cards and"
                                + " charts while it is the visible view — the reads"
                                + " run on a background thread, so the app never"
                                + " waits on them."),
                row("Window", geometryBox,
                        "When on, size/position/maximized state restore on the next"
                                + " launch; off always opens the default window."),
                row("Safety", voidPromptBox,
                        "A confirmation dialog before a journal entry is voided"
                                + " (voiding is always reversible, but the prompt"
                                + " catches slips)."),
                row("Reset", resetButton,
                        "Restores the factory defaults for every setting in this"
                                + " panel (theme, sizes, density, animations, money,"
                                + " workspace) — applied immediately, not on next"
                                + " launch."));
    }

    private static int indexOfStartup(ViewId id) {
        ViewId[] values = ViewId.values();
        for (int i = 0; i < values.length; i++) {
            if (values[i] == id) {
                return i;
            }
        }
        return 0;
    }

    // ------------------------------------------------------------------
    // DATA (2.11.2 — the demo books, loadable from Settings)
    // ------------------------------------------------------------------

    /**
     * The demo-data row: one button, guarded by {@link DemoData#canSeed} —
     * the demo seeds only a database with NO client rows at all, archived
     * ones included (an archived client still owns journal entries, FX
     * snapshots and shared adjustment templates, so seeding would write
     * over real books). The row says so plainly instead of hiding the rule
     * in a tooltip.
     */
    private VBox dataSection(Database database, Runnable afterDemoSeed) {
        Button demoButton = new Button("Load demo data");
        demoButton.getStyleClass().add("lp-compact-btn");

        if (database == null) {
            // constructed without the hook (legacy call sites): show the
            // rule, but not a button that cannot do anything
            demoButton.setDisable(true);
            return new VBox(8, row("Demo books", demoButton,
                    "Not available here — restart and use the LedgerPro-demo"
                            + " launcher."));
        }

        boolean canSeed = DemoData.canSeed(database);
        if (canSeed) {
            demoButton.setOnAction(e -> loadDemoData(database, afterDemoSeed));
        } else {
            demoButton.setDisable(true);
            demoButton.setTooltip(new Tooltip(
                    "The database already holds clients — archived ones count,"
                            + " because their books and shared rates are still"
                            + " in the database. The demo never writes over"
                            + " real data."));
        }

        String demoHint = canSeed
                ? "Fills the empty database with Northwind Retail Trading —"
                  + " a full FY2026 cycle: capital, prepayments, a USD equipment"
                  + " purchase converted at a cached rate, payroll with"
                  + " statutory contributions, a voided duplicate honestly"
                  + " reversed, recurring adjustment templates and the"
                  + " closing reports. Refreshes every view immediately."
                : "The database already holds clients, so the demo stays"
                  + " out — it never writes over real books. Archiving a"
                  + " client is not emptying the database (its entries and"
                  + " shared rates stay in place); to explore the demo,"
                  + " quit the app, move or rename the database file"
                  + " (~/.ledgerpro/ledgerpro.db on macOS/Windows"
                  + " Home), then start the app again — it creates a"
                  + " fresh one.";

        // 2.12.0: one-click backup + restore, beside the demo row
        Button backupButton = new Button("Back up now");
        backupButton.getStyleClass().add("lp-compact-btn");
        backupButton.setOnAction(e -> backupNow(database));
        Button restoreButton = new Button("Restore from backup…");
        restoreButton.getStyleClass().add("lp-compact-btn");
        restoreButton.setOnAction(e -> restoreFromBackup(database, afterDemoSeed));

        return new VBox(8,
                row("Demo books", demoButton, demoHint),
                row("Backups", new HBox(8, backupButton, restoreButton),
                        "One consistent snapshot into ~/.ledgerpro/backups"
                                + " (timestamped). Restore re-migrates an older"
                                + " backup to the current schema automatically."));
    }

    /**
     * 2.12.0: writes the snapshot and says where it landed. Same code the
     * command palette's "Back up the books now" runs.
     */
    private void backupNow(Database database) {
        try {
            java.nio.file.Path target =
                    new com.ledgerpro.service.BackupService(database).backupNow();
            Alert done = new Alert(Alert.AlertType.INFORMATION,
                    "A consistent snapshot of the whole database was written to:\n\n"
                            + target,
                    ButtonType.OK);
            done.setHeaderText("Backup saved");
            done.setTitle("LedgerPro");
            if (getDialogPane().getScene() != null) {
                done.initOwner(getDialogPane().getScene().getWindow());
            }
            done.showAndWait();
        } catch (RuntimeException e) {
            ClientsView.errorAlert(new IllegalStateException(
                    "The backup could not be written: " + e.getMessage()));
        }
    }

    /**
     * 2.12.0: picks a backup file, restores it over the live database
     * (after a confirmation that says what gets replaced), re-migrates,
     * then refreshes everything the shell owns.
     */
    private void restoreFromBackup(Database database, Runnable afterRestore) {
        javafx.stage.FileChooser chooser = new javafx.stage.FileChooser();
        chooser.setTitle("Restore from backup");
        chooser.setInitialDirectory(
                com.ledgerpro.service.BackupService.defaultBackupFolder().toFile());
        chooser.getExtensionFilters().add(
                new javafx.stage.FileChooser.ExtensionFilter(
                        "LedgerPro backups", "*.db", "*.sqlite"));
        java.io.File source = chooser.showOpenDialog(
                getDialogPane().getScene() == null ? null
                        : getDialogPane().getScene().getWindow());
        if (source == null) {
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Restore the books from this backup?\n\n" + source.getAbsolutePath()
                        + "\n\nThe CURRENT database is replaced by the backup's"
                        + " contents. Export a fresh backup first if the current"
                        + " books hold anything you still need.",
                ButtonType.YES, ButtonType.CANCEL);
        confirm.setHeaderText("Restore from backup");
        confirm.setTitle("LedgerPro");
        if (getDialogPane().getScene() != null) {
            confirm.initOwner(getDialogPane().getScene().getWindow());
        }
        if (confirm.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.YES) {
            return;
        }
        try {
            new com.ledgerpro.service.BackupService(database)
                    .restoreFrom(source.toPath());
        } catch (RuntimeException e) {
            ClientsView.errorAlert(new IllegalStateException(
                    "The restore failed: " + e.getMessage()
                            + ". The current database was left untouched where"
                            + " possible — verify with a fresh backup."));
            return;
        }
        if (afterRestore != null) {
            afterRestore.run();
        }
        Alert done = new Alert(Alert.AlertType.INFORMATION,
                "The books were restored from the backup and migrated to the"
                        + " current schema. Every view has refreshed.",
                ButtonType.OK);
        done.setHeaderText("Backup restored");
        done.setTitle("LedgerPro");
        if (getDialogPane().getScene() != null) {
            done.initOwner(getDialogPane().getScene().getWindow());
        }
        done.showAndWait();
    }

    /**
     * The button's act, kept out of the section builder: confirm, seed,
     * then let the shell re-read everything (client switcher, visible view,
     * db status) — the same refresh a view switch runs, so the demo books
     * appear without a restart. The seeding re-checks the guard itself;
     * if it comes back skipped, the user hears "skipped", not "done".
     */
    private void loadDemoData(Database database, Runnable afterDemoSeed) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Load the demo books into this database?\n\n"
                        + "Northwind Retail Trading, FY2026: journal entries, an"
                        + " FX cycle, adjustment templates and closing reports."
                        + " Nothing existing is touched — the demo only fills"
                        + " a database with no clients at all.",
                ButtonType.YES, ButtonType.CANCEL);
        confirm.setHeaderText("Load demo data");
        confirm.setTitle("LedgerPro");
        if (getDialogPane().getScene() != null) {
            confirm.initOwner(getDialogPane().getScene().getWindow());
        }
        if (confirm.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.YES) {
            return;
        }

        boolean seeded;
        try {
            seeded = DemoData.seedIfEmpty(database);
        } catch (RuntimeException e) {
            Alert warn = new Alert(Alert.AlertType.WARNING,
                    "The demo data could not be seeded:\n\n" + e.getMessage(),
                    ButtonType.OK);
            warn.setHeaderText(null);
            warn.setTitle("Demo data");
            if (getDialogPane().getScene() != null) {
                warn.initOwner(getDialogPane().getScene().getWindow());
            }
            warn.showAndWait();
            return;
        }

        if (!seeded) {
            // the guard says no: clients (archived included) appeared since
            // the button was built — say the truth, refresh nothing
            Alert skipped = new Alert(Alert.AlertType.WARNING,
                    "The demo was not loaded: this database already holds"
                            + " clients (archived ones count), and the demo never"
                            + " writes over real books.\n\nTo explore the demo,"
                            + " quit the app, move or rename the database file"
                            + " (~/.ledgerpro/ledgerpro.db), then start it again —"
                            + " a fresh database will be created.",
                    ButtonType.OK);
            skipped.setHeaderText("Demo skipped");
            skipped.setTitle("Demo data");
            if (getDialogPane().getScene() != null) {
                skipped.initOwner(getDialogPane().getScene().getWindow());
            }
            skipped.showAndWait();
            return;
        }

        if (afterDemoSeed != null) {
            afterDemoSeed.run();
        }

        Alert done = new Alert(Alert.AlertType.INFORMATION,
                "The demo books are loaded — Northwind Retail Trading, FY2026."
                        + " Every view has refreshed; the working client is"
                        + " selected on the switcher.",
                ButtonType.OK);
        done.setHeaderText("Demo data loaded");
        done.setTitle("LedgerPro");
        if (getDialogPane().getScene() != null) {
            done.initOwner(getDialogPane().getScene().getWindow());
        }
        done.showAndWait();
    }

    private VBox aboutSection() {
        Label text = new Label(
                "Everything applies live and is remembered between launches —"
                        + " there is no OK/Cancel to trip over: close when done."
                        + " Preferences live in the user profile (ledgerpro/app"
                        + " node), never in the accounting database.");
        text.getStyleClass().add("lp-field-hint");
        text.setWrapText(true);
        return new VBox(text);
    }

    /**
     * Reset now applies the defaults to the LIVE scene too (2.6.0): theme
     * reverts, text size returns to Auto, density class drops off — the
     * same panel is still open, so the user sees the reset happen instead
     * of discovering it on the next launch.
     */
    private void resetAll(Scene ownerScene) {
        Prefs prefs = Prefs.getInstance();
        prefs.resetDefaults();
        UiMotion.setEnabled(Prefs.DEFAULT_ANIMATIONS);
        Money.setGrouping(Prefs.DEFAULT_MONEY_GROUPED);
        Money.setZeroShown(Prefs.DEFAULT_ZERO_SHOWN);
        if (ownerScene != null) {
            ThemeManager.apply(ThemeManager.defaultTheme(), ownerScene);
            UiSettings.applyDensity(ownerScene, false);
        }
        UiScale.getInstance().setMode(UiScale.Mode.AUTO);
        Button close = (Button) getDialogPane().lookupButton(ButtonType.CLOSE);
        if (close != null) {
            close.fire();
        }
    }
}
