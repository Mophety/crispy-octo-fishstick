package com.ledgerpro.ui;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

import java.util.List;

/**
 * A row of equal-width cards that re-flows with the window (2.12.1).
 *
 * <p>The dashboard used to lay its cards out in {@code HBox}es with
 * {@code hgrow ALWAYS} and pixel minimums: on a wide screen every card
 * was fine, on a narrower one the HBox shrank all of them in equal steps,
 * a card's text wrapped into a tall column and the row pushed the cards
 * below it off the window. This grid keeps every cell the same width
 * (percent columns) and drops to fewer columns per row as soon as
 * {@code maxColumns} cells of {@code minCellEm} em no longer fit — so
 * cards shrink only down to their readable width and then stack.</p>
 *
 * <p>The threshold is in em of the grid's own font, so the break points
 * follow the Text scale exactly like the cards do.</p>
 */
final class ResponsiveGrid extends GridPane {

    private final int maxColumns;
    private final double minCellEm;

    /** The column count the constraints were last built for (-1 = none). */
    private int laidOutColumns = -1;

    /**
     * @param maxColumns columns per row when there is room
     * @param minCellEm  the narrowest a cell may get before the row wraps
     */
    ResponsiveGrid(int maxColumns, double minCellEm) {
        this.maxColumns = maxColumns;
        this.minCellEm = minCellEm;
        getStyleClass().add("lp-grid");
    }

    /** Replaces the cells (row-major order). */
    void setCells(List<Node> cells) {
        getChildren().setAll(cells);
        laidOutColumns = -1;
        requestLayout();
    }

    @Override
    protected void layoutChildren() {
        int columns = columnCount();
        if (columns != laidOutColumns) {
            laidOutColumns = columns;
            applyColumns(columns);
        }
        super.layoutChildren();
    }

    /** One cell wide at the very least, whatever the window does. */
    @Override
    protected double computeMinWidth(double height) {
        return minCellEm * UiSizing.em(this)
                + snappedLeftInset() + snappedRightInset();
    }

    /** The most columns that fit the grid's current width and text size. */
    private int columnCount() {
        double minPx = minCellEm * UiSizing.em(this);
        double gap = getHgap();
        double inside = getWidth() - snappedLeftInset() - snappedRightInset();
        int fit = 1;
        int limit = Math.min(maxColumns, Math.max(1, getChildren().size()));
        for (int columns = 2; columns <= limit; columns++) {
            if (columns * minPx + (columns - 1) * gap <= inside + 0.5) {
                fit = columns;
            }
        }
        return fit;
    }

    /** Equal percent columns, cells placed row-major. */
    private void applyColumns(int columns) {
        getColumnConstraints().clear();
        for (int i = 0; i < columns; i++) {
            ColumnConstraints constraints = new ColumnConstraints();
            constraints.setPercentWidth(100.0 / columns);
            constraints.setHgrow(Priority.ALWAYS);
            constraints.setFillWidth(true);
            getColumnConstraints().add(constraints);
        }
        List<Node> cells = getChildren();
        for (int index = 0; index < cells.size(); index++) {
            Node cell = cells.get(index);
            GridPane.setColumnIndex(cell, index % columns);
            GridPane.setRowIndex(cell, index / columns);
            GridPane.setHgrow(cell, Priority.ALWAYS);
        }
    }
}
