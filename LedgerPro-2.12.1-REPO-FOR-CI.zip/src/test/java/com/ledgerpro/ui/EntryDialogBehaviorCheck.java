package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.ui.Theme;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Behavior check for the journal-entry form's live save-button enablement
 * (dev tool, test sources — same package as the dialog so it can poke it).
 *
 * <p>The 2.2 bug this pins: the "Save &amp; post" / "Save draft" buttons'
 * disable binding observed only the header fields (date, period, currency),
 * so a fully typed, balanced entry kept its buttons dim until the accountant
 * touched one of THOSE. The check types a balanced entry WITHOUT ever
 * touching date / period / currency and asserts the buttons light up on the
 * last keystroke — plus the out-of-balance and back-in-balance transitions.</p>
 *
 * <pre>
 * xvfb-run -a java -cp ... com.ledgerpro.ui.EntryDialogBehaviorCheck /tmp/check.db [THEME]
 * </pre>
 */
public final class EntryDialogBehaviorCheck {

    private static int failures = 0;

    private static void check(boolean condition, String label) {
        System.out.println((condition ? "CHECK OK   " : "CHECK FAIL ") + label);
        if (!condition) {
            failures++;
        }
    }

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "/tmp/entry-behavior.db";
        Theme theme = args.length > 1
                ? Theme.valueOf(args[1].toUpperCase(java.util.Locale.ROOT))
                : Theme.PRIMER_LIGHT;

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                run(dbPath, theme);
            } catch (Throwable t) {
                failure.set(t);
            } finally {
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(60, TimeUnit.SECONDS)) {
            throw new IllegalStateException("behavior check timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("behavior check crashed", failure.get());
        }
        if (failures > 0) {
            throw new IllegalStateException(failures + " behavior check(s) failed");
        }
    }

    /** One editable line of the form, as seen from the scene graph. */
    private record Row(ComboBox<Account> account, TextField debit, TextField credit) {}

    private static void run(String dbPath, Theme theme) throws Exception {
        Application.setUserAgentStylesheet(theme.userAgentStylesheet());

        Database db = new Database(dbPath);
        db.migrate();
        ClientService clients = new ClientService(db);
        AccountService accounts = new AccountService(db);
        PeriodService periods = new PeriodService(db);
        FxRateService fx = new FxRateService(db);
        JournalService journal = new JournalService(db, fx);

        Client client = clients.create("ACME", "Acme Trading Corp.", "PHP");
        accounts.applyStandardChart(client.id());
        Period period = periods.create(client.id(), "FY2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));
        List<Period> open = periods.list(client.id()).stream()
                .filter(p -> !p.closed()).toList();
        List<Account> chart = accounts.list(client.id(), false);

        EntryDialog dialog = new EntryDialog(client, open, period, chart,
                fx, journal, null);
        DialogPane pane = dialog.getDialogPane();

        Scene scene = new Scene(new StackPane(pane), 900, 700);
        scene.getStylesheets().add(Objects.requireNonNull(
                EntryDialogBehaviorCheck.class.getResource("/css/ledgerpro.css")).toExternalForm());
        if (theme.overlayUrl() != null) {
            scene.getStylesheets().add(theme.overlayUrl());
        }
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        pane.applyCss();
        pane.layout();

        Button post = pane.lookupAll(".button").stream()
                .filter(n -> n instanceof Button)
                .map(n -> (Button) n)
                .filter(b -> "Save & post".equals(b.getText()))
                .findFirst().orElse(null);
        Button draft = pane.lookupAll(".button").stream()
                .filter(n -> n instanceof Button)
                .map(n -> (Button) n)
                .filter(b -> "Save draft".equals(b.getText()))
                .findFirst().orElse(null);
        check(post != null && draft != null, "both save buttons found");

        // ---- the starting state: everything empty -> disabled --------------
        check(post.isDisable(), "buttons disabled on an empty form");

        // ---- collect the rows from the scene graph (no coordinate sorting) -
        Map<Parent, List<Node>> byRow = new LinkedHashMap<>();
        for (Node node : pane.lookupAll(".text-field")) {
            if (node instanceof TextField tf && "0.00".equals(tf.getPromptText())) {
                byRow.computeIfAbsent(tf.getParent(), p -> new ArrayList<>()).add(tf);
            }
        }
        List<Row> rows = new ArrayList<>();
        for (Map.Entry<Parent, List<Node>> entry : byRow.entrySet()) {
            if (!(entry.getKey() instanceof HBox row)) {
                continue;   // the header labels row is not an edit row
            }
            TextField debit = null;
            TextField credit = null;
            ComboBox<Account> account = null;
            for (Node child : row.getChildrenUnmodifiable()) {
                if (child instanceof TextField tf && "0.00".equals(tf.getPromptText())) {
                    if (debit == null) {
                        debit = tf;
                    } else {
                        credit = tf;
                    }
                } else if (child instanceof ComboBox<?> combo && !combo.getItems().isEmpty()
                        && combo.getItems().get(0) instanceof Account) {
                    @SuppressWarnings("unchecked")
                    ComboBox<Account> cast = (ComboBox<Account>) combo;
                    account = cast;
                }
            }
            if (account != null && debit != null && credit != null) {
                rows.add(new Row(account, debit, credit));
            }
        }
        check(rows.size() == 2, "two edit rows discovered (found " + rows.size() + ")");
        if (rows.size() < 2 || post == null) {
            return;
        }

        // ---- type a balanced entry; NEVER touch date/period/currency -------
        rows.get(0).account().setValue(rows.get(0).account().getItems().get(0));
        rows.get(1).account().setValue(rows.get(1).account().getItems().get(1));
        rows.get(0).debit().setText("1250.00");
        rows.get(1).credit().setText("1250.00");

        // THE fix: enabled by the lines alone, no header poking
        check(!post.isDisable(),
                "Save & post ENABLED right after a balanced entry is typed");
        check(!draft.isDisable(), "Save draft follows the same rule");

        // ---- break the balance: must dim again immediately -----------------
        rows.get(1).credit().setText("900.00");
        check(post.isDisable(), "out-of-balance entry disables the buttons");

        // ---- repair: back on with the last keystroke ------------------------
        rows.get(1).credit().setText("1250.00");
        check(!post.isDisable(), "re-balancing re-enables the buttons");

        // ---- a malformed amount must also block saving ----------------------
        rows.get(0).debit().setText("12.5.0");
        check(post.isDisable(), "a malformed amount disables the buttons");
        rows.get(0).debit().setText("1250.00");
        check(!post.isDisable(), "fixing the amount re-enables the buttons");

        stage.hide();
    }
}
