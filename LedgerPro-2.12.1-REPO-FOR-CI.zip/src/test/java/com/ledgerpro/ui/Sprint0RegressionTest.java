package com.ledgerpro.ui;

import com.ledgerpro.dev.UiSnapshotSeed;
import com.ledgerpro.db.Database;
import com.ledgerpro.model.Client;
import com.ledgerpro.service.ClientService;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import java.nio.file.Files;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The 2.7.0 Sprint-0 regression pack: the three user-reported defects, each
 * with a test that FAILS against the 2.6.0 source and passes against the fix.
 *
 * <ul>
 *   <li><b>0.1 Dashboard empty</b> — the client dashboard must carry the
 *       selected client into the live-refresh path (liveClient) and read
 *       real figures; the shell must auto-select a client at startup.</li>
 *   <li><b>0.2 Animations dead</b> — a scene-attached node must actually
 *       animate through non-identity intermediates when motion is on.</li>
 *   <li><b>0.3 Anim toggle in the window</b> — the status bar carries
 *       readouts only; the Anim preference has no control there.</li>
 * </ul>
 *
 * <p>Runs the real JavaFX toolkit in software rendering (the same headless
 * recipe the shipped snapshot probes use), on a seeded throwaway database,
 * so the assertions watch the genuine wiring rather than a mock.</p>
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class Sprint0RegressionTest {

    private static Database database;
    private static Scene scene;
    private static AppShell shell;
    private static Client client;

    @BeforeAll
    static void boot() throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");
        CountDownLatch ready = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        // keep the FX thread alive for the whole class even though no
        // window stays open: implicit exit would tear the toolkit down
        // after the first close and every later runLater would queue forever
        // (the hang the first run hit)
        Platform.setImplicitExit(false);
        // 2.11.0: one surefire fork hosts several FX test classes (JournalFilters,
        // JournalReadability, this one); if an earlier class already booted the
        // toolkit, startup throws "Toolkit already initialized" — ride the live one
        try {
            Platform.startup(() -> { });
        } catch (IllegalStateException alreadyBooted) {
            // toolkit already initialized by an earlier class in this fork
        }
        Platform.runLater(() -> {
            try {
                java.nio.file.Path dir = Files.createTempDirectory("sprint0");
                database = new Database(dir.resolve("test.db").toString());
                database.migrate();
                UiSnapshotSeed.seedForScreenshots(database);

                scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                shell = (AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
                ready.countDown();
            } catch (Throwable t) {
                failure.set(t);
                ready.countDown();
            }
        });
        assertTrue(ready.await(60, TimeUnit.SECONDS), "JavaFX boot timed out");
        assertNull(failure.get(), "JavaFX boot failed");
    }

    @AfterAll
    static void shutdown() {
        // 2.7.0 fix for the first run's hang: never await a runLater from
        // the main thread here — the FX Application Thread can already be
        // gone after the last Stage closes, and the latch would never fire.
        // 2.10.0: Platform.exit() is GONE entirely — the suite now has more
        // than one FX-booting test class in this single surefire fork, and
        // an exit (even from a daemon thread) permanently kills the toolkit
        // for whichever FX class runs after this one (the next
        // Platform.startup throws "Platform.exit has been called"). The
        // toolkit is torn down with the JVM at fork teardown; nothing hangs
        // because nothing waits on it here.
    }

    /** Item 0.1: a working client exists right after startup (auto-select). */
    @Test
    @Order(1)
    void startupSelectsAClientAutomatically() throws Exception {
        AtomicReference<Client> selected = new AtomicReference<>();
        CountDownLatch done = new CountDownLatch(1);
        Platform.runLater(() -> {
            selected.set(shell.activeClientProperty().get());
            done.countDown();
        });
        assertTrue(done.await(10, TimeUnit.SECONDS));
        client = selected.get();
        assertNotNull(client, "2.6.0 defect: no working client auto-selected at startup");
    }

    /** Item 0.1: the dashboard fills with the client's figures. */
    @Test
    @Order(2)
    void dashboardShowsFiguresForSelectedClient() throws Exception {
        AtomicBoolean nonEmpty = new AtomicBoolean(false);
        AtomicReference<String> netIncomeText = new AtomicReference<>("");
        CountDownLatch done = new CountDownLatch(1);
        Platform.runLater(() -> {
            try {
                DashboardView dashboard = findDashboard();
                assertNotNull(dashboard, "dashboard view not in the scene");
                // switch to the dashboard and give the live read ~3s to land
                shell.show(ViewId.DASHBOARD);
            } finally {
                done.countDown();
            }
        });
        assertTrue(done.await(10, TimeUnit.SECONDS));
        // the live read happens on the dashboard's background thread; poll
        // the scene for a filled value label for up to 8 seconds
        long deadline = System.currentTimeMillis() + 8_000;
        while (System.currentTimeMillis() < deadline && !nonEmpty.get()) {
            CountDownLatch poll = new CountDownLatch(1);
            Platform.runLater(() -> {
                for (Node n : scene.getRoot().lookupAll(".lp-card-value")) {
                    String t = ((javafx.scene.control.Label) n).getText();
                    if (t != null && !t.isBlank() && !t.startsWith("—")) {
                        netIncomeText.compareAndSet("", t);
                        nonEmpty.set(true);
                    }
                }
                poll.countDown();
            });
            poll.await(1, TimeUnit.SECONDS);
            if (!nonEmpty.get()) {
                Thread.sleep(200);
            }
        }
        assertTrue(nonEmpty.get(),
                "2.6.0 defect: dashboard cards stayed empty (liveClient never set)"
                        + " — saw: " + netIncomeText.get());
    }

    /** Item 0.2: a scene-attached node actually animates when motion is on. */
    @Test
    @Order(3)
    void viewEnterAnimationPlaysThroughIntermediates() throws Exception {
        AtomicBoolean sawIntermediate = new AtomicBoolean(false);
        AtomicReference<Double> minOpacity = new AtomicReference<>(1.0);
        CountDownLatch finished = new CountDownLatch(1);
        Platform.runLater(() -> {
            UiMotion.setEnabled(true);
            try {
                Node node = shell.lookupAll(".lp-content").stream()
                        .filter(n -> n.getScene() != null)
                        .findFirst().orElse(null);
                assertNotNull(node, "content node not found in scene");
                // track opacity through the animation
                node.opacityProperty().addListener((obs, old, now) -> {
                    double nowValue = now.doubleValue();
                    if (nowValue < 1.0) {
                        sawIntermediate.set(true);
                        minOpacity.accumulateAndGet(nowValue, Math::min);
                    }
                });
                UiMotion.playViewEnter(node);
                // let the 180ms fade run, then assert
                javafx.animation.PauseTransition wait = new javafx.animation.PauseTransition(
                        javafx.util.Duration.millis(400));
                wait.setOnFinished(e -> finished.countDown());
                wait.play();
            } finally {
                UiMotion.setEnabled(false);
            }
        });
        assertTrue(finished.await(10, TimeUnit.SECONDS), "animation never finished");
        assertTrue(sawIntermediate.get(),
                "2.6.0 defect: playViewEnter never played (guard skipped a resting node)");
        assertTrue(minOpacity.get() < 0.5, "fade never went below 0.5 (min seen: "
                + minOpacity.get() + ")");
    }

    /** Item 0.3: the status bar holds readouts only — no Anim control. */
    @Test
    @Order(4)
    void statusBarCarriesNoAnimationControl() throws Exception {
        AtomicBoolean foundToggle = new AtomicBoolean(false);
        CountDownLatch done = new CountDownLatch(1);
        Platform.runLater(() -> {
            try {
                shell.show(ViewId.DASHBOARD);
            } finally {
                done.countDown();
            }
        });
        assertTrue(done.await(10, TimeUnit.SECONDS));
        CountDownLatch scan = new CountDownLatch(1);
        Platform.runLater(() -> {
            for (Node n : scene.getRoot().lookupAll(".lp-topbar")) {
                if (n instanceof javafx.scene.layout.HBox bar) {
                    for (Node child : bar.getChildren()) {
                        if (child instanceof javafx.scene.control.ToggleButton
                                || (child instanceof javafx.scene.control.Button)) {
                            String id = child.getId() == null ? "" : child.getId();
                            if (!id.isEmpty() || child instanceof
                                    javafx.scene.control.ToggleButton) {
                                foundToggle.set(true);
                            }
                        }
                    }
                }
            }
            scan.countDown();
        });
        assertTrue(scan.await(10, TimeUnit.SECONDS));
        assertTrue(!foundToggle.get(),
                "2.6.0 defect: a control (Anim toggle) still lives in the status bar");
    }

    /** Item 0.4: selecting a client is remembered across instances. */
    @Test
    @Order(5)
    void lastClientSelectionIsRemembered() throws Exception {
        CountDownLatch done = new CountDownLatch(1);
        Platform.runLater(() -> {
            try {
                ClientService clients = new ClientService(database);
                List<Client> list = clients.list(false);
                assertTrue(list.size() >= 1, "seeded database has clients");
                Client other = list.stream()
                        .filter(c -> client == null || c.id() != client.id())
                        .findFirst().orElse(list.getFirst());
                shell.selectWorkingClient(other);
                assertEquals(other.id(), Prefs.getInstance().lastClientId(),
                        "selection was not persisted to preferences");
                // and restoring by id re-selects the same client
                shell.selectWorkingClient(null);
                assertEquals(other.id(), shell.activeClientProperty().get().id(),
                        "remembered client was not restored");
            } finally {
                done.countDown();
            }
        });
        assertTrue(done.await(10, TimeUnit.SECONDS));
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private DashboardView findDashboard() {
        for (Node n : scene.getRoot().lookupAll(".lp-content")) {
            if (n instanceof javafx.scene.layout.StackPane) {
                for (Node child : ((javafx.scene.layout.StackPane) n).getChildren()) {
                    if (child instanceof DashboardView dv) {
                        return dv;
                    }
                }
            }
        }
        return null;
    }

    /** Exposes the scene to the test body (kept for future probes). */
    static Scene scene() {
        return scene;
    }

    static void assertNotSameClient(Client a, Client b) {
        assertNotEquals(a.id(), b.id(), "clients should differ");
    }
}
