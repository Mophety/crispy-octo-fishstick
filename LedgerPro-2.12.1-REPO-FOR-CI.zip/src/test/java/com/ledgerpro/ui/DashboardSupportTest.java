package com.ledgerpro.ui;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The dashboard's roll-up arithmetic (2.6.0): the ClientAggregates class
 * behind every card and chart, tested without JavaFX. The numbers here are
 * the numbers the live refresh paints, so a regression in the roll-up is
 * a regression on screen.
 */
class DashboardSupportTest {

    private static DashboardView.ClientAggregates agg(
            long revenueFeb, long revenueApr, long expenseJan, long expenseMar) {
        DashboardView.ClientAggregates a = new DashboardView.ClientAggregates();
        a.addRevenue("2026-02", revenueFeb);
        a.addRevenue("2026-04", revenueApr);
        a.addExpense("2026-01", expenseJan);
        a.addExpense("2026-03", expenseMar);
        return a;
    }

    @Test
    void netIncomeIsRevenueMinusExpenses() {
        DashboardView.ClientAggregates a = agg(
                12_000_000L, 3_500_000L, 1_800_000L, 240_000L);
        assertEquals(15_500_000L, a.totalRevenue());
        assertEquals(2_040_000L, a.totalExpenses());
        assertEquals(13_460_000L, a.netIncome());
    }

    @Test
    void aLossIsANegativeNetIncome() {
        DashboardView.ClientAggregates a = agg(500_000L, 0L, 800_000L, 100_000L);
        assertEquals(-400_000L, a.netIncome());
    }

    @Test
    void monthsMergeAcrossSeriesInOrder() {
        DashboardView.ClientAggregates a = agg(100L, 200L, 50L, 25L);
        // revenue in Feb+Apr, expenses in Jan+Mar: the trend chart's month
        // axis is the sorted union, gaps included
        assertEquals(List.of("2026-01", "2026-02", "2026-03", "2026-04"), a.months());
    }

    @Test
    void addRevenueAccumulatesWithinAMonth() {
        DashboardView.ClientAggregates a = new DashboardView.ClientAggregates();
        a.addRevenue("2026-07", 100L);
        a.addRevenue("2026-07", 250L);
        a.addRevenue("2026-08", 10L);
        assertEquals(360L, a.totalRevenue());
        assertEquals(2, a.months().size(), "Jul and Aug — two distinct months");
    }

    @Test
    void theBalanceProofReadsAsAssetsEqualLiabilitiesPlusEquity() {
        // 2.12.1 (C1): open period — assets = liabilities + equity + net income
        DashboardView.ClientAggregates a = new DashboardView.ClientAggregates();
        a.assets = 90_325L;
        a.liabilities = 4_000L;
        a.equity = 86_000L;
        a.addRevenue("2026-02", 325L);   // net income 325 completes the equation
        assertTrue(a.balanceHolds(),
                "assets = liabilities + equity + net income (open period)");

        DashboardView.ClientAggregates broken = new DashboardView.ClientAggregates();
        broken.assets = 90_325L;
        broken.liabilities = 4_000L;
        broken.equity = 86_000L;
        broken.addRevenue("2026-02", 300L);
        assertTrue(!broken.balanceHolds(), "a slipped entry fails the proof");

        // closed period — the closing entries folded income into equity
        DashboardView.ClientAggregates closed = new DashboardView.ClientAggregates();
        closed.periodClosed = true;
        closed.assets = 90_325L;
        closed.liabilities = 4_000L;
        closed.equity = 86_325L;
        closed.addRevenue("2026-02", 325L);
        assertTrue(closed.balanceHolds(),
                "closed period: net income is NOT double-counted");
    }

    @Test
    void aReversingEntryNetsItsVoidedOriginalToZeroInTheProof() {
        // 2.12.1 (C1): the voided 21,000 sale plus its REVERSING mirror
        // leave every aggregate untouched — the exact case the old query
        // dropped, which read the assets 21,000 high and called a balanced
        // ledger OUT OF BALANCE. The equation before and after the void
        // must both hold: the same 21,000 leaves revenue (net income) and
        // assets together.
        // Balanced ledger WITH the 21,000 sale live:
        //   assets 683,027.92 = 91,570 + 470,000 + net income 121,457.92
        DashboardView.ClientAggregates before = new DashboardView.ClientAggregates();
        before.assets = 683_027_92L;
        before.liabilities = 91_570_00L;
        before.equity = 470_000_00L;
        before.addRevenue("2026-10", 121_457_92L);
        assertTrue(before.balanceHolds());

        // voided + reversal: the sale leaves BOTH sides — assets lose
        // 21,000, revenue (net income) loses 21,000 — still balanced
        DashboardView.ClientAggregates after = new DashboardView.ClientAggregates();
        after.assets = 683_027_92L - 21_000_00L;
        after.liabilities = 91_570_00L;
        after.equity = 470_000_00L;
        after.addRevenue("2026-10", 121_457_92L - 21_000_00L);
        assertTrue(after.balanceHolds(),
                "voided + reversal nets to zero on BOTH sides of the equation");

        // and the anti-regression: what the OLD query produced — assets
        // still carry the sale (the mirror was dropped) while revenue
        // lost it — reads OUT OF BALANCE by exactly the voided amount
        DashboardView.ClientAggregates oldQuery = new DashboardView.ClientAggregates();
        oldQuery.assets = 683_027_92L;
        oldQuery.liabilities = 91_570_00L;
        oldQuery.equity = 470_000_00L;
        oldQuery.addRevenue("2026-10", 121_457_92L - 21_000_00L);
        assertTrue(!oldQuery.balanceHolds(),
                "dropping the mirror breaks the proof by the voided amount");
    }

    @Test
    void recentEntryAmountsAreTotalDebitsOneSideOfTheDoubleEntry() {
        // 2.12.1 (C2): the recents row carries the entry's total DEBITS —
        // the Journal tab's own Amount column rule — never both sides
        DashboardView.ClientAggregates a = new DashboardView.ClientAggregates();
        a.recents.add(new DashboardView.RecentEntry(
                1, 1, java.time.LocalDate.of(2026, 3, 5), "credit sale",
                21_000_00L, "Posted"));
        long volume = a.recents.stream()
                .filter(r -> "Posted".equals(r.status()))
                .mapToLong(DashboardView.RecentEntry::amountCents).sum();
        assertEquals(21_000_00L, volume,
                "one 21,000 entry posts volume 21,000 — not 42,000 (both sides)");
    }

    @Test
    void anEmptyPeriodRollsUpToZero() {
        DashboardView.ClientAggregates empty = new DashboardView.ClientAggregates();
        assertEquals(0L, empty.totalRevenue());
        assertEquals(0L, empty.totalExpenses());
        assertEquals(0L, empty.netIncome());
        assertTrue(empty.months().isEmpty());
        assertTrue(empty.balanceHolds(), "zero = zero + zero");
    }
}
