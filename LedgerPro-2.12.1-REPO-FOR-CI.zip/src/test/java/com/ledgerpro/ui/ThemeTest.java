package com.ledgerpro.ui;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The theme catalog behind the Appearance picker: every entry must resolve
 * its user-agent stylesheet and (when it declares one) its overlay CSS from
 * the application jar — a broken resource name would otherwise surface only
 * at first paint on a user's machine. Parsing of remembered names is pinned
 * too: unknown input falls back to the default look instead of failing the
 * launch.
 */
class ThemeTest {

    @Test
    void everyThemeCarriesAUserAgentStylesheet() {
        for (Theme theme : Theme.values()) {
            assertNotNull(theme.userAgentStylesheet(),
                    theme + " has no user-agent stylesheet");
            assertTrue(!theme.userAgentStylesheet().isBlank(),
                    theme + " has an empty user-agent stylesheet");
        }
    }

    @Test
    void overlayResourcesResolveWhenDeclared() {
        for (Theme theme : Theme.values()) {
            // 2.12.0: two themes carry overlays — Alexia (the whole look)
            // and Nord Dark (the WCAG AA muted-ink lift). Every other
            // theme must stay overlay-free so its palette is pure
            // AtlantaFX.
            if (theme == Theme.ALEXIA) {
                String url = theme.overlayUrl();
                assertNotNull(url, "Alexia's theme must ship its overlay stylesheet");
                assertTrue(url.endsWith("theme-alexia.css"),
                        "unexpected overlay for Alexia's theme: " + url);
            } else if (theme == Theme.NORD_DARK) {
                String url = theme.overlayUrl();
                assertNotNull(url, "Nord Dark must ship its AA overlay stylesheet");
                assertTrue(url.endsWith("theme-nord-dark-aa.css"),
                        "unexpected overlay for Nord Dark: " + url);
            } else {
                assertNull(theme.overlayUrl(),
                        theme + " should not carry an overlay stylesheet");
            }
        }
    }

    @Test
    void everyThemeHasAUserVisibleLabel() {
        for (Theme theme : Theme.values()) {
            assertNotNull(theme.label());
            assertTrue(!theme.label().isBlank(), theme + " has an empty label");
        }
    }

    @Test
    void parseFallsBackToPrimerLightForUnknownNames() {
        assertEquals(Theme.PRIMER_LIGHT, Theme.parse(null));
        assertEquals(Theme.PRIMER_LIGHT, Theme.parse(""));
        assertEquals(Theme.PRIMER_LIGHT, Theme.parse("NO_SUCH_THEME"));
        assertEquals(Theme.PRIMER_LIGHT, Theme.parse("alexia's theme"));
    }

    @Test
    void parseReadsBackEveryEnumName() {
        for (Theme theme : Theme.values()) {
            assertEquals(theme, Theme.parse(theme.name()));
        }
    }
}
