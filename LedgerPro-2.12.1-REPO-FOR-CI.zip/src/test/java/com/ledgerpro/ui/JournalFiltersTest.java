package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The 2.10.0 journal gates, against the real toolkit and a seeded
 * throwaway database (the same headless software-rendering recipe the
 * snapshot probes use):
 *
 * <ul>
 *   <li><b>the 2.3.1 default</b> — a fresh install opens the journal in
 *       REGISTER mode: one row per entry in the register table, the lines
 *       table hidden;</li>
 *   <li><b>the filters</b> — the search box and the status combo compose
 *       with the period filter over the cached rows, and the register
 *       shows exactly the filtered set (footer math covered by the same
 *       pass);</li>
 *   <li><b>no zebra/pill classes</b> — the register rows carry only the
 *       voided/normal classes, never the zebra or pill classes (the 2.3.1
 *       look restored);</li>
 *   <li><b>stale period filter</b> — switching clients clears a period
 *       selection that does not exist for the new client instead of
 *       silently filtering on a dead id.</li>
 * </ul>
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class JournalFiltersTest {

    /** Mirror of JournalView.STATUS_ALL (private there). */
    private static final String STATUS_ALL = "All statuses";

    private static Database database;
    private static Scene scene;
    private static AppShell shell;
    private static JournalView journal;
    private static ClientService clients;
    private static long nrth;
    private static long south;

    @BeforeAll
    static void boot() throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");
        CountDownLatch ready = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        // one surefire fork hosts several FX test classes: if the toolkit is
        // already up (Sprint0RegressionTest booted it first), startup would
        // throw "Toolkit already initialized" — just ride the live one
        try {
            Platform.startup(() -> { });
        } catch (IllegalStateException alreadyBooted) {
            // toolkit already initialized by an earlier class in this fork
        }
        Platform.setImplicitExit(false);
        Platform.runLater(() -> {
            try {
                Path dir = Files.createTempDirectory("jfilters");
                database = new Database(dir.resolve("test.db").toString());
                database.migrate();
                nrth = seed(database, "NRTH", "Norte Freight Systems, Inc.");
                south = seed(database, "SOUTH", "Southern Haulage Co.");

                scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                shell = (AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
                journal = journalViewOf(shell);
                ready.countDown();
            } catch (Throwable t) {
                failure.set(t);
                ready.countDown();
            }
        });
        assertTrue(ready.await(60, TimeUnit.SECONDS), "JavaFX boot timed out");
        assertNull(failure.get(), "JavaFX boot failed");
        assertNotNull(journal);
    }

    @AfterAll
    static void shutdown() {
        // NO Platform.exit() here: the suite runs in one fork and another
        // FX class (Sprint0RegressionTest) may run after this one — calling
        // exit would permanently kill the toolkit for the rest of the run
        // (the second startup throws "Platform.exit has been called").
        // Surefire's JVM exit tears the toolkit down with the process.
    }

    @Test
    void freshInstallOpensRegisterMode() throws Exception {
        // 2.10.0: the factory default is REGISTER (the 2.3.1 look). The
        // machine's preferences store persists across JVM runs, so the
        // DEFAULT constant + the parse fallback are the fresh-install
        // contract; the live instance is then set explicitly (the same
        // state a fresh install would boot with).
        assertEquals(Prefs.JournalMode.REGISTER, Prefs.DEFAULT_JOURNAL_MODE,
                "the factory default must be the flat register");
        assertEquals(Prefs.JournalMode.REGISTER, Prefs.JournalMode.parse("nonsense"));
        assertEquals(Prefs.JournalMode.REGISTER, Prefs.JournalMode.parse(null));
        Prefs.getInstance().setJournalMode(Prefs.JournalMode.REGISTER);
        assertEquals(Prefs.JournalMode.REGISTER, Prefs.getInstance().journalMode(),
                "the set mode must be the flat register");

        withClient(nrth, () -> {
            shell.show(ViewId.JOURNAL);
            TableView<?> register = registerTable();
            TableView<?> lines = linesTable();
            assertTrue(register.isVisible(), "register table must be the default");
            assertTrue(!lines.isVisible(), "lines table must be hidden by default");
            // one row per entry (6 posted + 1 draft)
            assertEquals(7, register.getItems().size(), "one row per entry");
            assertTrue(lines.getItems().isEmpty(),
                    "lines table carries no rows in register mode");
        });
    }

    @Test
    void registerRowsKeepSkinClassAndCarryZebra() throws Exception {
        withClient(nrth, () -> {
            shell.show(ViewId.JOURNAL);
            TableView<JournalService.EntrySummary> register = registerTable();
            for (int i = 0; i < register.getItems().size(); i++) {
                final int rowIndex = i;
                javafx.scene.Node row = register.lookupAll(".table-row-cell").stream()
                        .filter(n -> n instanceof javafx.scene.control.TableRow<?> tr
                                && tr.getIndex() == rowIndex)
                        .findFirst().orElse(null);
                if (row != null) {
                    ObservableList<String> classes = row.getStyleClass();
                    // 2.12.1 (P4-S1): the skin's own class SURVIVES the
                    // row factory (setAll used to drop it — losing the
                    // row height/padding/hover/selection styles)
                    assertTrue(classes.contains("table-row-cell"),
                            "skin class must survive");
                    // and every row carries its zebra parity class
                    assertTrue(classes.contains("lp-row-odd")
                            || classes.contains("lp-row-even"),
                            "zebra parity class on every row");
                    assertTrue(classes.stream().noneMatch(c ->
                            c.startsWith("lp-journal-pill")),
                            "no pill classes on register rows");
                }
            }
        });
    }

    @Test
    void searchFiltersTheRegisterLive() throws Exception {
        // 2.12.1: awaitRows FIRST — the register's read is async since the
        // 2.12.0 UiLoad work, so this test used to race its own first
        // assertion ("seeded year is visible (0)") and fail whole-suite
        // runs intermittently while passing alone. The body below is
        // unchanged; it just runs against settled rows now.
        withClient(nrth, () -> { }, true);
        withClient(nrth, () -> {
            shell.show(ViewId.JOURNAL);
            TableView<JournalService.EntrySummary> register = registerTable();
            int all = register.getItems().size();
            assertTrue(all >= 7, "seeded year is visible (" + all + ")");

            // memo text
            typeSearch("salaries");
            assertEquals(1, register.getItems().size(), "memo 'salaries' filters to 1");
            assertTrue(register.getItems().getFirst().entry().memo().contains("salaries"));

            // entry-number prefix: entry #1 also matches 10..19 — use exact-ish
            typeSearch("");
            typeSearch("rent");
            assertEquals(1, register.getItems().size(), "memo 'rent' filters to 1");

            // reference text
            typeSearch("");
            typeSearch("no-such-text");
            assertEquals(0, register.getItems().size(), "no match → empty register");

            typeSearch("");   // restore
            assertEquals(all, register.getItems().size());
        });
    }

    @Test
    void statusFilterComposesWithSearch() throws Exception {
        withClient(nrth, () -> {
            shell.show(ViewId.JOURNAL);
            TableView<JournalService.EntrySummary> register = registerTable();

            pickStatus("Draft");
            assertEquals(1, register.getItems().size(), "one draft seeded");
            assertTrue(register.getItems().getFirst().entry().memo().contains("draft"));

            pickStatus("Posted");
            assertEquals(6, register.getItems().size(), "six posted entries seeded");

            pickStatus("Voided");
            assertEquals(0, register.getItems().size(), "nothing voided");

            // compose: posted + search
            pickStatus("Posted");
            typeSearch("sale");
            assertEquals(2, register.getItems().size(),
                    "two posted 'sale' memos (cash + credit)");

            pickStatus("All statuses");
            typeSearch("");
        });
    }

    @Test
    void switchingClientsClearsStalePeriodFilter() throws Exception {
        // the whole body runs ON the FX thread via withClient — nesting
        // another runLater-and-await inside it deadlocks the FX thread
        withClient(nrth, () -> {
            shell.show(ViewId.JOURNAL);
            javafx.scene.control.ComboBox<Period> periodBox =
                    findPeriodCombo();
            assertNotNull(periodBox, "period filter exists");
            assertFalse(periodBox.getItems().isEmpty(), "NRTH has a period");
            periodBox.getSelectionModel().selectFirst();
            assertEquals(7, registerTable().getItems().size(),
                    "period filter shows NRTH's entries");

            // switch to SOUTH — their period has a DIFFERENT id, so the
            // selection must clear (the 2.10.0 stale-filter fix)
            shell.selectWorkingClientById(south);
            shell.show(ViewId.JOURNAL);
            Period value = periodBox.getValue();
            assertTrue(value == null || value.clientId() == south,
                    "stale period must not survive the client switch");
            assertTrue(registerTable().getItems().size() >= 7,
                    "SOUTH's own entries show after the switch");
        });
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** Runs the runnable on the FX thread with NRTH/SOUTH active, waits. */
    private void withClient(long clientId, Runnable body) throws Exception {
        withClient(clientId, body, false);
    }

    /**
     * Runs the runnable on the FX thread with NRTH/SOUTH active, waits.
     * 2.12.1: the register reload is ASYNCHRONOUS (the 2.12.0 UiLoad reader),
     * so {@code shell.show} returning does NOT mean the rows have landed —
     * an assertion made in the same FX pulse can see a still-empty table.
     * {@code awaitRows} pumps the FX event loop (from the TEST thread, so
     * the FX thread is never blocked) until the register holds at least one
     * row for the freshly shown client, or the timeout lapses — then the
     * body runs against settled data. This replaces the old flake where
     * {@code searchFiltersTheRegisterLive} intermittently failed its very
     * first assertion ("seeded year is visible (0)").
     */
    private void withClient(long clientId, Runnable body, boolean awaitRows)
            throws Exception {
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Platform.runLater(() -> {
            try {
                shell.selectWorkingClientById(clientId);
                shell.show(ViewId.JOURNAL);
                // start every body from a clean filter state: JUnit gives no
                // ordering guarantees, and a previous test's leftover search
                // text or status selection must not leak into this one
                resetFilters();
                body.run();
            } catch (Throwable t) {
                failure.set(t);
            } finally {
                done.countDown();
            }
        });
        assertTrue(done.await(20, TimeUnit.SECONDS), "FX body timed out");
        assertNull(failure.get(), "FX body failed");
        if (awaitRows) {
            awaitRegisterLoaded(clientId);
        }
    }

    /**
     * Pumps short runLater hops until the journal register has rows for the
     * client — the UiLoad read's apply pass runs on the FX thread between
     * hops, so the wait never deadlocks with it.
     */
    private void awaitRegisterLoaded(long clientId) throws Exception {
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(20);
        while (System.nanoTime() < deadline) {
            CountDownLatch pulse = new CountDownLatch(1);
            AtomicReference<Integer> size = new AtomicReference<>(0);
            Platform.runLater(() -> {
                try {
                    size.set(registerTable().getItems().size());
                } finally {
                    pulse.countDown();
                }
            });
            assertTrue(pulse.await(2, TimeUnit.SECONDS), "register pulse timed out");
            if (size.get() > 0) {
                return;
            }
            Thread.sleep(10);   // let the reader thread finish its SQLite read
        }
        fail("register never loaded rows for client " + clientId);
    }

    /** Clears the search box and the status filter (FX thread only). */
    private void resetFilters() {
        javafx.scene.control.TextField field = searchField();
        if (field != null && field.getText() != null && !field.getText().isEmpty()) {
            field.setText("");
        }
        javafx.scene.control.ComboBox<String> statusBox = statusCombo();
        if (statusBox != null && !STATUS_ALL.equals(statusBox.getValue())) {
            statusBox.getSelectionModel().selectFirst();
        }
    }

    // the two tables by their private fields — a lookup can race the first
    // CSS pulse, and visibility is orthogonal to lookup population anyway
    @SuppressWarnings("unchecked")
    private TableView<JournalService.EntrySummary> registerTable() {
        try {
            java.lang.reflect.Field f =
                    JournalView.class.getDeclaredField("table");
            f.setAccessible(true);
            return (TableView<JournalService.EntrySummary>) f.get(journal);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private TableView<JournalView.JournalRow> linesTable() {
        try {
            java.lang.reflect.Field f =
                    JournalView.class.getDeclaredField("linesTable");
            f.setAccessible(true);
            return (TableView<JournalView.JournalRow>) f.get(journal);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private javafx.scene.control.ComboBox<Period> findPeriodCombo() {
        try {
            java.lang.reflect.Field f =
                    JournalView.class.getDeclaredField("periodFilter");
            f.setAccessible(true);
            return (javafx.scene.control.ComboBox<Period>) f.get(journal);
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    private javafx.scene.control.TextField searchField() {
        try {
            java.lang.reflect.Field f =
                    JournalView.class.getDeclaredField("search");
            f.setAccessible(true);
            return (javafx.scene.control.TextField) f.get(journal);
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private javafx.scene.control.ComboBox<String> statusCombo() {
        try {
            java.lang.reflect.Field f =
                    JournalView.class.getDeclaredField("statusFilter");
            f.setAccessible(true);
            return (javafx.scene.control.ComboBox<String>) f.get(journal);
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    private void typeSearch(String text) {
        // bodies run ON the FX thread (withClient), so the change must be
        // applied synchronously — awaiting a queued runLater from here would
        // deadlock the FX thread against itself
        javafx.scene.control.TextField field = searchField();
        assertNotNull(field, "search field exists in the journal toolbar");
        field.setText(text);
    }

    private void pickStatus(String status) {
        javafx.scene.control.ComboBox<String> statusBox = statusCombo();
        assertNotNull(statusBox, "status filter exists");
        statusBox.getSelectionModel().select(status);
    }

    private static JournalView journalViewOf(AppShell shell) throws Exception {
        shell.show(ViewId.JOURNAL);
        java.lang.reflect.Field f = AppShell.class.getDeclaredField("journalView");
        f.setAccessible(true);
        Object view = f.get(shell);
        return view instanceof JournalView jv ? jv : null;
    }

    /** Seeds one client with a small profitable year (the snapshot shape). */
    private static long seed(Database database, String code, String name) {
        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        FxRateService fx = new FxRateService(database);
        JournalService journal = new JournalService(database, fx);

        long clientId = clients.create(code, name, "PHP").id();
        accounts.applyStandardChart(clientId);
        Period fy = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));

        SeedCtx ctx = new SeedCtx(accounts, journal, clientId, fy);
        post(ctx, LocalDate.of(2026, 1, 1), "initial capital",
                line(ctx, "1010", 1_000_000_00L), line(ctx, "3000", -1_000_000_00L));
        post(ctx, LocalDate.of(2026, 3, 5), "cash sales",
                line(ctx, "1010", 420_000_00L), line(ctx, "4010", -420_000_00L));
        post(ctx, LocalDate.of(2026, 5, 12), "credit sale",
                line(ctx, "1100", 180_000_00L), line(ctx, "4010", -180_000_00L));
        post(ctx, LocalDate.of(2026, 6, 30), "rent paid",
                line(ctx, "6100", 96_000_00L), line(ctx, "1010", -96_000_00L));
        post(ctx, LocalDate.of(2026, 10, 15), "salaries",
                line(ctx, "6000", 132_000_00L), line(ctx, "1010", -132_000_00L));
        post(ctx, LocalDate.of(2026, 11, 1), "utilities",
                line(ctx, "6110", 3_500_00L), line(ctx, "1010", -3_500_00L));

        journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 11, 2), EntryType.NORMAL,
                null, "power bill, draft", null, null, List.of(
                line(ctx, "6110", 3_500_00L),
                line(ctx, "1010", -3_500_00L))));
        return clientId;
    }

    /** A debit (positive) or credit (negative) line by account code. */
    private static JournalService.NewLine line(SeedCtx ctx, String code, long signed) {
        long account = ctx.accounts().list(ctx.clientId(), false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst().orElseThrow().id();
        return signed >= 0
                ? new JournalService.NewLine(account, signed, null, null)
                : new JournalService.NewLine(account, null, -signed, null);
    }

    private static void post(SeedCtx ctx, LocalDate date, String memo,
                             JournalService.NewLine... lines) {
        ctx.journal().post(ctx.journal().createDraft(new JournalService.NewEntry(
                ctx.clientId(), ctx.fy().id(), date, EntryType.NORMAL, null, memo,
                null, null, List.of(lines))).id());
    }

    private record SeedCtx(AccountService accounts, JournalService journal,
                           long clientId, Period fy) { }
}
