package com.ledgerpro.ui;

import org.junit.jupiter.api.Test;

import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The Prefs hub (2.5.0; 2.6.0 adds DashboardRefresh): every default, the
 * persistence round-trip, and the reset that Settings' Reset button runs.
 * The store is the real user-preferences node, so each case cleans its own
 * keys first (tests must not inherit or leak state).
 */
class PrefsTest {

    private static final String NODE = "ledgerpro/app";

    private void clearNode() {
        try {
            Preferences.userRoot().node(NODE).clear();
        } catch (BackingStoreException ignored) {
            // best effort; load() then reads the defaults anyway
        }
    }

    @Test
    void factoryDefaultsHold() {
        clearNode();
        Prefs prefs = Prefs.getInstance();
        prefs.load();

        assertEquals(Prefs.DEFAULT_ANIMATIONS, prefs.isAnimationsEnabled(),
                "animations default OFF");
        assertEquals(Prefs.DEFAULT_MONEY_GROUPED, prefs.isMoneyGrouped());
        assertEquals(Prefs.DEFAULT_ZERO_SHOWN, prefs.isZeroShown());
        assertFalse(prefs.isCompactDensity());
        assertTrue(prefs.isGeometryRemembered());
        assertTrue(prefs.isVoidPrompted());
        assertEquals(ViewId.DASHBOARD, prefs.startupView());
        assertEquals(Prefs.DEFAULT_DASHBOARD_REFRESH, prefs.dashboardRefresh(),
                "dashboard live refresh defaults to every 15 s");
    }

    @Test
    void dashboardRefreshParsesEverySavedShape() {
        // exact names
        assertEquals(Prefs.DashboardRefresh.OFF,
                Prefs.DashboardRefresh.parse("OFF"));
        assertEquals(Prefs.DashboardRefresh.SEC5,
                Prefs.DashboardRefresh.parse("SEC5"));
        assertEquals(Prefs.DashboardRefresh.SEC15,
                Prefs.DashboardRefresh.parse("SEC15"));
        assertEquals(Prefs.DashboardRefresh.SEC30,
                Prefs.DashboardRefresh.parse("SEC30"));
        // junk and missing fall back to the default, never to null
        assertEquals(Prefs.DEFAULT_DASHBOARD_REFRESH,
                Prefs.DashboardRefresh.parse("garbage"));
        assertEquals(Prefs.DEFAULT_DASHBOARD_REFRESH,
                Prefs.DashboardRefresh.parse(null));
        assertEquals(Prefs.DEFAULT_DASHBOARD_REFRESH,
                Prefs.DashboardRefresh.parse(""));
    }

    @Test
    void dashboardRefreshSecondsMatchTheirLabels() {
        assertEquals(0, Prefs.DashboardRefresh.OFF.seconds());
        assertEquals(5, Prefs.DashboardRefresh.SEC5.seconds());
        assertEquals(15, Prefs.DashboardRefresh.SEC15.seconds());
        assertEquals(30, Prefs.DashboardRefresh.SEC30.seconds());
        // every label is non-empty (it renders in a combo box)
        for (Prefs.DashboardRefresh rate : Prefs.DashboardRefresh.values()) {
            assertFalse(rate.label.isBlank(), rate + " needs a label");
        }
    }

    @Test
    void settersPersistAcrossAFreshInstance() {
        clearNode();
        Prefs prefs = Prefs.getInstance();
        prefs.load();
        prefs.setAnimationsEnabled(true);
        prefs.setMoneyGrouped(false);
        prefs.setZeroShown(true);
        prefs.setCompactDensity(true);
        prefs.setVoidPrompted(false);
        prefs.setDashboardRefresh(Prefs.DashboardRefresh.SEC5);

        // a fresh hub (a new JVM launch) reads the same choices back
        Prefs fresh = new PrefsForTest();
        fresh.load();
        assertTrue(fresh.isAnimationsEnabled());
        assertFalse(fresh.isMoneyGrouped());
        assertTrue(fresh.isZeroShown());
        assertTrue(fresh.isCompactDensity());
        assertFalse(fresh.isVoidPrompted());
        assertEquals(Prefs.DashboardRefresh.SEC5, fresh.dashboardRefresh());
    }

    @Test
    void resetRestoresEveryFactoryDefault() {
        clearNode();
        Prefs prefs = Prefs.getInstance();
        prefs.load();
        prefs.setAnimationsEnabled(true);
        prefs.setMoneyGrouped(false);
        prefs.setZeroShown(true);
        prefs.setCompactDensity(true);
        prefs.setGeometryRemembered(false);
        prefs.setVoidPrompted(false);
        prefs.setStartupView(ViewId.JOURNAL);
        prefs.setDashboardRefresh(Prefs.DashboardRefresh.SEC30);

        prefs.resetDefaults();

        assertEquals(Prefs.DEFAULT_ANIMATIONS, prefs.isAnimationsEnabled());
        assertEquals(Prefs.DEFAULT_MONEY_GROUPED, prefs.isMoneyGrouped());
        assertEquals(Prefs.DEFAULT_ZERO_SHOWN, prefs.isZeroShown());
        assertFalse(prefs.isCompactDensity());
        assertTrue(prefs.isGeometryRemembered());
        assertTrue(prefs.isVoidPrompted());
        assertEquals(ViewId.DASHBOARD, prefs.startupView());
        assertEquals(Prefs.DEFAULT_DASHBOARD_REFRESH, prefs.dashboardRefresh());
    }

    /** A second instance of the same package-visible hub (a "fresh launch"). */
    private static final class PrefsForTest extends Prefs {
        PrefsForTest() {
            super();   // ctor runs load() against the current store
        }
    }
}
