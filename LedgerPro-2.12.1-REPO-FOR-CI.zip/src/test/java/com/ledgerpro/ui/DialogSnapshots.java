package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Client;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.AdjTemplateService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.ui.Theme;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.MenuButton;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * Headless screenshot + behavior check of the FIXED dialogs (dev tool, test
 * sources — same package as the dialogs so it can see them): New client
 * (padding + chart template picker), New journal entry with many lines
 * (padding, scrolling, working ✕ and "···" per line), Load / Save template,
 * Apply chart template.
 *
 * <pre>
 * xvfb-run -a java -cp ... com.ledgerpro.ui.DialogSnapshots /tmp/snap.db out/ [THEME]
 * </pre>
 *
 * <p>Every dialog is rendered with the real theme and stylesheet (the
 * optional third argument is a Theme enum name — ALEXIA renders the whole
 * set in Alexia's theme), snapshotted to PNG, and — for the entry dialog —
 * the ✕ enable rule and the "···" menu presence are verified
 * programmatically, because "it renders" is not the same as "the button
 * works".</p>
 */
public final class DialogSnapshots {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "/tmp/dialog-snapshots.db";
        String outDir = args.length > 1 ? args[1] : "/tmp/dialog-snapshots";
        Theme theme = args.length > 2
                ? Theme.valueOf(args[2].toUpperCase(java.util.Locale.ROOT))
                : Theme.PRIMER_LIGHT;

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                run(dbPath, outDir, theme);
            } catch (Throwable t) {
                failure.set(t);
            } finally {
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(90, TimeUnit.SECONDS)) {
            throw new IllegalStateException("dialog snapshots timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("dialog snapshots failed", failure.get());
        }
    }

    private static void run(String dbPath, String outDir, Theme theme) throws Exception {
        Application.setUserAgentStylesheet(theme.userAgentStylesheet());

        Database db = new Database(dbPath);
        db.migrate();
        ClientService clients = new ClientService(db);
        AccountService accounts = new AccountService(db);
        PeriodService periods = new PeriodService(db);
        FxRateService fx = new FxRateService(db);
        JournalService journal = new JournalService(db, fx);
        AdjTemplateService adj = new AdjTemplateService(db);

        Client client = clients.create("ACME", "Acme Trading Corp.", "PHP");
        accounts.applyStandardChart(client.id());
        Period period = periods.create(client.id(), "FY2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));

        // one saved recurring template so the Load dialog has real content
        adj.save(client.id(), "DEP_SL", "Monthly depreciation — straight line", "",
                List.of(new AdjTemplateService.TemplateLine(1, "6400", "DR",
                                AdjTemplateService.FIXED, "1250.00",
                                "depreciation for the month"),
                        new AdjTemplateService.TemplateLine(2, "1510", "CR",
                                AdjTemplateService.FIXED, "1250.00",
                                "accumulated depreciation")));

        List<Period> open = periods.list(client.id()).stream()
                .filter(p -> !p.closed()).toList();
        List<com.ledgerpro.model.Account> chart = accounts.list(client.id(), false);

        // ---- 1) New client: padding + starting-chart picker --------------
        ClientDialog clientDialog = new ClientDialog(clients, accounts);
        capture(clientDialog.getDialogPane(), outDir, "01-new-client.png", theme);

        // ---- 2) New entry, then + Add line x10: scroll, ✕, "···" ---------
        EntryDialog entryDialog = new EntryDialog(client, open, period, chart,
                fx, journal, adj);
        DialogPane entryPane = entryDialog.getDialogPane();
        entryPane.applyCss();
        entryPane.layout();
        Hyperlink addLine = entryPane.lookupAll(".hyperlink").stream()
                .filter(h -> h instanceof Hyperlink)
                .map(h -> (Hyperlink) h)
                .filter(h -> h.getText() != null && h.getText().contains("Add line"))
                .findFirst().orElseThrow();
        for (int i = 0; i < 10; i++) {
            addLine.fire();
        }

        // ✕ rule: with 12 lines every ✕ must be ENABLED
        List<Button> crosses = entryPane.lookupAll(".button").stream()
                .filter(b -> b instanceof Button)
                .map(b -> (Button) b)
                .filter(b -> "✕".equals(b.getText()))
                .collect(Collectors.toList());
        System.out.println("CHECK rows=12 crossButtons=" + crosses.size()
                + " allEnabled=" + crosses.stream().noneMatch(Button::isDisable));

        // "···" menu: one per line, each with actions
        List<MenuButton> dots = entryPane.lookupAll(".menu-button").stream()
                .filter(m -> m instanceof MenuButton)
                .map(m -> (MenuButton) m)
                .filter(m -> "···".equals(m.getText()))
                .collect(Collectors.toList());
        System.out.println("CHECK dotsMenus=" + dots.size()
                + " menusHaveItems=" + dots.stream().allMatch(m -> !m.getItems().isEmpty()));

        // remove two lines: 10 remain, ✕ still enabled
        for (int i = 0; i < 2; i++) {
            crosses.get(i).fire();
        }
        System.out.println("CHECK after2Removal rows=10 crossEnabled="
                + crosses.stream().skip(2).noneMatch(Button::isDisable));

        // remove eight more: 2 remain, ✕ must lock again
        for (int i = 2; i < 10; i++) {
            crosses.get(i).fire();
        }
        List<Button> crossesNow = entryPane.lookupAll(".button").stream()
                .filter(b -> b instanceof Button)
                .map(b -> (Button) b)
                .filter(b -> "✕".equals(b.getText()))
                .collect(Collectors.toList());
        System.out.println("CHECK atTwoRows crossLocked="
                + crossesNow.stream().allMatch(Button::isDisable));

        // rebuild 12 lines for the visual capture
        for (int i = 0; i < 10; i++) {
            addLine.fire();
        }
        capture(entryPane, outDir, "02-new-entry-12-lines.png", theme);

        // ---- 3) Load template ---------------------------------------------
        LoadTemplateDialog loadDialog = new LoadTemplateDialog(adj, client);
        capture(loadDialog.getDialogPane(), outDir, "03-load-template.png", theme);

        // ---- 4) Save as template -------------------------------------------
        SaveTemplateDialog saveDialog = new SaveTemplateDialog(adj, client,
                "Monthly depreciation — straight line",
                List.of(new AdjTemplateService.TemplateLine(1, "6400", "DR",
                                AdjTemplateService.FIXED, "1250.00", null),
                        new AdjTemplateService.TemplateLine(2, "1510", "CR",
                                AdjTemplateService.FIXED, "1250.00", null)));
        capture(saveDialog.getDialogPane(), outDir, "04-save-template.png", theme);

        // ---- 5) Apply chart template ----------------------------------------
        ChartTemplateDialog chartDialog = new ChartTemplateDialog("ACME — Acme Trading Corp.");
        capture(chartDialog.getDialogPane(), outDir, "05-chart-templates.png", theme);

        System.out.println("SNAPSHOTS DONE -> " + Path.of(outDir).toAbsolutePath());
    }

    // ------------------------------------------------------------------
    // Rendering a DialogPane exactly as the running app styles it
    // ------------------------------------------------------------------

    private static void capture(DialogPane pane, String outDir, String file, Theme theme)
            throws Exception {
        // JavaFX's Dialog attaches its own internal Scene to the pane; reuse
        // it when present instead of fighting "already root of another scene"
        Scene scene = pane.getScene();
        if (scene == null) {
            scene = new Scene(pane);
        }
        scene.getStylesheets().setAll(Objects.requireNonNull(
                DialogSnapshots.class.getResource("/css/ledgerpro.css")).toExternalForm());
        // the theme's palette overlay (when it carries one) re-tints the
        // dialogs exactly as in the running app
        if (theme.overlayUrl() != null) {
            scene.getStylesheets().add(theme.overlayUrl());
        }
        pane.applyCss();
        pane.autosize();   // resize the pane itself to its preferred size
        pane.layout();
        WritableImage image = pane.snapshot(
                new javafx.scene.SnapshotParameters(), null);
        Path out = Path.of(outDir, file);
        out.getParent().toFile().mkdirs();
        writePng(image, out);
        System.out.println("SNAPSHOT " + file + " pane=" + (int) pane.getWidth()
                + "x" + (int) pane.getHeight());
    }

    private static void writePng(WritableImage image, Path out) throws Exception {
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                PixelFormat.getIntArgbInstance(), pixels, 0, w);
        BufferedImage buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        ImageIO.write(buffered, "png", new File(out.toString()));
    }

}
