package com.ledgerpro.ui;

import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * P3 Step 0 (2.12.1): the AFTER probe — asserts the fixed
 * {@code UiSizing.em()} measures the ROOT's scaled font (not the
 * platform default 13 px) for a node with no explicit font, the exact
 * case ResponsiveGrid's breakpoints depend on.
 *
 * <pre>
 * mvn -o exec:java -Ddb.cli.class=com.ledgerpro.ui.EmProbeFixed \
 *     -Dexec.classpathScope=test
 * </pre>
 */
public final class EmProbeFixed {

    public static void main(String[] args) throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        StringBuilder report = new StringBuilder();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                double[] scales = {1.00, 1.30};
                int[] step = {0};
                Runnable[] chain = new Runnable[1];
                chain[0] = () -> {
                    if (step[0] >= scales.length) {
                        Platform.exit();
                        done.countDown();
                        return;
                    }
                    double scale = scales[step[0]++];
                    // the exact structure ResponsiveGrid measures in: a
                    // GridPane (no font of its own) inside a scene whose
                    // root style carries the UiScale font
                    ResponsiveGrid grid = new ResponsiveGrid(4, 22);
                    grid.getChildren().add(new Label("cell"));
                    Pane root = new Pane(grid);
                    Scene scene = new Scene(root, 1280, 820);
                    root.setStyle("-fx-font-size: "
                            + String.format("%.2fpx", 14 * scale) + ";");
                    Stage stage = new Stage();
                    stage.setScene(scene);
                    stage.show();
                    javafx.animation.PauseTransition p =
                            new javafx.animation.PauseTransition(javafx.util.Duration.millis(300));
                    p.setOnFinished(e -> {
                        try {
                            double em = UiSizing.em(grid);
                            double expect = 14 * scale;
                            report.append(String.format(
                                    "scale=%.2f em=%.2f expect=%.2f rootStyle=%s %s%n",
                                    scale, em, expect, root.getStyle(),
                                    Math.abs(em - expect) < 0.01 ? "OK" : "WRONG"));
                        } catch (Throwable t) {
                            failure.set(t);
                        }
                        chain[0].run();
                    });
                    p.play();
                };
                chain[0].run();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(60, TimeUnit.SECONDS)) {
            throw new IllegalStateException("fixed em probe timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("fixed em probe failed", failure.get());
        }
        System.out.print(report);
        String out = report.toString();
        if (!out.replace("WRONG", "").equals(out)) {
            throw new IllegalStateException("em() still wrong: " + out);
        }
    }
}
