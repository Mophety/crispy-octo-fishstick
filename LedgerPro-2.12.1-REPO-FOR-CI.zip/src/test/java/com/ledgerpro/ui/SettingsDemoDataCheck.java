package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.dev.DemoData;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.stage.Stage;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Behavior check for the 2.11.2 Settings → Data section (dev tool, test
 * sources — same package as the dialog so it can poke it).
 *
 * <p>What it pins:</p>
 * <ul>
 *   <li>the Settings dialog really carries the DATA section and, against an
 *       empty database, an ENABLED "Load demo data" button;</li>
 *   <li>the flow the button runs (seed + the shell's after-seed hook) loads
 *       the demo books and lands Northwind as the working client — without
 *       a restart;</li>
 *   <li>the guard: against a database that already has clients, the button
 *       is DISABLED — the demo never mixes itself into real books.</li>
 * </ul>
 *
 * <p>Headless checks cannot click native Alert buttons, so the check drives
 * the exact two halves the button's handler runs — {@link DemoData#seedIfEmpty}
 * and the shell's after-seed hook — and asserts the button's own
 * enabled/disabled states around them.</p>
 *
 * <pre>
 * xvfb-run -a java -cp ... com.ledgerpro.ui.SettingsDemoDataCheck /tmp/sdd.db
 * </pre>
 */
public final class SettingsDemoDataCheck {

    private static int failures = 0;

    private static void check(boolean condition, String label) {
        System.out.println((condition ? "CHECK OK   " : "CHECK FAIL ") + label);
        if (!condition) {
            failures++;
        }
    }

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "/tmp/settings-demo.db";
        Files.deleteIfExists(Path.of(dbPath));

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();

                // deterministic look whatever this machine remembers
                ThemeManager.apply(Theme.PRIMER_LIGHT, null);

                Scene scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                PauseTransition step1 = new PauseTransition(Duration.millis(600));
                step1.setOnFinished(e1 -> {
                    try {
                        AppShell shell = (AppShell) scene.getRoot();

                        // --- the dialog carries the Data section, enabled
                        SettingsDialog dialog = new SettingsDialog(scene, database,
                                shell::afterDemoDataLoadedPublic);
                        dialog.initOwner(stage);
                        dialog.getDialogPane().applyCss();
                        dialog.getDialogPane().layout();

                        Button demo = findDemoButton(dialog.getDialogPane());
                        check(demo != null,
                                "Settings dialog carries the Load demo data button");
                        check(demo != null && !demo.isDisable(),
                                "button is ENABLED against the empty database");

                        // --- the flow the button runs: seed + hook
                        // seedIfEmpty must report what it did — the dialog's
                        // "loaded" message depends on this return value
                        boolean seeded = DemoData.seedIfEmpty(database);
                        check(seeded,
                                "seedIfEmpty returns TRUE against the empty"
                                        + " database");
                        check(!DemoData.seedIfEmpty(database),
                                "seedIfEmpty returns FALSE once clients exist"
                                        + " (no second demo written)");
                        shell.afterDemoDataLoadedPublic();

                        PauseTransition step2 = new PauseTransition(Duration.millis(400));
                        step2.setOnFinished(e2 -> {
                            try {
                                List<com.ledgerpro.model.Client> clients =
                                        new ClientService(database).list(false);
                                check(clients.size() == 1
                                                && "NRTH".equals(clients.getFirst().code()),
                                        "demo client Northwind (NRTH) is in the database ("
                                                + clients.size() + " client(s))");
                                check(shell.activeClientProperty().get() != null
                                                && "NRTH".equals(shell.activeClientProperty()
                                                .get().code()),
                                        "after-seed hook selected Northwind as the"
                                                + " working client");

                                long clientId = shell.activeClientProperty().get().id();
                                int entries = new JournalService(database,
                                        new FxRateService(database))
                                        .list(clientId, null).size();
                                check(entries >= 20,
                                        "journal carries the full demo cycle ("
                                                + entries + " entries)");

                                // --- the guard: reopen against a filled db
                                SettingsDialog reopened = new SettingsDialog(scene,
                                        database, shell::afterDemoDataLoadedPublic);
                                reopened.initOwner(stage);
                                reopened.getDialogPane().applyCss();
                                reopened.getDialogPane().layout();
                                Button demoAgain = findDemoButton(reopened.getDialogPane());
                                check(demoAgain != null && demoAgain.isDisable(),
                                        "button is DISABLED once the database holds"
                                                + " clients");

                                // --- 2.11.2 fix: the reported regression — the
                                // one and only client archived must NOT read as
                                // "empty". The old guard keyed on active clients
                                // only, so the button was enabled, the seed
                                // silently skipped and the dialog lied "loaded".
                                ClientService service = new ClientService(database);
                                com.ledgerpro.model.Client nrth =
                                        shell.activeClientProperty().get();
                                service.setActive(nrth.id(), false);   // archive it
                                check(DemoData.canSeed(database) == false,
                                        "canSeed is FALSE with the only client"
                                                + " ARCHIVED (archived rows count)");
                                check(!DemoData.seedIfEmpty(database),
                                        "seedIfEmpty still refuses after archiving"
                                                + " — no demo over real books");
                                SettingsDialog archivedDialog = new SettingsDialog(
                                        scene, database,
                                        shell::afterDemoDataLoadedPublic);
                                archivedDialog.initOwner(stage);
                                archivedDialog.getDialogPane().applyCss();
                                archivedDialog.getDialogPane().layout();
                                Button demoArchived =
                                        findDemoButton(archivedDialog.getDialogPane());
                                check(demoArchived != null && demoArchived.isDisable(),
                                        "button is DISABLED after the only client"
                                                + " was archived (the 2.11.2 fix)");
                                service.setActive(nrth.id(), true);   // restore

                                dialog.close();
                                reopened.close();
                                archivedDialog.close();
                                Platform.exit();
                                done.countDown();
                            } catch (Throwable t) {
                                failure.set(t);
                                Platform.exit();
                                done.countDown();
                            }
                        });
                        step2.play();
                    } catch (Throwable t) {
                        failure.set(t);
                        Platform.exit();
                        done.countDown();
                    }
                });
                step1.play();
            } catch (Throwable t) {
                failure.set(t);
                done.countDown();
                Platform.exit();
            }
        });

        if (!done.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("settings demo-data check timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("settings demo-data check crashed",
                    failure.get());
        }
        if (failures > 0) {
            throw new IllegalStateException(failures
                    + " settings demo-data check(s) failed");
        }
        System.out.println("SETTINGS DEMO-DATA CHECK DONE");
    }

    /** Locates the DATA section's button by its exact text. */
    private static Button findDemoButton(DialogPane pane) {
        return descend(pane.getContent() != null ? pane.getContent() : pane);
    }

    /** Depth-first walk for the "Load demo data" button. */
    private static Button descend(Node node) {
        if (node instanceof Button b
                && "Load demo data".equals(b.getText())) {
            return b;
        }
        if (node instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                Button found = descend(child);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }
}
