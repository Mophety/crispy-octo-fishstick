package com.ledgerpro.ui;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The responsive-text scale function of {@link UiScale}: pure arithmetic,
 * no JavaFX window needed. The clamp bounds and the reference size are the
 * contract the scene root binds to, so they are pinned down here.
 */
class UiScaleTest {

    private static final double EPSILON = 1e-9;

    @Test
    void designWindowReadsAsExactlyOne() {
        // the 1280x820 design window: its own geometric mean IS the reference
        assertEquals(1.0, UiScale.autoScaleFor(1280, 820), EPSILON);
        // a common laptop window sits within a rounding of 100% too
        assertEquals(1.0, UiScale.autoScaleFor(1366, 768), 0.001);
    }

    @Test
    void smallWindowsShrinkDownToTheFloor() {
        // the app's minimum 1024x660 window asks for ~0.80 and clamps at 0.85:
        // text never collapses to unreadable, whatever the window
        assertEquals(0.85, UiScale.autoScaleFor(1024, 660), EPSILON);
        assertEquals(0.85, UiScale.autoScaleFor(400, 300), EPSILON);
        assertEquals(0.85, UiScale.autoScaleFor(1, 1), EPSILON);
    }

    @Test
    void maximizedWindowsGrowTowardTheCeiling() {
        // mid-size windows scale up smoothly: 1440x900 ~ 1.11
        assertEquals(Math.sqrt(1440.0 * 900.0) / Math.sqrt(1280.0 * 820.0),
                UiScale.autoScaleFor(1440, 900), EPSILON);
        // a 1920x1040 fullscreen asks for ~1.38 and clamps at the 1.30
        // ceiling — maximized text stays readable, not cartoonish
        assertEquals(1.30, UiScale.autoScaleFor(1920, 1040), EPSILON);
        // a huge 4K-class window clamps at 1.30 too
        assertEquals(1.30, UiScale.autoScaleFor(3840, 2160), EPSILON);
    }

    @Test
    void notYetLaidOutWindowsKeepTheDesignSize() {
        // width/height of 0 happen before the scene is laid out
        assertEquals(1.0, UiScale.autoScaleFor(0, 820), EPSILON);
        assertEquals(1.0, UiScale.autoScaleFor(1280, 0), EPSILON);
    }

    @Test
    void aWideShortWindowAndATallNarrowWindowAgree() {
        // the geometric mean (not the arithmetic) drives the scale, so a
        // wide-but-short window does not over-inflate the text
        assertEquals(UiScale.autoScaleFor(2000, 525),
                UiScale.autoScaleFor(750, 1400), EPSILON);
    }

    @Test
    void everyWindowSizeStaysInsideTheClamp() {
        // sweep a realistic range: nothing escapes 0.85..1.30
        for (double w = 200; w <= 4000; w += 137.0) {
            for (double h = 200; h <= 2200; h += 173.0) {
                double scale = UiScale.autoScaleFor(w, h);
                assertTrue(scale >= 0.85 - EPSILON && scale <= 1.30 + EPSILON,
                        "scale " + scale + " out of range for " + w + "x" + h);
            }
        }
    }
}
