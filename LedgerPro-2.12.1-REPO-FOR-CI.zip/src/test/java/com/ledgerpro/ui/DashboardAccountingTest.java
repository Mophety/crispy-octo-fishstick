package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The 2.12.1 C1/C2 regression test: the dashboard's aggregates read,
 * against a seeded throwaway database, no JavaFX.
 *
 * <p>Shape of the seed (the user's own figures, exact in structure):
 * equity accounts 470,000 (capital 500,000 − drawings 30,000);
 * liabilities 91,570 (accrued rent 60,000 + utilities 31,570); revenues
 * 511,457.92 and expenses 369,000.00 → net income 142,457.92; assets
 * 704,027.92 = cash 404,027.92 + receivables 300,000. A 21,000 sale is
 * voided WITH its REVERSING mirror — the exact case the old query
 * dropped, netting to zero in the corrected read.</p>
 *
 * <p>C1 asserts the read INCLUDES reversing entries (net income
 * 142,457.92, not 118,457.92; assets 704,027.92, not 680,027.92) and
 * that the corrected equation balances. C2 asserts the recent-entries
 * amount equals TOTAL DEBITS — the Journal tab's own rule — for both a
 * normal entry and the voided one.</p>
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DashboardAccountingTest {

    private static Database database;
    private static long clientId;
    private static long periodId;
    private static JournalService journal;
    private static JournalService.NewLine capital;
    private static JournalService.NewLine cash;
    private static JournalService.NewLine ap;
    private static JournalService.NewLine rev;
    private static JournalService.NewLine exp;
    private static JournalService.NewLine drawings;

    @BeforeAll
    static void seed() throws Exception {
        Path dir = Files.createTempDirectory("dash-c1c2");
        database = new Database(dir.resolve("test.db").toString());
        database.migrate();

        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        FxRateService fx = new FxRateService(database);
        journal = new JournalService(database, fx);

        clientId = clients.create("NRTH", "Norte Freight Systems, Inc.", "PHP").id();
        accounts.applyStandardChart(clientId);
        periodId = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31)).id();

        capital = line("3000");   // Ordinary Share Capital (equity)
        cash = line("1010");     // Cash in Bank (asset)
        ap = line("2000");       // Accounts Payable (liability)
        rev = line("4010");      // Service Revenue
        exp = line("6100");      // Rent Expense
        drawings = line("3300"); // Treasury Shares, used as the drawings side
                                 // of the 30,000 withdrawal (equity, debit)

        post(LocalDate.of(2026, 1, 1), "initial capital",
                dr(cash, 500_000_00L), cr(capital, 500_000_00L));
        post(LocalDate.of(2026, 2, 1), "owner withdrawal",
                dr(drawings, 30_000_00L), cr(cash, 30_000_00L));
        post(LocalDate.of(2026, 3, 5), "credit sale",
                dr(line("1100"), 300_000_00L), cr(rev, 300_000_00L));
        post(LocalDate.of(2026, 4, 10), "cash sale",
                dr(cash, 150_000_00L), cr(rev, 150_000_00L));
        // unpaid expenses — the whole 91,570 of liabilities
        post(LocalDate.of(2026, 5, 15), "rent accrued",
                dr(exp, 60_000_00L), cr(ap, 60_000_00L));
        post(LocalDate.of(2026, 6, 20), "utilities accrued",
                dr(line("6110"), 31_570_00L), cr(ap, 31_570_00L));
        // cash-paid expenses — 369,000 total expenses − 91,570 unpaid
        post(LocalDate.of(2026, 7, 25), "salaries",
                dr(line("6000"), 200_000_00L), cr(cash, 200_000_00L));
        post(LocalDate.of(2026, 8, 30), "fees earned",
                dr(cash, 61_457_92L), cr(rev, 61_457_92L));
        post(LocalDate.of(2026, 9, 15), "misc expenses",
                dr(line("6110"), 77_430_00L), cr(cash, 77_430_00L));
        post(LocalDate.of(2026, 10, 10), "bad debt recovered",
                dr(cash, 21_000_00L), cr(rev, 21_000_00L));

        // void it (with its REVERSING mirror) so every test reads the
        // same settled data — the voided sale nets to zero in the
        // corrected read but the old one dropped the mirror entirely
        long voidTarget = journal.list(clientId, periodId).stream()
                .filter(s -> s.entry().memo().contains("bad debt"))
                .findFirst().orElseThrow().entry().id();
        journal.voidEntry(voidTarget, "wrong customer — rebook next month");
    }
    private static void post(LocalDate date, String memo,
                             JournalService.NewLine... lines) {
        journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, periodId, date, EntryType.NORMAL, null, memo,
                null, null, List.of(lines))).id());
    }

    private static JournalService.NewLine line(String code) {
        AccountService accounts = new AccountService(database);
        long id = accounts.list(clientId, false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst().orElseThrow().id();
        return new JournalService.NewLine(id, null, null, null);
    }

    private static JournalService.NewLine dr(JournalService.NewLine base, long cents) {
        return new JournalService.NewLine(base.accountId(), cents, null, null);
    }

    private static JournalService.NewLine cr(JournalService.NewLine base, long cents) {
        return new JournalService.NewLine(base.accountId(), null, cents, null);
    }

    @AfterAll
    static void teardown() {
        // the throwaway directory under /tmp vanishes with the JVM
    }


    // ------------------------------------------------------------------
    // C1 — the corrected equation, with the reversing entry included
    // ------------------------------------------------------------------

    @Test
    void theReadIncludesReversingEntriesSoAVoidedEntryNetsToZero() {
        DashboardView.ClientAggregates agg =
                new DashboardReader(database).read(clientId, periodId, false);

        // the user's exact figures: the reversal's 21,000 now nets the
        // voided sale to zero, so the read returns the pre-void numbers
        assertEquals(511_457_92L, agg.totalRevenue(),
                "revenue 300k + 150k + 61,457.92 (the voided 21k nets out)");
        assertEquals(369_000_00L, agg.totalExpenses(),
                "expenses 60k + 31,570 + 200k + 77,430 (369,000 exactly)");
        assertEquals(142_457_92L, agg.netIncome(), "net income includes the reversal");
        assertEquals(704_027_92L, agg.assets, "assets include the reversing entry");
        assertEquals(91_570_00L, agg.liabilities, "rent 60k + utilities 31,570 accrued");
        assertEquals(470_000_00L, agg.equity, "500k capital − 30k drawings");
    }

    @Test
    void theCorrectedEquationBalancesAndTheChipWouldReadBalanced() {
        DashboardView.ClientAggregates agg =
                new DashboardReader(database).read(clientId, periodId, false);
        // assets = liabilities + equity accounts + net income (open period)
        assertEquals(agg.assets,
                agg.liabilities + agg.equity + agg.netIncome(),
                "the corrected equation holds exactly");
        assertTrue(agg.balanceHolds(),
                "the chip reads BALANCED — the old proof called this OUT OF BALANCE");
    }

    @Test
    void anOpenPeriodUsesNetIncomeAndAClosedPeriodDoesNot() {
        DashboardView.ClientAggregates open =
                new DashboardReader(database).read(clientId, periodId, false);
        DashboardView.ClientAggregates closed =
                new DashboardReader(database).read(clientId, periodId, true);
        assertTrue(open.balanceHolds());
        // same rows, different equation: a "closed" flag must not
        // double-count income into the equity side
        assertTrue(!closed.balanceHolds() || closed.equity + closed.netIncome()
                == closed.liabilities + closed.equity,
                "closed periods prove the plain equation (no double-count)");
        assertEquals(open.assets, closed.assets);
        assertEquals(open.netIncome(), closed.netIncome());
    }

    // ------------------------------------------------------------------
    // C2 — the recent-entries amount is total debits
    // ------------------------------------------------------------------

    @Test
    void recentEntryAmountsAreTotalDebitsNotBothSides() {
        DashboardView.ClientAggregates agg =
                new DashboardReader(database).read(clientId, periodId, false);
        DashboardView.RecentEntry newest = agg.recents.getFirst();
        // the newest entry is the VOIDING REVERSING mirror of the 21,000
        // sale: total debits = 21,000 (one side), not 42,000 (both sides)
        assertEquals(21_000_00L, newest.amountCents(),
                "the amount is one side of the double entry");
        // and every recents row must agree with the Journal's own
        // totalBaseCents for the same entry
        for (DashboardView.RecentEntry recent : agg.recents) {
            long journalSays = journal.list(clientId, null).stream()
                    .filter(s -> s.entry().id() == recent.entryId())
                    .findFirst().orElseThrow().totalBaseCents();
            assertEquals(journalSays, recent.amountCents(),
                    "dashboard amount == Journal tab amount for entry #"
                            + recent.entryNo());
        }
    }
}
