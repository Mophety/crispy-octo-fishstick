package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The 2.11.0 UI gates, against the real toolkit (the same headless
 * software-rendering recipe the snapshot probes use) — every one of them
 * a defect the user's screenshots proved:
 *
 * <ul>
 *   <li><b>the toolbar is TWO rows</b> (actions, then filters) — the
 *       2.10.0 single row carried ~1550 px of content and JavaFX
 *       ellipsized three button labels on the user's window;</li>
 *   <li><b>no button label can ever be truncated</b> — every button is
 *       pinned to its computed size (min = computed), and no label text
 *       contains an ellipsis character;</li>
 *   <li><b>status cells use CSS classes</b> (lp-status-ok / -void /
 *       -draft), which re-resolve on the ThemeManager CSS re-pass —
 *       the 2.10.0 inline setStyle could render near-background hues on
 *       dark themes (a 6% luminance gap in the user's screenshot);</li>
 *   <li><b>the dashboard's charts are capped</b> — every chart node
 *       carries a max height (the balance bars rendered 612 logical px
 *       tall on the user's screen), the pie's minimum width is 300
 *       (was 280), and both chart rows share the window's growth.</li>
 * </ul>
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class JournalReadabilityTest {

    private static Database database;
    private static Scene scene;
    private static AppShell shell;
    private static JournalView journal;
    private static DashboardView dashboard;

    @BeforeAll
    static void boot() throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");
        CountDownLatch ready = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        try {
            Platform.startup(() -> { });
        } catch (IllegalStateException alreadyBooted) {
            // another FX class in this fork booted the toolkit first
        }
        Platform.setImplicitExit(false);
        Platform.runLater(() -> {
            try {
                Path dir = Files.createTempDirectory("jread");
                database = new Database(dir.resolve("test.db").toString());
                database.migrate();
                seedMinimal(database);

                scene = com.ledgerpro.App.buildScene(database, 1680, 1050);
                shell = (AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
                shell.show(ViewId.JOURNAL);
                journal = viewOf(shell, "journalView");
                shell.show(ViewId.DASHBOARD);
                // the dashboard view lives in the shippedViews map (the
                // shell caches every created view there)
                Field map = AppShell.class.getDeclaredField("shippedViews");
                map.setAccessible(true);
                java.util.Map<?, ?> shipped = (java.util.Map<?, ?>) map.get(shell);
                dashboard = (DashboardView) shipped.get(ViewId.DASHBOARD);
                shell.show(ViewId.JOURNAL);
                ready.countDown();
            } catch (Throwable t) {
                failure.set(t);
                ready.countDown();
            }
        });
        assertTrue(ready.await(60, TimeUnit.SECONDS), "JavaFX boot timed out");
        assertNull(failure.get(), "JavaFX boot failed");
        assertNotNull(journal);
        assertNotNull(dashboard);
    }

    @AfterAll
    static void shutdown() {
        // no Platform.exit — other FX classes in this fork still need the
        // toolkit (2.10.0 suite convention)
    }

    // ------------------------------------------------------------------
    // Toolbar gates
    // ------------------------------------------------------------------

    @Test
    void toolbarRowsActionsThenFilters() throws Exception {
        AtomicReference<Object> out = new AtomicReference<>();
        runOnFx(() -> shell.show(ViewId.JOURNAL));
        runOnFx(() -> {
            // find the toolbar: the container whose direct children are
            // two HBox rows — the journal's own root IS a VBox, so walk it
            // and then its immediate VBox children
            VBox toolbar = findTwoRowToolbar(journal);
            assertNotNull(toolbar, "the journal toolbar must be a VBox of two HBox rows");
            HBox row1 = (HBox) toolbar.getChildren().get(0);
            HBox row2 = (HBox) toolbar.getChildren().get(1);
            HBox row3 = (HBox) toolbar.getChildren().get(2);
            // rows 1-2 hold the action buttons; row 3 holds the search +
            // status + period controls
            assertTrue(toolbar.getChildrenUnmodifiable().stream()
                    .flatMap(r -> ((HBox) r).getChildrenUnmodifiable().stream())
                    .anyMatch(c -> c instanceof Button b && "Post".equals(b.getText())),
                    "an actions row carries Post");
            assertTrue(row3.getChildren().stream().anyMatch(
                    c -> c instanceof javafx.scene.control.TextField),
                    "the filters row carries the search box");
            assertTrue(row3.getChildren().stream().anyMatch(
                    c -> c instanceof Label l && "Period:".equals(l.getText())),
                    "the filters row carries the period caption");
            out.set(toolbar);
        });
        assertNotNull(out.get());
    }

    @Test
    void everyToolbarButtonIsNeverTruncatable() throws Exception {
        runOnFx(() -> {
            // the INVARIANT is size, not characters: a button pinned to its
            // computed size can never ellipsize, so the label the user sees
            // is always the full one. (Labels may still END with the
            // deliberate dialog-indicator '…' — that is a suffix the label
            // itself carries, not a clip.)
            for (Button b : allButtons(journal)) {
                assertEquals(Region.USE_COMPUTED_SIZE, b.getMinWidth(),
                        "button '" + b.getText() + "' must pin minWidth to its"
                                + " computed size so its label can never be ellipsized");
                assertTrue(b.getPrefWidth() == Region.USE_COMPUTED_SIZE
                                || b.getPrefWidth() >= 0,
                        "button '" + b.getText() + "' keeps a computed-size pref width");
            }
        });
    }

    @Test
    void layoutToggleLabelsAreShort() throws Exception {
        runOnFx(() -> {
            Button toggle = null;
            for (Button b : allButtons(journal)) {
                if ("Paper".equals(b.getText()) || "Register".equals(b.getText())) {
                    toggle = b;
                    break;
                }
            }
            assertNotNull(toggle, "the layout toggle must use the short Paper/Register label");
            assertTrue(toggle.getTooltip() != null && !toggle.getTooltip().getText().isEmpty(),
                    "the toggle's tooltip carries the full description");
        });
    }

    // ------------------------------------------------------------------
    // Status color gates
    // ------------------------------------------------------------------

    @Test
    void statusCellsCarryThemeSafeClasses() throws Exception {
        runOnFx(() -> {
            // the register's status column applies lp-status-* classes —
            // check through the built view: the 2.11.0 CSS defines
            // .lp-status-ok.table-cell etc. Here we assert the CELL FACTORY
            // wiring: render a cell through the column's cell factory
            TableView<com.ledgerpro.service.JournalService.EntrySummary> register =
                    registerTable();
            @SuppressWarnings("rawtypes")
            javafx.scene.control.TableColumn rawStatusColumn = register.getColumns().stream()
                    .filter(c -> "Status".equals(c.getText()))
                    .findFirst().orElseThrow();
            @SuppressWarnings("unchecked")
            javafx.scene.control.TableCell<String, String> cell =
                    (javafx.scene.control.TableCell<String, String>)
                            rawStatusColumn.getCellFactory().call(rawStatusColumn);
            updateCellItem(cell, "Posted");
            assertTrue(cell.getStyleClass().contains("lp-status-ok"),
                    "Posted renders through the lp-status-ok CSS class");
            updateCellItem(cell, "Voided");
            assertTrue(cell.getStyleClass().contains("lp-status-void"),
                    "Voided renders through the lp-status-void CSS class");
            updateCellItem(cell, "Draft");
            assertTrue(cell.getStyleClass().contains("lp-status-draft"),
                    "Draft renders through the lp-status-draft CSS class");
            updateCellItem(cell, null);
            assertTrue(cell.getStyleClass().stream().noneMatch(
                            c -> c.startsWith("lp-status-")),
                    "empty cells carry no status class");
        });
    }

    // ------------------------------------------------------------------
    // The ledgers-look gates (2.11.1)
    // ------------------------------------------------------------------

    @Test
    void amountColumnWearsTheLedgersGreen() throws Exception {
        runOnFx(() -> {
            TableView<com.ledgerpro.service.JournalService.EntrySummary> register =
                    registerTable();
            var amount = register.getColumns().stream()
                    .filter(c -> c.getText().startsWith("Amount"))
                    .findFirst().orElseThrow();
            assertTrue(amount.getStyleClass().contains("lp-col-money-strong"),
                    "the Amount column carries the ledgers' green-bold class");
            // 2.12.1 (P4-S2): the width is em-based now — the em-scaled
            // band keeps the figures breathing at every text scale
            assertTrue(amount.getMinWidth() > 0,
                    "the Amount column has an em-scaled min width");
            assertTrue(amount.getStyleClass().contains("lp-col-tabular"),
                    "tabular digits on the money column (P4)");
            var noCol = register.getColumns().stream()
                    .filter(c -> "No".equals(c.getText()))
                    .findFirst().orElseThrow();
            assertTrue(noCol.getStyleClass().contains("lp-col-strong"),
                    "the Entry No column is strong ink like the ledger's Entry");
        });
    }

    // ------------------------------------------------------------------
    // Dashboard gates
    // ------------------------------------------------------------------

    @Test
    void dashboardChartsAreCappedAndProportioned() throws Exception {
        runOnFx(() -> {
            assertNotNull(dashboard, "dashboard view exists");
            var trend = field(dashboard, "trendChart");
            var pie = field(dashboard, "expensePie");
            var bars = field(dashboard, "balanceBars");
            assertTrue(((Region) trend).getMaxHeight() <= 420,
                    "the trend chart's height is capped at 420");
            assertTrue(((Region) bars).getMaxHeight() <= 360,
                    "the balance bars' height is capped at 360");
            // 2.12.1 (P2-S2): the pie card now centers the disc inside
            // a BorderPane (disc left, legend right) and lets the chart
            // take the card's full height — the 2.11.0 caps were about
            // the old fixed-pref pie; the card's own row still caps.
            assertTrue(((Region) pie).getMinWidth() >= 240,
                    "the pie's minimum width is at least 240");
        });
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** Depth-limited search for the VBox whose children are exactly two
     * HBoxes (the 2.11.0 two-row toolbar). */
    private static VBox findTwoRowToolbar(javafx.scene.Parent parent) {
        // 2.12.1 (P4-S6): the toolbar is now THREE HBox rows (create+period,
        // entry+output, filters) — all HBox children of one VBox
        if (parent instanceof VBox box && box.getChildren().size() == 3
                && box.getChildren().stream().allMatch(c -> c instanceof HBox)) {
            return box;
        }
        for (Node child : parent.getChildrenUnmodifiable()) {
            if (child instanceof javafx.scene.Parent p) {
                VBox found = findTwoRowToolbar(p);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    private static List<Button> allButtons(javafx.scene.Parent root) {
        return root.lookupAll(".button").stream()
                .filter(n -> n instanceof Button)
                .map(n -> (Button) n)
                .toList();
    }

    @SuppressWarnings("unchecked")
    private TableView<com.ledgerpro.service.JournalService.EntrySummary> registerTable() {
        try {
            Field f = JournalView.class.getDeclaredField("table");
            f.setAccessible(true);
            return (TableView<com.ledgerpro.service.JournalService.EntrySummary>) f.get(journal);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    /** updateItem is protected on Cell — reach it by reflection. */
    private static void updateCellItem(
            javafx.scene.control.TableCell<String, String> cell, String value) {
        try {
            java.lang.reflect.Method m = javafx.scene.control.Cell.class
                    .getDeclaredMethod("updateItem", Object.class, boolean.class);
            m.setAccessible(true);
            m.invoke(cell, value, false);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    private Object field(Object owner, String name) {
        try {
            Field f = owner.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.get(owner);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private static <T> T viewOf(AppShell shell, String fieldName) throws Exception {
        Field f = AppShell.class.getDeclaredField(fieldName);
        f.setAccessible(true);
        return (T) f.get(shell);
    }

    private void runOnFx(Runnable body) throws InterruptedException {
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Platform.runLater(() -> {
            try {
                body.run();
            } catch (Throwable t) {
                failure.set(t);
            } finally {
                done.countDown();
            }
        });
        assertTrue(done.await(20, TimeUnit.SECONDS), "FX body timed out");
        assertNull(failure.get(), "FX body failed");
    }

    /** A tiny year: one client, one period, two posted entries + a draft. */
    private static void seedMinimal(Database database) {
        com.ledgerpro.service.ClientService clients =
                new com.ledgerpro.service.ClientService(database);
        com.ledgerpro.service.AccountService accounts =
                new com.ledgerpro.service.AccountService(database);
        com.ledgerpro.service.PeriodService periods =
                new com.ledgerpro.service.PeriodService(database);
        com.ledgerpro.service.FxRateService fx =
                new com.ledgerpro.service.FxRateService(database);
        com.ledgerpro.service.JournalService journal =
                new com.ledgerpro.service.JournalService(database, fx);

        long clientId = clients.create("NRTH", "Norte Freight Systems", "PHP").id();
        accounts.applyStandardChart(clientId);
        var fy = periods.create(clientId, "FY2026",
                java.time.LocalDate.of(2026, 1, 1), java.time.LocalDate.of(2026, 12, 31));
        long cash = accounts.list(clientId, false).stream()
                .filter(a -> a.code().equals("1010")).findFirst().orElseThrow().id();
        long capital = accounts.list(clientId, false).stream()
                .filter(a -> a.code().equals("3000")).findFirst().orElseThrow().id();
        long fees = accounts.list(clientId, false).stream()
                .filter(a -> a.code().equals("4010")).findFirst().orElseThrow().id();
        journal.post(journal.createDraft(new com.ledgerpro.service.JournalService.NewEntry(
                clientId, fy.id(), java.time.LocalDate.of(2026, 1, 1),
                com.ledgerpro.model.EntryType.NORMAL, null, "initial capital",
                null, null, java.util.List.of(
                new com.ledgerpro.service.JournalService.NewLine(cash, 1_000_000_00L, null, null),
                new com.ledgerpro.service.JournalService.NewLine(capital, null, 1_000_000_00L, null)))).id());
        journal.post(journal.createDraft(new com.ledgerpro.service.JournalService.NewEntry(
                clientId, fy.id(), java.time.LocalDate.of(2026, 3, 5),
                com.ledgerpro.model.EntryType.NORMAL, null, "cash sales",
                null, null, java.util.List.of(
                new com.ledgerpro.service.JournalService.NewLine(cash, 420_000_00L, null, null),
                new com.ledgerpro.service.JournalService.NewLine(fees, null, 420_000_00L, null)))).id());
        journal.createDraft(new com.ledgerpro.service.JournalService.NewEntry(
                clientId, fy.id(), java.time.LocalDate.of(2026, 11, 2),
                com.ledgerpro.model.EntryType.NORMAL, null, "power bill, draft",
                null, null, java.util.List.of(
                new com.ledgerpro.service.JournalService.NewLine(cash, 3_500_00L, null, null),
                new com.ledgerpro.service.JournalService.NewLine(fees, null, 3_500_00L, null))));
    }

}
