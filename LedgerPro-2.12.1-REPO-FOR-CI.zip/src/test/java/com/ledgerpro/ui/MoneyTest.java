package com.ledgerpro.ui;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Money's Settings-controlled presentation (2.5.0; 2.6.0 pins it down):
 * grouping, the blank-vs-0.00 zero, and the parse round-trips that must
 * hold whatever the display flags are.
 */
class MoneyTest {

    @BeforeEach
    void resetFlags() {
        Money.setGrouping(true);
        Money.setZeroShown(false);
    }

    @AfterEach
    void restoreFlags() {
        Money.setGrouping(true);
        Money.setZeroShown(false);
    }

    @Test
    void groupingTogglesTheCommas() {
        assertEquals("1,234,567.89", Money.format(123_456_789L));
        Money.setGrouping(false);
        assertEquals("1234567.89", Money.format(123_456_789L));
        // and back
        Money.setGrouping(true);
        assertEquals("1,234,567.89", Money.format(123_456_789L));
    }

    @Test
    void smallAmountsNeverGroup() {
        Money.setGrouping(true);
        assertEquals("125.00", Money.format(12_500L));
        assertEquals("999.99", Money.format(99_999L));
        // the thousands separator starts at 1,000.00
        assertEquals("1,000.00", Money.format(100_000L));
    }

    @Test
    void zeroFollowsThePaperConvention() {
        assertEquals("", Money.format(0L), "blank zero is the default");
        Money.setZeroShown(true);
        assertEquals("0.00", Money.format(0L));
        Money.setZeroShown(false);
        assertEquals("", Money.format(0L));
        // zero flags never affect non-zero amounts
        assertEquals("10.00", Money.format(1_000L));
    }

    @Test
    void formatGroupedIgnoresTheGroupingFlag() {
        // totals lines and footers group even when the table rows do not
        Money.setGrouping(false);
        assertEquals("1,234,567.89", Money.formatGrouped(123_456_789L));
        // but the zero convention still applies
        assertEquals("", Money.formatGrouped(0L));
        Money.setZeroShown(true);
        assertEquals("0.00", Money.formatGrouped(0L));
    }

    @Test
    void parsingAcceptsBothDisplayShapes() {
        // parseCents strips grouping whatever the display flag is
        Money.setGrouping(false);
        assertEquals(123_456_789L, Money.parseCents("1,234,567.89"));
        assertEquals(123_456_789L, Money.parseCents("1234567.89"));
        assertEquals(1_000L, Money.parseCents("10.00"));
        assertEquals(50L, Money.parseCents("0.5"), "rounds half-up to cents");
    }

    @Test
    void parsingRejectsTheUnusable() {
        IllegalArgumentException blank =
                assertThrows(IllegalArgumentException.class, () -> Money.parseCents("  "));
        assertTrue(blank.getMessage().contains("must be typed"));
        IllegalArgumentException negative =
                assertThrows(IllegalArgumentException.class, () -> Money.parseCents("-5"));
        assertTrue(negative.getMessage().contains("positive"));
        IllegalArgumentException garbage =
                assertThrows(IllegalArgumentException.class, () -> Money.parseCents("abc"));
        assertTrue(garbage.getMessage().contains("not a valid amount"));
    }

    @Test
    void isParsableMatchesParseCents() {
        assertTrue(Money.isParsable("1,234.56"));
        assertTrue(Money.isParsable("0.5"));
        assertFalse(Money.isParsable(""));
        assertFalse(Money.isParsable("-1"));
        assertFalse(Money.isParsable("twelve"));
        assertFalse(Money.isParsable(null));
    }

    @Test
    void ratesTrimToPlainStrings() {
        assertEquals("56.732", Money.rate(56.732));
        assertEquals("56", Money.rate(56.0));
        assertEquals("0.1", Money.rate(0.1));
        // never scientific notation, however small
        assertFalse(Money.rate(0.000001).contains("E"));
        assertEquals("0.000001", Money.rate(0.000001));
    }
}
