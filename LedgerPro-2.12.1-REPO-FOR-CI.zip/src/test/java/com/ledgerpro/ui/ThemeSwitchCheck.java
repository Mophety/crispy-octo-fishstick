package com.ledgerpro.ui;

import com.ledgerpro.db.Database;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.PixelReader;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.PauseTransition;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Runtime theme-switch check (dev tool, test sources): boots the real scene,
 * then flips through Alexia's theme and back to Primer Light — verifying by
 * PIXEL that (a) switching TO an overlay theme restyles the open scene and
 * (b) switching AWAY removes the overlay again. This is the exact code path
 * the sidebar's APPEARANCE picker takes.
 *
 * <pre>
 * xvfb-run -a java -cp ... com.ledgerpro.ui.ThemeSwitchCheck /tmp/tsc.db
 * </pre>
 */
public final class ThemeSwitchCheck {

    private static int failures = 0;

    private static void check(boolean condition, String label) {
        System.out.println((condition ? "CHECK OK   " : "CHECK FAIL ") + label);
        if (!condition) {
            failures++;
        }
    }

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "/tmp/theme-switch.db";

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();

                // force the STARTING theme to Primer Light whatever this
                // machine remembers — the check must be deterministic
                ThemeManager.apply(Theme.PRIMER_LIGHT, null);

                Scene scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                PauseTransition step1 = new PauseTransition(Duration.millis(700));
                step1.setOnFinished(e1 -> {
                    check(isLight(scene), "starts in Primer Light (light pixels)");

                    ThemeManager.apply(Theme.ALEXIA, scene);
                    PauseTransition step2 = new PauseTransition(Duration.millis(700));
                    step2.setOnFinished(e2 -> {
                        check(isAlexiaGreen(scene),
                                "switch to Alexia's theme restyles the live scene");

                        ThemeManager.apply(Theme.PRIMER_DARK, scene);
                        PauseTransition step3 = new PauseTransition(Duration.millis(700));
                        step3.setOnFinished(e3 -> {
                            check(isPrimerDarkGray(scene),
                                    "switch to Primer Dark restyles the live scene");

                            ThemeManager.apply(Theme.PRIMER_LIGHT, scene);
                            PauseTransition step4 = new PauseTransition(Duration.millis(700));
                            step4.setOnFinished(e4 -> {
                                check(isLight(scene),
                                        "switching back to Primer Light REMOVES the overlay");
                                check(scene.getStylesheets().size() == 1,
                                        "scene carries only the author stylesheet again ("
                                                + scene.getStylesheets().size() + ")");
                                Platform.exit();
                                done.countDown();
                            });
                            step4.play();
                        });
                        step3.play();
                    });
                    step2.play();
                });
                step1.play();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(90, TimeUnit.SECONDS)) {
            throw new IllegalStateException("theme switch check timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("theme switch check crashed", failure.get());
        }
        if (failures > 0) {
            throw new IllegalStateException(failures + " theme switch check(s) failed");
        }
        System.out.println("THEME SWITCH CHECK DONE");
    }

    /** Mean color of a patch of the content area. */
    private static String content(Scene scene) {
        var img = scene.snapshot(null);
        PixelReader reader = img.getPixelReader();
        long rs = 0;
        long gs = 0;
        long bs = 0;
        long n = 0;
        int w = (int) img.getWidth();
        int h = (int) img.getHeight();
        for (int y = (int) (h * 0.55); y < h * 0.95; y += 4) {
            for (int x = (int) (w * 0.60); x < w * 0.97; x += 4) {
                int p = reader.getArgb(x, y);
                rs += (p >> 16) & 0xFF;
                gs += (p >> 8) & 0xFF;
                bs += p & 0xFF;
                n++;
            }
        }
        return String.format("#%02X%02X%02X", (int) (rs / n), (int) (gs / n), (int) (bs / n));
    }

    private static boolean isLight(Scene scene) {
        String c = content(scene);
        System.out.println("        content=" + c);
        return redOf(c) > 0x90;   // light page: red channel well above 0x90
    }

    private static boolean isAlexiaGreen(Scene scene) {
        String c = content(scene);
        System.out.println("        content=" + c);
        // dark and green-tinted: green channel clearly above red and blue
        return c.charAt(3) >= '1' && c.charAt(3) <= '3'
                && c.charAt(1) >= '0' && c.charAt(1) <= '2'
                && greenOf(c) > redOf(c);
    }

    private static boolean isPrimerDarkGray(Scene scene) {
        String c = content(scene);
        System.out.println("        content=" + c);
        // Primer Dark subtle #161B22: dark, blue >= red (no green tint)
        return c.charAt(1) >= '1' && blueOf(c) >= redOf(c) && greenOf(c) <= blueOf(c);
    }

    private static int redOf(String hex) {
        return Integer.parseInt(hex.substring(1, 3), 16);
    }

    private static int greenOf(String hex) {
        return Integer.parseInt(hex.substring(3, 5), 16);
    }

    private static int blueOf(String hex) {
        return Integer.parseInt(hex.substring(5, 7), 16);
    }
}
