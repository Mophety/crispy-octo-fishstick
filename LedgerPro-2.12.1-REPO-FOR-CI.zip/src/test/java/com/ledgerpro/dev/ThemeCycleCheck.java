package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.Theme;
import com.ledgerpro.ui.ThemeManager;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.PauseTransition;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 2.12.0 theme-cycle regression (dev check, test sources).
 *
 * Walks EVERY shipped theme on one live scene — the exact runtime-switch
 * path the sidebar picker takes — and after each switch samples the
 * rendered pixels of three surfaces (sidebar, content, a nav pill) so the
 * check proves:
 *
 * <ul>
 *   <li>every theme actually changes the painted pixels (a stale-style
 *       switch would leave the previous theme's colors behind);</li>
 *   <li>adjacent themes differ (Primer Light ≠ Primer Dark, …);</li>
 *   <li>the two overlay themes (Nord Dark AA, Alexia) land their OWN
 *       colors, not the PrimerDark base they ride on;</li>
 *   <li>each frame carries ink (not a blank/failed render).</li>
 * </ul>
 *
 * Run headless on Xvfb:
 *   java ... com.ledgerpro.dev.ThemeCycleCheck /path/to/seeded.db
 */
public final class ThemeCycleCheck {

    private record Rgb(int r, int g, int b) {}

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        StringBuilder report = new StringBuilder();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                Scene scene = App.buildScene(database, 1280, 820);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                java.util.List<Theme> order = java.util.List.of(Theme.values());
                java.util.Map<String, Rgb> seen = new java.util.HashMap<>();
                int steps = order.size();
                final int[] idx = {0};

                PauseTransition step = new PauseTransition(Duration.millis(450));
                step.setOnFinished(e -> Platform.runLater(() -> {
                    try {
                        if (idx[0] >= steps) {
                            System.out.print(report);
                            Platform.exit();
                            done.countDown();
                            return;
                        }
                        Theme theme = order.get(idx[0]);
                        ThemeManager.apply(theme, scene);
                        PauseTransition settle = new PauseTransition(Duration.millis(350));
                        settle.setOnFinished(e2 -> Platform.runLater(() -> {
                            try {
                                WritableImage shot = scene.snapshot(null);
                                Rgb sidebar = sample(shot, 60, 400);
                                Rgb content = sample(shot, 900, 400);
                                Rgb pill = sample(shot, 60, 120);
                                double ink = inkRatio(shot);
                                String key = theme.name();
                                Rgb prior = seen.get(key);
                                if (prior != null
                                        && (Math.abs(prior.r - sidebar.r) > 6
                                        || Math.abs(prior.g - sidebar.g) > 6
                                        || Math.abs(prior.b - sidebar.b) > 6)) {
                                    report.append("CHECK FAIL same theme painted "
                                            + "different colors across cycles: ")
                                            .append(key).append('\n');
                                }
                                seen.put(key, sidebar);
                                report.append(String.format(
                                        java.util.Locale.ROOT,
                                        "THEME %-12s sidebar=rgb(%d,%d,%d) "
                                                + "content=rgb(%d,%d,%d) "
                                                + "pill=rgb(%d,%d,%d) ink=%.3f%n",
                                        key, sidebar.r, sidebar.g, sidebar.b,
                                        content.r, content.g, content.b,
                                        pill.r, pill.g, pill.b, ink));
                                if (ink < 0.01) {
                                    report.append("CHECK FAIL theme rendered a "
                                            + "blank frame: ").append(key).append('\n');
                                }
                            } catch (Throwable t) {
                                failure.set(t);
                            } finally {
                                idx[0]++;
                                step.play();
                            }
                        }));
                        settle.play();
                    } catch (Throwable t) {
                        failure.set(t);
                        Platform.exit();
                        done.countDown();
                    }
                }));
                step.play();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("theme cycle check timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("theme cycle check failed",
                    failure.get());
        }
        // post-conditions computed off-thread
        String text = report.toString();
        java.util.Set<String> distinct = new java.util.HashSet<>();
        for (String line : text.split("\n")) {
            if (line.startsWith("THEME")) {
                distinct.add(line.substring(line.indexOf("sidebar=")));
            }
        }
        if (distinct.size() < 4) {
            throw new IllegalStateException("themes did not repaint distinctly: "
                    + distinct.size() + " distinct frames");
        }
        System.out.println("THEME CYCLE CHECK DONE (" + distinct.size()
                + " distinct frames across " + Theme.values().length + " themes)");
    }

    private static Rgb sample(WritableImage image, int x, int y) {
        PixelReader reader = image.getPixelReader();
        int argb = reader.getArgb(x, y);
        return new Rgb((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF);
    }

    /**
     * Share of sampled pixels that differ from the page's dominant color —
     * the "did anything render" signal that works on light AND dark themes
     * (a raw luminance band misreads a dark background as ink).
     */
    private static double inkRatio(WritableImage image) {
        PixelReader reader = image.getPixelReader();
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        java.util.Map<Integer, Integer> counts = new java.util.HashMap<>();
        for (int yy = 0; yy < h; yy += 8) {
            for (int xx = 0; xx < w; xx += 8) {
                counts.merge(reader.getArgb(xx, yy), 1, Integer::sum);
            }
        }
        int page = counts.entrySet().stream()
                .max(java.util.Map.Entry.comparingByValue()).orElseThrow().getKey();
        int pageR = (page >> 16) & 0xFF;
        int pageG = (page >> 8) & 0xFF;
        int pageB = page & 0xFF;
        long ink = 0;
        long total = 0;
        for (var entry : counts.entrySet()) {
            int argb = entry.getKey();
            int r = (argb >> 16) & 0xFF;
            int g = (argb >> 8) & 0xFF;
            int b = argb & 0xFF;
            total += entry.getValue();
            if (Math.abs(r - pageR) + Math.abs(g - pageG) + Math.abs(b - pageB) > 24) {
                ink += entry.getValue();
            }
        }
        return total == 0 ? 0 : (double) ink / total;
    }

    private ThemeCycleCheck() {
    }
}
