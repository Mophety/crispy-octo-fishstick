package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Side;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;

/**
 * Screenshot seed for the 2.5.0 headless verification tool — an honest
 * demo shape so every view has something real to show. Everything is
 * inserted ONLY when the corresponding table is empty, so real data is
 * never touched.
 */
public final class UiSnapshotSeed {

    private UiSnapshotSeed() {
    }

    /** Clients + chart + FX + journal when empty, so every view shows honest content. */
    public static void seedForScreenshots(Database database) {
        try (Connection con = database.open()) {
            if (count(con, "clients") == 0) {
                seedClients(con);
            }
            if (count(con, "accounts") == 0) {
                seedChart(con);
            }
            if (count(con, "fx_rates") == 0) {
                seedFx(con);
            }
            if (count(con, "periods") == 0) {
                seedPeriodAndJournal(con);
            }
        } catch (Exception e) {
            throw new IllegalStateException("failed to seed the screenshot db", e);
        }
    }

    private static long count(Connection con, String table) throws Exception {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) {
            return rs.next() ? rs.getLong(1) : 0;
        }
    }

    private static void seedClients(Connection con) throws Exception {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO clients(code, name, base_currency, tax_id, is_setup, active)"
                        + " VALUES (?, ?, ?, ?, 1, 1)")) {
            insert(ps, "NRT", "Northwind Retail Trading", "PHP", "009-876-543-001");
            insert(ps, "BCS", "Bright Copy Studio", "PHP", "009-876-543-002");
            insert(ps, "GPP", "Golden Paw Petcare", "USD", "009-876-543-003");
        }
    }

    private static void insert(PreparedStatement ps, String code, String name,
                               String currency, String taxId) throws Exception {
        ps.setString(1, code);
        ps.setString(2, name);
        ps.setString(3, currency);
        ps.setString(4, taxId);
        ps.executeUpdate();
    }

    private static void seedChart(Connection con) throws Exception {
        // a compact but honest corporate chart: the codes the demo journal
        // posts against (cash, AR, supplies, accum dep, AP, unearned,
        // capital, drawing/dividends, service revenue, and expenses)
        Object[][] rows = {
                {"1100", "Cash", AccountType.ASSET, Side.DEBIT, 1, 0},
                {"1200", "Accounts Receivable", AccountType.ASSET, Side.DEBIT, 1, 0},
                {"1300", "Supplies", AccountType.ASSET, Side.DEBIT, 1, 0},
                {"1420", "Equipment", AccountType.ASSET, Side.DEBIT, 1, 0},
                {"1430", "Accumulated Depreciation", AccountType.ASSET, Side.CREDIT, 1, 0},
                {"2100", "Accounts Payable", AccountType.LIABILITY, Side.CREDIT, 1, 0},
                {"2150", "Unearned Service Revenue", AccountType.LIABILITY, Side.CREDIT, 1, 0},
                {"3000", "Ordinary Share Capital", AccountType.EQUITY, Side.CREDIT, 1, 0},
                {"3900", "Dividends Declared", AccountType.EQUITY, Side.DEBIT, 0, 0},
                {"4000", "Service Revenue", AccountType.REVENUE, Side.CREDIT, 0, 0},
                {"6100", "Salaries Expense", AccountType.EXPENSE, Side.DEBIT, 0, 0},
                {"6200", "Rent Expense", AccountType.EXPENSE, Side.DEBIT, 0, 0},
                {"6300", "Utilities Expense", AccountType.EXPENSE, Side.DEBIT, 0, 0},
                {"6400", "Depreciation Expense", AccountType.EXPENSE, Side.DEBIT, 0, 0},
                {"6500", "Supplies Expense", AccountType.EXPENSE, Side.DEBIT, 0, 0},
        };
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT MIN(id) FROM clients")) {
            long clientId = rs.next() ? rs.getLong(1) : 0;
            if (clientId <= 0) {
                throw new IllegalStateException("no client to seed the chart for");
            }
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO accounts(client_id, code, name, type, normal_side,"
                            + " is_permanent, is_retained_earnings, active)"
                            + " VALUES (?, ?, ?, ?, ?, ?, ?, 1)")) {
                for (Object[] row : rows) {
                    ps.setLong(1, clientId);
                    ps.setString(2, (String) row[0]);
                    ps.setString(3, (String) row[1]);
                    ps.setString(4, ((AccountType) row[2]).name());
                    ps.setString(5, ((Side) row[3]).name());
                    ps.setInt(6, (Integer) row[4]);
                    ps.setInt(7, (Integer) row[5]);
                    ps.executeUpdate();
                }
            }
        }
    }

    private static void seedFx(Connection con) throws Exception {
        // column order matches the INSERT below: base (reporting) currency
        // first, then quote (foreign), then the date — 2.12.0 fix: the old
        // rows had date/base/quote, which wrote 'PHP' into base_currency
        // and 'USD' into rate_date and crashed FxRateService.mapRow.
        Object[][] rates = {
                {"PHP", "USD", "2026-01-02", 58.40},
                {"PHP", "EUR", "2026-01-02", 62.90},
                {"PHP", "USD", "2026-01-05", 58.45},
        };
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO fx_rates(base_currency, quote_currency, rate_date,"
                        + " rate, source) VALUES (?, ?, ?, ?, 'MANUAL')")) {
            for (Object[] r : rates) {
                ps.setString(1, (String) r[0]);
                ps.setString(2, (String) r[1]);
                ps.setString(3, (String) r[2]);
                ps.setDouble(4, (Double) r[3]);
                ps.executeUpdate();
            }
        }
    }

    private static void seedPeriodAndJournal(Connection con) throws Exception {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT MIN(id) FROM clients WHERE base_currency = 'PHP'")) {
            long clientId = rs.next() ? rs.getLong(1) : 0;
            if (clientId <= 0) {
                throw new IllegalStateException("no PHP client to seed the period for");
            }
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO periods(client_id, name, start_date, end_date, status)"
                            + " VALUES (?, 'FY2026', '2026-01-01', '2026-12-31',"
                            + " 'OPEN')",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setLong(1, clientId);
                ps.executeUpdate();
                ResultSet keys = ps.getGeneratedKeys();
                if (!keys.next() || keys.getObject(1) == null) {
                    throw new IllegalStateException("period insert returned no key");
                }
                long periodId = ((Number) keys.getObject(1)).longValue();

                // opening capital: 500,000 investment (Cash debited, Share
                // Capital credited — the way books actually open)
                entry(con, clientId, periodId, 1, "NORMAL", "2026-01-02", "OB-1",
                        "Opening books", "1100", 50_000_000L, "3000", 50_000_000L);
                // service revenue spread over the year (the trend chart needs months)
                entry(con, clientId, periodId, 2, "NORMAL", "2026-02-15", "INV-101",
                        "February retainer", "1100", 12_000_000L, "4000", 12_000_000L);
                entry(con, clientId, periodId, 3, "NORMAL", "2026-04-20", "INV-102",
                        "April service fees", "1200", 3_500_000L, "4000", 3_500_000L);
                entry(con, clientId, periodId, 4, "NORMAL", "2026-07-18", "INV-103",
                        "July service fees", "1200", 2_800_000L, "4000", 2_800_000L);
                entry(con, clientId, periodId, 5, "NORMAL", "2026-10-05", "INV-104",
                        "October service fees", "1200", 3_100_000L, "4000", 3_100_000L);
                // expenses across the year (the pie chart needs several accounts)
                entry(con, clientId, periodId, 6, "NORMAL", "2026-01-31", "PAY-1",
                        "January payroll", "6100", 1_800_000L, "1100", 1_800_000L);
                entry(con, clientId, periodId, 7, "NORMAL", "2026-02-28", "PAY-2",
                        "February payroll", "6100", 1_800_000L, "1100", 1_800_000L);
                entry(con, clientId, periodId, 8, "NORMAL", "2026-03-31", "RENT-1",
                        "Q1 office rent", "6200", 1_500_000L, "1100", 1_500_000L);
                entry(con, clientId, periodId, 9, "NORMAL", "2026-03-31", "UTIL-1",
                        "Q1 utilities", "6300", 240_000L, "1100", 240_000L);
                entry(con, clientId, periodId, 10, "NORMAL", "2026-04-30", "PAY-3",
                        "April payroll", "6100", 1_800_000L, "1100", 1_800_000L);
                entry(con, clientId, periodId, 11, "NORMAL", "2026-06-30", "DIV-1",
                        "Q2 dividends", "3900", 350_000L, "1100", 350_000L);
                // adjustments: depreciation 1,200 + supplies used 2,700 + unearned earned 1,600
                entry(con, clientId, periodId, 12, "ADJUSTING", "2026-12-31", "ADJ-DEP",
                        "Annual depreciation", "6400", 120_000L, "1430", 120_000L);
                entry(con, clientId, periodId, 13, "ADJUSTING", "2026-12-31", "ADJ-SUP",
                        "Supplies consumed", "6500", 270_000L, "1300", 270_000L);
                entry(con, clientId, periodId, 14, "ADJUSTING", "2026-12-31", "ADJ-UNE",
                        "Unearned earned", "2150", 160_000L, "4000", 160_000L);
            }
        }
    }

    private static void entry(Connection con, long clientId, long periodId,
                              int entryNo, String type, String date,
                              String reference, String memo,
                              String drCode, long drCents,
                              String crCode, long crCents) throws Exception {
        long entryId;
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO journal_entries(client_id, period_id, entry_no, type,"
                        + " entry_date, reference, memo, posted)"
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, 1)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, clientId);
            ps.setLong(2, periodId);
            ps.setInt(3, entryNo);
            ps.setString(4, type);
            ps.setString(5, date);
            ps.setString(6, reference);
            ps.setString(7, memo);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (!keys.next() || keys.getObject(1) == null) {
                throw new IllegalStateException("entry insert returned no key");
            }
            entryId = ((Number) keys.getObject(1)).longValue();
        }
        line(con, entryId, 1, drCode, drCents, 0);
        line(con, entryId, 2, crCode, 0, crCents);
    }

    private static void line(Connection con, long entryId, int lineNo, String code,
                             long drCents, long crCents) throws Exception {
        long accountId;
        try (PreparedStatement find = con.prepareStatement(
                "SELECT a.id FROM accounts a JOIN clients c ON c.id = a.client_id"
                        + " WHERE a.code = ? AND c.base_currency = 'PHP'"
                        + " ORDER BY a.id LIMIT 1")) {
            find.setString(1, code);
            ResultSet rs = find.executeQuery();
            accountId = rs.next() ? rs.getLong(1) : 0;
        }
        if (accountId <= 0) {
            throw new IllegalStateException("no account '" + code + "' to seed");
        }
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO journal_lines(entry_id, line_no, account_id,"
                        + " debit_cents, credit_cents) VALUES (?, ?, ?, ?, ?)")) {
            ps.setLong(1, entryId);
            ps.setInt(2, lineNo);
            ps.setLong(3, accountId);
            // the CHECK on journal_lines is "exactly one side filled": the
            // empty side is SQL NULL (setNull — a boxed-null ternary would NPE)
            if (drCents == 0) {
                ps.setNull(4, Types.INTEGER);
            } else {
                ps.setLong(4, drCents);
            }
            if (crCents == 0) {
                ps.setNull(5, Types.INTEGER);
            } else {
                ps.setLong(5, crCents);
            }
            ps.executeUpdate();
        }
    }
}
