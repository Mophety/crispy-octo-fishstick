package com.ledgerpro.dev;

import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.JournalEntry;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.db.Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.List;

/**
 * Stress books for the 2.12.1 layout audit (dev tool, test sources).
 *
 * <p>A SECOND client ("XTME — Extremes Trading Co.") next to the Northwind
 * demo, built to hit every edge the dashboard and journal charts have:</p>
 *
 * <ul>
 *   <li>a 9-digit month (revenue 123,456,789.00) — axis ticks, compact
 *       labels, column widths;</li>
 *   <li>a month whose revenue is exactly ZERO (expenses only) — the point
 *       sits on the x-axis and must stay visible;</li>
 *   <li>five expense accounts, two of them under 3% — the pie's "Other"
 *       bucket and its legend;</li>
 *   <li>a draft, a posted-then-voided entry with its reversing mirror, and
 *       an entry whose memo is far longer than one cell — the journal's
 *       status pills, voided-row styling and memo tooltip.</li>
 * </ul>
 *
 * <p>Only ever added to a throwaway audit database; never to the user's.</p>
 */
public final class AuditScenarios {

    private AuditScenarios() {
    }

    /** The client code of the stress books. */
    public static final String CODE = "XTME";

    /** Seeds the stress client once; returns its id. */
    public static long seedExtremes(Database database) {
        try (Connection con = database.open();
             var ps = con.prepareStatement("SELECT id FROM clients WHERE code = ?")) {
            ps.setString(1, CODE);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot look for " + CODE, e);
        }
        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        JournalService journal = new JournalService(database, new FxRateService(database));

        long clientId = clients.create(CODE, "Extremes Trading Co.", "PHP").id();
        accounts.applyStandardChart(clientId);
        long periodId = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31)).id();

        long cash = account(accounts, clientId, "1010");
        long capital = account(accounts, clientId, "3000");
        long revenue = account(accounts, clientId, "4000");
        long salaries = account(accounts, clientId, "6000");
        long rent = account(accounts, clientId, "6100");
        long utilities = account(accounts, clientId, "6110");
        long supplies = account(accounts, clientId, "6150");
        long misc = account(accounts, clientId, "6800");

        post(journal, clientId, periodId, LocalDate.of(2026, 1, 5),
                "CAP-001", "Initial capital — owners' cash in", 10_000_000_00L, cash, capital);
        post(journal, clientId, periodId, LocalDate.of(2026, 2, 10),
                "SLS-0001", "February sales — the 9-digit month", 123_456_789_00L, cash, revenue);
        post(journal, clientId, periodId, LocalDate.of(2026, 3, 15),
                "RENT-03", "March rent — a month with zero revenue", 18_000_00L, rent, cash);
        post(journal, clientId, periodId, LocalDate.of(2026, 5, 20),
                "SLS-0002", "May sales — a small month", 4_999_99L, cash, revenue);
        post(journal, clientId, periodId, LocalDate.of(2026, 6, 30),
                "PAY-06", "June payroll", 132_000_00L, salaries, cash);
        post(journal, clientId, periodId, LocalDate.of(2026, 6, 30),
                "MERA-06", "June utilities — 2.3% of expenses", 3_500_00L, utilities, cash);
        post(journal, clientId, periodId, LocalDate.of(2026, 6, 30),
                "SUP-06", "June supplies — 0.8% of expenses", 1_200_00L, supplies, cash);
        post(journal, clientId, periodId, LocalDate.of(2026, 6, 30),
                "MISC-06", "June miscellany", 8_500_00L, misc, cash);

        // an entry whose memo is far longer than one memo cell (tooltip check)
        String longMemo = "Annual general meeting refreshments, venue hire, sound system and the "
                + "printed handouts for the stockholders — reimbursed through the petty cash "
                + "custodian with official receipts attached to the voucher (AGM-2026-PETTY)";
        post(journal, clientId, periodId, LocalDate.of(2026, 9, 30),
                "PETTY-0930", longMemo, 6_400_00L, misc, cash);

        // a posted-then-voided duplicate: the register keeps both sides
        JournalEntry duplicate = post(journal, clientId, periodId, LocalDate.of(2026, 8, 9),
                "MERA-08", "August utilities — accidental duplicate posting", 2_900_00L,
                utilities, cash);
        journal.voidEntry(duplicate.id(), "typed twice — the second posting is cancelled");

        // a draft: nothing posted, shows the amber pill
        journal.createDraft(new JournalService.NewEntry(clientId, periodId,
                LocalDate.of(2026, 7, 2), EntryType.NORMAL,
                "SLS-0003", "Draft: invoice not yet delivered to the customer", null, null,
                List.of(new JournalService.NewLine(cash, 12_345_67L, null, null),
                        new JournalService.NewLine(revenue, null, 12_345_67L, null))));
        return clientId;
    }

    private static long account(AccountService accounts, long clientId, String code) {
        return accounts.findByCode(clientId, code)
                .orElseThrow(() -> new IllegalStateException(
                        "standard chart is missing account " + code))
                .id();
    }

    /** A posted two-line entry: debit {@code debit}, credit {@code credit}. */
    private static JournalEntry post(JournalService journal, long clientId, long periodId,
                                     LocalDate date, String reference, String memo,
                                     long cents, long debit, long credit) {
        JournalEntry draft = journal.createDraft(new JournalService.NewEntry(
                clientId, periodId, date, EntryType.NORMAL, reference, memo, null, null,
                List.of(new JournalService.NewLine(debit, cents, null, null),
                        new JournalService.NewLine(credit, null, cents, null))));
        return journal.post(draft.id());
    }
}
