package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.model.Period;

import java.time.LocalDate;
import java.util.List;

/**
 * Builds a LARGE journal for scale testing (dev tool): one client, one
 * year-long period, N posted entries with 2-4 lines each — the shape a
 * real year of books has, at a size the demo seed never reaches.
 *
 *   java ... com.ledgerpro.dev.SeedBigJournal /tmp/big.db 2000
 */
public final class SeedBigJournal {

    public static void main(String[] args) throws Exception {
        String path = args.length > 0 ? args[0] : "/tmp/big.db";
        int entries = args.length > 1 ? Integer.parseInt(args[1]) : 2000;

        Database db = new Database(path);
        db.migrate();

        ClientService clients = new ClientService(db);
        AccountService accounts = new AccountService(db);
        PeriodService periods = new PeriodService(db);
        FxRateService fx = new FxRateService(db);
        JournalService journal = new JournalService(db, fx);

        long clientId;
        var existing = clients.list(false);
        if (existing.isEmpty()) {
            clientId = clients.create("BIG", "Big Year Co", "PHP").id();
        } else {
            clientId = existing.getFirst().id();
        }
        List<Account> chart = accounts.list(clientId, false);
        if (chart.size() < 4) {
            accounts.applyStandardChart(clientId);
            chart = accounts.list(clientId, false);
        }
        Account cash = chart.get(0);
        Account revenue = chart.stream()
                .filter(a -> a.type().name().contains("REVENUE"))
                .findFirst().orElse(chart.get(chart.size() - 1));
        Account expense = chart.stream()
                .filter(a -> a.type().name().contains("EXPENSE"))
                .findFirst().orElse(chart.get(chart.size() - 1));

        List<Period> ps = periods.list(clientId);
        Period period = ps.isEmpty()
                ? periods.create(clientId, "FY2026",
                        LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31))
                : ps.getFirst();

        java.util.List<Long> created = new java.util.ArrayList<>();
        for (int i = 0; i < entries; i++) {
            int day = (i % 360) + 1;
            LocalDate date = LocalDate.of(2026, 1, 1).plusDays(day - 1);
            long amount = 1_000_00 + (i % 50) * 100;
            created.add(journal.createDraft(new JournalService.NewEntry(clientId,
                    period.id(), date, com.ledgerpro.model.EntryType.NORMAL,
                    null, "scale entry " + i, null, null, List.of(
                            new JournalService.NewLine(cash.id(), amount, null, null),
                            new JournalService.NewLine(revenue.id(), null, amount, null)))).id());
            if (i % 3 == 0) {
                long amt2 = 500_00 + (i % 30) * 50;
                created.add(journal.createDraft(new JournalService.NewEntry(clientId,
                        period.id(), date, com.ledgerpro.model.EntryType.NORMAL,
                        null, "scale expense " + i, null, null, List.of(
                                new JournalService.NewLine(expense.id(), amt2, null, null),
                                new JournalService.NewLine(cash.id(), null, amt2, null)))).id());
            }
        }
        // post everything
        for (long id : created) {
            journal.post(id);
        }
        System.out.println("seeded big journal: " + entries + "+ entries at " + path);
    }

    private SeedBigJournal() {
    }
}
