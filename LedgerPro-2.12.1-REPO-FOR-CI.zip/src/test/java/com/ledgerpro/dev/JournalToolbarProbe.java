package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.UiScale;
import com.ledgerpro.ui.ViewId;
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Labeled;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * P4 Step 6 (2.12.1): measures the JOURNAL toolbar's rows — every
 * button's text vs. its rendered width (is the label really clipped?),
 * plus the rows' total minimum widths against the window. Headless,
 * same seed as JournalScaleSnapshots.
 *
 * <pre>
 * mvn -o exec:java -Ddb.cli.class=com.ledgerpro.dev.JournalToolbarProbe \
 *     -Dexec.classpathScope=test -Dexec.args="/tmp/p4probe.db"
 * </pre>
 */
public final class JournalToolbarProbe {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "/tmp/p4probe.db";
        System.setProperty("prism.order", "sw");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Files.deleteIfExists(Path.of(dbPath));
        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                JournalScaleSnapshots.seedPublic(database);

                double[][] matrix = {
                        {1.00, 1100, 700}, {1.00, 1280, 820},
                        {1.30, 1100, 700}, {1.30, 1280, 820}};
                int[] steps = {0};
                Runnable[] chain = new Runnable[1];
                chain[0] = () -> {
                    if (steps[0] >= matrix.length) {
                        Platform.exit();
                        done.countDown();
                        return;
                    }
                    double scale = matrix[steps[0]][0];
                    int width = (int) matrix[steps[0]][1];
                    int height = (int) matrix[steps[0]][2];
                    Scene scene = App.buildScene(database, width, height);
                    AppShell shell = (AppShell) scene.getRoot();
                    shell.show(ViewId.JOURNAL);
                    Stage stage = new Stage();
                    stage.setScene(scene);
                    stage.show();

                    UiScale ui = UiScale.getInstance();
                    ui.setMode(UiScale.Mode.FIXED);
                    ui.setCustomScale(scale);
                    ui.reapplyNow();

                    PauseTransition settle = new PauseTransition(Duration.millis(900));
                    settle.setOnFinished(e -> {
                        try {
                            System.out.println("== scale " + scale + " window " + width + "x" + height);
                            for (Node n : scene.getRoot().lookupAll(".button")) {
                                if (n instanceof Button b) {
                                    String text = b.getText();
                                    if (text == null || text.isBlank()) {
                                        continue;
                                    }
                                    // does the label's own LabeledText clip?
                                    javafx.scene.Node inner = b.lookup(".text");
                                    boolean clipped = inner instanceof javafx.scene.text.Text t
                                            && t.getLayoutBounds().getWidth()
                                                < textWidth(text, b) - 1;
                                    System.out.printf("  btn %-18s w=%.0f textW=%.0f %s%n",
                                            text, b.getWidth(), textWidth(text, b),
                                            clipped ? "CLIPPED" : "ok");
                                }
                            }
                            stage.close();
                        } catch (Throwable t) {
                            failure.set(t);
                        }
                        steps[0]++;
                        chain[0].run();
                    });
                    settle.play();
                };
                chain[0].run();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(90, TimeUnit.SECONDS)) {
            throw new IllegalStateException("toolbar probe timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("toolbar probe failed", failure.get());
        }
    }

    private static double textWidth(String text, Labeled control) {
        javafx.scene.text.Text probe = new javafx.scene.text.Text(text);
        probe.setFont(control.getFont());
        return probe.getBoundsInLocal().getWidth();
    }
}
