package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.ui.Prefs;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Verifies the 2.8.0 journal modes at the SCENE level (not pixels): the
 * ENTRY_LINES table's rows — account rows plus the '# memo' continuation
 * rows — and the register's zebra/pill state. Prints the row model so the
 * check is exact.
 */
public final class JournalModeProbe {

    public static void main(String[] args) throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");
        CountDownLatch done = new CountDownLatch(1);

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Path dir = Files.createTempDirectory("jm280");
                Database database = new Database(dir.resolve("ledgerpro.db").toString());
                database.migrate();

                com.ledgerpro.service.AccountService accounts =
                        new com.ledgerpro.service.AccountService(database);
                ClientService clients = new ClientService(database);
                PeriodService periods = new PeriodService(database);
                JournalService journal = new JournalService(database,
                        new com.ledgerpro.service.FxRateService(database));

                long clientId = clients.create("NRTH", "Northwind Retail", "PHP").id();
                accounts.applyStandardChart(clientId);
                long fy = periods.create(clientId, "FY 2026",
                        LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31)).id();
                long cash = accounts.findByCode(clientId, "1010").orElseThrow().id();
                long capital = accounts.findByCode(clientId, "3000").orElseThrow().id();
                long sales = accounts.findByCode(clientId, "4010").orElseThrow().id();

                journal.post(journal.createDraft(new JournalService.NewEntry(
                        clientId, fy, LocalDate.of(2026, 1, 1), EntryType.NORMAL,
                        null, "initial capital", null, null, List.of(
                        new JournalService.NewLine(cash, 1_000_000_00L, null, "capital in"),
                        new JournalService.NewLine(capital, null, 1_000_000_00L, "capital in")))).id());
                journal.post(journal.createDraft(new JournalService.NewEntry(
                        clientId, fy, LocalDate.of(2026, 3, 5), EntryType.NORMAL,
                        null, "cash sales", null, null, List.of(
                        new JournalService.NewLine(cash, 420_000_00L, null, "sale"),
                        new JournalService.NewLine(sales, null, 420_000_00L, "sale")))).id());

                Scene scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                com.ledgerpro.ui.AppShell shell =
                        (com.ledgerpro.ui.AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                // switch to ENTRY_LINES mode and inspect the visible table
                Prefs.getInstance().setJournalMode(Prefs.JournalMode.ENTRY_LINES);
                shell.show(com.ledgerpro.ui.ViewId.JOURNAL);

                javafx.animation.PauseTransition wait = new javafx.animation.PauseTransition(
                        javafx.util.Duration.millis(900));
                wait.setOnFinished(e -> {
                    try {
                        for (javafx.scene.Node node : scene.getRoot().lookupAll(".table-view")) {
                            if (node instanceof TableView<?> tv && node.isVisible()
                                    && node.isManaged()) {
                                System.out.println("table rows: " + tv.getItems().size());
                                for (int i = 0; i < tv.getItems().size(); i++) {
                                    Object row = tv.getItems().get(i);
                                    System.out.println("  row " + i + ": " + row);
                                }
                            }
                        }
                    } finally {
                        done.countDown();
                    }
                });
                wait.play();
            } catch (Throwable t) {
                t.printStackTrace();
                done.countDown();
            }
        });
        done.await(60, TimeUnit.SECONDS);
        Platform.exit();
    }
}
