package com.ledgerpro.dev;

import com.ledgerpro.db.Database;

/**
 * One-shot helper (dev tool, test sources): builds the seeded database the
 * StartupProbe copies per run — clients, chart, FX and a posted journal, the
 * exact {@link UiSnapshotSeed#seedForScreenshots} shape every headless
 * capture already uses.
 *
 * <pre>
 *   java -cp test-classes:app.jar:deps com.ledgerpro.dev.SeedProbeDb /tmp/probe-seed.db
 * </pre>
 */
public final class SeedProbeDb {

    public static void main(String[] args) throws Exception {
        String path = args.length > 0 ? args[0] : "/tmp/probe-seed.db";
        Database database = new Database(path);
        database.migrate();
        UiSnapshotSeed.seedForScreenshots(database);
        System.out.println("probe database seeded: " + path);
    }

    private SeedProbeDb() {
    }
}
