package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.UiScale;
import com.ledgerpro.ui.ViewId;
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * P4 Step 6 (2.12.1): headless JOURNAL capture at 100% / 130% text scale
 * across 1100x700, 1280x820 and 1680x1050 windows (the sidebar ships
 * in every capture — the shell wraps the journal), six PNGs plus a
 * scene-text dump per capture, seeded with the user's exact C1/C2
 * figures INCLUDING entry #21 ("sads"/"sasa") staying untouched.
 *
 * <pre>
 * mvn -o exec:java -Ddb.cli.class=com.ledgerpro.dev.JournalScaleSnapshots \
 *     -Dexec.classpathScope=test -Dexec.args="/tmp/p4snap.db /tmp/p4snap"
 * </pre>
 */
public final class JournalScaleSnapshots {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "/tmp/p4snap.db";
        String outDir = args.length > 1 ? args[1] : "/tmp/p4snap";

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Files.deleteIfExists(Path.of(dbPath));
        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                seed(database);

                double[][] matrix = {
                        {1.00, 1100, 700}, {1.00, 1280, 820},
                        {1.00, 1680, 1050},
                        {1.30, 1100, 700}, {1.30, 1280, 820},
                        {1.30, 1680, 1050}};
                int[] steps = {0};
                Runnable[] chain = new Runnable[1];
                chain[0] = () -> {
                    if (steps[0] >= matrix.length) {
                        Platform.exit();
                        done.countDown();
                        return;
                    }
                    double scale = matrix[steps[0]][0];
                    int width = (int) matrix[steps[0]][1];
                    int height = (int) matrix[steps[0]][2];
                    Scene scene = App.buildScene(database, width, height);
                    AppShell shell = (AppShell) scene.getRoot();
                    shell.show(ViewId.JOURNAL);
                    Stage stage = new Stage();
                    stage.setScene(scene);
                    stage.show();

                    UiScale ui = UiScale.getInstance();
                    ui.setMode(UiScale.Mode.FIXED);
                    ui.setCustomScale(scale);
                    ui.reapplyNow();

                    PauseTransition settle = new PauseTransition(Duration.millis(900));
                    settle.setOnFinished(e -> {
                        try {
                            String tag = String.format("scale%03d-%dx%d",
                                    Math.round(scale * 100), width, height);
                            Path out = Path.of(outDir, "journal-" + tag + ".png");
                            Files.createDirectories(out.getParent());
                            WritableImage image = scene.snapshot(null);
                            writePng(image, out);
                            dumpScene(scene, Path.of(outDir, "journal-" + tag + ".txt"));
                            System.out.println("written " + out.toAbsolutePath()
                                    + " appliedScale=" + ui.getScale());
                            stage.close();
                        } catch (Throwable t) {
                            failure.set(t);
                        }
                        steps[0]++;
                        chain[0].run();
                    });
                    settle.play();
                };
                chain[0].run();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("journal snapshots timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("journal snapshots failed", failure.get());
        }
    }

    // ------------------------------------------------------------------
    // Scene dump (labels / chart / table cells) — the text-level evidence
    // ------------------------------------------------------------------

    private static void dumpScene(Scene scene, Path out) throws Exception {
        StringBuilder sb = new StringBuilder();
        java.util.function.Consumer<javafx.scene.Node> walk = new java.util.function.Consumer<>() {
            @Override
            public void accept(javafx.scene.Node node) {
                if (node instanceof javafx.scene.control.Labeled l
                        && l.getText() != null && !l.getText().isBlank()) {
                    sb.append("LABEL  ").append(l.getText().strip()).append('\n');
                } else if (node instanceof javafx.scene.text.Text t
                        && t.getText() != null && !t.getText().isBlank()) {
                    sb.append("TEXT   ").append(t.getText().strip()).append('\n');
                    if (t.getText().strip().endsWith("...")
                            && !t.getText().strip().endsWith("…")) {
                        sb.append("  at   ");
                        for (javafx.scene.Node p = t.getParent(); p != null; p = p.getParent()) {
                            sb.append(p.getClass().getSimpleName()).append('>');
                            if (p instanceof javafx.scene.control.Labeled l) {
                                sb.append("label=").append(l.getText()).append(' ');
                            }
                        }
                        sb.append('\n');
                    }
                }
                if (node instanceof javafx.scene.Parent parent) {
                    for (javafx.scene.Node child : parent.getChildrenUnmodifiable()) {
                        accept(child);
                    }
                }
            }
        };
        walk.accept(scene.getRoot());
        Files.writeString(out, sb.toString());
    }

    private static void writePng(WritableImage image, Path out) throws Exception {
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                PixelFormat.getIntArgbInstance(), pixels, 0, w);
        BufferedImage buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        ImageIO.write(buffered, "png", out.toFile());
    }

    // ------------------------------------------------------------------
    // The seed — the user's exact C1/C2 figures; entry #21 stays
    // ------------------------------------------------------------------

    private static com.ledgerpro.service.JournalService journal;
    private static com.ledgerpro.service.AccountService accountService;
    private static long clientId;
    private static long periodId;

    /** The Phase 4 seed (shared with JournalToolbarProbe). */
    static void seedPublic(Database database) {
        seed(database);
    }

    private static void seed(Database database) {
        var clients = new com.ledgerpro.service.ClientService(database);
        accountService = new com.ledgerpro.service.AccountService(database);
        var periods = new com.ledgerpro.service.PeriodService(database);
        var fx = new com.ledgerpro.service.FxRateService(database);
        journal = new com.ledgerpro.service.JournalService(database, fx);

        clientId = clients.create("NRTH", "Northwind Retail Trading", "PHP").id();
        accountService.applyStandardChart(clientId);
        periodId = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31)).id();

        post(LocalDate.of(2026, 1, 1), "initial capital",
                dr("1010", 500_000_00L), cr("3000", 500_000_00L));
        post(LocalDate.of(2026, 2, 1), "owner withdrawal",
                dr("3300", 30_000_00L), cr("1010", 30_000_00L));
        post(LocalDate.of(2026, 3, 5), "credit sale",
                dr("1100", 300_000_00L), cr("4010", 300_000_00L));
        post(LocalDate.of(2026, 4, 10), "cash sale",
                dr("1010", 150_000_00L), cr("4010", 150_000_00L));
        post(LocalDate.of(2026, 5, 15), "rent accrued",
                dr("6100", 60_000_00L), cr("2000", 60_000_00L));
        post(LocalDate.of(2026, 6, 20), "utilities accrued",
                dr("6110", 31_570_00L), cr("2000", 31_570_00L));
        post(LocalDate.of(2026, 7, 25), "salaries",
                dr("6000", 200_000_00L), cr("1010", 200_000_00L));
        post(LocalDate.of(2026, 8, 30), "fees earned",
                dr("1010", 61_457_92L), cr("4010", 61_457_92L));
        post(LocalDate.of(2026, 9, 15), "misc expenses",
                dr("6110", 77_430_00L), cr("1010", 77_430_00L));
        post(LocalDate.of(2026, 10, 10), "bad debt recovered",
                dr("1010", 21_000_00L), cr("4010", 21_000_00L));

        long voidTarget = journal.list(clientId, periodId).stream()
                .filter(s -> s.entry().memo().contains("bad debt"))
                .findFirst().orElseThrow().entry().id();
        journal.voidEntry(voidTarget, "wrong customer — rebook next month");

        // entry #21 — the user's own test rows, untouched (a DRAFT pair
        // keeps the register honest about all three states; NOT voided:
        // the user said they will void it themselves in the app)
        post(LocalDate.of(2026, 11, 2), "sads",
                dr("6110", 1_000_00L), cr("1010", 1_000_00L));
        post(LocalDate.of(2026, 11, 3), "sasa",
                dr("6110", 2_000_00L), cr("1010", 2_000_00L));
    }

    private static void post(LocalDate date, String memo,
                             com.ledgerpro.service.JournalService.NewLine... lines) {
        journal.post(journal.createDraft(new com.ledgerpro.service.JournalService.NewEntry(
                clientId, periodId, date, com.ledgerpro.model.EntryType.NORMAL,
                null, memo, null, null, List.of(lines))).id());
    }

    private static com.ledgerpro.service.JournalService.NewLine dr(
            String code, long cents) {
        return new com.ledgerpro.service.JournalService.NewLine(
                idOf(code), cents, null, null);
    }

    private static com.ledgerpro.service.JournalService.NewLine cr(
            String code, long cents) {
        return new com.ledgerpro.service.JournalService.NewLine(
                idOf(code), null, cents, null);
    }

    private static long idOf(String code) {
        return accountService.list(clientId, false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst().orElseThrow().id();
    }
}
