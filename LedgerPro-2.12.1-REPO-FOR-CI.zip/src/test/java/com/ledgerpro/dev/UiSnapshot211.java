package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.Theme;
import com.ledgerpro.ui.ThemeManager;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The 2.11.0 headless verification captures — the defects the user's
 * screenshots proved, re-measured on the fixed build:
 *
 * <ol>
 *   <li>the JOURNAL in all SIX themes (status-column text-vs-background
 *       contrast is MEASURED per theme in the analysis pass — the user's
 *       dark screenshot failed at a 6/255 luminance gap);</li>
 *   <li>the DASHBOARD on Primer Light and Primer Dark at the USER's window
 *       aspect (1680x1050 logical) — the giant bar chart and the tiny pie
 *       are re-measured there;</li>
 *   <li>the toolbar band of every journal capture — zero ellipsis glyphs
 *       is the gate (the user's screenshots had three).</li>
 * </ol>
 */
public final class UiSnapshot211 {

    public static void main(String[] args) throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Path dir = Files.createTempDirectory("ui211");
                Database database = new Database(dir.resolve("ledgerpro.db").toString());
                database.migrate();
                long nrth = seed(database);

                Scene scene = com.ledgerpro.App.buildScene(database, 1680, 1050);
                AppShell shell = (AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
                Object journal = journalOf(shell);

                // 1) journal in all six themes
                captureThemes(scene, shell, journal, nrth, done, failure);
            } catch (Throwable t) {
                t.printStackTrace();
                failure.set(t);
                done.countDown();
            }
        });

        if (!done.await(300, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI snapshot timed out: " + failure.get());
        }
        Throwable t = failure.get();
        if (t != null) {
            throw new IllegalStateException("UI snapshot failed: " + t, t);
        }
        Platform.exit();
    }

    /** Walks the six themes: journal capture per theme + dashboard on two. */
    private static void captureThemes(Scene scene, AppShell shell, Object journal,
                                      long clientId, CountDownLatch done,
                                      AtomicReference<Throwable> failure) {
        Theme[] themes = Theme.values();
        int[] i = {0};
        next(themes, i, scene, shell, journal, clientId, done, failure);
    }

    private static void next(Theme[] themes, int[] i, Scene scene, AppShell shell,
                             Object journal, long clientId, CountDownLatch done,
                             AtomicReference<Throwable> failure) {
        if (i[0] >= themes.length) {
            done.countDown();
            return;
        }
        Theme theme = themes[i[0]++];
        try {
            ThemeManager.apply(theme, scene);
        } catch (Throwable t) {
            failure.set(t);
            done.countDown();
            return;
        }
        pause(900, () -> {
            try {
                String slug = theme.name().toLowerCase().replace('_', '-');
                // journal
                shell.selectWorkingClientById(clientId);
                shell.show(ViewId.JOURNAL);
                pause(1500, () -> {
                    try {
                        captureSafe(scene, "journal-211-" + slug);
                        // dashboard on the first and second themes (light + dark)
                        if (i[0] <= 2) {
                            shell.show(ViewId.DASHBOARD);
                            pause(2000, () -> {
                                try {
                                    captureSafe(scene, "dashboard-211-" + slug);
                                    next(themes, i, scene, shell, journal,
                                            clientId, done, failure);
                                } catch (Throwable t) {
                                    failure.set(t);
                                    done.countDown();
                                }
                            });
                        } else {
                            next(themes, i, scene, shell, journal,
                                    clientId, done, failure);
                        }
                    } catch (Throwable t) {
                        failure.set(t);
                        done.countDown();
                    }
                });
            } catch (Throwable t) {
                failure.set(t);
                done.countDown();
            }
        });
    }

    /** Prints the toolbar invariants (checked by the pixel pass after). */
    @SuppressWarnings("unused")
    private static void printToolbarWidths(Object journal) {
        for (Node n : ((javafx.scene.Parent) journal).lookupAll(".button")) {
            if (n instanceof Button b) {
                System.out.printf("btn %-14s min=%s pref=%s%n",
                        b.getText(), b.getMinWidth(), b.getPrefWidth());
            }
        }
    }

    private static Object journalOf(AppShell shell) throws Exception {
        shell.show(ViewId.JOURNAL);
        Field f = AppShell.class.getDeclaredField("journalView");
        f.setAccessible(true);
        return f.get(shell);
    }

    @SuppressWarnings("unchecked")
    static TableView<Object> registerTableOf(Object journal) {
        try {
            Field f = Class.forName("com.ledgerpro.ui.JournalView")
                    .getDeclaredField("table");
            f.setAccessible(true);
            return (TableView<Object>) f.get(journal);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    static ObservableList<Node> toolbarButtons(Object journal) {
        return null;
    }

    private static void pause(long ms, Runnable then) {
        javafx.animation.PauseTransition wait = new javafx.animation.PauseTransition(
                javafx.util.Duration.millis(ms));
        wait.setOnFinished(e -> then.run());
        wait.play();
    }

    private static void captureSafe(Scene scene, String name) {
        try {
            capture(scene, name);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void capture(Scene scene, String name) throws Exception {
        javafx.scene.image.WritableImage image = scene.snapshot(null);
        Path out = Path.of("target/ui-snapshots", name + ".png");
        Files.createDirectories(out.getParent());
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                javafx.scene.image.PixelFormat.getIntArgbInstance(), pixels, 0, w);
        java.awt.image.BufferedImage buffered =
                new java.awt.image.BufferedImage(w, h,
                        java.awt.image.BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        javax.imageio.ImageIO.write(buffered, "png", out.toFile());
        System.out.println("captured " + out);
    }

    /** Seeds one client with a small profitable year (the snapshot shape). */
    private static long seed(Database database) {
        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        FxRateService fx = new FxRateService(database);
        JournalService journal = new JournalService(database, fx);

        long clientId = clients.create("NRTH", "Northwind Retail Trading", "PHP").id();
        accounts.applyStandardChart(clientId);
        Period fy = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));

        SeedCtx ctx = new SeedCtx(accounts, journal, clientId, fy);
        post(ctx, LocalDate.of(2026, 1, 1), "initial capital",
                line(ctx, "1010", 1_000_000_00L), line(ctx, "3000", -1_000_000_00L));
        post(ctx, LocalDate.of(2026, 3, 5), "cash sales",
                line(ctx, "1010", 420_000_00L), line(ctx, "4010", -420_000_00L));
        post(ctx, LocalDate.of(2026, 5, 12), "credit sale",
                line(ctx, "1100", 180_000_00L), line(ctx, "4010", -180_000_00L));
        post(ctx, LocalDate.of(2026, 6, 30), "rent paid",
                line(ctx, "6100", 96_000_00L), line(ctx, "1010", -96_000_00L));
        post(ctx, LocalDate.of(2026, 10, 15), "salaries",
                line(ctx, "6000", 132_000_00L), line(ctx, "1010", -132_000_00L));
        post(ctx, LocalDate.of(2026, 11, 1), "utilities",
                line(ctx, "6110", 3_500_00L), line(ctx, "1010", -3_500_00L));

        journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 11, 2), EntryType.NORMAL,
                null, "electricity bill, draft", null, null, List.of(
                line(ctx, "6110", 3_500_00L),
                line(ctx, "1010", -3_500_00L))));
        return clientId;
    }

    /** A debit (positive) or credit (negative) line by account code. */
    private static JournalService.NewLine line(SeedCtx ctx, String code, long signed) {
        long account = ctx.accounts().list(ctx.clientId(), false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst().orElseThrow().id();
        return signed >= 0
                ? new JournalService.NewLine(account, signed, null, null)
                : new JournalService.NewLine(account, null, -signed, null);
    }

    private static void post(SeedCtx ctx, LocalDate date, String memo,
                             JournalService.NewLine... lines) {
        ctx.journal().post(ctx.journal().createDraft(new JournalService.NewEntry(
                ctx.clientId(), ctx.fy().id(), date, EntryType.NORMAL, null, memo,
                null, null, List.of(lines))).id());
    }

    private record SeedCtx(AccountService accounts, JournalService journal,
                           long clientId, Period fy) { }
}
