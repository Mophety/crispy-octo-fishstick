package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.UiScale;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * P3 Step 0 (2.12.1): measure what {@code UiSizing.em()} reports at 100%
 * and 130% text scale, against the root font the responsive-text system
 * actually applies — the probe the phase asked for before ResponsiveGrid
 * gets used on the dashboard.
 *
 * <pre>
 * mvn -o exec:java -Ddb.cli.class=com.ledgerpro.dev.EmProbe \
 *     -Dexec.classpathScope=test -Dexec.args="/tmp/emprobe.db"
 * </pre>
 */
public final class EmProbe {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "/tmp/emprobe.db";
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Files.deleteIfExists(Path.of(dbPath));
        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                Scene scene = App.buildScene(database, 1280, 820);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                double[] scales = {1.00, 1.30};
                int[] step = {0};
                Runnable[] chain = new Runnable[1];
                chain[0] = () -> {
                    if (step[0] >= scales.length) {
                        Platform.exit();
                        done.countDown();
                        return;
                    }
                    double scale = scales[step[0]++];
                    UiScale ui = UiScale.getInstance();
                    ui.setMode(UiScale.Mode.FIXED);
                    ui.setCustomScale(scale);
                    ui.reapplyNow();
                    // settle one pulse so CSS applies the root style
                    javafx.animation.PauseTransition p =
                            new javafx.animation.PauseTransition(javafx.util.Duration.millis(400));
                    p.setOnFinished(e -> {
                        try {
                            String rootStyle = scene.getRoot().styleProperty().get();
                            Label probe = new Label("M");
                            probe.getStyleClass().add("lp-card-title");
                            ((javafx.scene.Parent) scene.getRoot()).getChildrenUnmodifiable();
                            // a hidden label INSIDE the page: put it in the
                            // scene so it inherits the root font
                            Label hidden = new Label("M");
                            hidden.setVisible(false);
                            hidden.setManaged(false);
                            scene.getRoot().getChildrenUnmodifiable();
                            if (scene.getRoot() instanceof javafx.scene.Parent parent) {
                                parent.getChildrenUnmodifiable();
                            }
                            // add to the shell (a StackPane? AppShell is a Parent)
                            javafx.scene.Parent root = scene.getRoot();
                            if (root instanceof javafx.scene.Group g) {
                                g.getChildren().add(hidden);
                            } else if (root instanceof javafx.scene.layout.Pane pane) {
                                pane.getChildren().add(hidden);
                            }
                            hidden.applyCss();
                            Label plain = new Label("M");
                            plain.applyCss();
                            System.out.println("scale=" + scale
                                    + " rootStyle=" + rootStyle
                                    + " inSceneLabelFont=" + hidden.getFont().getSize()
                                    + " orphanLabelFont=" + plain.getFont().getSize()
                                    + " defaultFont=" + javafx.scene.text.Font.getDefault().getSize());
                        } catch (Throwable t) {
                            failure.set(t);
                        }
                        chain[0].run();
                    });
                    p.play();
                };
                chain[0].run();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(60, TimeUnit.SECONDS)) {
            throw new IllegalStateException("em probe timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("em probe failed", failure.get());
        }
    }
}
