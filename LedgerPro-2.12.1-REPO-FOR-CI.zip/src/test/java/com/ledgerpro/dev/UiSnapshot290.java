package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.DialogPane;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The 2.9.0 headless verification captures — one per user-reported issue:
 * the journal in its new default (the paper-book layout), the journal
 * toggled to the register, the dashboard with its on-chart numbers, the
 * dashboard after a client switch (must show the NEW client's own
 * figures, not the old client's ghost), two theme switches (dark, then
 * Alexia's overlay), and the New-entry dialog at its default and stretched
 * sizes (resizable) and at its floor. Same software-rendering recipe as
 * UiSnapshot280.
 */
public final class UiSnapshot290 {

    public static void main(String[] args) throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Path dir = Files.createTempDirectory("ui290");
                Database database = new Database(dir.resolve("ledgerpro.db").toString());
                database.migrate();
                long nrth = seed(database, "NRTH", "Northwind Retail Trading");
                long south = seed(database, "SOUTH", "Southern Haulage Co.");

                Scene scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                com.ledgerpro.ui.AppShell shell =
                        (com.ledgerpro.ui.AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
                shell.selectWorkingClientById(nrth);

                // 1) the journal in its new DEFAULT — the paper book
                shell.show(com.ledgerpro.ui.ViewId.JOURNAL);
                pause(1600, () -> {
                    capture(scene, "journal-paper-290", failure);
                    // 2) the toolbar toggle → register, capture, back
                    toggleJournalLayout(shell);
                    pause(900, () -> {
                        capture(scene, "journal-register-290", failure);
                        toggleJournalLayout(shell);   // restore the default
                        // 3) dashboard: value labels + caption totals
                        shell.show(com.ledgerpro.ui.ViewId.DASHBOARD);
                        pause(2600, () -> {
                            capture(scene, "dashboard-290", failure);
                            // 4) the client switch — SOUTH's own figures must
                            // replace NORTH's (ghost chart bug)
                            shell.selectWorkingClientById(south);
                            pause(2400, () -> {
                                capture(scene, "dashboard-switched-290", failure);
                                // 5) theme switch ×2: dark, then the overlay
                                com.ledgerpro.ui.ThemeManager.apply(
                                        com.ledgerpro.ui.Theme.PRIMER_DARK, scene);
                                pause(900, () -> {
                                    capture(scene, "theme-dark-290", failure);
                                    com.ledgerpro.ui.ThemeManager.apply(
                                            com.ledgerpro.ui.Theme.ALEXIA, scene);
                                    pause(900, () -> {
                                        capture(scene, "theme-alexia-290", failure);
                                        com.ledgerpro.ui.ThemeManager.apply(
                                                com.ledgerpro.ui.Theme.PRIMER_LIGHT,
                                                scene);
                                        // 6) the resizable entry dialog:
                                        // default → 1100×720 → floor 860×560
                                        shell.selectWorkingClientById(nrth);
                                        pause(1400, () -> {
                                            openAndStretchEntryDialog(shell, failure,
                                                    done);
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            } catch (Throwable t) {
                failure.set(t);
                done.countDown();
            }
        });

        if (!done.await(180, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI snapshot timed out — the FX"
                    + " chain stalled; failure so far: " + failure.get());
        }
        Throwable t = failure.get();
        if (t != null) {
            t.printStackTrace();
            throw new IllegalStateException("UI snapshot failed: " + t, t);
        }
        Platform.exit();
    }

    /** Clicks the journal's layout toggle button (the toolbar's swap). */
    private static void toggleJournalLayout(com.ledgerpro.ui.AppShell shell) {
        shell.show(com.ledgerpro.ui.ViewId.JOURNAL);
        for (javafx.scene.Node node : shell.lookupAll(".lp-compact-btn")) {
            if (node instanceof javafx.scene.control.Button button) {
                String text = button.getText();
                if (text != null && (text.contains("register")
                        || text.contains("paper journal"))) {
                    button.fire();
                    return;
                }
            }
        }
    }

    /**
     * Opens the New-entry dialog from the shell's own Ctrl/Cmd+N entry
     * point, then stretches its window and captures at three sizes. The
     * dialog blocks its own thread in showAndWait, so the call rides a
     * background thread and the dialog's window is found among the shown
     * windows (it is a DialogPane root).
     */
    private static void openAndStretchEntryDialog(com.ledgerpro.ui.AppShell shell,
                                                   AtomicReference<Throwable> failure,
                                                   CountDownLatch done) {
        Thread opener = new Thread(() -> Platform.runLater(() -> {
            // inside runLater: fires the journal's offerNewEntry, which opens
            // the modal on THIS FX thread (showAndWait pumps events, so the
            // capture callbacks below still run)
            try {
                java.lang.reflect.Method m = com.ledgerpro.ui.JournalView.class
                        .getDeclaredMethod("offerNewEntry");
                m.setAccessible(true);
                m.invoke(journalOf(shell));
            } catch (Exception e) {
                failure.set(e);
                done.countDown();
            }
        }));
        opener.setDaemon(true);
        opener.start();

        // the dialog window appears async; watch for it and drive the sizes
        waitForDialogWindow(0, shell, failure, done);
    }

    private static void waitForDialogWindow(int attempt,
                                            com.ledgerpro.ui.AppShell shell,
                                            AtomicReference<Throwable> failure,
                                            CountDownLatch done) {
        if (attempt > 200) {   // ~10s
            failure.set(new IllegalStateException("entry dialog never appeared"));
            done.countDown();
            return;
        }
        Window dialogWindow = null;
        for (Window w : Window.getWindows()) {
            if (w instanceof Stage s && s.getScene() != null
                    && s.getScene().getRoot() instanceof DialogPane) {
                dialogWindow = s;
            }
        }
        if (dialogWindow == null) {
            pause(50, () -> waitForDialogWindow(attempt + 1, shell, failure, done));
            return;
        }
        Window window = dialogWindow;
        pause(700, () -> {
            capturePane((DialogPane) ((Stage) window).getScene().getRoot(),
                    "entry-dialog-default-290", failure);
            window.setWidth(1100);
            window.setHeight(720);
            pause(900, () -> {
                capturePane((DialogPane) ((Stage) window).getScene().getRoot(),
                        "entry-dialog-stretched-290", failure);
                window.setWidth(860);
                window.setHeight(560);
                pause(700, () -> {
                    capturePane((DialogPane) ((Stage) window).getScene().getRoot(),
                            "entry-dialog-floor-290", failure);
                    window.hide();
                    done.countDown();
                });
            });
        });
    }

    /** The shell's journal view — created once, cached field. */
    private static com.ledgerpro.ui.JournalView journalOf(
            com.ledgerpro.ui.AppShell shell) throws Exception {
        shell.show(com.ledgerpro.ui.ViewId.JOURNAL);
        java.lang.reflect.Field f = com.ledgerpro.ui.AppShell.class
                .getDeclaredField("journalView");
        f.setAccessible(true);
        Object view = f.get(shell);
        if (view instanceof com.ledgerpro.ui.JournalView journal) {
            return journal;
        }
        throw new IllegalStateException("journal view was never created");
    }

    private static void pause(long ms, Runnable then) {
        javafx.animation.PauseTransition wait = new javafx.animation.PauseTransition(
                javafx.util.Duration.millis(ms));
        wait.setOnFinished(e -> then.run());
        wait.play();
    }

    private static void capture(Scene scene, String name,
                                AtomicReference<Throwable> failure) {
        try {
            javafx.scene.image.WritableImage image = scene.snapshot(null);
            writeImage(image, name);
        } catch (Throwable t) {
            failure.set(t);
        }
    }

    private static void capturePane(DialogPane pane, String name,
                                    AtomicReference<Throwable> failure) {
        try {
            javafx.scene.image.WritableImage image =
                    pane.snapshot(new javafx.scene.SnapshotParameters(), null);
            writeImage(image, name);
        } catch (Throwable t) {
            failure.set(t);
        }
    }

    private static void writeImage(javafx.scene.image.Image image, String name)
            throws Exception {
        Path out = Path.of("target/ui-snapshots", name + ".png");
        Files.createDirectories(out.getParent());
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                javafx.scene.image.PixelFormat.getIntArgbInstance(), pixels, 0, w);
        java.awt.image.BufferedImage buffered =
                new java.awt.image.BufferedImage(w, h,
                        java.awt.image.BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        javax.imageio.ImageIO.write(buffered, "png", out.toFile());
        System.out.println("captured " + out);
    }

    /** Seeds one client with a small profitable year; returns its id. */
    private static long seed(Database database, String code, String name) {
        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        FxRateService fx = new FxRateService(database);
        JournalService journal = new JournalService(database, fx);

        long clientId = clients.create(code, name, "PHP").id();
        accounts.applyStandardChart(clientId);
        Period fy = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));

        SeedCtx ctx = new SeedCtx(accounts, journal, clientId, fy);
        post(ctx, LocalDate.of(2026, 1, 1), "initial capital",
                new JournalService.NewLine(acct(ctx, "1010"), 1_000_000_00L, null,
                        "capital in"),
                new JournalService.NewLine(acct(ctx, "3000"), null, 1_000_000_00L,
                        "capital in"));
        post(ctx, LocalDate.of(2026, 3, 5), "cash sales",
                new JournalService.NewLine(acct(ctx, "1010"), 420_000_00L, null,
                        "sale"),
                new JournalService.NewLine(acct(ctx, "4010"), null, 420_000_00L,
                        "sale"));
        post(ctx, LocalDate.of(2026, 5, 12), "credit sale",
                new JournalService.NewLine(acct(ctx, "1100"), 180_000_00L, null,
                        "on account"),
                new JournalService.NewLine(acct(ctx, "4010"), null, 180_000_00L,
                        "on account"));
        post(ctx, LocalDate.of(2026, 6, 30), "rent paid",
                new JournalService.NewLine(acct(ctx, "6100"), 96_000_00L, null,
                        "rent"),
                new JournalService.NewLine(acct(ctx, "1010"), null, 96_000_00L,
                        "rent"));
        post(ctx, LocalDate.of(2026, 10, 15), "salaries",
                new JournalService.NewLine(acct(ctx, "6000"), 132_000_00L, null,
                        "salaries"),
                new JournalService.NewLine(acct(ctx, "1010"), null, 132_000_00L,
                        "salaries"));

        journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 11, 2), EntryType.NORMAL,
                null, "electricity bill, draft", null, null, List.of(
                new JournalService.NewLine(acct(ctx, "6110"), 3_500_00L, null,
                        "power"),
                new JournalService.NewLine(acct(ctx, "1010"), null, 3_500_00L,
                        "power"))));
        return clientId;
    }

    /** Carries the per-seed context so the helpers stay static. */
    private record SeedCtx(AccountService accounts, JournalService journal,
                           long clientId, Period fy) { }

    private static long acct(SeedCtx ctx, String code) {
        return ctx.accounts().list(ctx.clientId(), false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst().orElseThrow().id();
    }

    private static void post(SeedCtx ctx, LocalDate date, String memo,
                             JournalService.NewLine... lines) {
        ctx.journal().post(ctx.journal().createDraft(new JournalService.NewEntry(
                ctx.clientId(), ctx.fy().id(), date, EntryType.NORMAL, null, memo,
                null, null, List.of(lines))).id());
    }
}
