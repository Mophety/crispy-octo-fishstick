package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.ui.Money;

import java.util.List;

/**
 * Headless LEDGER probe (dev tool, test sources): prints the general ledger
 * of every demo account EXACTLY as the UI renders it — the Money.format
 * string of each Debit/Credit/Balance cell and the view's footer line —
 * so debit/credit output can be checked without a screen.
 */
public final class LedgerProbe {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        Database database = new Database(dbPath);
        database.migrate();

        // seed demo data exactly as the UI snapshot tool does
        for (String seed : new String[]{
                "seedDemoClients", "seedDemoAccounts",
                "seedDemoFxRates", "seedDemoJournal"}) {
            var method = UiSnapshot.class.getDeclaredMethod(seed, Database.class);
            method.setAccessible(true);
            method.invoke(null, database);
        }

        AccountService accounts = new AccountService(database);
        JournalService journal = new JournalService(database, null);

        long clientId;
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT MIN(client_id) FROM accounts")) {
            clientId = rs.next() ? rs.getLong(1) : 0;
        }

        for (String code : new String[]{"1010", "3000", "4000", "6100", "2000", "1510", "6400"}) {
            Account account = accounts.findByCode(clientId, code).orElse(null);
            if (account == null) {
                System.out.println("== " + code + ": no such account");
                continue;
            }
            List<JournalService.LedgerRow> rows = journal.ledger(clientId, account.id());
            System.out.println();
            System.out.println("== " + code + " " + account.name() + " ("
                    + account.type() + ", normal " + account.normalSide() + ") ==");
            System.out.printf("%-12s %5s  %-13s %13s %13s %15s%n",
                    "DATE", "ENTRY", "TYPE", "DEBIT", "CREDIT", "BALANCE");
            for (JournalService.LedgerRow r : rows) {
                System.out.printf("%-12s %5d  %-13s %13s %13s %15s%n",
                        r.date(), r.entryNo(), r.type().label,
                        r.debitCents() == null ? "" : Money.format(r.debitCents()),
                        r.creditCents() == null ? "" : Money.format(r.creditCents()),
                        Money.format(r.balanceCents()));
            }
            long dr = rows.stream().mapToLong(r -> r.debitCents() == null ? 0 : r.debitCents()).sum();
            long cr = rows.stream().mapToLong(r -> r.creditCents() == null ? 0 : r.creditCents()).sum();
            long closing = rows.isEmpty() ? 0 : rows.getLast().balanceCents();
            // the exact footer text LedgersView builds:
            System.out.println("FOOTER: " + rows.size() + " posted lines · movement Dr "
                    + Money.format(dr) + " / Cr " + Money.format(cr)
                    + " · closing balance " + Money.format(closing) + " PHP ("
                    + (closing >= 0 ? account.normalSide().label : account.normalSide().opposite().label)
                    + "-normal)");
        }
    }
}
