package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.FxRate;
import com.ledgerpro.service.FxRateService;

import java.time.LocalDate;

/**
 * Live FX round-trip (dev tool, test sources — network-dependent, therefore
 * deliberately NOT part of the deterministic {@code mvn test} gate).
 *
 * <p>Fetches a real rate from Frankfurter, stores it in the cache, reads it
 * back and prints the whole journey. Use it to verify a machine's network
 * path to the API:</p>
 *
 * <pre>
 * mvn exec:java -Dexec.mainClass=com.ledgerpro.dev.FxLiveCheck \
 *          -Dexec.classpathScope=test \
 *          -Dexec.args="data/ledgerpro.db USD PHP 2026-10-28"
 * </pre>
 *
 * <p>Arguments: db path, from, to, ISO date (omit the date for "latest").</p>
 */
public final class FxLiveCheck {

    public static void main(String[] args) {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        String from = args.length > 1 ? args[1] : "USD";
        String to = args.length > 2 ? args[2] : "PHP";
        LocalDate date = args.length > 3 ? LocalDate.parse(args[3]) : null;

        Database database = new Database(dbPath);
        database.migrate();
        FxRateService service = new FxRateService(database);

        System.out.println("LedgerPro - live FX check");
        System.out.println("  pair     : " + from + " → " + to
                + (date == null ? " (latest)" : " @ " + date));

        FxRate stored = service.fetchAndStore(date, from, to);
        System.out.println("  fetched  : " + stored.pair() + " @ " + stored.asOf()
                + " = " + stored.rate() + "  (source " + stored.source()
                + ", written " + stored.fetchedAt() + ")");

        if (date != null && !date.equals(stored.asOf())) {
            System.out.println("  note     : the provider clamped the request to its"
                    + " latest trading day — the cache is truthful about that");
        }

        FxRate readBack = service.findCached(stored.asOf(), from, to).orElseThrow();
        System.out.println("  readback : " + readBack.pair() + " @ " + readBack.asOf()
                + " = " + readBack.rate());
        System.out.println("OK - live fetch, cache and read-back all agree.");
    }

    private FxLiveCheck() {
    }
}
