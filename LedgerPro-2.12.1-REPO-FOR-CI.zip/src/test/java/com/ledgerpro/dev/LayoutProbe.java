package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Headless LAYOUT probe (dev tool, test sources): boots the real application
 * scene at a simulated fullscreen size, walks the node tree and measures how
 * much vertical space each view actually consumes — specifically the DEAD
 * SPACE between each view's lowest content and the bottom of the window.
 *
 * <pre>
 * xvfb-run -a mvn exec:java -Dexec.mainClass=com.ledgerpro.dev.LayoutProbe \
 *          -Dexec.classpathScope=test \
 *          -Dexec.args="data/ledgerpro.db 1920 1040"
 * </pre>
 *
 * Prints one line per view: scene height, view height, content bottom edge
 * (scene coords), dead space at bottom, and the TableView height if any.
 */
public final class LayoutProbe {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        double width = args.length > 1 ? Double.parseDouble(args[1]) : 1920;
        double height = args.length > 2 ? Double.parseDouble(args[2]) : 1040;

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                // same demo seed as UiSnapshot so every view has content
                for (String seed : new String[]{
                        "seedDemoClients", "seedDemoAccounts",
                        "seedDemoFxRates", "seedDemoJournal"}) {
                    var method = UiSnapshot.class.getDeclaredMethod(seed, Database.class);
                    method.setAccessible(true);
                    method.invoke(null, database);
                }

                Scene scene = App.buildScene(database, width, height);
                AppShell shell = (AppShell) scene.getRoot();
                long clientId = chartOwnerClient(database);
                if (clientId > 0) {
                    shell.selectWorkingClientById(clientId);
                }

                // Layout only happens once the scene is attached to a shown
                // window — same as a real launch.
                javafx.stage.Stage stage = new javafx.stage.Stage();
                stage.setScene(scene);
                stage.setWidth(width);
                stage.setHeight(height);
                stage.show();

                ViewId[] views = {
                        ViewId.DASHBOARD, ViewId.CLIENTS, ViewId.COA, ViewId.FX_RATES,
                        ViewId.JOURNAL, ViewId.LEDGERS, ViewId.TRIAL_BALANCE,
                        ViewId.WORKSHEET, ViewId.REPORTS, ViewId.AUDIT};

                probeNextView(views, 0, scene, shell, width, height, done, failure);
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("layout probe timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("layout probe failed", failure.get());
        }
    }

    private static void probeNextView(ViewId[] views, int index, Scene scene,
                                      AppShell shell, double width, double height,
                                      CountDownLatch done,
                                      AtomicReference<Throwable> failure) {
        if (index >= views.length) {
            Platform.exit();
            done.countDown();
            return;
        }
        ViewId id = views[index];
        try {
            shell.show(id);
        } catch (Throwable t) {
            System.out.printf("%-14s SKIP (%s)%n", id.name(), t.getMessage());
            probeNextView(views, index + 1, scene, shell, width, height, done, failure);
            return;
        }
        PauseTransition settle = new PauseTransition(Duration.millis(250));
        settle.setOnFinished(e -> {
            try {
                Node view = scene.getRoot().lookupAll(".lp-content")
                        .stream().findFirst().map(n -> (Parent) n).orElse(null);
                Node current = null;
                if (view instanceof Parent p) {
                    current = p.getChildrenUnmodifiable().isEmpty()
                            ? null : p.getChildrenUnmodifiable().getFirst();
                }
                report(id, scene, current, width, height);
            } catch (Throwable t) {
                failure.set(t);
            }
            probeNextView(views, index + 1, scene, shell, width, height, done, failure);
        });
        settle.play();
    }

    private static void report(ViewId id, Scene scene, Node view,
                               double width, double height) {
        StringBuilder line = new StringBuilder();
        if (view == null) {
            System.out.printf("%-14s NO VIEW NODE%n", id.name());
            return;
        }
        Bounds viewBounds = view.getBoundsInParent();
        Bounds sceneBounds = view.localToScene(view.getBoundsInLocal());
        double deadBottom = height - (sceneBounds.getMinY() + sceneBounds.getHeight());
        line.append(String.format("%-14s viewH=%7.1f  bottomEdge=%7.1f  deadSpace=%7.1f",
                id.name(), viewBounds.getHeight(), sceneBounds.getMinY()
                        + sceneBounds.getHeight(), deadBottom));
        // deepest visible descendant: the lowest content edge actually shown
        double deepest = deepestVisibleBottom(view, sceneBounds.getMinY());
        line.append(String.format("  deepestContent=%7.1f  fillGap=%7.1f",
                deepest, height - deepest));
        TableView<?> tv = findTableView(view);
        if (tv != null) {
            Bounds tb = tv.localToScene(tv.getBoundsInLocal());
            line.append(String.format("  tableViewH=%7.1f (bottom=%7.1f)",
                    tv.getBoundsInLocal().getHeight(), tb.getMinY() + tb.getHeight()));
        }
        System.out.println(line);
    }

    /** Lowest visible, managed content edge within the view (scene coords). */
    private static double deepestVisibleBottom(Node node, double sceneOffsetY) {
        double lowest = sceneOffsetY;
        if (node instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                if (!child.isManaged() || !child.isVisible()
                        || child.getBoundsInParent().isEmpty()) {
                    continue;
                }
                Bounds cb = child.getBoundsInParent();
                double childSceneY = sceneOffsetY + cb.getMinY();
                double candidate = childSceneY + cb.getHeight();
                lowest = Math.max(lowest, deepestVisibleBottom(child, childSceneY));
                if (candidate > lowest) {
                    lowest = candidate;
                }
            }
        }
        return lowest;
    }

    private static TableView<?> findTableView(Node root) {
        if (root instanceof TableView<?> tv) {
            return tv;
        }
        if (root instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                TableView<?> tv = findTableView(child);
                if (tv != null) {
                    return tv;
                }
            }
        }
        return null;
    }

    private static long chartOwnerClient(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT MIN(client_id) FROM accounts")) {
            if (rs.next() && rs.getLong(1) > 0) {
                return rs.getLong(1);
            }
        } catch (Exception ignored) {
            // fall through to the first client
        }
        try (var con = database.open();
             var rs = con.createStatement().executeQuery("SELECT MIN(id) FROM clients")) {
            return rs.next() ? rs.getLong(1) : 0;
        } catch (Exception e) {
            return 0;
        }
    }
}
