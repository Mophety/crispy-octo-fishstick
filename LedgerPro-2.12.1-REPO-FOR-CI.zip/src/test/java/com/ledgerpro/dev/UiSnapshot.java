package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.JournalEntry;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.Theme;
import com.ledgerpro.ui.ThemeManager;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.WritableImage;
import javafx.scene.image.PixelFormat;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.PauseTransition;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Headless UI smoke check + screenshot generator (dev tool, test sources).
 *
 * <p>Boots the REAL application scene ({@link App#buildScene}) on a virtual
 * display (Xvfb / xvfb-run), lets one pulse pass so CSS and layout settle,
 * snapshots the scene to PNG and exits. This is how the shell is verified
 * end-to-end without a human at the screen:</p>
 *
 * <pre>
 * xvfb-run -a mvn exec:java -Dexec.mainClass=com.ledgerpro.dev.UiSnapshot \
 *          -Dexec.classpathScope=test \
 *          -Dexec.args="data/ledgerpro.db target/ui-snapshots dashboard"
 * </pre>
 *
 * <p>Third argument selects the view to capture: dashboard | clients | coa |
 * fx_rates | journal | ledgers | trial_balance | worksheet | reports. The
 * optional FOURTH argument selects the theme to capture it in (a
 * {@link Theme} enum name, e.g. ALEXIA); without it the remembered theme
 * applies, exactly as a normal launch would. The theme name is appended to
 * the output file name, so several themes can be captured side by side.</p>
 *
 * <p>If the clients table is empty, three demo clients are inserted first (only when
 * the table has zero rows, so real data is never touched); likewise a
 * standard chart for the first client, a handful of cached FX rates, and a
 * demo period with a posted journal (including one multi-currency entry,
 * one voided entry and a dividend) — so every view has something honest to
 * show.</p>
 */
public final class UiSnapshot {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        String outDir = args.length > 1 ? args[1] : "target/ui-snapshots";
        String viewName = args.length > 2 ? args[2] : "dashboard";
        String themeName = args.length > 3 ? args[3] : null;
        ViewId view = ViewId.valueOf(viewName.toUpperCase(Locale.ROOT));
        Theme theme = themeName == null ? null : Theme.valueOf(themeName.toUpperCase(Locale.ROOT));

        // Software rendering: works on any machine, including CI sandboxes
        // without a GPU. Must be set before the toolkit initializes.
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                seedDemoClients(database);
                seedDemoAccounts(database);
                seedDemoFxRates(database);
                seedDemoJournal(database);

                // the worksheet is a wide working paper — capture it on a
                // wider scene so all thirteen columns are readable at once
                boolean wide = view == ViewId.WORKSHEET;
                Scene scene = App.buildScene(database, wide ? 2100 : 1280, wide ? 880 : 820);
                AppShell shell = (AppShell) scene.getRoot();
                if (view == ViewId.COA || view == ViewId.JOURNAL || view == ViewId.LEDGERS
                        || view == ViewId.TRIAL_BALANCE || view == ViewId.WORKSHEET
                        || view == ViewId.REPORTS) {
                    shell.selectWorkingClientById(chartOwnerClient(database));
                }
                shell.show(view);

                // the worksheet is a tall working paper: scroll its grid to
                // the bottom so the capture shows the paper sheet's total
                // rows (TOTAL Unadjusted … NET INCOME … TOTALS), not just
                // the account rows
                if (view == ViewId.WORKSHEET) {
                    for (Node node : scene.getRoot().lookupAll(".table-view")) {
                        if (node instanceof javafx.scene.control.TableView<?> tableView
                                && !tableView.getItems().isEmpty()) {
                            tableView.scrollTo(tableView.getItems().size() - 1);
                        }
                    }
                }

                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                // A theme argument exercises the RUNTIME switch — the exact
                // code path the sidebar's Appearance picker takes — so the
                // capture proves a live theme change restyles the open scene.
                if (theme != null) {
                    ThemeManager.apply(theme, scene);
                }

                // One animation pulse later the theme, CSS and layout have
                // settled - then capture.
                PauseTransition settle = new PauseTransition(Duration.millis(900));
                settle.setOnFinished(e -> {
                    try {
                        String suffix = theme == null ? "" : "-" + theme.name().toLowerCase(Locale.ROOT);
                        Path out = Path.of(outDir, viewName.toLowerCase(Locale.ROOT) + suffix + ".png");
                        Files.createDirectories(out.getParent());
                        writePng(scene.snapshot(null), out);
                        System.out.println("UI snapshot written: " + out.toAbsolutePath());
                    } catch (Throwable t) {
                        failure.set(t);
                    } finally {
                        Platform.exit();
                        done.countDown();
                    }
                });
                settle.play();

            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(60, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI snapshot timed out after 60 s");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("UI snapshot failed", failure.get());
        }
    }

    /**
     * Writes the JavaFX image as PNG using only JDK classes (ImageIO) - no
     * javafx-swing dependency needed for this dev tool.
     */
    private static void writePng(WritableImage image, Path out) throws Exception {
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                PixelFormat.getIntArgbInstance(), pixels, 0, w);
        BufferedImage buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        ImageIO.write(buffered, "png", out.toFile());
    }

    /** The client whose chart the demo seed filled (fallback: first client). */
    private static long chartOwnerClient(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT MIN(client_id) FROM accounts")) {
            if (rs.next() && rs.getLong(1) > 0) {
                return rs.getLong(1);
            }
        } catch (Exception ignored) {
            // fall through to the first client
        }
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT MIN(id) FROM clients")) {
            return rs.next() ? rs.getLong(1) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Demo clients for a screenshot-worthy table - inserted only when the
     * register is completely empty, never alongside real data.
     */
    private static void seedDemoClients(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery("SELECT COUNT(*) FROM clients")) {
            if (rs.next() && rs.getInt(1) > 0) {
                return;
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot inspect clients table", e);
        }
        String[][] demo = {
                {"NRTH", "Norte Freight Systems, Inc.", "PHP"},
                {"SLRA", "Solera Resorts & Hotels, Inc.", "PHP"},
                {"GBLC", "Global Circuit Electronics, Inc.", "USD"},
        };
        try (var con = database.open()) {
            for (String[] row : demo) {
                try (var ps = con.prepareStatement(
                        "INSERT INTO clients(code, name, base_currency) VALUES (?, ?, ?)")) {
                    ps.setString(1, row[0]);
                    ps.setString(2, row[1]);
                    ps.setString(3, row[2]);
                    ps.executeUpdate();
                }
                try (var ps = con.prepareStatement(
                        "INSERT INTO audit_log(client_id, action, detail)"
                                + " VALUES ((SELECT id FROM clients WHERE code = ?),"
                                + " 'SEED_DEMO', 'dev screenshot data')")) {
                    ps.setString(1, row[0]);
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot seed demo clients", e);
        }
    }

    /**
     * A standard chart (plus one deactivated account for a mixed status
     * column) for the first client - only when the accounts table is empty.
     */
    private static void seedDemoAccounts(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT COUNT(*) FROM accounts")) {
            if (rs.next() && rs.getInt(1) > 0) {
                return;
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot inspect accounts table", e);
        }

        long clientId;
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT MIN(id) FROM clients")) {
            if (!rs.next() || rs.getLong(1) == 0) {
                return;   // no clients to seed a chart for
            }
            clientId = rs.getLong(1);
        } catch (Exception e) {
            throw new IllegalStateException("cannot inspect clients table", e);
        }

        new AccountService(database).applyStandardChart(clientId);
        try (var con = database.open();
             var ps = con.prepareStatement(
                     "UPDATE accounts SET active = 0 WHERE client_id = ? AND code = '1400'")) {
            ps.setLong(1, clientId);
            ps.executeUpdate();
        } catch (Exception e) {
            throw new IllegalStateException("cannot deactivate demo account", e);
        }
    }

    /**
     * A handful of cached FX rates (one manual, so both sources show) - only
     * when the fx_rates table is empty.
     */
    private static void seedDemoFxRates(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery("SELECT COUNT(*) FROM fx_rates")) {
            if (!rs.next() || rs.getInt(1) > 0) {
                return;
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot inspect fx_rates table", e);
        }
        String today = java.time.LocalDate.now().toString();
        String older = java.time.LocalDate.now().minusDays(3).toString();
        String oldest = java.time.LocalDate.now().minusDays(7).toString();
        String[][] demo = {
                {older, "USD", "PHP", "56.7102", "FRANKFURTER"},
                {oldest, "USD", "PHP", "56.6881", "FRANKFURTER"},
                {older, "EUR", "PHP", "63.1017", "FRANKFURTER"},
                {today, "USD", "EUR", "0.9215", "MANUAL"},
        };
        try (var con = database.open()) {
            for (String[] row : demo) {
                try (var ps = con.prepareStatement(
                        "INSERT INTO fx_rates(rate_date, quote_currency, base_currency,"
                                + " rate, source, note)"
                                + " VALUES (?, ?, ?, ?, ?, '')")) {
                    ps.setString(1, row[0]);
                    ps.setString(2, row[1]);
                    ps.setString(3, row[2]);
                    ps.setString(4, row[3]);
                    ps.setString(5, row[4]);
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot seed demo fx rates", e);
        }
    }

    /**
     * A demo period with a posted journal — one entry per story worth
     * seeing in a screenshot: capitalization, revenue, rent, a USD invoice
     * converted through the FX cache, an adjusting entry that hits a contra
     * account, and one voided duplicate with its reversing mirror. Only when
     * the journal is completely empty, and only through the real services
     * (so ledger_balances and the audit log stay true).
     */
    private static void seedDemoJournal(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT COUNT(*) FROM journal_entries")) {
            if (rs.next() && rs.getInt(1) > 0) {
                return;
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot inspect journal_entries table", e);
        }

        long clientId = chartOwnerClient(database);
        if (clientId == 0) {
            return;   // no client, no chart — nothing to journal about
        }
        try (var con = database.open();
             var rs = con.createStatement().executeQuery(
                     "SELECT COUNT(*) FROM accounts WHERE client_id = " + clientId)) {
            if (!rs.next() || rs.getInt(1) == 0) {
                return;
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot inspect accounts table", e);
        }

        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        JournalService journal = new JournalService(database, new FxRateService(database));

        Period fy2026 = periods.list(clientId).stream()
                .filter(p -> "FY2026".equals(p.name()))
                .findFirst()
                .orElseGet(() -> periods.create(clientId, "FY2026",
                        java.time.LocalDate.of(2026, 1, 1),
                        java.time.LocalDate.of(2026, 12, 31)));

        long cashBank = accountId(accounts, clientId, "1010");
        long shareCapital = accountId(accounts, clientId, "3000");
        long serviceRevenue = accountId(accounts, clientId, "4000");
        long rent = accountId(accounts, clientId, "6100");
        long comms = accountId(accounts, clientId, "6120");
        long payables = accountId(accounts, clientId, "2000");
        long depreciation = accountId(accounts, clientId, "6400");
        long accumDepreciation = accountId(accounts, clientId, "1510");
        long utilities = accountId(accounts, clientId, "6110");

        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.of(2026, 1, 5), EntryType.NORMAL,
                null, "Initial capitalization — founders' cash in", null, null,
                List.of(new JournalService.NewLine(cashBank, 250_000_000L, null, null),
                        new JournalService.NewLine(shareCapital, null, 250_000_000L, null))));

        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.of(2026, 1, 12), EntryType.NORMAL,
                null, "Consulting revenue — Q1 retainer, OR-2026-114", null, null,
                List.of(new JournalService.NewLine(cashBank, 64_000_000L, null, null),
                        new JournalService.NewLine(serviceRevenue, null, 64_000_000L, null))));

        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.of(2026, 1, 31), EntryType.NORMAL,
                null, "January office rent — Ayala Tower 2, unit 1701", null, null,
                List.of(new JournalService.NewLine(rent, 18_000_000L, null, null),
                        new JournalService.NewLine(cashBank, null, 18_000_000L, null))));

        // a multi-currency entry: USD invoice converted through the FX cache
        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.now().minusDays(1), EntryType.NORMAL,
                null, "AWS hosting invoice INV-88231 (USD 3,000.00)", "USD", null, 
                List.of(new JournalService.NewLine(comms, 300_000L, null, null),
                        new JournalService.NewLine(payables, null, 300_000L, null))));

        // an adjusting entry hitting a contra account
        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.now().minusDays(2), EntryType.ADJUSTING,
                null, "October depreciation — tower suite fit-out", null, null, 
                List.of(new JournalService.NewLine(depreciation, 2_500_000L, null, null),
                        new JournalService.NewLine(accumDepreciation, null, 2_500_000L, null))));

        // more end-of-period adjustments, so the worksheet's adjustment
        // columns and the statements carry a real story
        long salaries = accountId(accounts, clientId, "6000");
        long salariesPayable = accountId(accounts, clientId, "2100");
        long suppliesExpense = accountId(accounts, clientId, "6150");
        long prepaid = accountId(accounts, clientId, "1300");
        long dividends = accountId(accounts, clientId, "3900");

        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.now().minusDays(2), EntryType.ADJUSTING,
                null, "October salaries accrued — payday falls in November", null, null, 
                List.of(new JournalService.NewLine(salaries, 3_200_000L, null, null),
                        new JournalService.NewLine(salariesPayable, null, 3_200_000L, null))));

        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.now().minusDays(2), EntryType.ADJUSTING,
                null, "Prepaid insurance and licenses consumed in October", null, null, 
                List.of(new JournalService.NewLine(suppliesExpense, 1_800_000L, null, null),
                        new JournalService.NewLine(prepaid, null, 1_800_000L, null))));

        // a dividend: contra equity, so the equity statement carries its
        // "Less" line and the 10-column sheet its drawing column
        post(journal, new JournalService.NewEntry(clientId, fy2026.id(),
                java.time.LocalDate.now().minusDays(4), EntryType.NORMAL,
                null, "Q4 cash dividend declared and paid", null, null, 
                List.of(new JournalService.NewLine(dividends, 12_000_000L, null, null),
                        new JournalService.NewLine(cashBank, null, 12_000_000L, null))));

        // a posted-then-voided duplicate: the register keeps both sides
        JournalEntry duplicate = post(journal, new JournalService.NewEntry(clientId,
                fy2026.id(), java.time.LocalDate.now().minusDays(9), EntryType.NORMAL,
                null, "Meralco October billing — accidental duplicate", null, null,
                List.of(new JournalService.NewLine(utilities, 1_500_000L, null, null),
                        new JournalService.NewLine(cashBank, null, 1_500_000L, null))));
        journal.voidEntry(duplicate.id(),
                "duplicate of the real October Meralco billing — see the following entry");
    }

    private static long accountId(AccountService accounts, long clientId, String code) {
        return accounts.findByCode(clientId, code)
                .orElseThrow(() -> new IllegalStateException(
                        "demo chart is missing account " + code))
                .id();
    }

    /** create + post in one step (demo seeding only). */
    private static JournalEntry post(JournalService journal,
                                     JournalService.NewEntry entry) {
        JournalEntry draft = journal.createDraft(entry);
        return journal.post(draft.id());
    }
}
