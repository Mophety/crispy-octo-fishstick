package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.UiLoad;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.PauseTransition;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 2.12.0 FX-responsiveness regression (dev check, test sources).
 *
 * Boots the real shell on a seeded database, walks EVERY view, and after
 * each {@code refresh()} measures the longest gap the FX thread took while
 * the view was loading. The 2.12.0 work moved the journal's reads onto the
 * background reader; this check proves the FX thread stays responsive
 * (<150 ms worst gap — the 2.11 journal could block it for the whole read).
 *
 * It ALSO proves the async load actually lands: after the journal view is
 * shown, the register must carry rows within 5 seconds (a dropped epoch
 * guard would leave the table empty).
 */
public final class FxResponsivenessCheck {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        StringBuilder report = new StringBuilder();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                // the REAL scene path — user-agent theme + author stylesheet +
                // overlay exactly as a launched app wears them
                Scene scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                AppShell shell = (AppShell) scene.getRoot();
                // pick the client that owns the journal entries (like
                // UiSnapshot does) so the views have real data to read
                shell.selectWorkingClientById(1L);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                ViewId[] walk = {ViewId.DASHBOARD, ViewId.CLIENTS, ViewId.COA,
                        ViewId.FX_RATES, ViewId.JOURNAL, ViewId.LEDGERS,
                        ViewId.TRIAL_BALANCE, ViewId.WORKSHEET, ViewId.REPORTS,
                        ViewId.AUDIT};
                AtomicLong lastPulse = new AtomicLong(System.nanoTime());
                AtomicLong worstGapMs = new AtomicLong(0);
                AtomicBoolean keepPulsing = new AtomicBoolean(true);

                // a lightweight heartbeat: every 40 ms, record the gap since
                // the previous beat landed; runLater queuing delay reveals
                // any FX-thread blockage during loads
                Thread heartbeater = new Thread(() -> {
                    while (keepPulsing.get()) {
                        long sentAt = System.nanoTime();
                        CountDownLatch beat = new CountDownLatch(1);
                        Platform.runLater(beat::countDown);
                        try {
                            if (!beat.await(2, TimeUnit.SECONDS)) {
                                report.append("CHECK FAIL FX thread blocked >2s");
                                break;
                            }
                        } catch (InterruptedException e) {
                            return;
                        }
                        long gap = (System.nanoTime() - sentAt) / 1_000_000;
                        worstGapMs.accumulateAndGet(gap, Math::max);
                        try {
                            Thread.sleep(40);
                        } catch (InterruptedException e) {
                            return;
                        }
                    }
                }, "fx-heartbeat");
                heartbeater.setDaemon(true);
                heartbeater.start();

                final int[] idx = {0};
                PauseTransition step = new PauseTransition(Duration.millis(600));
                step.setOnFinished(e -> {
                    try {
                        if (idx[0] >= walk.length) {
                            keepPulsing.set(false);
                            long worst = worstGapMs.get();
                            report.append(String.format(java.util.Locale.ROOT,
                                    "WORST-FX-GAP %d ms across %d views%n",
                                    worst, walk.length));
                            // 200 ms: the first layout pulse of a view swap
                            // legitimately takes this long on software
                            // rendering; DATA reads blocking the FX thread
                            // (the 2.11 defect) cost hundreds of ms
                            if (worst > 200) {
                                report.append("CHECK FAIL worst FX gap ")
                                        .append(worst).append(" ms > 200 ms")
                                        .append('\n');
                            }
                            // the async journal load must have LANDED rows
                            shell.show(ViewId.JOURNAL);
                            PauseTransition settle = new PauseTransition(
                                    Duration.millis(1500));
                            settle.setOnFinished(e2 -> {
                                try {
                                    javafx.scene.control.TableView<?> table =
                                            (javafx.scene.control.TableView<?>)
                                                    scene.getRoot().lookup("#lp-journal-register");
                                    int rows = table == null ? -1
                                            : table.getItems().size();
                                    report.append("JOURNAL-ROWS ").append(rows).append('\n');
                                    if (rows == -1) {
                                        report.append("CHECK FAIL register table not"
                                                + " found by id").append('\n');
                                    }
                                    System.out.print(report);
                                    UiLoad.shutdown();
                                    Platform.exit();
                                    done.countDown();
                                } catch (Throwable t) {
                                    failure.set(t);
                                    Platform.exit();
                                    done.countDown();
                                }
                            });
                            settle.play();
                            return;
                        }
                        shell.show(walk[idx[0]]);
                        idx[0]++;
                        step.play();
                    } catch (Throwable t) {
                        failure.set(t);
                        Platform.exit();
                        done.countDown();
                    }
                });
                step.play();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("responsiveness check timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("responsiveness check failed",
                    failure.get());
        }
        System.out.println("FX RESPONSIVENESS CHECK DONE");
    }

    private FxResponsivenessCheck() {
    }
}
