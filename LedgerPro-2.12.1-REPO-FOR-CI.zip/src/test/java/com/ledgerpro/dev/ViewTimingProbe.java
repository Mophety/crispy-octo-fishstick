package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.PauseTransition;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Per-view refresh timing (dev tool): shows each view on the real scene and
 * measures how long the synchronous part of refresh() keeps the FX thread,
 * plus the heartbeater gap during that window. Tells us WHICH view still
 * blocks after the 2.12.0 async work.
 */
public final class ViewTimingProbe {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        StringBuilder report = new StringBuilder();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                Scene scene = App.buildScene(database, 1280, 820);
                AppShell shell = (AppShell) scene.getRoot();
                shell.selectWorkingClientById(1L);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                ViewId[] walk = {ViewId.DASHBOARD, ViewId.CLIENTS, ViewId.COA,
                        ViewId.FX_RATES, ViewId.JOURNAL, ViewId.LEDGERS,
                        ViewId.TRIAL_BALANCE, ViewId.WORKSHEET, ViewId.REPORTS,
                        ViewId.AUDIT};
                final int[] idx = {0};
                PauseTransition step = new PauseTransition(Duration.millis(700));
                step.setOnFinished(e -> {
                    try {
                        if (idx[0] >= walk.length) {
                            System.out.print(report);
                            com.ledgerpro.ui.UiLoad.shutdown();
                            Platform.exit();
                            done.countDown();
                            return;
                        }
                        ViewId id = walk[idx[0]];
                        long t0 = System.nanoTime();
                        shell.show(id);
                        long syncMs = (System.nanoTime() - t0) / 1_000_000;
                        report.append(String.format(java.util.Locale.ROOT,
                                "VIEW %-14s sync-refresh %d ms%n",
                                id, syncMs));
                        idx[0]++;
                        step.play();
                    } catch (Throwable t) {
                        failure.set(t);
                        Platform.exit();
                        done.countDown();
                    }
                });
                step.play();
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("view timing probe timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("view timing probe failed",
                    failure.get());
        }
        System.out.println("VIEW TIMING PROBE DONE");
    }

    private ViewTimingProbe() {
    }
}
