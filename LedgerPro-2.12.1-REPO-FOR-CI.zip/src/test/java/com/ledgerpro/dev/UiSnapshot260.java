package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.SettingsDialog;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;
import javafx.stage.Stage;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The 2.6.0 headless verification tool: boots the REAL application scene,
 * captures a view — and (new this release) the OPEN SETTINGS DIALOG — so
 * the dialog's width/padding and the dashboard's period row + live stamp
 * can be verified pixel-wise:
 *
 * <pre>
 * mvn exec:java -Ddb.cli.class=com.ledgerpro.dev.UiSnapshot260 \
 *          -Dexec.classpathScope=test \
 *          -Dexec.args="data/ledgerpro.db out view width height [tag]"
 * </pre>
 *
 * <p>Views: dashboard / journal / worksheet / settings. The "settings"
 * capture opens the dialog modally on a background latch (the dialog's own
 * thread-of-show is the JavaFX one), waits for its layout to settle, and
 * snapshots the whole scene — dialog and dimmed shell together.</p>
 */
public final class UiSnapshot260 {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        String outDir = args.length > 1 ? args[1] : "target/ui-snapshots";
        String viewName = args.length > 2 ? args[2] : "dashboard";
        int width = args.length > 3 ? Integer.parseInt(args[3]) : 1280;
        int height = args.length > 4 ? Integer.parseInt(args[4]) : 820;
        String tag = args.length > 5 ? args[5] : "";

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                UiSnapshotSeed.seedForScreenshots(database);

                Scene scene = App.buildScene(database, width, height);
                AppShell shell = (AppShell) scene.getRoot();
                shell.selectWorkingClientById(firstClient(database));

                boolean isSettings = "settings".equalsIgnoreCase(viewName);
                ViewId view = ViewId.valueOf(
                        (isSettings ? "dashboard" : viewName).toUpperCase(Locale.ROOT));
                shell.show(view);

                if (view == ViewId.WORKSHEET) {
                    for (javafx.scene.Node node
                            : scene.getRoot().lookupAll(".table-view")) {
                        if (node instanceof javafx.scene.control.TableView<?> tableView
                                && !tableView.getItems().isEmpty()) {
                            tableView.scrollTo(tableView.getItems().size() - 1);
                        }
                    }
                }

                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                if (isSettings) {
                    // open the settings dialog on a worker thread so its
                    // showAndWait does not block this runLater lambda
                    CountDownLatch dialogOpen = new CountDownLatch(1);
                    Thread opener = new Thread(() -> Platform.runLater(() -> {
                        SettingsDialog dialog = new SettingsDialog(scene);
                        dialog.initOwner(stage);
                        dialog.showAndWait();
                        dialogOpen.countDown();
                    }));
                    opener.start();
                    // the dialog lays out on its own pulse: give it two
                    PauseTransition settle = new PauseTransition(Duration.millis(1400));
                    settle.setOnFinished(e -> finish(scene, outDir, "settings",
                            width, height, tag, done, failure));
                    settle.play();
                } else {
                    PauseTransition settle = new PauseTransition(Duration.millis(900));
                    settle.setOnFinished(e -> finish(scene, outDir, viewName,
                            width, height, tag, done, failure));
                    settle.play();
                }

            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(90, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI snapshot timed out after 90 s");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("UI snapshot failed", failure.get());
        }
        // give any dialog thread a moment to exit cleanly
        Thread.sleep(300);
    }

    private static void finish(Scene scene, String outDir, String viewName,
                               int width, int height, String tag,
                               CountDownLatch done, AtomicReference<Throwable> failure) {
        try {
            String suffix = tag.isEmpty() ? "" : "-" + tag;
            Path out = Path.of(outDir, viewName.toLowerCase(Locale.ROOT)
                    + suffix + "-" + width + "x" + height + ".png");
            Files.createDirectories(out.getParent());
            writePng(scene.snapshot(null), out);
            System.out.println("UI snapshot written: " + out.toAbsolutePath());
            Platform.exit();
            done.countDown();
        } catch (Throwable t) {
            failure.set(t);
            Platform.exit();
            done.countDown();
        }
    }

    private static long firstClient(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery("SELECT MIN(id) FROM clients")) {
            return rs.next() ? rs.getLong(1) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private static void writePng(WritableImage image, Path out) throws Exception {
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                PixelFormat.getIntArgbInstance(), pixels, 0, w);
        BufferedImage buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        ImageIO.write(buffered, "png", out.toFile());
    }
}
