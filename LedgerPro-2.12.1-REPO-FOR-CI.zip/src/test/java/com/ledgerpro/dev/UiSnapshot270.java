package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.CashFlowService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.ClosingService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The 2.7.0 headless verification captures: the dashboard with LIVE FIGURES
 * (the Sprint-0 fix — the 2.6.0 captures could not show them), the Reports
 * view's new Cash Flow tab, and the journal after a full close (closing
 * entries visible, period locked). Runs the same software-rendering recipe
 * as UiSnapshot260.
 */
public final class UiSnapshot270 {

    public static void main(String[] args) throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Path dir = Files.createTempDirectory("ui270");
                Database database = new Database(dir.resolve("ledgerpro.db").toString());
                database.migrate();
                seedAccountingYear(database);

                Scene scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                com.ledgerpro.ui.AppShell shell =
                        (com.ledgerpro.ui.AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                // dashboard with live figures (Sprint 0 acceptance)
                shell.show(com.ledgerpro.ui.ViewId.DASHBOARD);
                pause(2600, () -> {
                    capture(scene, "target/ui-snapshots", "dashboard-270", failure);
                    if (failure.get() != null) {
                        done.countDown();
                        return;
                    }
                    // Reports view: the new Cash Flow tab (4th tab selected)
                    shell.show(com.ledgerpro.ui.ViewId.REPORTS);
                    pause(1400, () -> {
                        selectCashFlowTab(scene);
                        pause(1200, () -> {
                            capture(scene, "target/ui-snapshots", "reports-cashflow-270",
                                    failure);
                            // journal: closing entries visible, period locked
                            shell.show(com.ledgerpro.ui.ViewId.JOURNAL);
                            pause(1400, () -> {
                                capture(scene, "target/ui-snapshots", "journal-closed-270",
                                        failure);
                                done.countDown();
                            });
                        });
                    });
                });

            } catch (Throwable t) {
                failure.set(t);
                done.countDown();
            }
        });

        if (!done.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI snapshot timed out");
        }
        Throwable t = failure.get();
        if (t != null) {
            throw new IllegalStateException("UI snapshot failed", t);
        }
        Platform.exit();
    }

    /** A small profitable year: the shape the cash-flow statement proves on. */
    private static void seedAccountingYear(Database database) {
        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        FxRateService fx = new FxRateService(database);
        JournalService journal = new JournalService(database, fx);

        long clientId = clients.create("NRTH", "Northwind Retail Trading", "PHP").id();
        accounts.applyStandardChart(clientId);
        Period fy = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));

        SeedCtx ctx = new SeedCtx(accounts, journal, clientId, fy);
        post(ctx, LocalDate.of(2026, 1, 1), "initial capital",
                new JournalService.NewLine(acct(ctx, "1010"), 1_000_000_00L, null, "capital in"),
                new JournalService.NewLine(acct(ctx, "3000"), null, 1_000_000_00L, "capital in"));
        post(ctx, LocalDate.of(2026, 3, 5), "cash sales",
                new JournalService.NewLine(acct(ctx, "1010"), 420_000_00L, null, "sale"),
                new JournalService.NewLine(acct(ctx, "4010"), null, 420_000_00L, "sale"));
        post(ctx, LocalDate.of(2026, 5, 12), "credit sale",
                new JournalService.NewLine(acct(ctx, "1100"), 180_000_00L, null, "on account"),
                new JournalService.NewLine(acct(ctx, "4010"), null, 180_000_00L, "on account"));
        post(ctx, LocalDate.of(2026, 6, 30), "rent paid",
                new JournalService.NewLine(acct(ctx, "6100"), 96_000_00L, null, "rent"),
                new JournalService.NewLine(acct(ctx, "1010"), null, 96_000_00L, "rent"));
        post(ctx, LocalDate.of(2026, 9, 8), "equipment purchase",
                new JournalService.NewLine(acct(ctx, "1500"), 240_000_00L, null, "equipment"),
                new JournalService.NewLine(acct(ctx, "1010"), null, 240_000_00L, "paid"));
        post(ctx, LocalDate.of(2026, 10, 15), "salaries",
                new JournalService.NewLine(acct(ctx, "6000"), 132_000_00L, null, "salaries"),
                new JournalService.NewLine(acct(ctx, "1010"), null, 132_000_00L, "salaries"));
        // adjusting: depreciation + accrual (the cash-flow add-backs)
        journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 12, 31), EntryType.ADJUSTING,
                null, "depreciation for the year", null, null, List.of(
                new JournalService.NewLine(acct(ctx, "6130"), 24_000_00L, null, "depreciation"),
                new JournalService.NewLine(acct(ctx, "1510"), null, 24_000_00L,
                        "accumulated")))).id());
        journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 12, 31), EntryType.ADJUSTING,
                null, "accrued utilities for December", null, null, List.of(
                new JournalService.NewLine(acct(ctx, "6110"), 9_000_00L, null, "accrual"),
                new JournalService.NewLine(acct(ctx, "2010"), null, 9_000_00L, "accrued")))).id());

        // the close: full cycle with the new service (S2 acceptance)
        ClosingService closing = new ClosingService(database, journal, accounts);
        closing.generateAndPost(fy.id());
        periods.close(fy.id());
    }

    /** Clicks the Cash Flow tab in the Reports view's tab pane. */
    private static void selectCashFlowTab(Scene scene) {
        for (javafx.scene.Node node : scene.getRoot().lookupAll(".tab-pane")) {
            if (node instanceof javafx.scene.control.TabPane pane) {
                for (javafx.scene.control.Tab tab : pane.getTabs()) {
                    if (tab.getText() != null && tab.getText().toLowerCase(
                            Locale.ROOT).contains("cash flow")) {
                        pane.getSelectionModel().select(tab);
                        return;
                    }
                }
            }
        }
    }

    /** Carries the per-seed context so the helpers stay static. */
    private record SeedCtx(AccountService accounts, JournalService journal,
                           long clientId, Period fy) {
    }

    private static long acct(SeedCtx ctx, String code) {
        return ctx.accounts().findByCode(ctx.clientId(), code).orElseThrow().id();
    }

    private static void post(SeedCtx ctx, LocalDate d, String memo,
                             JournalService.NewLine... ls) {
        ctx.journal().post(ctx.journal().createDraft(new JournalService.NewEntry(
                ctx.clientId(), ctx.fy().id(), d, EntryType.NORMAL, null, memo, null,
                null, List.of(ls))).id());
    }

    private static void pause(int millis, Runnable then) {
        javafx.animation.PauseTransition wait = new javafx.animation.PauseTransition(
                javafx.util.Duration.millis(millis));
        wait.setOnFinished(e -> then.run());
        wait.play();
    }

    private static void capture(Scene scene, String outDir, String name,
                                AtomicReference<Throwable> failure) {
        try {
            javafx.scene.image.WritableImage image = scene.snapshot(null);
            Path out = Path.of(outDir, name + ".png");
            Files.createDirectories(out.getParent());
            int w = (int) image.getWidth();
            int h = (int) image.getHeight();
            int[] pixels = new int[w * h];
            image.getPixelReader().getPixels(0, 0, w, h,
                    javafx.scene.image.PixelFormat.getIntArgbInstance(), pixels, 0, w);
            java.awt.image.BufferedImage buffered =
                    new java.awt.image.BufferedImage(w, h,
                            java.awt.image.BufferedImage.TYPE_INT_ARGB);
            buffered.setRGB(0, 0, w, h, pixels, 0, w);
            javax.imageio.ImageIO.write(buffered, "png", out.toFile());
            System.out.println("UI snapshot written: " + out.toAbsolutePath());
        } catch (Exception e) {
            failure.set(e);
        }
    }
}
