package com.ledgerpro.dev;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.service.AccountService;
import com.ledgerpro.service.ClientService;
import com.ledgerpro.service.FxRateService;
import com.ledgerpro.service.JournalService;
import com.ledgerpro.service.PeriodService;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The 2.10.0 headless verification captures — one per user-visible change:
 * the journal in its RESTORED default (the flat 2.3.1 register look, to be
 * pixel-checked against journal-231-reference.png), the paper journal via
 * the toolbar toggle (still available), the search box filtering live, the
 * status filter composed with search, and the filtered footer statistics.
 */
public final class UiSnapshot210 {

    public static void main(String[] args) throws Exception {
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Path dir = Files.createTempDirectory("ui210");
                Database database = new Database(dir.resolve("ledgerpro.db").toString());
                database.migrate();
                long nrth = seed(database, "NRTH", "Northwind Retail Trading");
                long south = seed(database, "SOUTH", "Southern Haulage Co.");

                Scene scene = com.ledgerpro.App.buildScene(database, 1280, 820);
                com.ledgerpro.ui.AppShell shell =
                        (com.ledgerpro.ui.AppShell) scene.getRoot();
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
                shell.selectWorkingClientById(nrth);

                Object journal = journalOf(shell);

                // 1) the RESTORED default: the flat 2.3.1 register
                shell.show(com.ledgerpro.ui.ViewId.JOURNAL);
                pause(1600, () -> {
                    captureSafe(scene, "journal-register-210");
                    // 2) search filtering live
                    TextField search = searchField(journal);
                    pause(400, () -> {
                        search.setText("sale");
                        pause(700, () -> {
                            captureSafe(scene, "journal-search-210");
                            search.setText("");
                            // 3) status filter
                            pause(500, () -> {
                                statusCombo(journal).getSelectionModel().select("Draft");
                                pause(700, () -> {
                                    captureSafe(scene, "journal-status-filter-210");
                                    statusCombo(journal).getSelectionModel().selectFirst();
                                    // 4) the client switch (stale-period fix + repaint)
                                    pause(400, () -> {
                                        shell.selectWorkingClientById(south);
                                        pause(1200, () -> {
                                            captureSafe(scene, "journal-switched-210");
                                            // 5) the paper journal toggle (still one click)
                                            toggleLayout(shell, journal);
                                            pause(1400, () -> {
                                                captureSafe(scene, "journal-paper-210");
                                                toggleLayout(shell, journal);   // restore
                                                pause(400, () -> {
                                                    done.countDown();
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            } catch (Throwable t) {
                t.printStackTrace();
                failure.set(t);
                done.countDown();
            }
        });

        if (!done.await(180, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI snapshot timed out; failure: "
                    + failure.get());
        }
        Throwable t = failure.get();
        if (t != null) {
            throw new IllegalStateException("UI snapshot failed: " + t, t);
        }
        Platform.exit();
    }

    /** Clicks the journal's layout toggle (paper ↔ register). */
    private static void toggleLayout(com.ledgerpro.ui.AppShell shell, Object journal) {
        for (javafx.scene.Node node : shell.lookupAll(".lp-compact-btn")) {
            if (node instanceof javafx.scene.control.Button button) {
                String text = button.getText();
                if (text != null && (text.contains("register")
                        || text.contains("paper journal"))) {
                    button.fire();
                    return;
                }
            }
        }
    }

    private static Object journalOf(com.ledgerpro.ui.AppShell shell) throws Exception {
        shell.show(com.ledgerpro.ui.ViewId.JOURNAL);
        Field f = com.ledgerpro.ui.AppShell.class.getDeclaredField("journalView");
        f.setAccessible(true);
        return f.get(shell);
    }

    private static TextField searchField(Object journal) {
        try {
            Field f = com.ledgerpro.ui.JournalView.class.getDeclaredField("search");
            f.setAccessible(true);
            return (TextField) f.get(journal);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private static javafx.scene.control.ComboBox<String> statusCombo(Object journal) {
        try {
            Field f = com.ledgerpro.ui.JournalView.class.getDeclaredField("statusFilter");
            f.setAccessible(true);
            return (javafx.scene.control.ComboBox<String>) f.get(journal);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    private static void pause(long ms, Runnable then) {
        javafx.animation.PauseTransition wait = new javafx.animation.PauseTransition(
                javafx.util.Duration.millis(ms));
        wait.setOnFinished(e -> then.run());
        wait.play();
    }

    /** Capture that swallows checked exceptions into a runtime wrapper. */
    private static void captureSafe(Scene scene, String name) {
        try {
            capture(scene, name);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void capture(Scene scene, String name) throws Exception {
        javafx.scene.image.WritableImage image = scene.snapshot(null);
        Path out = Path.of("target/ui-snapshots", name + ".png");
        Files.createDirectories(out.getParent());
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                javafx.scene.image.PixelFormat.getIntArgbInstance(), pixels, 0, w);
        java.awt.image.BufferedImage buffered =
                new java.awt.image.BufferedImage(w, h,
                        java.awt.image.BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        javax.imageio.ImageIO.write(buffered, "png", out.toFile());
        System.out.println("captured " + out);
    }

    /** Seeds one client with a small profitable year (the snapshot shape). */
    private static long seed(Database database, String code, String name) {
        ClientService clients = new ClientService(database);
        AccountService accounts = new AccountService(database);
        PeriodService periods = new PeriodService(database);
        FxRateService fx = new FxRateService(database);
        JournalService journal = new JournalService(database, fx);

        long clientId = clients.create(code, name, "PHP").id();
        accounts.applyStandardChart(clientId);
        Period fy = periods.create(clientId, "FY 2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));

        SeedCtx ctx = new SeedCtx(accounts, journal, clientId, fy);
        post(ctx, LocalDate.of(2026, 1, 1), "initial capital",
                line(ctx, "1010", 1_000_000_00L), line(ctx, "3000", -1_000_000_00L));
        post(ctx, LocalDate.of(2026, 3, 5), "cash sales",
                line(ctx, "1010", 420_000_00L), line(ctx, "4010", -420_000_00L));
        post(ctx, LocalDate.of(2026, 5, 12), "credit sale",
                line(ctx, "1100", 180_000_00L), line(ctx, "4010", -180_000_00L));
        post(ctx, LocalDate.of(2026, 6, 30), "rent paid",
                line(ctx, "6100", 96_000_00L), line(ctx, "1010", -96_000_00L));
        post(ctx, LocalDate.of(2026, 10, 15), "salaries",
                line(ctx, "6000", 132_000_00L), line(ctx, "1010", -132_000_00L));

        journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 11, 2), EntryType.NORMAL,
                null, "electricity bill, draft", null, null, List.of(
                line(ctx, "6110", 3_500_00L),
                line(ctx, "1010", -3_500_00L))));
        return clientId;
    }

    /** A debit (positive) or credit (negative) line by account code. */
    private static JournalService.NewLine line(SeedCtx ctx, String code, long signed) {
        long account = ctx.accounts().list(ctx.clientId(), false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst().orElseThrow().id();
        return signed >= 0
                ? new JournalService.NewLine(account, signed, null, null)
                : new JournalService.NewLine(account, null, -signed, null);
    }

    private static void post(SeedCtx ctx, LocalDate date, String memo,
                             JournalService.NewLine... lines) {
        ctx.journal().post(ctx.journal().createDraft(new JournalService.NewEntry(
                ctx.clientId(), ctx.fy().id(), date, EntryType.NORMAL, null, memo,
                null, null, List.of(lines))).id());
    }

    private record SeedCtx(AccountService accounts, JournalService journal,
                           long clientId, Period fy) { }
}
