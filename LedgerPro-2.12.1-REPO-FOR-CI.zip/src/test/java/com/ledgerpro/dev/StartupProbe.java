package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Cold-start + memory probe (dev tool, test sources) for the 2.12.0
 * performance work: boots the REAL application scene exactly like a
 * packaged launch does, on a fresh copy of a seeded database, and prints
 * two numbers the before/after comparison needs:
 *
 * <pre>
 *   ms-to-scene   JVM start → buildScene returned (theme, CSS, shell, views)
 *   ms-to-layout  + one layout pulse after stage.show()
 *   heap-used     after System.gc() at ready (MB)
 * </pre>
 *
 * The seed database is COPIED per run so every run measures the same cold
 * path (fresh page cache per JVM, no WAL leftovers from the previous run).
 *
 * <pre>
 *   xvfb-run java ... com.ledgerpro.dev.StartupProbe seeded.db
 * </pre>
 */
public final class StartupProbe {

    public static void main(String[] args) throws Exception {
        String sourceDb = args.length > 0 ? args[0] : "data/ledgerpro.db";
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        // fresh copy per run: same data, cold file cache, no WAL residue
        Path run = Path.of("target", "startup-probe",
                "run-" + System.nanoTime() + ".db");
        Files.createDirectories(run.getParent());
        Files.copy(Path.of(sourceDb), run,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        long[] sceneAt = {0};
        long[] layoutAt = {0};
        long[] heap = {0};

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(run.toString());
                database.migrate();
                long t0 = System.nanoTime();
                Scene scene = App.buildScene(database);
                long t1 = System.nanoTime();
                sceneAt[0] = t1 - t0;
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
                // one pulse after show: layout + CSS applied
                Platform.runLater(() -> {
                    try {
                        stage.getScene().getRoot().applyCss();
                        stage.getScene().getRoot().layout();
                        layoutAt[0] = System.nanoTime() - t0;
                        System.gc();
                        Thread.sleep(120);
                        System.gc();
                        heap[0] = Runtime.getRuntime().totalMemory()
                                - Runtime.getRuntime().freeMemory();
                    } catch (Throwable t) {
                        failure.set(t);
                    } finally {
                        Platform.exit();
                        done.countDown();
                    }
                });
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(60, TimeUnit.SECONDS)) {
            throw new IllegalStateException("startup probe timed out");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("startup probe failed", failure.get());
        }
        // total wall time from JVM launch (the wrapper passes -Dprobe.start,
        // epoch ms at exec time) to the first laid-out frame; -1 when absent
        long probeStart = Long.parseLong(System.getProperty("probe.start", "0"));
        long wallMs = probeStart == 0 ? -1
                : System.currentTimeMillis() - probeStart;
        System.out.printf(java.util.Locale.ROOT,
                "PROBE ms-to-scene=%d ms-to-layout=%d heap-used-mb=%d wall-ms=%d%n",
                sceneAt[0] / 1_000_000,
                layoutAt[0] / 1_000_000,
                heap[0] / (1024 * 1024),
                wallMs);
    }

    private StartupProbe() {
    }
}
