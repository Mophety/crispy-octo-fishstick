package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.Theme;
import com.ledgerpro.ui.ThemeManager;
import com.ledgerpro.ui.UiScale;
import com.ledgerpro.ui.ViewId;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.Chart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.skin.TableColumnHeader;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.Region;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Headless LAYOUT AUDIT for the 2.12.1 dashboard / journal work (dev tool,
 * test sources). Boots the real scene on the Northwind demo books at a given
 * window size and text scale, waits for the async reads to land, then writes
 *
 * <ul>
 *   <li>a PNG of the whole scene, and</li>
 *   <li>a text report: root font, the bounds of the interesting regions,
 *       every {@link Labeled} whose text does not fit its node (truncated),
 *       every table column (declared vs actual width), the visible rows and
 *       their cells, and the chart nodes.</li>
 * </ul>
 *
 * <p>A reader without image input uses the report to verify "nothing is
 * ellipsized, nothing overflows, the last row is whole" — and the PNG for a
 * second opinion through OCR / a vision model.</p>
 *
 * <pre>
 * UiAudit2121 &lt;dbPath&gt; &lt;outDir&gt; &lt;view&gt; &lt;width&gt; &lt;height&gt; &lt;scale&gt; [THEME] [tag] [scenario]
 *   scale    "auto" = the app's own responsive scale for that window size,
 *            a number (e.g. 1.5) = root font forced to 14 px x scale. The app
 *            clamps its own scale to 0.85..1.30, so 1.5 is a STRESS TEST that
 *            the shipped UI cannot reach by itself.
 *   scenario "demo" (default, the shipped Northwind books) or "extremes"
 *            (a second client with zero-value months, one 9-digit month and
 *            a 12-digit month; used to stress axis formats and labels).
 * </pre>
 */
public final class UiAudit2121 {

    private static final List<String> TRACKED = List.of(
            "lp-sidebar", "lp-topbar", "lp-statusbar", "lp-content", "lp-heading",
            "lp-live-stamp", "lp-compact-btn", "lp-primary-btn", "lp-card", "lp-card-title",
            "lp-card-value", "lp-card-note", "lp-chart-card", "lp-chart-title",
            "lp-toolbar-group", "lp-toolbar-sep", "lp-chip", "lp-nav-btn", "lp-nav-section",
            "lp-kpi", "lp-kpi-accent", "lp-chart-legend", "lp-chart-legend-row",
            "lp-journal-subtitle", "lp-journal-footer", "lp-hint");

    private UiAudit2121() {
    }

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        String outDir = args.length > 1 ? args[1] : "target/ui-audit";
        String viewName = args.length > 2 ? args[2] : "dashboard";
        double width = args.length > 3 ? Double.parseDouble(args[3]) : 1280;
        double height = args.length > 4 ? Double.parseDouble(args[4]) : 820;
        String scaleArg = args.length > 5 ? args[5] : "auto";
        String themeArg = args.length > 6 && !args[6].isBlank() ? args[6] : null;
        String tag = args.length > 7 && !args[7].isBlank() ? args[7] : "run";
        String scenario = args.length > 8 && !args[8].isBlank() ? args[8] : "demo";
        ViewId view = ViewId.valueOf(viewName.toUpperCase(Locale.ROOT));

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                DemoData.seedIfEmpty(database);
                long clientId = clientId(database, "NRTH");
                if ("extremes".equals(scenario)) {
                    clientId = AuditScenarios.seedExtremes(database);
                }

                Scene scene = App.buildScene(database, width, height);
                AppShell shell = (AppShell) scene.getRoot();
                shell.selectWorkingClientById(clientId);
                shell.show(view);

                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                if (themeArg != null) {
                    // the runtime switch, exactly as the Appearance picker does it
                    ThemeManager.apply(Theme.valueOf(themeArg.toUpperCase(Locale.ROOT)), scene);
                }
                if (!"auto".equalsIgnoreCase(scaleArg)) {
                    forceScale(scene, Double.parseDouble(scaleArg));
                }

                // The views read on a background thread and the table's
                // virtual flow creates its cells in a post-layout pulse:
                // wait until the data is on screen (a populated row or a
                // drawn chart), let it settle, THEN measure. The snapshot
                // is taken AFTER the report on purpose: scene.snapshot()
                // re-runs CSS/layout, which makes the virtual flow release
                // and recreate its cells, and a report taken afterwards
                // reads freshly-created, still-empty rows (the first
                // baseline run did exactly that and reported "null" cells
                // although the PNG shows the rows).
                waitForData(scene, 60, () -> {
                    try {
                        scene.getRoot().applyCss();
                        scene.getRoot().layout();
                        String suffix = "-" + tag + "-" + viewName.toLowerCase(Locale.ROOT)
                                + "-" + (int) width + "x" + (int) height
                                + "-" + scaleArg.toLowerCase(Locale.ROOT)
                                + (themeArg == null ? "" : "-" + themeArg.toLowerCase(Locale.ROOT))
                                + ("demo".equals(scenario) ? "" : "-" + scenario);
                        Path dir = Path.of(outDir);
                        Files.createDirectories(dir);
                        StringBuilder report = new StringBuilder();
                        describe(scene, shell, view, scaleArg, report, stage);
                        Path png = dir.resolve("audit" + suffix + ".png");
                        writePng(scene.snapshot(null), png);
                        Path txt = dir.resolve("audit" + suffix + ".txt");
                        Files.writeString(txt, report.toString(), StandardCharsets.UTF_8);
                        System.out.println("AUDIT_OK png=" + png.toAbsolutePath()
                                + " txt=" + txt.toAbsolutePath());
                        System.out.println(report);
                    } catch (Throwable t) {
                        failure.set(t);
                    } finally {
                        Platform.exit();
                        done.countDown();
                    }
                });
            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });
        if (!done.await(90, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI audit timed out after 90 s");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("UI audit failed", failure.get());
        }
    }

    /**
     * Polls every 100 ms until the view shows its data — a table row that
     * carries an item, or a chart whose slices/points have nodes — then
     * lets 700 ms of pulses pass before {@code ready} runs. Gives up
     * after {@code attempts} polls (an empty client never shows data).
     */
    private static void waitForData(Scene scene, int attemptsLeft, Runnable ready) {
        if (hasData(scene) || attemptsLeft == 0) {
            PauseTransition settle = new PauseTransition(Duration.millis(700));
            settle.setOnFinished(e -> ready.run());
            settle.play();
            return;
        }
        PauseTransition step = new PauseTransition(Duration.millis(100));
        step.setOnFinished(e -> waitForData(scene, attemptsLeft - 1, ready));
        step.play();
    }

    private static boolean hasData(Scene scene) {
        List<Node> all = new ArrayList<>();
        collect(scene.getRoot(), all);
        for (Node node : all) {
            if (!isShown(node)) {
                continue;
            }
            if (node instanceof TableView<?> table) {
                for (javafx.scene.control.TableRow<?> row : tableRowsWithItem(table)) {
                    if (isShown(row)) {
                        return true;
                    }
                }
            }
            if (node instanceof PieChart pie) {
                for (PieChart.Data data : pie.getData()) {
                    if (data.getNode() != null) {
                        return true;
                    }
                }
            }
            if (node instanceof XYChart<?, ?> xy) {
                for (XYChart.Series<?, ?> series : xy.getData()) {
                    for (XYChart.Data<?, ?> data : series.getData()) {
                        if (data.getNode() != null) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /** The table's rows (scene graph, not CSS lookup) that carry an item. */
    static List<javafx.scene.control.TableRow<?>> tableRowsWithItem(TableView<?> table) {
        List<Node> nodes = new ArrayList<>();
        collect(table, nodes);
        List<javafx.scene.control.TableRow<?>> rows = new ArrayList<>();
        for (Node node : nodes) {
            if (node instanceof javafx.scene.control.TableRow<?> row && row.getItem() != null) {
                rows.add(row);
            }
        }
        return rows;
    }

    /**
     * True when the node and every ancestor is visible and managed — the
     * only nodes a user can actually see. (A hidden table still reports
     * isVisible() == true on its own placeholder label.)
     */
    static boolean isShown(Node node) {
        if (node.getScene() == null) {
            return false;
        }
        for (Node current = node; current != null; current = current.getParent()) {
            if (!current.isVisible() || !current.isManaged()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Replaces the responsive binding with a fixed root font: 14 px (the
     * design size) times the requested scale. The app's own controller is
     * left running, so the status bar still prints ITS (clamped) value —
     * only the root font is forced here.
     */
    private static void forceScale(Scene scene, double scale) {
        Region root = (Region) scene.getRoot();
        root.styleProperty().unbind();
        root.setStyle(String.format(Locale.ROOT, "-fx-font-size: %.2fpx;", 14.0 * scale));
    }

    private static long clientId(Database database, String code) {
        try (var con = database.open();
             var ps = con.prepareStatement("SELECT id FROM clients WHERE code = ?")) {
            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        } catch (Exception e) {
            throw new IllegalStateException("cannot find client " + code, e);
        }
    }

    // ------------------------------------------------------------------
    // The report
    // ------------------------------------------------------------------

    private static void describe(Scene scene, AppShell shell, ViewId view,
                                 String scaleArg, StringBuilder out, Stage stage) {
        Region root = (Region) scene.getRoot();
        out.append(String.format(Locale.ROOT,
                "== stage %.0fx%.0f (x %.0f, y %.0f) · scene %.0fx%.0f at (%.0f, %.0f) · root %s %.1fx%.1f at (%.1f, %.1f)%n",
                stage.getWidth(), stage.getHeight(), stage.getX(), stage.getY(),
                scene.getWidth(), scene.getHeight(), scene.getX(), scene.getY(),
                root.getClass().getSimpleName(), root.getWidth(), root.getHeight(),
                root.getLayoutX(), root.getLayoutY()));
        Parent rootParent = root.getParent();
        if (rootParent != null) {
            out.append(String.format(Locale.ROOT,
                    "   root parent %s %.1fx%.1f at (%.1f, %.1f) · root translate (%.1f, %.1f) scale (%.2f, %.2f)%n",
                    rootParent.getClass().getName(), rootParent.getLayoutBounds().getWidth(),
                    rootParent.getLayoutBounds().getHeight(), rootParent.getLayoutX(),
                    rootParent.getLayoutY(), root.getTranslateX(), root.getTranslateY(),
                    root.getScaleX(), root.getScaleY()));
        }
        // JavaFX exposes no public font on Region: read the inherited font
        // off the first plain labeled in the tree (the sidebar brand)
        Font rootFont = null;
        List<Node> tree = new ArrayList<>();
        collect(root, tree);
        for (Node node : tree) {
            if (node instanceof Labeled labeled && labeled.getStyleClass().contains("lp-nav-btn")) {
                rootFont = labeled.getFont();
                break;
            }
        }
        if (rootFont == null) {
            rootFont = Font.getDefault();
        }
        out.append("== scene ").append((int) scene.getWidth()).append("x")
                .append((int) scene.getHeight())
                .append(" · requested scale ").append(scaleArg)
                .append(" · UiScale says ").append(String.format(Locale.ROOT, "%.2f", UiScale.getInstance().getScale()))
                .append(" · root font ").append(fmt(rootFont.getSize())).append("px ")
                .append(rootFont.getFamily()).append('\n');
        out.append("root style: ").append(root.getStyle()).append('\n');
        out.append("root classes: ").append(root.getStyleClass()).append('\n');

        // 1. the tracked regions
        out.append("\n-- tracked regions (scene coords: x, y, w x h; min/pref w) --\n");
        List<Node> all = new ArrayList<>();
        collect(root, all);
        for (Node node : all) {
            for (String cls : TRACKED) {
                if (node.getStyleClass().contains(cls)) {
                    Bounds b = sceneBounds(node);
                    if (b == null) {
                        break;
                    }
                    out.append(String.format(Locale.ROOT, "%-18s x%-7.1f y%-7.1f w%-7.1f h%-6.1f",
                            cls, b.getMinX(), b.getMinY(), b.getWidth(), b.getHeight()));
                    if (node instanceof Region region) {
                        out.append(String.format(Locale.ROOT, " minW %-7.1f prefW %-7.1f maxW ",
                                region.getMinWidth(), region.getPrefWidth()));
                        out.append(region.getMaxWidth() > 1e300 ? "MAX" : fmt(region.getMaxWidth()));
                    }
                    if (node instanceof Labeled labeled) {
                        out.append(" text=\"").append(labeled.getText()).append('"');
                    }
                    out.append('\n');
                    break;
                }
            }
        }

        // 2. every labeled whose text does not fit
        out.append("\n-- truncated labels (text does not fit its node) --\n");
        int truncated = 0;
        for (Node node : all) {
            if (node instanceof Labeled labeled && isTruncated(labeled)) {
                truncated++;
                Bounds b = sceneBounds(node);
                out.append(String.format(Locale.ROOT, "  TRUNC x%-6.1f y%-6.1f w%-6.1f need %-6.1f %-22s \"%s\"%n",
                        b.getMinX(), b.getMinY(), labeled.getWidth(), neededWidth(labeled),
                        labeled.getClass().getSimpleName(), labeled.getText()));
            }
        }
        if (truncated == 0) {
            out.append("  (none)\n");
        }

        // 2b. why: the first few truncated labels that are not table cells,
        //     with their font, padding, preferred/min/max width and the
        //     siblings they share a row with
        out.append("\n-- truncation detail (non-cell labels, first 8) --\n");
        int detailed = 0;
        for (Node node : all) {
            if (detailed >= 8) {
                break;
            }
            if (node instanceof Labeled labeled && !(labeled instanceof TableCell<?, ?>)
                    && isTruncated(labeled)) {
                detailed++;
                out.append(String.format(Locale.ROOT,
                        "  \"%s\" %s font=%s/%.2f padding=%s width=%.2f pref=%.2f min=%.2f max=%.0f textOverrun=%s wrap=%s%n",
                        labeled.getText(), labeled.getClass().getSimpleName(),
                        labeled.getFont().getFamily(), labeled.getFont().getSize(),
                        labeled.getPadding(), labeled.getWidth(), labeled.prefWidth(-1),
                        labeled.minWidth(-1), labeled.getMaxWidth(),
                        labeled.getTextOverrun(), labeled.isWrapText()));
                Parent parent = labeled.getParent();
                if (parent != null) {
                    out.append(String.format(Locale.ROOT, "    parent %s width=%.2f insets=%s children:%n",
                            parent.getClass().getSimpleName(),
                            parent instanceof Region parentRegion ? parentRegion.getWidth() : -1.0,
                            parent instanceof Region parentRegion ? parentRegion.getInsets() : "-"));
                    int index = 0;
                    for (Node sibling : parent.getChildrenUnmodifiable()) {
                        String text = sibling instanceof Labeled siblingLabeled
                                ? " \"" + siblingLabeled.getText() + "\"" : "";
                        String size = sibling instanceof Region siblingRegion
                                ? String.format(Locale.ROOT, "w=%.1f pref=%.1f min=%.1f max=%.0f",
                                siblingRegion.getWidth(), siblingRegion.prefWidth(-1),
                                siblingRegion.minWidth(-1), siblingRegion.getMaxWidth())
                                : "not-a-region";
                        out.append(String.format(Locale.ROOT, "      [%d] %s%s %s%s%n",
                                index++, sibling.getClass().getSimpleName(), text, size,
                                sibling == labeled ? "  <== this" : ""));
                    }
                }
                if (labeled instanceof Control) {
                    for (Node child : ((Parent) labeled).getChildrenUnmodifiable()) {
                        out.append(String.format(Locale.ROOT,
                                "    inner %s bounds=%s layoutBounds=%.1fx%.1f%n",
                                child.getClass().getSimpleName(), child.getBoundsInParent(),
                                child.getLayoutBounds().getWidth(), child.getLayoutBounds().getHeight()));
                    }
                }
            }
        }
        if (detailed == 0) {
            out.append("  (none)\n");
        }

        // 2c. the sidebar's width: CSS asks for 17em, so the measured width
        //     must be 17 x the root font
        out.append("\n-- sidebar width --\n");
        for (Node node : all) {
            if (node.getStyleClass().contains("lp-sidebar") && node instanceof Region region) {
                out.append(String.format(Locale.ROOT,
                        "  width=%.1f minWidth=%.1f prefWidth=%.1f maxWidth=%.0f insets=%s → %.2f px per em at %s%n",
                        region.getWidth(), region.getMinWidth(), region.getPrefWidth(),
                        region.getMaxWidth(), region.getInsets(),
                        region.getWidth() / 17.0, rootFont));
                int index = 0;
                for (Node child : ((Parent) node).getChildrenUnmodifiable()) {
                    if (child instanceof Region childRegion) {
                        out.append(String.format(Locale.ROOT, "      [%d] %-28s w=%.1f pref=%.1f min=%.1f%n",
                                index, child.getClass().getSimpleName(), childRegion.getWidth(),
                                childRegion.prefWidth(-1), childRegion.minWidth(-1)));
                    }
                    index++;
                }
            }
        }

        // 3. labeled nodes spilling past the right edge of the scene or of
        //    their parent region (clipped content)
        out.append("\n-- overflow (node wider than its parent region, or past the scene edge) --\n");
        int overflow = 0;
        for (Node node : all) {
            if (!(node instanceof Labeled labeled) || labeled.getText() == null
                    || labeled.getText().isBlank() || !isShown(labeled)) {
                continue;
            }
            Bounds b = sceneBounds(node);
            if (b == null) {
                continue;
            }
            String why = null;
            if (b.getMaxX() > scene.getWidth() + 0.5) {
                why = "past scene right edge";
            } else if (node.getParent() instanceof Region parent) {
                Bounds pb = sceneBounds(parent);
                if (pb != null && b.getMaxX() > pb.getMaxX() + 0.5) {
                    why = "past parent right edge";
                }
            }
            if (why != null) {
                overflow++;
                out.append(String.format(Locale.ROOT,
                        "  OVERFLOW %-22s \"%s\" right %.1f %s%n",
                        labeled.getClass().getSimpleName(), labeled.getText(), b.getMaxX(), why));
            }
        }
        if (overflow == 0) {
            out.append("  (none)\n");
        }

        // 4. tables
        out.append("\n-- tables --\n");
        for (Node node : all) {
            if (node instanceof TableView<?> table && isShown(table)
                    && table.getHeight() > 0) {
                describeTable(table, out);
            }
        }

        // 4b. text that runs past the inner edge of its own node (cells
        //     whose graphic or figure is wider than the column, labels
        //     clipped by their parent) — reported separately from ellipsis
        out.append("\n-- cell content vs column (text + graphic wider than the cell's inner width) --\n");
        int overset = 0;
        for (Node node : all) {
            if (node instanceof TableCell<?, ?> cell && isShown(cell)
                    && cell.getItem() != null) {
                double needed = cellNeededWidth(cell);
                double inner = cellInnerWidth(cell);
                if (needed > inner + 0.5) {
                    overset++;
                    out.append(String.format(Locale.ROOT,
                            "  OVERSET %-10s text=\"%s\" graphic=%s needs %.1f inner %.1f%n",
                            cell.getTableColumn() == null ? "-" : cell.getTableColumn().getText(),
                            cell.getText(),
                            cell.getGraphic() == null ? "-" : cell.getGraphic().getStyleClass(),
                            needed, inner));
                }
            }
        }
        if (overset == 0) {
            out.append("  (none)\n");
        }

        // 5. charts
        out.append("\n-- charts --\n");
        for (Node node : all) {
            if (node instanceof Chart chart && isShown(chart)) {
                describeChart(chart, out);
            }
        }

        // 6. the toolbar of the journal view (buttons in order, with state)
        if (view == ViewId.JOURNAL) {
            out.append("\n-- journal toolbar buttons (scene order, top to bottom / left to right) --\n");
            List<Labeled> buttons = new ArrayList<>();
            for (Node node : all) {
                if (node instanceof Labeled labeled && isShown(labeled)
                        && (labeled instanceof javafx.scene.control.Button
                        || labeled instanceof javafx.scene.control.ToggleButton)
                        && !(labeled instanceof javafx.scene.control.RadioButton)) {
                    buttons.add(labeled);
                }
            }
            buttons.sort((a, b) -> {
                Bounds ba = sceneBounds(a);
                Bounds bb = sceneBounds(b);
                int rows = Double.compare(Math.round(ba.getMinY() / 4), Math.round(bb.getMinY() / 4));
                return rows != 0 ? rows : Double.compare(ba.getMinX(), bb.getMinX());
            });
            for (Labeled button : buttons) {
                Bounds b = sceneBounds(button);
                out.append(String.format(Locale.ROOT, "  x%-7.1f y%-6.1f w%-7.1f h%-5.1f %-28s disabled=%s text=\"%s\"%n",
                        b.getMinX(), b.getMinY(), b.getWidth(), b.getHeight(),
                        button.getClass().getSimpleName(), button.isDisable(), button.getText()));
            }
        }
        out.append("\n-- summary --\n");
        out.append("truncated=").append(truncated).append(" overflow=").append(overflow);
        if (overset > 0) {
            out.append(" overset=").append(overset);
        }
        out.append('\n');
    }

    /** The cell width minus its left/right padding. */
    static double cellInnerWidth(TableCell<?, ?> cell) {
        javafx.geometry.Insets padding = cell.getPadding();
        return cell.getWidth() - padding.getLeft() - padding.getRight();
    }

    /** Text plus graphic (with the gap) the cell wants, in its own font. */
    static double cellNeededWidth(TableCell<?, ?> cell) {
        double needed = cell.getText() == null ? 0 : textWidth(cell.getText(), cell.getFont());
        Node graphic = cell.getGraphic();
        if (graphic != null && graphic.isVisible()) {
            needed += graphic.getLayoutBounds().getWidth() + cell.getGraphicTextGap();
        }
        return needed;
    }

    private static void describeTable(TableView<?> table, StringBuilder out) {
        Bounds b = sceneBounds(table);
        out.append(String.format(Locale.ROOT,
                "%n%s id=%s classes=%s%n  scene x%.1f y%.1f w%.1f h%.1f · items %d · policy %s%n",
                table.getClass().getSimpleName(), table.getId(), table.getStyleClass(),
                b.getMinX(), b.getMinY(), b.getWidth(), b.getHeight(),
                table.getItems().size(),
                table.getColumnResizePolicy().getClass().getSimpleName()
                        + ":" + table.getColumnResizePolicy()));

        // the content area under the header
        double headerHeight = 0;
        Node headerRow = table.lookup("NestedTableColumnHeader");
        if (headerRow != null) {
            headerHeight = headerRow.getLayoutBounds().getHeight();
        }
        double sum = 0;
        double sumPref = 0;
        double sumMin = 0;
        for (TableColumn<?, ?> column : table.getColumns()) {
            sum += column.getWidth();
            sumPref += column.getPrefWidth();
            sumMin += column.getMinWidth();
        }
        out.append(String.format(Locale.ROOT,
                "  columns: actual %.1f · declared pref %.1f · declared min %.1f · table width %.1f · header %.1f%n",
                sum, sumPref, sumMin, table.getWidth(), headerHeight));
        for (TableColumn<?, ?> column : table.getColumns()) {
            StringBuilder flags = new StringBuilder();
            for (Node header : table.lookupAll(".column-header")) {
                if (header instanceof TableColumnHeader columnHeader
                        && columnHeader.getTableColumn() == column) {
                    for (Node child : columnHeader.getChildrenUnmodifiable()) {
                        if (child instanceof Labeled headerLabel && headerLabel.isVisible()) {
                            flags.append(" header=\"").append(headerLabel.getText()).append('"');
                            if (isTruncated(headerLabel)) {
                                flags.append(" HEADER-TRUNCATED");
                            }
                        }
                    }
                }
            }
            String sort = column.getSortType() == null ? "-"
                    : column.getSortType().name().toLowerCase(Locale.ROOT);
            out.append(String.format(Locale.ROOT,
                    "    %-18s actual %6.1f pref %6.1f min %6.1f sortable=%-5s sort=%-4s classes=%s%s%n",
                    "\"" + column.getText() + "\"", column.getWidth(), column.getPrefWidth(),
                    column.getMinWidth(), column.isSortable(), sort, column.getStyleClass(), flags));
        }

        // the visible rows and their cells. Rows come from the real scene
        // graph, not lookupAll(".table-row-cell"): a row factory that
        // replaces the row's style classes (the 2.12.0 journal did) makes
        // its rows invisible to that lookup.
        List<Node> rows = new ArrayList<>();
        collect(table, rows);
        rows.removeIf(node -> !(node instanceof javafx.scene.control.TableRow<?> row)
                || row.getItem() == null || !isShown(row));
        rows.sort((x, y) -> Double.compare(x.getLayoutY(), y.getLayoutY()));
        double contentBottom = table.getHeight() - headerHeight;
        out.append("  visible rows: ").append(rows.size()).append('\n');
        for (Node row : rows) {
            double rowHeight = row.getBoundsInParent().getHeight();
            double rowTop = headerHeight + row.getLayoutY();
            double rowBottom = rowTop + rowHeight;
            if (rowBottom <= headerHeight + 0.5 || rowTop >= table.getHeight()) {
                continue;
            }
            String clipped = rowBottom > table.getHeight() + 0.5
                    ? String.format(Locale.ROOT, " CLIPPED(%.1f px visible of %.1f)",
                    table.getHeight() - rowTop, rowHeight)
                    : "";
            out.append(String.format(Locale.ROOT,
                    "    row y%.1f..%.1f h%.1f opacity=%.2f classes=%s%s%n",
                    rowTop, rowBottom, rowHeight, row.getOpacity(), row.getStyleClass(), clipped));
            if (row instanceof Parent rowParent) {
                StringBuilder cells = new StringBuilder();
                for (Node child : rowParent.getChildrenUnmodifiable()) {
                    if (child instanceof TableCell<?, ?> cell && cell.isVisible()) {
                        if (!cells.isEmpty()) {
                            cells.append(" | ");
                        }
                        cells.append('"').append(cell.getText()).append("\" w").append(fmt(cell.getWidth()));
                        cells.append(' ').append(cell.getAlignment());
                        if (cell.getFont() != null) {
                            cells.append(' ').append(fmt(cell.getFont().getSize())).append("px");
                        }
                        if (isTruncated(cell)) {
                            cells.append(" TRUNC");
                        }
                        if (cell.getGraphic() instanceof Labeled pill) {
                            cells.append(" pill=\"").append(pill.getText()).append("\" pw")
                                    .append(fmt(pill.getWidth())).append(" pmin")
                                    .append(fmt(pill.minWidth(-1)));
                        }
                        if (cellNeededWidth(cell) > cellInnerWidth(cell) + 0.5) {
                            cells.append(" OVERSET(")
                                    .append(fmt(cellNeededWidth(cell) - cellInnerWidth(cell)))
                                    .append(')');
                        }
                    }
                }
                out.append("      cells: ").append(cells).append('\n');
            }
        }
        if (contentBottom > 0) {
            out.append(String.format(Locale.ROOT, "  content area under header: %.1f px%n", contentBottom));
        }
    }

    private static void describeChart(Chart chart, StringBuilder out) {
        Bounds b = sceneBounds(chart);
        out.append(String.format(Locale.ROOT,
                "%n%s id=%s classes=%s%n  scene x%.1f y%.1f w%.1f h%.1f · animated=%s · legend=%s %s%n",
                chart.getClass().getSimpleName(), chart.getId(), chart.getStyleClass(),
                b.getMinX(), b.getMinY(), b.getWidth(), b.getHeight(),
                chart.getAnimated(), chart.isLegendVisible(),
                chart.getLegendSide() == null ? "-" : chart.getLegendSide()));
        out.append("  title=\"").append(chart.getTitle()).append("\"\n");
        out.append("  style=\"").append(chart.getStyle()).append("\"\n");
        if (chart instanceof PieChart pie) {
            out.append("  labelsVisible=").append(pie.getLabelsVisible())
                    .append(" labelLineLength=").append(pie.getLabelLineLength())
                    .append(" startAngle=").append(pie.getStartAngle())
                    .append(" clockwise=").append(pie.isClockwise()).append('\n');
            for (PieChart.Data data : pie.getData()) {
                Bounds slice = data.getNode() == null ? null : sceneBounds(data.getNode());
                out.append(String.format(Locale.ROOT, "    slice \"%s\" node=%s bounds=%s%n",
                        data.getName(),
                        data.getNode() == null ? "null" : data.getNode().getStyleClass(),
                        slice == null ? "-" : String.format(Locale.ROOT, "%.0fx%.0f", slice.getWidth(), slice.getHeight())));
            }
            Node pieLegend = pie.lookup(".chart-legend");
            if (pieLegend != null) {
                Bounds legend = sceneBounds(pieLegend);
                out.append(String.format(Locale.ROOT, "  legend bounds %.0fx%.0f at x%.0f y%.0f%n",
                        legend.getWidth(), legend.getHeight(), legend.getMinX(), legend.getMinY()));
            }
        }
        if (chart instanceof XYChart<?, ?> xy) {
            out.append("  alternativeRowFillVisible=").append(xy.isAlternativeRowFillVisible())
                    .append(" verticalZeroLineVisible=").append(xy.isVerticalZeroLineVisible())
                    .append(" horizontalZeroLineVisible=").append(xy.isHorizontalZeroLineVisible())
                    .append('\n');
            for (Object axisObject : new Object[]{xy.getXAxis(), xy.getYAxis()}) {
                if (axisObject instanceof javafx.scene.chart.Axis<?> axis) {
                    Bounds axisBounds = sceneBounds(axis);
                    out.append(String.format(Locale.ROOT,
                            "    axis %s label=\"%s\" side=%s animated=%s bounds x%.0f y%.0f %.0fx%.0f%n",
                            axis.getClass().getSimpleName(), axis.getLabel(), axis.getSide(),
                            axis.getAnimated(), axisBounds.getMinX(), axisBounds.getMinY(),
                            axisBounds.getWidth(), axisBounds.getHeight()));
                    if (axis instanceof javafx.scene.chart.ValueAxis<?> valueAxis) {
                        out.append(String.format(Locale.ROOT,
                                "      range %.3f..%.3f minorCount=%d tickLabelsVisible=%s",
                                valueAxis.getLowerBound(), valueAxis.getUpperBound(),
                                valueAxis.getMinorTickCount(),
                                valueAxis.isTickLabelsVisible()));
                        if (axis instanceof javafx.scene.chart.NumberAxis numberAxis) {
                            out.append(String.format(Locale.ROOT, " tickUnit=%.3f", numberAxis.getTickUnit()));
                        }
                        out.append('\n');
                    }
                }
            }
            for (int s = 0; s < xy.getData().size(); s++) {
                XYChart.Series<?, ?> series = xy.getData().get(s);
                StringBuilder extras = new StringBuilder();
                int shown = 0;
                for (XYChart.Data<?, ?> data : series.getData()) {
                    Node node = data.getNode();
                    if (node == null || shown >= 30) {
                        continue;
                    }
                    if (shown > 0) {
                        extras.append("; ");
                    }
                    Bounds nodeBounds = sceneBounds(node);
                    extras.append(data.getXValue()).append('=').append(data.getYValue()).append(' ')
                            .append(nodeBounds == null ? "no-bounds"
                                    : String.format(Locale.ROOT, "%.0fx%.0f", nodeBounds.getWidth(), nodeBounds.getHeight()))
                            .append(" opacity=").append(fmt(node.getOpacity()));
                    shown++;
                }
                out.append("    series \"").append(series.getName()).append("\": ")
                        .append(series.getData().size()).append(" points → ").append(extras).append('\n');
            }
            Node xyLegend = xy.lookup(".chart-legend");
            if (xyLegend != null) {
                Bounds legend = sceneBounds(xyLegend);
                out.append(String.format(Locale.ROOT, "  legend bounds %.0fx%.0f at x%.0f y%.0f%n",
                        legend.getWidth(), legend.getHeight(), legend.getMinX(), legend.getMinY()));
            }
            // the custom symbol nodes carry the value labels
            for (Node node : xy.lookupAll(".chart-line-symbol")) {
                Bounds symbol = sceneBounds(node);
                if (symbol != null && symbol.getWidth() > 0) {
                    out.append(String.format(Locale.ROOT, "    symbol %s %.1fx%.1f at x%.0f y%.0f children=%d%n",
                            node.getStyleClass(), symbol.getWidth(), symbol.getHeight(),
                            symbol.getMinX(), symbol.getMinY(),
                            node instanceof Parent parent ? parent.getChildrenUnmodifiable().size() : 0));
                    break;
                }
            }
        }
        for (Node node : chart.lookupAll(".chart-title")) {
            Bounds title = sceneBounds(node);
            out.append(String.format(Locale.ROOT, "  chart-title node w%.0f h%.0f%n",
                    title.getWidth(), title.getHeight()));
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** The width the labeled needs to print {@code text} in its own font. */
    static double textWidth(String text, Font font) {
        javafx.scene.text.Text probe = new javafx.scene.text.Text(text == null ? "" : text);
        probe.setFont(font);
        return probe.getLayoutBounds().getWidth();
    }

    /** The width the labeled needs for its text, padding and graphic. */
    static double neededWidth(Labeled labeled) {
        double width = textWidth(labeled.getText(), labeled.getFont());
        width += labeled.getPadding().getLeft() + labeled.getPadding().getRight();
        Node graphic = labeled.getGraphic();
        if (graphic != null && graphic.isVisible()) {
            width += graphic.getLayoutBounds().getWidth() + labeled.getGraphicTextGap();
        }
        return width;
    }

    /**
     * True when the labeled's text does not fit the node. Measured from the
     * raw string in the node's font, NOT from prefWidth: a text that is
     * already ellipsized has shrunk its own layout bounds, so prefWidth of a
     * truncated label lies.
     */
    static boolean isTruncated(Labeled labeled) {
        if (labeled.isWrapText() || labeled.getText() == null || labeled.getText().isBlank()
                || !isShown(labeled)) {
            return false;
        }
        double needed = neededWidth(labeled);
        return Double.isFinite(needed) && labeled.getWidth() + 0.75 < needed;
    }

    static Bounds sceneBounds(Node node) {
        if (node.getScene() == null) {
            return null;
        }
        Bounds local = node.getBoundsInLocal();
        if (local.isEmpty()) {
            return null;
        }
        try {
            return node.localToScene(local);
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void collect(Node node, List<Node> into) {
        into.add(node);
        if (node instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                collect(child, into);
            }
        }
    }

    static String fmt(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    private static void writePng(WritableImage image, Path out) throws Exception {
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                PixelFormat.getIntArgbInstance(), pixels, 0, w);
        BufferedImage buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        ImageIO.write(buffered, "png", out.toFile());
    }

    /** Silences the unused-warning for the Control/Label imports when the report grows. */
    static String name(Node node) {
        return node instanceof Control || node instanceof Label || node instanceof Region
                ? node.getClass().getSimpleName() : node.getClass().getName();
    }

    static {
        // keeps javac from flagging PrintWriter as unused if a later edit drops it
        PrintWriter.class.getName();
    }
}
