package com.ledgerpro.dev;

import com.ledgerpro.App;
import com.ledgerpro.db.Database;
import com.ledgerpro.ui.AppShell;
import com.ledgerpro.ui.UiScale;
import com.ledgerpro.ui.ViewId;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;
import javafx.stage.Stage;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The 2.5.0 headless verification tool: boots the REAL application scene at
 * a REQUESTED WINDOW SIZE and captures it, printing the live responsive-text
 * scale so the screenshots and the scale function can be cross-checked:
 *
 * <pre>
 * mvn exec:java -Ddb.cli.class=com.ledgerpro.dev.UiSnapshot250 \
 *          -Dexec.classpathScope=test \
 *          -Dexec.args="data/ledgerpro.db out dir view width height [tag]"
 * </pre>
 *
 * <p>Works exactly like {@link UiSnapshot} (demo data is seeded when the
 * database is empty, the worksheet scrolls to its totals rows) with two
 * additions: the window size is an argument, and an optional tag lands in
 * the output filename (e.g. {@code 10col} / {@code 13col} for the worksheet
 * format captures).</p>
 */
public final class UiSnapshot250 {

    public static void main(String[] args) throws Exception {
        String dbPath = args.length > 0 ? args[0] : "data/ledgerpro.db";
        String outDir = args.length > 1 ? args[1] : "target/ui-snapshots";
        String viewName = args.length > 2 ? args[2] : "dashboard";
        int width = args.length > 3 ? Integer.parseInt(args[3]) : 1280;
        int height = args.length > 4 ? Integer.parseInt(args[4]) : 820;
        String tag = args.length > 5 ? args[5] : "";
        ViewId view = ViewId.valueOf(viewName.toUpperCase(Locale.ROOT));

        System.setProperty("prism.order", "sw");
        System.setProperty("prism.vsync", "false");

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();

        Platform.startup(() -> { });
        Platform.runLater(() -> {
            try {
                Database database = new Database(dbPath);
                database.migrate();
                UiSnapshotSeed.seedForScreenshots(database);

                Scene scene = App.buildScene(database, width, height);
                AppShell shell = (AppShell) scene.getRoot();
                shell.selectWorkingClientById(firstClient(database));

                if (view == ViewId.WORKSHEET && "10col".equals(tag)) {
                    // flip the format combo to the classic 10-column sheet
                    for (javafx.scene.Node node
                            : scene.getRoot().lookupAll(".combo-box")) {
                        if (node instanceof javafx.scene.control.ComboBox<?> box
                                && !box.getItems().isEmpty()
                                && box.getItems().getFirst() instanceof
                                    com.ledgerpro.service.WorksheetService.WorksheetFormat) {
                            @SuppressWarnings("unchecked")
                            javafx.scene.control.ComboBox<com.ledgerpro.service
                                    .WorksheetService.WorksheetFormat> formatBox
                                    = (javafx.scene.control.ComboBox<com.ledgerpro.service
                                            .WorksheetService.WorksheetFormat>) box;
                            formatBox.setValue(formatBox.getItems().getFirst());
                        }
                    }
                }
                shell.show(view);

                if (view == ViewId.WORKSHEET) {
                    for (javafx.scene.Node node
                            : scene.getRoot().lookupAll(".table-view")) {
                        if (node instanceof javafx.scene.control.TableView<?> tableView
                                && !tableView.getItems().isEmpty()) {
                            tableView.scrollTo(tableView.getItems().size() - 1);
                        }
                    }
                }

                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                PauseTransition settle = new PauseTransition(Duration.millis(900));
                settle.setOnFinished(e -> {
                    try {
                        double expected = UiScale.autoScaleFor(width, height);
                        System.out.printf("ui-scale: %.3f (expected %.3f) mode=%s%n",
                                UiScale.getInstance().getScale(), expected,
                                UiScale.getInstance().getMode());
                        String suffix = tag.isEmpty() ? "" : "-" + tag;
                        String sizeTag = width + "x" + height;
                        Path out = Path.of(outDir, viewName.toLowerCase(Locale.ROOT)
                                + suffix + "-" + sizeTag + ".png");
                        Files.createDirectories(out.getParent());
                        writePng(scene.snapshot(null), out);
                        System.out.println("UI snapshot written: "
                                + out.toAbsolutePath());
                    } catch (Throwable t) {
                        failure.set(t);
                    } finally {
                        Platform.exit();
                        done.countDown();
                    }
                });
                settle.play();

            } catch (Throwable t) {
                failure.set(t);
                Platform.exit();
                done.countDown();
            }
        });

        if (!done.await(60, TimeUnit.SECONDS)) {
            throw new IllegalStateException("UI snapshot timed out after 60 s");
        }
        if (failure.get() != null) {
            throw new IllegalStateException("UI snapshot failed", failure.get());
        }
    }

    private static long firstClient(Database database) {
        try (var con = database.open();
             var rs = con.createStatement().executeQuery("SELECT MIN(id) FROM clients")) {
            return rs.next() ? rs.getLong(1) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private static void writePng(WritableImage image, Path out) throws Exception {
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        int[] pixels = new int[w * h];
        image.getPixelReader().getPixels(0, 0, w, h,
                PixelFormat.getIntArgbInstance(), pixels, 0, w);
        BufferedImage buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        buffered.setRGB(0, 0, w, h, pixels, 0, w);
        ImageIO.write(buffered, "png", out.toFile());
    }
}
