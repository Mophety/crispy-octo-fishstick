package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The 2.7.0 statement of cash flows — the plan's Sprint 3 acceptance: on a
 * scenario with depreciation, an accrual and an equipment purchase (the
 * demo's exact shape), the indirect-method statement must reconcile to the
 * penny against the cash accounts' own movement, and each section must
 * classify its rows correctly.
 */
class CashFlowServiceTest {

    private static final LocalDate JAN_01 = LocalDate.of(2026, 1, 1);
    private static final LocalDate DEC_31 = LocalDate.of(2026, 12, 31);

    @TempDir
    Path tmp;

    private Database database;
    private ClientService clients;
    private AccountService accounts;
    private PeriodService periods;
    private FxRateService fx;
    private JournalService journal;
    private CashFlowService cashFlow;

    private long clientId;
    private Period fy2026;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("cashflow.db").toString());
        database.migrate();
        clients = new ClientService(database);
        accounts = new AccountService(database);
        periods = new PeriodService(database);
        fx = new FxRateService(database);
        journal = new JournalService(database, fx);
        cashFlow = new CashFlowService(database);

        clientId = clients.create("NRTH", "Norte Freight Systems, Inc.", "PHP").id();
        accounts.applyStandardChart(clientId);
        fy2026 = periods.create(clientId, "FY2026", JAN_01, DEC_31);
    }

    private long acct(String code) {
        return accounts.findByCode(clientId, code).orElseThrow().id();
    }

    private void post(LocalDate date, EntryType type, String memo,
                      JournalService.NewLine... lines) {
        journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, fy2026.id(), date, type, null, memo, null, null,
                List.of(lines))).id());
    }

    // ------------------------------------------------------------------
    // The scenario: capital, sales, rent (cash), equipment purchase
    // (investing), depreciation (non-cash), accrued salaries (working cap)
    // ------------------------------------------------------------------

    private void seedScenario() {
        // capital in: +1,000,000 cash
        post(JAN_01, EntryType.NORMAL, "initial capital",
                new JournalService.NewLine(acct("1010"), 1_000_000_00L, null, "capital in"),
                new JournalService.NewLine(acct("3000"), null, 1_000_000_00L, "capital in"));
        // cash sales: +120,000
        post(LocalDate.of(2026, 6, 1), EntryType.NORMAL, "cash sales",
                new JournalService.NewLine(acct("1010"), 120_000_00L, null, "cash sale"),
                new JournalService.NewLine(acct("4010"), null, 120_000_00L, "sales"));
        // rent paid: -70,000
        post(LocalDate.of(2026, 7, 1), EntryType.NORMAL, "rent paid",
                new JournalService.NewLine(acct("6100"), 70_000_00L, null, "rent"),
                new JournalService.NewLine(acct("1010"), null, 70_000_00L, "rent paid"));
        // equipment purchase: -80,000 cash (investing)
        post(LocalDate.of(2026, 8, 1), EntryType.NORMAL, "equipment purchase",
                new JournalService.NewLine(acct("1500"), 80_000_00L, null, "equipment"),
                new JournalService.NewLine(acct("1010"), null, 80_000_00L, "paid"));
        // depreciation adjustment: 8,000 (non-cash)
        post(DEC_31, EntryType.ADJUSTING, "depreciation for the year",
                new JournalService.NewLine(acct("6130"), 8_000_00L, null, "depreciation"),
                new JournalService.NewLine(acct("1510"), null, 8_000_00L, "accumulated"));
        // accrued salaries: 5,000 (working capital, no cash)
        post(DEC_31, EntryType.ADJUSTING, "accrued salaries for December",
                new JournalService.NewLine(acct("6000"), 5_000_00L, null, "accrual"),
                new JournalService.NewLine(acct("2100"), null, 5_000_00L, "accrual"));
    }

    @Test
    void statementReconcilesToCashMovementToThePenny() {
        seedScenario();

        CashFlowService.CashFlowStatement s = cashFlow.statement(fy2026.id());

        // cash movement: 1,000,000 + 120,000 - 70,000 - 80,000 = 970,000
        assertEquals(970_000_00L, s.cashEnd() - s.cashStart());

        // net income = 120,000 - 70,000 - 8,000 - 5,000 = 37,000
        assertEquals(37_000_00L, s.netIncome());

        // operating = NI + depreciation + accrued salaries = 37,000 + 8,000 + 5,000 = 50,000
        assertEquals(50_000_00L, s.operatingTotal(),
                "operating must add back depreciation and the accrual");

        // investing = -80,000 (the equipment purchase)
        assertEquals(-80_000_00L, s.investingTotal());

        // financing = +1,000,000 (the capital in)
        assertEquals(1_000_000_00L, s.financingTotal());

        // net movement = 50,000 - 80,000 + 1,000,000 = 970,000 — reconciles
        assertEquals(970_000_00L, s.netMovement());
        assertTrue(s.reconciles(),
                "the statement must reconcile to the cash accounts' movement");
    }

    @Test
    void sectionsCarryTheirOwnRows() {
        seedScenario();
        CashFlowService.CashFlowStatement s = cashFlow.statement(fy2026.id());

        assertTrue(s.operating().stream().anyMatch(r ->
                        r.caption().startsWith("Net income")),
                "operating starts from net income");
        assertTrue(s.operating().stream().anyMatch(r ->
                        r.caption().contains("depreciation")),
                "depreciation is an add-back row");
        assertTrue(s.investing().stream().anyMatch(r ->
                        r.caption().contains("Property, Plant and Equipment")),
                "the equipment purchase sits in investing");
        assertTrue(s.financing().stream().anyMatch(r ->
                        r.caption().contains("Ordinary Share Capital")),
                "the capital contribution sits in financing");
    }

    @Test
    void emptyPeriodProducesAValidZeroStatement() {
        CashFlowService.CashFlowStatement s = cashFlow.statement(fy2026.id());
        assertEquals(0, s.netIncome());
        assertEquals(0, s.netMovement());
        assertTrue(s.reconciles());
    }
}
