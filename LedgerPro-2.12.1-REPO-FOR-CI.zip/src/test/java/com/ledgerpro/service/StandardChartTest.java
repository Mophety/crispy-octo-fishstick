package com.ledgerpro.service;

import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Side;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-3 gate, part two: the standard chart template itself must be
 * internally sound before any client's chart is seeded from it.
 */
class StandardChartTest {

    private final List<StandardChart.Row> rows = StandardChart.rows();

    @Test
    void codesAreUniqueFourDigitStringsInAscendingOrder() {
        Set<String> seen = new HashSet<>();
        String previous = "";
        for (StandardChart.Row row : rows) {
            assertTrue(seen.add(row.code()), "duplicate code in template: " + row.code());
            assertTrue(row.code().matches("\\d{4}"),
                    "codes are four digits: " + row.code());
            assertTrue(row.code().compareTo(previous) > 0,
                    "template must be sorted by code: " + previous + " then " + row.code());
            previous = row.code();
            assertFalse(row.name().isBlank(), "blank name for " + row.code());
        }
    }

    @Test
    void thousandBlocksMatchTheTypes() {
        for (StandardChart.Row row : rows) {
            char first = row.code().charAt(0);
            switch (first) {
                case '1' -> assertEquals(AccountType.ASSET, row.type(), row.code());
                case '2' -> assertEquals(AccountType.LIABILITY, row.type(), row.code());
                case '3' -> assertEquals(AccountType.EQUITY, row.type(), row.code());
                case '4' -> assertEquals(AccountType.REVENUE, row.type(), row.code());
                case '5', '6' -> assertEquals(AccountType.EXPENSE, row.type(), row.code());
                default -> throw new AssertionError("unexpected code block: " + row.code());
            }
        }
    }

    @Test
    void contraAccountsArePartOfTheStandard() {
        long contraCount = rows.stream()
                .filter(r -> r.side() != r.type().defaultSide())
                .count();
        assertTrue(contraCount >= 4,
                "a serious standard chart carries several contra accounts, found "
                        + contraCount);

        StandardChart.Row accumulated = findByCode("1510");
        assertEquals(AccountType.ASSET, accumulated.type());
        assertEquals(Side.CREDIT, accumulated.side());

        assertEquals(Side.DEBIT, findByCode("3300").side(), "Treasury Shares");
        assertEquals(Side.DEBIT, findByCode("4020").side(), "Sales Returns");
        assertEquals(Side.CREDIT, findByCode("1110").side(), "Allowance for Doubtful Accounts");
    }

    @Test
    void everyTypeAndSideIsValid() {
        for (StandardChart.Row row : rows) {
            // enums cannot be null here, but the invariant is worth pinning:
            // every row must sit on the allowed side of its type's default
            assertTrue(row.type() == AccountType.ASSET
                    || row.type() == AccountType.LIABILITY
                    || row.type() == AccountType.EQUITY
                    || row.type() == AccountType.REVENUE
                    || row.type() == AccountType.EXPENSE);
            assertTrue(row.side() == Side.DEBIT || row.side() == Side.CREDIT);
        }
    }

    @Test
    void templateIsAFullCorporateChart() {
        assertEquals(StandardChart.size(), rows.size());
        assertTrue(StandardChart.size() >= 40,
                "the template should be a usable corporate chart, has "
                        + StandardChart.size());
        assertTrue(rows.stream().anyMatch(r -> r.code().equals("1010")));
        assertTrue(rows.stream().anyMatch(r -> r.code().equals("2000")));
        assertTrue(rows.stream().anyMatch(r -> r.code().equals("3000")));
        assertTrue(rows.stream().anyMatch(r -> r.code().equals("4000")));
        assertTrue(rows.stream().anyMatch(r -> r.code().equals("5000")));
    }

    private StandardChart.Row findByCode(String code) {
        return rows.stream()
                .filter(r -> r.code().equals(code))
                .findFirst()
                .orElseThrow(() -> new AssertionError("missing template row " + code));
    }
}
