package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.FxRate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-3 gate, part three: the FX cache — fetch (through an injectable,
 * offline fetcher), manual override, lookup precedence including the inverse
 * fallback, and the audit rows with a NULL client.
 */
class FxRateServiceTest {

    private static final LocalDate OCT_20 = LocalDate.of(2026, 10, 20);
    private static final LocalDate OCT_28 = LocalDate.of(2026, 10, 28);
    private static final LocalDate OCT_31 = LocalDate.of(2026, 10, 31);   // a Saturday

    @TempDir
    Path tmp;

    private Database database;
    private FakeFetcher fetcher;
    private FxRateService service;

    /** Deterministic stand-in for the Frankfurter HTTP client. */
    private static final class FakeFetcher implements RateFetcher {
        final Map<String, Result> quotes = new HashMap<>();
        String failWith;   // non-null → every call throws IOException(failWith)

        @Override
        public Result fetch(LocalDate date, String from, String to) throws Exception {
            if (failWith != null) {
                throw new IOException(failWith);
            }
            Result result = quotes.get(key(date, from, to));
            if (result == null) {
                throw new IOException("no canned quote for " + key(date, from, to));
            }
            return result;
        }

        void quote(LocalDate date, String from, String to, double rate) {
            quotes.put(key(date, from, to), new Result(date, rate));
        }

        /** A weekend-style clamp: asked for {@code ask}, answered for {@code effective}. */
        void quoteClamped(LocalDate ask, LocalDate effective, String from, String to, double rate) {
            quotes.put(key(ask, from, to), new Result(effective, rate));
        }

        private static String key(LocalDate date, String from, String to) {
            return (date == null ? "latest" : date.toString()) + "|" + from + "|" + to;
        }
    }

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("fx.db").toString());
        database.migrate();
        fetcher = new FakeFetcher();
        service = new FxRateService(database, fetcher);
    }

    // ------------------------------------------------------------------
    // Fetch + store
    // ------------------------------------------------------------------

    @Test
    void fetchAndStoreCachesTheQuoteAndReturnsIt() {
        fetcher.quote(OCT_28, "USD", "PHP", 56.732);

        FxRate stored = service.fetchAndStore(OCT_28, "usd", "php");

        assertEquals("USD", stored.fromCur(), "currencies are normalized to upper case");
        assertEquals("PHP", stored.toCur());
        assertEquals(OCT_28, stored.asOf());
        assertEquals(56.732, stored.rate(), 1e-9);
        assertEquals(FxRate.Source.FRANKFURTER, stored.source());
        assertTrue(stored.fetchedAt() != null && !stored.fetchedAt().isBlank());

        Optional<FxRate> cached = service.findCached(OCT_28, "USD", "PHP");
        assertTrue(cached.isPresent());
        assertEquals(stored, cached.get());
    }

    @Test
    void fetchStoresUnderTheProvidersEffectiveDate() {
        // Saturday request → the ECB set answers with Friday's rate
        fetcher.quoteClamped(OCT_31, LocalDate.of(2026, 10, 30), "USD", "PHP", 56.70);

        FxRate stored = service.fetchAndStore(OCT_31, "USD", "PHP");

        assertEquals(LocalDate.of(2026, 10, 30), stored.asOf(),
                "the cache must be truthful about which trading day the rate is");
        assertTrue(service.findCached(OCT_31, "USD", "PHP").isEmpty());
        assertTrue(service.findCached(LocalDate.of(2026, 10, 30), "USD", "PHP").isPresent());
    }

    @Test
    void fetchFailureBecomesFriendlyExceptionAndStoresNothing() {
        fetcher.failWith = "network unreachable";

        FxUnavailableException e = assertThrows(FxUnavailableException.class,
                () -> service.fetchAndStore(OCT_28, "USD", "PHP"));
        assertTrue(e.getMessage().contains("USD") && e.getMessage().contains("PHP"));
        assertEquals("network unreachable", e.getCause().getMessage());

        assertTrue(service.listRecent(100).isEmpty(), "nothing half-stored on failure");
    }

    @Test
    void nonPositiveQuoteFromProviderIsRejected() {
        fetcher.quote(OCT_28, "USD", "PHP", -1.0);
        assertThrows(FxUnavailableException.class,
                () -> service.fetchAndStore(OCT_28, "USD", "PHP"));
    }

    // ------------------------------------------------------------------
    // Manual rates
    // ------------------------------------------------------------------

    @Test
    void manualRateOverridesTheApiRateForTheSameDateAndPair() {
        fetcher.quote(OCT_28, "USD", "PHP", 56.732);
        service.fetchAndStore(OCT_28, "USD", "PHP");

        FxRate manual = service.putManual(OCT_28, "USD", "PHP", 57.05);

        assertEquals(FxRate.Source.MANUAL, manual.source());
        assertEquals(57.05, manual.rate(), 1e-9);
        assertEquals(FxRate.Source.MANUAL,
                service.findCached(OCT_28, "USD", "PHP").orElseThrow().source());

        // and a later API re-fetch takes the pair back
        FxRate refetched = service.fetchAndStore(OCT_28, "USD", "PHP");
        assertEquals(FxRate.Source.FRANKFURTER, refetched.source());
        assertEquals(56.732, refetched.rate(), 1e-9);
    }

    @Test
    void manualRateValidatesInput() {
        assertThrows(IllegalArgumentException.class,
                () -> service.putManual(null, "USD", "PHP", 56.0));
        assertThrows(IllegalArgumentException.class,
                () -> service.putManual(OCT_28, "USD", "PHP", 0));
        assertThrows(IllegalArgumentException.class,
                () -> service.putManual(OCT_28, "USD", "PHP", -1));
        assertThrows(IllegalArgumentException.class,
                () -> service.putManual(OCT_28, "US", "PHP", 56.0));
        assertThrows(IllegalArgumentException.class,
                () -> service.putManual(OCT_28, "usd", "usd", 1.0),
                "a rate from a currency to itself is meaningless");
    }

    // ------------------------------------------------------------------
    // Lookup precedence
    // ------------------------------------------------------------------

    @Test
    void latestUpToUsesTheNewestRowOnOrBeforeTheDate() {
        fetcher.quote(OCT_20, "USD", "PHP", 56.10);
        fetcher.quote(OCT_28, "USD", "PHP", 56.732);
        service.fetchAndStore(OCT_20, "USD", "PHP");
        service.fetchAndStore(OCT_28, "USD", "PHP");

        assertEquals(56.10, service.latestUpTo(
                LocalDate.of(2026, 10, 25), "USD", "PHP").orElseThrow().rate(), 1e-9);
        assertEquals(56.732, service.latestUpTo(OCT_28, "USD", "PHP").orElseThrow().rate(), 1e-9);
        assertEquals(56.732, service.latestUpTo(OCT_31, "USD", "PHP").orElseThrow().rate(), 1e-9,
                "a rate stays valid until replaced");
        assertTrue(service.latestUpTo(LocalDate.of(2026, 10, 19), "USD", "PHP").isEmpty(),
                "nothing cached on or before that date");
    }

    @Test
    void latestUpToFallsBackToTheInversePair() {
        fetcher.quote(OCT_28, "USD", "PHP", 56.732);
        service.fetchAndStore(OCT_28, "USD", "PHP");

        Optional<FxRate> inverse = service.latestUpTo(OCT_31, "PHP", "USD");
        assertTrue(inverse.isPresent(), "the inverse direction must be derivable");
        assertEquals("PHP", inverse.orElseThrow().fromCur());
        assertEquals("USD", inverse.orElseThrow().toCur());
        assertEquals(1 / 56.732, inverse.orElseThrow().rate(), 1e-9);
    }

    @Test
    void aDirectlyCachedDirectionBeatsTheInverseOne() {
        // PHP→USD exists but is older than the USD→PHP row
        fetcher.quote(OCT_20, "PHP", "USD", 0.0175);
        fetcher.quote(OCT_28, "USD", "PHP", 56.732);
        service.fetchAndStore(OCT_20, "PHP", "USD");
        service.fetchAndStore(OCT_28, "USD", "PHP");

        FxRate chosen = service.latestUpTo(OCT_31, "PHP", "USD").orElseThrow();
        assertEquals(OCT_20, chosen.asOf(),
                "the direct row wins even though the inverse row is newer — a"
                        + " predictable, documented rule");
        assertEquals(0.0175, chosen.rate(), 1e-9);
    }

    // ------------------------------------------------------------------
    // Listing + audit
    // ------------------------------------------------------------------

    @Test
    void listRecentIsNewestFirst() {
        fetcher.quote(OCT_20, "USD", "PHP", 56.10);
        fetcher.quote(OCT_28, "EUR", "PHP", 62.4);
        fetcher.quote(OCT_28, "USD", "PHP", 56.732);
        service.fetchAndStore(OCT_20, "USD", "PHP");
        service.fetchAndStore(OCT_28, "EUR", "PHP");
        service.fetchAndStore(OCT_28, "USD", "PHP");

        List<FxRate> recent = service.listRecent(10);
        assertEquals(3, recent.size());
        assertEquals(OCT_28, recent.getFirst().asOf());
        assertEquals(OCT_28, recent.get(1).asOf());
        assertEquals(OCT_20, recent.get(2).asOf());
        // same date → alphabetical by pair: EUR→PHP before USD→PHP
        assertEquals("EUR", recent.getFirst().fromCur());
        assertEquals("USD", recent.get(1).fromCur());
    }

    @Test
    void storedRatesAuditWithANullClient() throws SQLException {
        fetcher.quote(OCT_28, "USD", "PHP", 56.732);
        service.fetchAndStore(OCT_28, "USD", "PHP");
        service.putManual(OCT_28, "EUR", "PHP", 62.4);

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT action, client_id, detail FROM audit_log ORDER BY id")) {
            assertTrue(rs.next());
            assertEquals("FX_RATE_STORED", rs.getString("action"));
            assertEquals(0, rs.getLong("client_id"));
            assertTrue(rs.wasNull(), "FX audit rows belong to the firm, not a client");
            assertTrue(rs.getString("detail").contains("USD"));

            assertTrue(rs.next());
            assertEquals("FX_RATE_STORED", rs.getString("action"));
            assertTrue(rs.getString("detail").contains("MANUAL"));

            assertFalse(rs.next());
        }
    }
}
