package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 2.10.0 gates: the batched line loader must return EXACTLY what the
 * per-entry loader returns (same rows, same order, same grouping), and the
 * V6 migration must leave the journal_lines entry index in place on both a
 * fresh database and one opened from the 2.9.0 shape (V1–V5 only).
 */
class JournalBatchLinesTest {

    @TempDir
    Path tmp;

    private Database database;
    private JournalService journal;
    private FxRateService fx;
    private AccountService accounts;
    private PeriodService periods;
    private ClientService clients;

    private long clientId;
    private Period fy;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("batch.db").toString());
        database.migrate();
        clients = new ClientService(database);
        accounts = new AccountService(database);
        periods = new PeriodService(database);
        fx = new FxRateService(database);
        journal = new JournalService(database, fx);

        clientId = clients.create("NRTH", "Norte Freight Systems, Inc.", "PHP").id();
        accounts.applyStandardChart(clientId);
        fy = periods.create(clientId, "FY2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));

        // a busy year: six posted entries + one draft, varied line counts
        post("initial capital", "1010", 1_000_000_00L, "3000");
        post("cash sales", "1010", 420_000_00L, "4010");
        post("credit sale", "1100", 180_000_00L, "4010");
        post("rent paid", "6100", 96_000_00L, "1010");
        post("salaries", "6000", 132_000_00L, "1010");
        post("utilities", "6110", 3_500_00L, "1010");
        journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 11, 2), EntryType.NORMAL,
                null, "power bill, draft", null, null, List.of(
                line("6110", 800_00L, null),
                line("1010", null, 800_00L))));
    }

    // ------------------------------------------------------------------
    // The batch gate
    // ------------------------------------------------------------------

    @Test
    void batchLinesMatchPerEntryLines() {
        Map<Long, List<JournalService.LineRow>> batched =
                journal.linesForEntries(clientId);

        // every entry the per-entry loader knows must appear in the batch
        // with the same rows in the same order; a client with no lines for
        // some entry shows no key (same as lines() → empty list)
        for (JournalService.EntrySummary summary : journal.list(clientId, null)) {
            long id = summary.entry().id();
            List<JournalService.LineRow> perEntry = journal.lines(id);
            List<JournalService.LineRow> fromBatch = batched.get(id);
            if (perEntry.isEmpty()) {
                assertTrue(fromBatch == null || fromBatch.isEmpty(),
                        "entry " + id + " has no lines; batch must agree");
                continue;
            }
            assertEquals(perEntry.size(), fromBatch.size(), "entry " + id);
            for (int i = 0; i < perEntry.size(); i++) {
                JournalService.LineRow a = perEntry.get(i);
                JournalService.LineRow b = fromBatch.get(i);
                assertEquals(a.line().id(), b.line().id(), "entry " + id + " line " + i);
                assertEquals(a.line().lineNo(), b.line().lineNo());
                assertEquals(a.line().debitCents(), b.line().debitCents());
                assertEquals(a.line().creditCents(), b.line().creditCents());
                assertEquals(a.account().id(), b.account().id());
                assertEquals(a.account().code(), b.account().code());
            }
        }
    }

    @Test
    void batchGroupsOnlyThisClient() {
        // a second client with its own entry must not leak into the batch
        long other = clients.create("OTHER", "Other Trading Co.", "PHP").id();
        accounts.applyStandardChart(other);
        Period otherFy = periods.create(other, "FY2026",
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31));
        journal.post(journal.createDraft(new JournalService.NewEntry(
                other, otherFy.id(), LocalDate.of(2026, 2, 1), EntryType.NORMAL,
                null, "their entry", null, null, List.of(
                new JournalService.NewLine(acct(other, "1010"), 500_00L, null, null),
                new JournalService.NewLine(acct(other, "3000"), null, 500_00L, null)))).id());

        Map<Long, List<JournalService.LineRow>> mine =
                journal.linesForEntries(clientId);
        for (Long entryId : mine.keySet()) {
            for (JournalService.EntrySummary summary : journal.list(clientId, null)) {
                // every grouped id belongs to MY entries
                boolean mineFlag = summary.entry().id() == entryId;
                assertTrue(mineFlag || journal.lines(entryId).isEmpty()
                                || belongsToClient(entryId, clientId),
                        "foreign entry " + entryId + " leaked into the batch");
            }
        }
        // and the other client's batch holds their entry
        assertTrue(journal.linesForEntries(other).size() >= 1);
        assertFalse(journal.linesForEntries(other).keySet().stream()
                .anyMatch(id -> journal.list(clientId, null).stream()
                        .anyMatch(s -> s.entry().id() == id)));
    }

    private boolean belongsToClient(long entryId, long clientId) {
        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT client_id FROM journal_entries WHERE id = " + entryId)) {
            return rs.next() && rs.getLong(1) == clientId;
        } catch (SQLException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------
    // The V6 migration gate
    // ------------------------------------------------------------------

    @Test
    void v6IndexPresentOnFreshDatabase() throws SQLException {
        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT name FROM sqlite_master WHERE type = 'index'"
                             + " AND name = 'idx_journal_lines_entry'")) {
            assertTrue(rs.next(), "idx_journal_lines_entry must exist after migrate");
        }
    }

    // ------------------------------------------------------------------
    // Helpers (same shape as JournalServiceTest's)
    // ------------------------------------------------------------------

    private long acct(long forClient, String code) {
        return accounts.list(forClient, false).stream()
                .filter(a -> a.code().equals(code))
                .findFirst().orElseThrow().id();
    }

    private JournalService.NewLine line(String code, Long dr, Long cr) {
        return new JournalService.NewLine(acct(clientId, code), dr, cr, null);
    }

    private void post(String memo, String drAccount, long drCents, String crAccount) {
        journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, fy.id(), LocalDate.of(2026, 3, 5), EntryType.NORMAL,
                null, memo, null, null, List.of(
                new JournalService.NewLine(acct(clientId, drAccount), drCents, null, null),
                new JournalService.NewLine(acct(clientId, crAccount), null, drCents, null)))).id());
    }
}
