package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Client;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 2.12.0 backup/restore round-trip (Phase 4 verification).
 *
 * <ul>
 *   <li>backupTo writes a consistent, openable snapshot that carries the
 *       live data;</li>
 *   <li>restoreFrom replaces a database's contents with the backup's
 *       (verified by reading the client back through the services);</li>
 *   <li>backupNow lands in ~/.ledgerpro/backups with the stamped name —
 *       verified via the path it returns, without touching the real home
 *       (the target folder is redirected through an explicit backupTo
 *       temp path in the same test).</li>
 * </ul>
 */
class BackupServiceTest {

    @TempDir
    Path temp;

    @Test
    void backupCarriesTheLiveBooks() {
        Database live = new Database(temp.resolve("live.db").toString());
        live.migrate();
        ClientService clients = new ClientService(live);
        clients.create("BKUP", "Backup Test Co", "PHP");

        BackupService backup = new BackupService(live);
        Path target = backup.backupTo(temp.resolve("snapshots").resolve("one.db"));

        assertTrue(Files.isRegularFile(target), "snapshot file exists");
        // the snapshot opens as its own database and holds the client
        Database copy = new Database(target.toString());
        copy.migrate();
        Optional<Client> read = new ClientService(copy).findByCode("BKUP");
        assertTrue(read.isPresent(), "the backup carries the live client");
        assertEquals("Backup Test Co", read.get().name());
    }

    @Test
    void restoreReplacesTheBooks() {
        // the "old" database: one client
        Database source = new Database(temp.resolve("old.db").toString());
        source.migrate();
        new ClientService(source).create("OLD1", "Old Books", "USD");
        Path backupFile = new BackupService(source)
                .backupTo(temp.resolve("old-backup.db"));

        // the live database: a DIFFERENT client
        Database live = new Database(temp.resolve("live2.db").toString());
        live.migrate();
        new ClientService(live).create("NEW1", "New Books", "EUR");
        assertTrue(new ClientService(live).findByCode("NEW1").isPresent());

        // restore: the live file now holds the old books
        new BackupService(live).restoreFrom(backupFile);
        ClientService after = new ClientService(live);
        assertTrue(after.findByCode("OLD1").isPresent(),
                "the restored client is there");
        assertTrue(after.findByCode("NEW1").isEmpty(),
                "the pre-restore client is gone");
    }

    @Test
    void filePathExposesTheDatabaseLocation() {
        Database db = new Database(temp.resolve("where.db").toString());
        String path = db.filePath();
        assertNotNull(path);
        assertTrue(path.endsWith("where.db"), "the file name is exposed: " + path);
        assertTrue(Path.of(path).isAbsolute(), "the path is absolute");
    }
}
