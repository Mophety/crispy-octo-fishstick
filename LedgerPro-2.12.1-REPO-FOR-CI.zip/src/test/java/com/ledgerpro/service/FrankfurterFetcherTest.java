package com.ledgerpro.service;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-3 gate, part four: the Frankfurter response parser, exercised with
 * canned JSON — no network in the test suite. (Live reachability is checked
 * by the dev tooling, not by the build.)
 */
class FrankfurterFetcherTest {

    @Test
    void parsesAHappyHistoricalResponse() throws IOException {
        RateFetcher.Result result = FrankfurterFetcher.parse(
                "{\"amount\":1.0,\"base\":\"USD\",\"date\":\"2026-10-30\","
                        + "\"rates\":{\"PHP\":56.732}}",
                "PHP");

        assertEquals(LocalDate.of(2026, 10, 30), result.date());
        assertEquals(56.732, result.rate(), 1e-9);
    }

    @Test
    void parsesALatestResponse() throws IOException {
        RateFetcher.Result result = FrankfurterFetcher.parse(
                "{\"amount\":1.0,\"base\":\"EUR\",\"date\":\"2026-10-29\","
                        + "\"rates\":{\"PHP\":63.1017,\"USD\":1.0865}}",
                "PHP");

        assertEquals(63.1017, result.rate(), 1e-9);
    }

    @Test
    void rejectsAResponseWithoutTheWantedCurrency() {
        IOException e = assertThrows(IOException.class, () -> FrankfurterFetcher.parse(
                "{\"amount\":1.0,\"base\":\"USD\",\"date\":\"2026-10-30\","
                        + "\"rates\":{\"EUR\":0.9215}}",
                "PHP"));
        assertTrue(e.getMessage().contains("PHP"),
                "the message names the missing currency: " + e.getMessage());
    }

    @Test
    void carriesTheProvidersOwnMessageThrough() {
        IOException e = assertThrows(IOException.class, () -> FrankfurterFetcher.parse(
                "{\"message\":\"no rate data for currency 'XYZ'\"}",
                "XYZ"));
        assertTrue(e.getMessage().contains("no rate data"),
                "the provider's reason reaches the user: " + e.getMessage());
    }

    @Test
    void rejectsNonJsonBodies() {
        assertThrows(IOException.class, () ->
                FrankfurterFetcher.parse("<html>Bad Gateway</html>", "PHP"));
        assertThrows(IOException.class, () -> FrankfurterFetcher.parse("", "PHP"));
    }
}
