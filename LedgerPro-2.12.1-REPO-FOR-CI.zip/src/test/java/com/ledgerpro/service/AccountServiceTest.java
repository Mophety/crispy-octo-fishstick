package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.Side;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-3 gate, part one: every chart-of-accounts rule the UI relies on must
 * hold in code before it is trusted in the UI. Each test uses its own
 * throwaway database file.
 */
class AccountServiceTest {

    @TempDir
    Path tmp;

    private Database database;
    private AccountService service;
    private ClientService clientService;
    private long clientId;
    private long otherClientId;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("accounts.db").toString());
        database.migrate();
        clientService = new ClientService(database);
        service = new AccountService(database);
        clientId = clientService.create("NRTH", "Norte Freight Systems, Inc.", "PHP").id();
        otherClientId = clientService.create("SLRA", "Solera Resorts & Hotels, Inc.", "PHP").id();
    }

    // ------------------------------------------------------------------
    // Creation
    // ------------------------------------------------------------------

    @Test
    void createPersistsAllFieldsAndNormalizes() {
        Account created = service.create(clientId, " 1010 ",
                "  Cash in Bank — Operating  ", AccountType.ASSET, Side.DEBIT);

        assertEquals("1010", created.code(), "codes are trimmed and upper-cased");
        assertEquals("Cash in Bank — Operating", created.name());
        assertTrue(created.active(), "new accounts start active");
        assertEquals(clientId, created.clientId());

        Optional<Account> readBack = service.findByCode(clientId, "1010");
        assertTrue(readBack.isPresent());
        assertEquals(created, readBack.get());
    }

    @Test
    void createSupportsContraAccountsByExplicitNormalSide() {
        Account accumulatedDepreciation = service.create(clientId, "1510",
                "Accumulated Depreciation — PP&E", AccountType.ASSET, Side.CREDIT);
        Account treasuryShares = service.create(clientId, "3300",
                "Treasury Shares", AccountType.EQUITY, Side.DEBIT);
        Account salesReturns = service.create(clientId, "4020",
                "Sales Returns and Allowances", AccountType.REVENUE, Side.DEBIT);
        Account cash = service.create(clientId, "1010",
                "Cash in Bank", AccountType.ASSET, Side.DEBIT);

        assertTrue(accumulatedDepreciation.contra(),
                "an ASSET increased by credits is a contra account");
        assertTrue(treasuryShares.contra());
        assertTrue(salesReturns.contra());
        assertFalse(cash.contra());
    }

    @Test
    void createRejectsDuplicateCodeWithinTheSameChart() {
        service.create(clientId, "1010", "Cash in Bank", AccountType.ASSET, Side.DEBIT);

        DuplicateAccountCodeException e = assertThrows(DuplicateAccountCodeException.class,
                () -> service.create(clientId, "1010", "A different account",
                        AccountType.LIABILITY, Side.CREDIT));
        assertEquals("1010", e.code());
    }

    @Test
    void sameCodeIsAllowedAcrossDifferentClients() {
        service.create(clientId, "1010", "Cash in Bank", AccountType.ASSET, Side.DEBIT);

        Account other = service.create(otherClientId, "1010", "Cash in Bank",
                AccountType.ASSET, Side.DEBIT);
        assertEquals(otherClientId, other.clientId());
        assertEquals(1, service.list(clientId, true).size());
        assertEquals(1, service.list(otherClientId, true).size());
    }

    @Test
    void createValidatesShape() {
        assertThrows(IllegalArgumentException.class, () ->
                service.create(clientId, "   ", "Name", AccountType.ASSET, Side.DEBIT));
        assertThrows(IllegalArgumentException.class, () ->
                service.create(clientId, "10 10", "Name", AccountType.ASSET, Side.DEBIT));
        assertThrows(IllegalArgumentException.class, () ->
                service.create(clientId, "10.10", "Name", AccountType.ASSET, Side.DEBIT));
        assertThrows(IllegalArgumentException.class, () ->
                service.create(clientId, "1234567890123", "Name", AccountType.ASSET, Side.DEBIT));
        assertThrows(IllegalArgumentException.class, () ->
                service.create(clientId, "1010", "   ", AccountType.ASSET, Side.DEBIT));
        assertThrows(IllegalArgumentException.class, () ->
                service.create(clientId, "1010", "Name", null, Side.DEBIT));
        assertThrows(IllegalArgumentException.class, () ->
                service.create(clientId, "1010", "Name", AccountType.ASSET, null));
    }

    @Test
    void createOnUnknownClientThrows() {
        assertThrows(NoSuchElementException.class, () ->
                service.create(999, "1010", "Cash", AccountType.ASSET, Side.DEBIT));
    }

    // ------------------------------------------------------------------
    // Listing
    // ------------------------------------------------------------------

    @Test
    void listOrdersByCodeAndHidesInactiveByDefault() {
        service.create(clientId, "1110", "Allowance for Doubtful Accounts",
                AccountType.ASSET, Side.CREDIT);
        service.create(clientId, "1010", "Cash in Bank", AccountType.ASSET, Side.DEBIT);
        service.create(clientId, "1100", "Accounts Receivable", AccountType.ASSET, Side.DEBIT);

        List<Account> all = service.list(clientId, true);
        assertEquals(List.of("1010", "1100", "1110"),
                all.stream().map(Account::code).toList(),
                "ordering must follow the code, not insertion");

        Account receivable = service.findByCode(clientId, "1100").orElseThrow();
        service.setActive(receivable.id(), false);
        assertEquals(List.of("1010", "1110"),
                service.list(clientId, false).stream().map(Account::code).toList(),
                "inactive accounts drop out of the default list");
        assertEquals(3, service.list(clientId, true).size(),
                "but stay reachable with includeInactive");
    }

    @Test
    void listIsScopedToTheClient() {
        service.create(clientId, "1010", "Cash in Bank", AccountType.ASSET, Side.DEBIT);
        service.create(otherClientId, "2000", "Accounts Payable",
                AccountType.LIABILITY, Side.CREDIT);

        assertEquals(List.of("1010"),
                service.list(clientId, true).stream().map(Account::code).toList());
    }

    // ------------------------------------------------------------------
    // Update: rename always, structure only while unposted
    // ------------------------------------------------------------------

    @Test
    void renameIsAlwaysAllowedEvenOncePosted() throws SQLException {
        Account cash = service.create(clientId, "1010", "Cash in Bank",
                AccountType.ASSET, Side.DEBIT);
        postOneLine(cash.id());

        Account renamed = service.update(cash.id(), "1010", "Cash in Bank — BDO",
                AccountType.ASSET, Side.DEBIT);
        assertEquals("Cash in Bank — BDO", renamed.name());
        assertEquals("1010", renamed.code(), "code untouched by a pure rename");
    }

    @Test
    void structuralChangesAreAllowedWhileNothingIsPosted() {
        Account account = service.create(clientId, "1999", "Temporary",
                AccountType.ASSET, Side.DEBIT);

        Account changed = service.update(account.id(), "1998", "Temporary",
                AccountType.EXPENSE, Side.DEBIT);
        assertEquals("1998", changed.code());
        assertEquals(AccountType.EXPENSE, changed.type());
        assertEquals(Side.DEBIT, changed.normalSide());
    }

    @Test
    void structuralChangesAreRefusedOnceJournalLinesExist() throws SQLException {
        Account cash = service.create(clientId, "1010", "Cash in Bank",
                AccountType.ASSET, Side.DEBIT);
        postOneLine(cash.id());

        assertThrows(AccountFrozenException.class, () ->
                service.update(cash.id(), "1011", "Cash in Bank",
                        AccountType.ASSET, Side.DEBIT));
        assertThrows(AccountFrozenException.class, () ->
                service.update(cash.id(), "1010", "Cash in Bank",
                        AccountType.EXPENSE, Side.DEBIT));
        assertThrows(AccountFrozenException.class, () ->
                service.update(cash.id(), "1010", "Cash in Bank",
                        AccountType.ASSET, Side.CREDIT));

        Account unchanged = service.findByCode(clientId, "1010").orElseThrow();
        assertEquals(AccountType.ASSET, unchanged.type(),
                "a rejected update must leave the account untouched");
        assertEquals(Side.DEBIT, unchanged.normalSide());
    }

    @Test
    void updateRejectsDuplicateCode() {
        service.create(clientId, "1010", "Cash in Bank", AccountType.ASSET, Side.DEBIT);
        Account other = service.create(clientId, "1020", "Petty Cash",
                AccountType.ASSET, Side.DEBIT);

        assertThrows(DuplicateAccountCodeException.class, () ->
                service.update(other.id(), "1010", "Petty Cash",
                        AccountType.ASSET, Side.DEBIT));
    }

    @Test
    void updateOnUnknownIdThrows() {
        assertThrows(NoSuchElementException.class, () ->
                service.update(999, "1010", "Name", AccountType.ASSET, Side.DEBIT));
    }

    // ------------------------------------------------------------------
    // Deactivate / restore
    // ------------------------------------------------------------------

    @Test
    void deactivateThenRestoreRoundTrips() {
        Account created = service.create(clientId, "1010", "Cash in Bank",
                AccountType.ASSET, Side.DEBIT);

        service.setActive(created.id(), false);
        assertFalse(service.findByCode(clientId, "1010").orElseThrow().active());

        service.setActive(created.id(), true);
        assertTrue(service.findByCode(clientId, "1010").orElseThrow().active());
    }

    @Test
    void setActiveOnUnknownIdThrows() {
        assertThrows(NoSuchElementException.class, () -> service.setActive(999, false));
    }

    // ------------------------------------------------------------------
    // Standard chart
    // ------------------------------------------------------------------

    @Test
    void applyStandardChartFillsAnEmptyChart() {
        int inserted = service.applyStandardChart(clientId);

        assertEquals(StandardChart.size(), inserted);
        List<Account> chart = service.list(clientId, true);
        assertEquals(StandardChart.size(), chart.size());

        Account accumulated = service.findByCode(clientId, "1510").orElseThrow();
        assertEquals(AccountType.ASSET, accumulated.type());
        assertEquals(Side.CREDIT, accumulated.normalSide());
        assertTrue(accumulated.contra(), "the standard chart includes contra accounts");
    }

    @Test
    void applyStandardChartIsIdempotent() {
        service.applyStandardChart(clientId);

        assertEquals(0, service.applyStandardChart(clientId),
                "the second run must find nothing missing");
        assertEquals(StandardChart.size(), service.list(clientId, true).size());
    }

    @Test
    void applyStandardChartKeepsExistingAccountsUntouched() {
        service.create(clientId, "1010", "BDO Operating Account",
                AccountType.ASSET, Side.DEBIT);

        int inserted = service.applyStandardChart(clientId);

        assertEquals(StandardChart.size() - 1, inserted,
                "one code already existed, so one row less is inserted");
        assertEquals("BDO Operating Account",
                service.findByCode(clientId, "1010").orElseThrow().name(),
                "the existing account is never overwritten");
    }

    @Test
    void applyStandardChartOnUnknownClientThrows() {
        assertThrows(NoSuchElementException.class, () -> service.applyStandardChart(999));
    }

    // ------------------------------------------------------------------
    // Audit trail
    // ------------------------------------------------------------------

    @Test
    void everyMutationWritesItsAuditRow() throws SQLException {
        Account cash = service.create(clientId, "1010", "Cash in Bank",
                AccountType.ASSET, Side.DEBIT);
        service.update(cash.id(), "1010", "Cash in Bank — BDO",
                AccountType.ASSET, Side.DEBIT);
        service.setActive(cash.id(), false);
        service.setActive(cash.id(), true);
        service.applyStandardChart(otherClientId);

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT action, client_id FROM audit_log ORDER BY id")) {
            List<String> actions = new java.util.ArrayList<>();
            List<Long> accountRowClients = new java.util.ArrayList<>();
            while (rs.next()) {
                String action = rs.getString("action");
                actions.add(action);
                if (action.equals("CREATE_ACCOUNT") || action.equals("UPDATE_ACCOUNT")
                        || action.equals("DEACTIVATE_ACCOUNT")
                        || action.equals("RESTORE_ACCOUNT")
                        || action.equals("APPLY_COA_TEMPLATE")) {
                    accountRowClients.add(rs.getLong("client_id"));
                }
            }

            assertEquals(List.of("CREATE_CLIENT", "CREATE_CLIENT", "CREATE_ACCOUNT",
                            "UPDATE_ACCOUNT", "DEACTIVATE_ACCOUNT", "RESTORE_ACCOUNT",
                            "APPLY_COA_TEMPLATE"),
                    actions, "one audit row per mutation, in order");

            for (long rowClient : accountRowClients.subList(0, 4)) {
                assertEquals(clientId, rowClient, "account mutations audit with their client");
            }
            assertEquals(otherClientId, accountRowClients.getLast(),
                    "the template application audits with its own client");
        }
    }

    // ------------------------------------------------------------------
    // Fixture: post one journal line against an account (Phase 4 will do
    // this through its own service; the guard must already hold now)
    // ------------------------------------------------------------------

    private void postOneLine(long accountId) throws SQLException {
        try (Connection con = database.open()) {
            long periodId;
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO periods(client_id, name, start_date, end_date)"
                            + " VALUES (?, 'FY2026', '2026-01-01', '2026-12-31')",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setLong(1, clientId);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    keys.next();
                    periodId = keys.getLong(1);
                }
            }
            long entryId;
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO journal_entries(client_id, period_id, entry_no,"
                            + " entry_date, type, memo) VALUES (?, ?, 1, '2026-10-28',"
                            + " 'NORMAL', 'fixture')",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setLong(1, clientId);
                ps.setLong(2, periodId);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    keys.next();
                    entryId = keys.getLong(1);
                }
            }
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO journal_lines(entry_id, account_id, debit_cents)"
                            + " VALUES (?, ?, 100000)")) {
                ps.setLong(1, entryId);
                ps.setLong(2, accountId);
                ps.executeUpdate();
            }
        }
    }
}
