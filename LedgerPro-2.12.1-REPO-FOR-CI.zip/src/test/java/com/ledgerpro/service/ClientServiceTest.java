package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Client;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-2 gate: every client rule the UI relies on must hold in code before
 * it is trusted in the UI. Each test uses its own throwaway database file.
 */
class ClientServiceTest {

    @TempDir
    Path tmp;

    private ClientService service;
    private Database database;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("clients.db").toString());
        database.migrate();
        service = new ClientService(database);
    }

    // ------------------------------------------------------------------
    // Creation
    // ------------------------------------------------------------------

    @Test
    void createPersistsAllFieldsAndDefaultsCurrencyToPhp() {
        Client created = service.create("  nrth ", "  Norte Freight Systems, Inc. ", null);

        assertEquals("NRTH", created.code(), "codes are trimmed and upper-cased");
        assertEquals("Norte Freight Systems, Inc.", created.name());
        assertEquals("PHP", created.baseCurrency(), "blank currency must fall back to PHP");
        assertTrue(created.active(), "new clients start active");
        assertTrue(created.createdAt() != null && !created.createdAt().isBlank());

        Optional<Client> readBack = service.findByCode("nrth");
        assertTrue(readBack.isPresent());
        assertEquals(created, readBack.get(), "findByCode must be case-insensitive");
    }

    @Test
    void createRejectsDuplicateCodeWithFriendlyException() {
        service.create("NRTH", "Norte Freight Systems, Inc.", "PHP");

        DuplicateClientCodeException e = assertThrows(DuplicateClientCodeException.class,
                () -> service.create("nrth", "A different company", "USD"));
        assertEquals("NRTH", e.code());
    }

    @Test
    void createValidatesCodeShapeAndName() {
        assertThrows(IllegalArgumentException.class, () -> service.create("   ", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> service.create("TOO LONG CODE HERE", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> service.create("BAD CODE!", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> service.create("OK", "   ", null));
        assertThrows(IllegalArgumentException.class, () -> service.create("OK", "Name", "DOLLARS"));
    }

    // ------------------------------------------------------------------
    // Listing
    // ------------------------------------------------------------------

    @Test
    void listOrdersByCodeAndHidesArchivedByDefault() {
        service.create("ZULU", "Zulu Corp.", null);
        service.create("ALFA", "Alfa Corp.", null);
        service.create("MIKE", "Mike Corp.", null);

        List<Client> all = service.list(false);
        assertEquals(List.of("ALFA", "MIKE", "ZULU"), all.stream().map(Client::code).toList(),
                "ordering must follow the code, not insertion");

        Client mike = service.findByCode("MIKE").orElseThrow();
        service.setActive(mike.id(), false);
        List<Client> activeOnly = service.list(false);
        assertEquals(List.of("ALFA", "ZULU"), activeOnly.stream().map(Client::code).toList());

        List<Client> includingArchived = service.list(true);
        assertEquals(3, includingArchived.size(), "archived clients must stay reachable");
        assertFalse(includingArchived.stream()
                .filter(c -> c.code().equals("MIKE"))
                .findFirst()
                .orElseThrow()
                .active());
    }

    // ------------------------------------------------------------------
    // Archive / restore
    // ------------------------------------------------------------------

    @Test
    void archiveThenRestoreRoundTrips() {
        Client created = service.create("NRTH", "Norte Freight Systems, Inc.", null);

        service.setActive(created.id(), false);
        assertFalse(service.findByCode("NRTH").orElseThrow().active());

        service.setActive(created.id(), true);
        assertTrue(service.findByCode("NRTH").orElseThrow().active());
    }

    @Test
    void setActiveOnUnknownIdThrows() {
        assertThrows(NoSuchElementException.class, () -> service.setActive(999, false));
    }

    // ------------------------------------------------------------------
    // Audit trail
    // ------------------------------------------------------------------

    @Test
    void everyMutationWritesItsAuditRow() throws SQLException {
        Client created = service.create("NRTH", "Norte Freight Systems, Inc.", "PHP");
        service.setActive(created.id(), false);
        service.setActive(created.id(), true);

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT action, client_id FROM audit_log ORDER BY id")) {
            String[] expected = {"CREATE_CLIENT", "ARCHIVE_CLIENT", "RESTORE_CLIENT"};
            for (String action : expected) {
                assertTrue(rs.next(), "audit row missing for " + action);
                assertEquals(action, rs.getString("action"));
                assertEquals(created.id(), rs.getLong("client_id"));
            }
            assertFalse(rs.next(), "no further audit rows expected");
        }
    }
}
