package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Period;
import com.ledgerpro.model.TbStage;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * The 2.7.0 closing workflow — the acceptance criteria from the improvement
 * plan's Sprint 2, tested end to end on a real database:
 *
 * <ul>
 *   <li>the generator produces a balanced CLOSING draft set that zeroes
 *       every temporary account;</li>
 *   <li>posting it leaves the post-closing trial balance with zero
 *       temporary balances (the stage the 2.6.0 code could never reach);</li>
 *   <li>the checklist blocks a close with unposted drafts, an unbalanced
 *       trial balance, or a pending closing set;</li>
 *   <li>reversing entries carry an accrual into the next period correctly.</li>
 * </ul>
 */
class ClosingServiceTest {

    private static final LocalDate JAN_01 = LocalDate.of(2026, 1, 1);
    private static final LocalDate DEC_31 = LocalDate.of(2026, 12, 31);

    @TempDir
    Path tmp;

    private Database database;
    private ClientService clients;
    private AccountService accounts;
    private PeriodService periods;
    private FxRateService fx;
    private JournalService journal;
    private ClosingService closing;

    private long clientId;
    private Period fy2026;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("closing.db").toString());
        database.migrate();
        clients = new ClientService(database);
        accounts = new AccountService(database);
        periods = new PeriodService(database);
        fx = new FxRateService(database);
        journal = new JournalService(database, fx);
        closing = new ClosingService(database, journal, accounts);

        clientId = clients.create("NRTH", "Norte Freight Systems, Inc.", "PHP").id();
        accounts.applyStandardChart(clientId);
        fy2026 = periods.create(clientId, "FY2026", JAN_01, DEC_31);
    }

    // (no @AfterEach: the shipped services never close the SQLite pool;
    // tests rely on @TempDir cleanup, exactly like JournalServiceTest)

    private long acct(String code) {
        return accounts.findByCode(clientId, code).orElseThrow().id();
    }

    private void post(JournalService.NewEntry entry) {
        journal.post(journal.createDraft(entry).id());
    }

    // ------------------------------------------------------------------
    // Scenario: a simple profitable year
    // ------------------------------------------------------------------

    /** Capital 1,000,000; revenue 120,000; expenses 70,000 → NI 50,000. */
    private void seedProfitableYear() {
        post(new JournalService.NewEntry(clientId, fy2026.id(), JAN_01, EntryType.NORMAL,
                null, "initial capital", null, null, List.of(
                new JournalService.NewLine(acct("1010"), 1_000_000_00L, null, "capital in"),
                new JournalService.NewLine(acct("3000"), null, 1_000_000_00L, "capital in"))));
        post(new JournalService.NewEntry(clientId, fy2026.id(), LocalDate.of(2026, 6, 1),
                EntryType.NORMAL, null, "sales", null, null, List.of(
                new JournalService.NewLine(acct("1010"), 120_000_00L, null, "cash sale"),
                new JournalService.NewLine(acct("4010"), null, 120_000_00L, "sales"))));
        post(new JournalService.NewEntry(clientId, fy2026.id(), LocalDate.of(2026, 7, 1),
                EntryType.NORMAL, null, "rent", null, null, List.of(
                new JournalService.NewLine(acct("6100"), 70_000_00L, null, "rent"),
                new JournalService.NewLine(acct("1010"), null, 70_000_00L, "rent paid"))));
    }

    @Test
    void generatedClosingSetZeroesTemporaryAccountsAndBalances() {
        seedProfitableYear();

        ClosingService.ClosingSet set = closing.generateAndPost(fy2026.id());

        // one entry per step: revenues, expenses, IS→RE (net income exists)
        assertFalse(set.empty());
        assertEquals(3, set.entries().size(), "revenue close, expense close, IS sweep");
        assertEquals(50_000_00L, set.netIncomeCents());

        // the post-closing TB holds only permanent accounts with balances
        JournalService.TrialBalance post = journal.trialBalance(fy2026.id(), TbStage.POST_CLOSING);
        assertTrue(post.balanced(), "post-closing TB must balance");

        for (JournalService.TrialBalanceRow row : post.rows()) {
            if (row.account().type().isPermanent()) {
                continue;
            }
            assertEquals(0, row.debitCents() - row.creditCents(),
                    "temporary account " + row.account().code() + " not zeroed");
        }

        // RE's closing movement: the sweep entry DEBITED RE (Dr RE /
        // Cr Income Summary), so the TB row reads the debit movement.
        long re = post.rows().stream()
                .filter(r -> r.account().isRetainedEarnings())
                .mapToLong(r -> r.debitCents() - r.creditCents())
                .sum();
        assertEquals(50_000_00L, re,
                "retained earnings close movement not equal to net income");
    }

    @Test
    void closingDraftsAreDraftsUntilPosted() {
        seedProfitableYear();

        ClosingService.ClosingSet set = closing.generateClosingDrafts(fy2026.id());

        for (JournalService.EntrySummary summary : set.entries()) {
            assertFalse(summary.entry().posted(), "generator must not post");
            assertEquals(EntryType.CLOSING, summary.entry().type());
        }

        // the unadjusted-stage TB still shows the temporary balances (closing
        // is draft only), while the post-closing stage sees nothing yet
        JournalService.TrialBalance pre = journal.trialBalance(fy2026.id(), TbStage.UNADJUSTED);
        assertTrue(pre.rows().stream().anyMatch(r -> r.account().code().equals("4010")));
        JournalService.TrialBalance post = journal.trialBalance(fy2026.id(), TbStage.POST_CLOSING);
        // unposted closing drafts change nothing: revenue still carries its
        // NORMAL credit balance in the post-closing view
        long sales4010 = post.rows().stream()
                .filter(r -> r.account().code().equals("4010"))
                .mapToLong(r -> r.creditCents() - r.debitCents())
                .sum();
        assertEquals(120_000_00L, sales4010,
                "unposted closing set must not change the post-closing view");
    }

    @Test
    void dividendsCloseToRetainedEarnings() {
        seedProfitableYear();
        // declare a 10,000 dividend
        post(new JournalService.NewEntry(clientId, fy2026.id(), LocalDate.of(2026, 11, 1),
                EntryType.NORMAL, null, "dividend declared", null, null, List.of(
                new JournalService.NewLine(acct("3900"), 10_000_00L, null, "dividend"),
                new JournalService.NewLine(acct("1010"), null, 10_000_00L, "dividend paid"))));

        ClosingService.ClosingSet set = closing.generateAndPost(fy2026.id());

        // dividends closed: the 4-step set (rev, exp, IS sweep, dividends)
        assertEquals(4, set.entries().size());

        JournalService.TrialBalance post = journal.trialBalance(fy2026.id(), TbStage.POST_CLOSING);
        assertTrue(post.balanced());
        long re = post.rows().stream()
                .filter(r -> r.account().isRetainedEarnings())
                .mapToLong(r -> r.debitCents() - r.creditCents())
                .sum();
        assertEquals(50_000_00L + 10_000_00L, re,
                "RE absorbed NI and dividends: dr movement = NI + DIV");
        // dividends account zeroed in the post-closing TB
        assertEquals(0, post.rows().stream()
                .filter(r -> r.account().code().equals("3900"))
                .mapToLong(r -> r.debitCents() - r.creditCents())
                .sum(), "dividends account not zeroed");
    }

    @Test
    void checklistBlocksUnpostedDrafts() {
        seedProfitableYear();
        // leave one draft behind
        journal.createDraft(new JournalService.NewEntry(clientId, fy2026.id(),
                LocalDate.of(2026, 8, 1), EntryType.NORMAL, null, "draft sale", null,
                null, List.of(
                new JournalService.NewLine(acct("1010"), 5_000_00L, null, "draft"),
                new JournalService.NewLine(acct("4010"), null, 5_000_00L, "draft"))));

        List<ClosingService.CheckItem> items = closing.closeChecklist(fy2026.id());
        assertTrue(items.stream().anyMatch(i -> i.key().equals("drafts") && !i.ok()),
                "unposted drafts must block");

        try {
            closing.generateClosingDrafts(fy2026.id());
            fail("generator must refuse with unposted drafts");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("close blocked"));
        }
    }

    @Test
    void checklistBlocksAPendingClosingSet() {
        seedProfitableYear();
        closing.generateClosingDrafts(fy2026.id());   // leaves drafts

        try {
            closing.generateClosingDrafts(fy2026.id());
            fail("second generation must refuse while drafts pend");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("close blocked"));
        }
    }

    @Test
    void incomeSummaryAccountIsCreatedOnDemand() {
        seedProfitableYear();
        ClosingService.ClosingSet set = closing.generateClosingDrafts(fy2026.id());

        assertNotNull(set.incomeSummary());
        assertEquals(ClosingService.INCOME_SUMMARY_CODE, set.incomeSummary().code());
        assertEquals("Income Summary", set.incomeSummary().name());
        // idempotent: second lookup finds the same account
        assertEquals(set.incomeSummary().id(),
                accounts.findByCode(clientId, ClosingService.INCOME_SUMMARY_CODE)
                        .orElseThrow().id());
    }

    @Test
    void reversalCarriesAccrualIntoNextPeriod() {
        seedProfitableYear();
        // an accrual-style adjusting entry: salaries payable 8,000
        post(new JournalService.NewEntry(clientId, fy2026.id(), DEC_31,
                EntryType.ADJUSTING, null, "accrued salaries for December", null,
                null, List.of(
                new JournalService.NewLine(acct("6000"), 8_000_00L, null, "accrual"),
                new JournalService.NewLine(acct("2100"), null, 8_000_00L, "accrual"))));
        closing.generateAndPost(fy2026.id());

        // next period
        Period fy2027 = periods.create(clientId, "FY2027",
                LocalDate.of(2027, 1, 1), LocalDate.of(2027, 12, 31));

        List<ClosingService.ReversalCandidate> candidates =
                closing.reversalCandidates(fy2026.id());
        assertEquals(1, candidates.size(), "the accrued-salaries adjustment is the candidate");

        JournalService.EntrySummary reversed = closing.reverseInto(
                candidates.getFirst().entry().entry().id(), fy2027.id());
        assertFalse(reversed.entry().posted(), "reversal lands as a draft");
        assertEquals(EntryType.REVERSING, reversed.entry().type());
        assertEquals(LocalDate.of(2027, 1, 1), reversed.entry().date(),
                "reversal dates to the new period's start");

        // sides swapped: debit salaries payable, credit salaries expense
        List<JournalService.LineRow> lines = journal.lines(reversed.entry().id());
        long payableDebit = lines.stream()
                .filter(l -> l.account().code().equals("2100"))
                .mapToLong(l -> nullToZero(l.line().debitCents())).sum();
        long expenseCredit = lines.stream()
                .filter(l -> l.account().code().equals("6000"))
                .mapToLong(l -> nullToZero(l.line().creditCents())).sum();
        assertEquals(8_000_00L, payableDebit, "payable side not reversed to debit");
        assertEquals(8_000_00L, expenseCredit, "expense side not reversed to credit");

        // REVERSING stays out of the unadjusted stage (TbStage contract)
        journal.post(reversed.entry().id());
        JournalService.TrialBalance unadj2027 = journal.trialBalance(fy2027.id(),
                TbStage.UNADJUSTED);
        assertNotEquals(0, unadj2027.rows().size(), "the reversal should appear in FY2027");
    }

    private static long nullToZero(Long v) {
        return v == null ? 0 : v;
    }
}
