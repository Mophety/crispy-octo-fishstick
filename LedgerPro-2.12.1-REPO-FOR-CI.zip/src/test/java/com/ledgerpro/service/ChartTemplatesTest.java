package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-gate for the preset chart catalog: the presets must be internally
 * sound (unique, sorted codes; STANDARD exactly the firm's chart) because
 * they are inserted into real clients' charts verbatim.
 */
class ChartTemplatesTest {

    @Test
    void threePresetsShip() {
        assertEquals(3, ChartTemplates.all().size());
        assertEquals(List.of("MINIMAL", "STANDARD", "DETAILED"),
                ChartTemplates.all().stream().map(ChartTemplates.Definition::code).toList());
    }

    @Test
    void minimalIsALeanCompleteChart() {
        ChartTemplates.Definition minimal = ChartTemplates.byCode("MINIMAL").orElseThrow();
        assertTrue(minimal.size() >= 14, "a lean chart still needs the essentials, has "
                + minimal.size());
        assertTrue(minimal.rows().stream().anyMatch(r -> r.code().equals("1010")));
        assertTrue(minimal.rows().stream().anyMatch(r -> r.code().equals("4000")));
    }

    @Test
    void standardIsExactlyTheFirmsChart() {
        ChartTemplates.Definition standard = ChartTemplates.byCode("STANDARD").orElseThrow();
        assertEquals(StandardChart.size(), standard.size());
        assertEquals(StandardChart.rows(), standard.rows(),
                "STANDARD delegates to StandardChart so the two can never drift");
    }

    @Test
    void detailedExtendsTheStandardChartWithUniqueCodes() {
        ChartTemplates.Definition detailed = ChartTemplates.byCode("DETAILED").orElseThrow();
        ChartTemplates.Definition standard = ChartTemplates.byCode("STANDARD").orElseThrow();
        assertTrue(detailed.size() > standard.size());
        // every standard code present, extras on top, nothing duplicated
        assertTrue(detailed.rows().containsAll(standard.rows()));
        assertEquals(detailed.rows().size(), detailed.rows().stream()
                .map(StandardChart.Row::code).distinct().count(),
                "codes must be unique inside the preset");
        assertEquals(standard.size() + 16, detailed.size());
    }

    @Test
    void everyPresetHasUniqueSortedCodes() {
        for (ChartTemplates.Definition definition : ChartTemplates.all()) {
            List<String> codes = definition.rows().stream()
                    .map(StandardChart.Row::code).toList();
            assertEquals(codes.size(), codes.stream().distinct().count(),
                    "duplicate code in " + definition.code());
            assertEquals(codes.stream().sorted().toList(), codes,
                    definition.code() + " rows must be sorted by code");
        }
    }

    @Test
    void byCodeIsCaseInsensitiveAndEmptySafe() {
        assertTrue(ChartTemplates.byCode("standard").isPresent());
        assertTrue(ChartTemplates.byCode("  Standard ").isPresent());
        assertTrue(ChartTemplates.byCode(null).isEmpty());
        assertTrue(ChartTemplates.byCode("").isEmpty());
        assertTrue(ChartTemplates.byCode("NOPE").isEmpty());
    }

    @Test
    void applyingIsIdempotentAndAudited(@TempDir Path tmp) {
        Database db = new Database(tmp.resolve("t.db").toString());
        db.migrate();
        ClientService clients = new ClientService(db);
        AccountService accounts = new AccountService(db);
        long clientId = clients.create("ACME", "Acme Trading Corp.", "PHP").id();
        assertEquals(null, clients.chartTemplateOf(clientId),
                "applying without recording leaves provenance NULL");

        ChartTemplates.Definition minimal = ChartTemplates.byCode("MINIMAL").orElseThrow();
        int inserted = accounts.applyChartTemplate(clientId, minimal);
        assertEquals(minimal.size(), inserted);
        assertEquals(0, accounts.applyChartTemplate(clientId, minimal),
                "second application must insert nothing");
        assertEquals(minimal.size(), accounts.list(clientId, true).size());
        assertThrows(IllegalArgumentException.class,
                () -> accounts.applyChartTemplate(clientId, null));
    }

    @Test
    void creatingAClientCanRecordTheTemplateProvenance(@TempDir Path tmp) {
        Database db = new Database(tmp.resolve("t.db").toString());
        db.migrate();
        ClientService clients = new ClientService(db);
        long clientId = clients.create("NRTH", "Norte Freight Systems, Inc.", "PHP",
                "detailed").id();
        assertEquals("DETAILED", clients.chartTemplateOf(clientId));
        assertThrows(IllegalArgumentException.class,
                () -> clients.create("BAD1", "Bad Template Pick", "PHP", "NOPE"));
    }
}
