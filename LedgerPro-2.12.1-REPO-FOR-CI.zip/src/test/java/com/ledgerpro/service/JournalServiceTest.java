package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.JournalEntry;
import com.ledgerpro.model.Period;
import com.ledgerpro.model.TbStage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-4 gate, part two: the journal — Dr = Cr enforcement, sequential
 * numbering, posting into the ledger-balance cache, no-delete voiding via
 * mirrored reversing entries, multi-currency conversion through the FX
 * cache (with the rounding residual absorbed), and the three trial-balance
 * checkpoints.
 */
class JournalServiceTest {

    private static final LocalDate JAN_01 = LocalDate.of(2026, 1, 1);
    private static final LocalDate JAN_10 = LocalDate.of(2026, 1, 10);
    private static final LocalDate JAN_12 = LocalDate.of(2026, 1, 12);
    private static final LocalDate DEC_31 = LocalDate.of(2026, 12, 31);

    @TempDir
    Path tmp;

    private Database database;
    private JournalService journal;
    private FxRateService fx;
    private AccountService accounts;
    private PeriodService periods;
    private ClientService clients;

    private long clientId;
    private Period fy2026;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("journal.db").toString());
        database.migrate();
        clients = new ClientService(database);
        accounts = new AccountService(database);
        periods = new PeriodService(database);
        fx = new FxRateService(database);
        journal = new JournalService(database, fx);

        clientId = clients.create("NRTH", "Norte Freight Systems, Inc.", "PHP").id();
        accounts.applyStandardChart(clientId);
        fy2026 = periods.create(clientId, "FY2026", JAN_01, DEC_31);
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private long acct(String code) {
        return accounts.findByCode(clientId, code).orElseThrow().id();
    }

    private JournalService.NewEntry entry(LocalDate date, EntryType type, String currency,
                                          JournalService.NewLine... lines) {
        return new JournalService.NewEntry(clientId, fy2026.id(), date, type,
                null, "test entry", currency, null, List.of(lines));
    }

    private JournalEntry posted(LocalDate date, EntryType type, String currency,
                                JournalService.NewLine... lines) {
        JournalEntry draft = journal.createDraft(entry(date, type, currency, lines));
        return journal.post(draft.id());
    }

    private Map<String, long[]> balancesFromCache(long periodId) throws SQLException {
        Map<String, long[]> map = new HashMap<>();
        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT a.code, b.debit_total_cents, b.credit_total_cents"
                             + " FROM ledger_balances b JOIN accounts a ON a.id = b.account_id"
                             + " WHERE b.period_id = " + periodId)) {
            while (rs.next()) {
                map.put(rs.getString(1), new long[]{rs.getLong(2), rs.getLong(3)});
            }
        }
        return map;
    }

    // ------------------------------------------------------------------
    // Creation + numbering
    // ------------------------------------------------------------------

    @Test
    void createDraftStoresABalancedUnpostedEntry() {
        JournalEntry entry = journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 1_000_000L, null, "cash in"),
                new JournalService.NewLine(acct("3000"), null, 1_000_000L, null)));

        assertFalse(entry.posted(), "a new entry starts as a draft");
        assertEquals(1, entry.entryNo());
        assertEquals(JAN_10, entry.date());
        assertEquals(EntryType.NORMAL, entry.type());
        assertNull(entry.currency(), "null currency = base currency");
        assertNull(entry.fxRate());

        List<JournalService.LineRow> lines = journal.lines(entry.id());
        assertEquals(2, lines.size());
        assertEquals("1010", lines.get(0).account().code());
        assertEquals(1_000_000L, lines.get(0).line().debitCents());
        assertNull(lines.get(0).line().creditCents());
        assertEquals(1_000_000L, lines.get(1).line().creditCents());

        var summary = journal.list(clientId, null).getFirst();
        assertFalse(summary.voided());
        assertFalse(summary.entry().posted());
        assertEquals(1_000_000L, summary.totalBaseCents());
        assertEquals(2, summary.lineCount());
    }

    @Test
    void entryNumbersAreSequentialPerClient() {
        long otherClient = clients.create("GBLC", "Global Circuit Electronics, Inc.", "USD").id();
        accounts.create(otherClient, "1000", "Cash", com.ledgerpro.model.AccountType.ASSET,
                com.ledgerpro.model.Side.DEBIT);
        accounts.create(otherClient, "4000", "Sales",
                com.ledgerpro.model.AccountType.REVENUE, com.ledgerpro.model.Side.CREDIT);
        Period otherPeriod = periods.create(otherClient, "FY2026", JAN_01, DEC_31);

        journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 100L, null, null),
                new JournalService.NewLine(acct("4000"), null, 100L, null)));
        journal.createDraft(entry(JAN_12, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 100L, null, null),
                new JournalService.NewLine(acct("4000"), null, 100L, null)));
        JournalEntry otherEntry = journal.createDraft(new JournalService.NewEntry(
                otherClient, otherPeriod.id(), JAN_10, EntryType.NORMAL, null, null, null,
                null,
                List.of(new JournalService.NewLine(
                                accounts.findByCode(otherClient, "1000").orElseThrow().id(),
                                100L, null, null),
                        new JournalService.NewLine(
                                accounts.findByCode(otherClient, "4000").orElseThrow().id(),
                                null, 100L, null))));

        assertEquals(2, journal.list(clientId, null).getFirst().entry().entryNo(),
                "second NRTH entry is #2");
        assertEquals(1, otherEntry.entryNo(), "GBLC has its own sequence starting at 1");
    }

    @Test
    void unbalancedEntryIsRejectedWhole() throws SQLException {
        assertThrows(UnbalancedEntryException.class, () -> journal.createDraft(
                entry(JAN_10, EntryType.NORMAL, null,
                        new JournalService.NewLine(acct("1010"), 1_000_000L, null, null),
                        new JournalService.NewLine(acct("4000"), null, 999_999L, null))));

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM journal_entries")) {
            assertTrue(rs.next());
            assertEquals(0, rs.getInt(1), "nothing stored, not even a draft");
        }
    }

    @Test
    void malformedLinesAndShapeAreRejected() {
        JournalService.NewLine cash = new JournalService.NewLine(acct("1010"), 100L, null, null);
        JournalService.NewLine sales = new JournalService.NewLine(acct("4000"), null, 100L, null);

        assertThrows(IllegalArgumentException.class, () -> journal.createDraft(
                entry(JAN_10, EntryType.NORMAL, null, cash)),
                "one line is not an entry");
        assertThrows(IllegalArgumentException.class, () -> journal.createDraft(
                entry(JAN_10, EntryType.NORMAL, null, cash,
                        new JournalService.NewLine(acct("4000"), null, null, null))),
                "a line with no side");
        assertThrows(IllegalArgumentException.class, () -> journal.createDraft(
                entry(JAN_10, EntryType.NORMAL, null, cash,
                        new JournalService.NewLine(acct("4000"), 100L, 100L, null))),
                "a line with both sides");
        assertThrows(IllegalArgumentException.class, () -> journal.createDraft(
                entry(JAN_10, EntryType.NORMAL, null, cash,
                        new JournalService.NewLine(acct("4000"), 0L, null, null))),
                "zero amounts are not postings");
        assertThrows(IllegalArgumentException.class, () -> journal.createDraft(
                entry(null, EntryType.NORMAL, null, cash, sales)));
        assertThrows(EntryStateException.class, () -> journal.createDraft(
                entry(JAN_10, EntryType.REVERSING, null, cash, sales)),
                "REVERSING entries are born only from voiding");
    }

    @Test
    void accountsOfAnotherClientOrDeactivatedAreRejected() {
        long otherClient = clients.create("GBLC", "Global Circuit Electronics, Inc.", "USD").id();
        long foreignAccount = accounts.create(otherClient, "1000", "Cash",
                com.ledgerpro.model.AccountType.ASSET, com.ledgerpro.model.Side.DEBIT).id();

        IllegalArgumentException foreign = assertThrows(IllegalArgumentException.class,
                () -> journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                        new JournalService.NewLine(foreignAccount, 100L, null, null),
                        new JournalService.NewLine(acct("4000"), null, 100L, null))));
        assertTrue(foreign.getMessage().contains("another client"));

        long pettyCash = acct("1020");
        accounts.setActive(pettyCash, false);
        IllegalArgumentException inactive = assertThrows(IllegalArgumentException.class,
                () -> journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                        new JournalService.NewLine(pettyCash, 100L, null, null),
                        new JournalService.NewLine(acct("4000"), null, 100L, null))));
        assertTrue(inactive.getMessage().contains("deactivated"));
        accounts.setActive(pettyCash, true);
    }

    @Test
    void datesOutsideThePeriodAndClosedPeriodsAreRejected() {
        IllegalArgumentException outside = assertThrows(IllegalArgumentException.class,
                () -> journal.createDraft(entry(LocalDate.of(2025, 12, 31),
                        EntryType.NORMAL, null,
                        new JournalService.NewLine(acct("1010"), 100L, null, null),
                        new JournalService.NewLine(acct("4000"), null, 100L, null))));
        assertTrue(outside.getMessage().contains("outside period"));

        periods.close(fy2026.id());
        assertThrows(PeriodClosedException.class, () -> journal.createDraft(
                entry(JAN_10, EntryType.NORMAL, null,
                        new JournalService.NewLine(acct("1010"), 100L, null, null),
                        new JournalService.NewLine(acct("4000"), null, 100L, null))));

        // a draft created before closing can no longer be posted either
        periods.reopen(fy2026.id());
        JournalEntry draft = journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 100L, null, null),
                new JournalService.NewLine(acct("4000"), null, 100L, null)));
        periods.close(fy2026.id());
        assertThrows(PeriodClosedException.class, () -> journal.post(draft.id()));
    }

    // ------------------------------------------------------------------
    // Posting + ledger cache
    // ------------------------------------------------------------------

    @Test
    void draftCarriesNoLedgerEffectPostingFillsTheCache() throws SQLException {
        JournalEntry draft = journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 1_000_000L, null, null),
                new JournalService.NewLine(acct("3000"), null, 1_000_000L, null)));

        assertTrue(balancesFromCache(fy2026.id()).isEmpty(), "drafts feed nothing");
        assertTrue(journal.ledger(clientId, acct("1010")).isEmpty());
        assertTrue(journal.trialBalance(fy2026.id(), TbStage.UNADJUSTED).rows().isEmpty());

        JournalEntry posted = journal.post(draft.id());
        assertTrue(posted.posted());

        Map<String, long[]> cache = balancesFromCache(fy2026.id());
        assertEquals(1_000_000L, cache.get("1010")[0], "cash debits cached");
        assertEquals(0L, cache.get("1010")[1]);
        assertEquals(0L, cache.get("3000")[0]);
        assertEquals(1_000_000L, cache.get("3000")[1], "share capital credits cached");

        assertThrows(EntryStateException.class, () -> journal.post(draft.id()),
                "posting twice is refused");
        assertThrows(NoSuchElementException.class, () -> journal.post(999L));
    }

    // ------------------------------------------------------------------
    // Voiding
    // ------------------------------------------------------------------

    @Test
    void voidingMirrorsLineByLineAndCancelsTheLedger() throws SQLException {
        JournalEntry original = posted(JAN_10, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 1_000_000L, null, "in"),
                new JournalService.NewLine(acct("4000"), null, 1_000_000L, null));

        JournalEntry mirror = journal.voidEntry(original.id(), "wrong customer");

        assertEquals(EntryType.REVERSING, mirror.type());
        assertEquals(original.id(), mirror.voidOfId());
        assertTrue(mirror.posted(), "the mirror is born posted");
        assertEquals(original.entryNo() + 1, mirror.entryNo());
        assertEquals(original.date(), mirror.date(), "same period, same date: bounds hold");
        assertTrue(mirror.memo().contains("VOID of entry #1"));
        assertTrue(mirror.memo().contains("wrong customer"));

        List<JournalService.LineRow> mirrorLines = journal.lines(mirror.id());
        assertEquals("1010", mirrorLines.get(0).account().code());
        assertEquals(1_000_000L, mirrorLines.get(0).line().creditCents(),
                "the debit line flips to credit");
        assertEquals("4000", mirrorLines.get(1).account().code());
        assertEquals(1_000_000L, mirrorLines.get(1).line().debitCents(),
                "the credit line flips to debit");

        Map<String, long[]> cache = balancesFromCache(fy2026.id());
        for (long[] totals : cache.values()) {
            assertEquals(totals[0], totals[1], "every touched account nets to zero");
        }
        assertEquals(1_000_000L, cache.get("1010")[0]);
        assertEquals(1_000_000L, cache.get("1010")[1]);

        var summary = journal.list(clientId, null).stream()
                .filter(s -> s.entry().id() == original.id()).findFirst().orElseThrow();
        assertTrue(summary.voided(), "the register derives 'voided' from the mirror");

        assertThrows(EntryStateException.class,
                () -> journal.voidEntry(original.id(), "again"),
                "double voiding is refused");
        assertThrows(EntryStateException.class,
                () -> journal.voidEntry(mirror.id(), "nope"),
                "mirrors are not voided themselves");

        // the trial balance cancels too — both sides still visible, still equal
        JournalService.TrialBalance tb = journal.trialBalance(fy2026.id(), TbStage.UNADJUSTED);
        assertTrue(tb.balanced());
        assertEquals(2_000_000L, tb.totalDebitCents(), "gross activity stays visible");
        assertEquals(2_000_000L, tb.totalCreditCents());
    }

    @Test
    void voidingADraftIsRefusedAndNothingIsEverDeleted() {
        JournalEntry draft = journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 100L, null, null),
                new JournalService.NewLine(acct("4000"), null, 100L, null)));

        EntryStateException refused = assertThrows(EntryStateException.class,
                () -> journal.voidEntry(draft.id(), "typo"));
        assertTrue(refused.getMessage().contains("draft"));

        assertEquals(1, journal.list(clientId, null).size(),
                "the draft stays in the register — nothing is deleted");
    }

    // ------------------------------------------------------------------
    // Multi-currency entries
    // ------------------------------------------------------------------

    @Test
    void foreignCurrencyEntryConvertsThroughTheCacheIntoBaseCents() {
        fx.putManual(JAN_10, "USD", "PHP", 56.732);

        JournalEntry entry = journal.createDraft(entry(JAN_12, EntryType.NORMAL, "USD",
                new JournalService.NewLine(acct("6120"), 300_000L, null, "AWS"),
                new JournalService.NewLine(acct("2000"), null, 300_000L, null)));

        assertEquals("USD", entry.currency());
        assertEquals(56.732, entry.fxRate(), 1e-9, "the resolved rate is snapshotted");

        List<JournalService.LineRow> lines = journal.lines(entry.id());
        assertEquals(17_019_600L, lines.get(0).line().debitCents(),
                "USD 3,000.00 × 56.732 lands as base cents");
        assertEquals(17_019_600L, lines.get(1).line().creditCents());

        journal.post(entry.id());
        JournalService.TrialBalance tb = journal.trialBalance(fy2026.id(), TbStage.UNADJUSTED);
        assertEquals(17_019_600L, tb.totalDebitCents(), "reports read one currency: PHP");
        assertEquals(17_019_600L, tb.totalCreditCents());
    }

    @Test
    void foreignCurrencyWithoutACachedRateIsRejected() throws SQLException {
        FxUnavailableException missing = assertThrows(FxUnavailableException.class,
                () -> journal.createDraft(entry(JAN_10, EntryType.NORMAL, "EUR",
                        new JournalService.NewLine(acct("6120"), 100L, null, null),
                        new JournalService.NewLine(acct("2000"), null, 100L, null))));
        assertTrue(missing.getMessage().contains("EUR"));
        assertTrue(missing.getMessage().contains("FX Rates"),
                "the message says where to fix it");

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM journal_entries")) {
            assertTrue(rs.next());
            assertEquals(0, rs.getInt(1));
        }
    }

    @Test
    void roundingResidualIsAbsorbedSoDebitsEqualCreditsExactly() throws SQLException {
        // rate 0.1: 5 cents → 0.5 base cents → rounds to 1; 10 cents → 1 exactly.
        // two debit lines of 5 + one credit line of 10: typed balances (10 = 10),
        // converted debits 1 + 1 = 2 ≠ credit 1 — the credit line absorbs +1.
        fx.putManual(JAN_10, "JPY", "PHP", 0.1);

        JournalEntry entry = journal.createDraft(entry(JAN_10, EntryType.NORMAL, "JPY",
                new JournalService.NewLine(acct("6110"), 5L, null, null),
                new JournalService.NewLine(acct("6120"), 5L, null, null),
                new JournalService.NewLine(acct("2000"), null, 10L, null)));

        List<JournalService.LineRow> lines = journal.lines(entry.id());
        assertEquals(1L, lines.get(0).line().debitCents());
        assertEquals(1L, lines.get(1).line().debitCents());
        assertEquals(2L, lines.get(2).line().creditCents(),
                "the largest (only) credit line absorbed the residual");

        long dr = lines.stream().mapToLong(l ->
                l.line().debitCents() == null ? 0 : l.line().debitCents()).sum();
        long cr = lines.stream().mapToLong(l ->
                l.line().creditCents() == null ? 0 : l.line().creditCents()).sum();
        assertEquals(dr, cr, "debits equal credits EXACTLY after conversion");

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT detail FROM audit_log WHERE action = 'CREATE_ENTRY'")) {
            assertTrue(rs.next());
            assertTrue(rs.getString(1).contains("rounding residual absorbed"),
                    "the audit trail records the rounding adjustment");
        }
    }

    // ------------------------------------------------------------------
    // Trial balance checkpoints + ledger
    // ------------------------------------------------------------------

    @Test
    void trialBalanceStagesFollowTheCycle() {
        posted(JAN_01, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 1_000_000L, null, null),
                new JournalService.NewLine(acct("4000"), null, 1_000_000L, null));
        posted(JAN_10, EntryType.ADJUSTING, null,
                new JournalService.NewLine(acct("6400"), 50_000L, null, null),
                new JournalService.NewLine(acct("1510"), null, 50_000L, null));
        posted(DEC_31, EntryType.CLOSING, null,
                new JournalService.NewLine(acct("4000"), 1_000_000L, null, null),
                new JournalService.NewLine(acct("3200"), null, 1_000_000L, null));

        JournalService.TrialBalance unadjusted =
                journal.trialBalance(fy2026.id(), TbStage.UNADJUSTED);
        assertEquals(2, unadjusted.rows().size(), "cash + revenue only");
        assertEquals(1_000_000L, unadjusted.totalDebitCents());
        assertTrue(unadjusted.balanced());

        JournalService.TrialBalance adjusted =
                journal.trialBalance(fy2026.id(), TbStage.ADJUSTED);
        assertEquals(4, adjusted.rows().size(), "+ depreciation + contra account");
        assertEquals(1_050_000L, adjusted.totalDebitCents());
        assertTrue(adjusted.balanced());

        JournalService.TrialBalance postClosing =
                journal.trialBalance(fy2026.id(), TbStage.POST_CLOSING);
        assertEquals(1_050_000L + 1_000_000L, postClosing.totalDebitCents());
        assertEquals(postClosing.totalDebitCents(), postClosing.totalCreditCents(),
                "revenue closed into retained earnings still balances");
    }

    @Test
    void ledgerRunsTheBalanceInTheAccountsNormalDirection() {
        posted(JAN_01, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 1_000_000L, null, null),
                new JournalService.NewLine(acct("4000"), null, 1_000_000L, null));
        posted(JAN_12, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("6100"), 180_000L, null, null),
                new JournalService.NewLine(acct("1010"), null, 180_000L, null));
        posted(JAN_10, EntryType.ADJUSTING, null,
                new JournalService.NewLine(acct("6400"), 50_000L, null, null),
                new JournalService.NewLine(acct("1510"), null, 50_000L, null));

        List<JournalService.LedgerRow> cash = journal.ledger(clientId, acct("1010"));
        assertEquals(2, cash.size());
        assertEquals(1_000_000L, cash.get(0).balanceCents(), "debit-normal grows with debits");
        assertEquals(820_000L, cash.get(1).balanceCents(), "and shrinks with credits");

        List<JournalService.LedgerRow> accum = journal.ledger(clientId, acct("1510"));
        assertEquals(1, accum.size());
        assertEquals(50_000L, accum.getFirst().balanceCents(),
                "credit-normal contra account grows with credits — positive balance");

        assertThrows(IllegalArgumentException.class,
                () -> journal.ledger(999L, acct("1010")), "another client's ledger");
    }

    @Test
    void ledgerBalancesCacheAlwaysMatchesThePostedJournal() throws SQLException {
        posted(JAN_01, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 1_000_000L, null, null),
                new JournalService.NewLine(acct("4000"), null, 1_000_000L, null));
        JournalEntry voided = posted(JAN_12, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("6110"), 60_000L, null, null),
                new JournalService.NewLine(acct("1010"), null, 60_000L, null));
        journal.voidEntry(voided.id(), "duplicate");

        Map<String, long[]> fromJournal = new HashMap<>();
        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT a.code, COALESCE(SUM(l.debit_cents), 0), COALESCE(SUM(l.credit_cents), 0)"
                             + " FROM journal_lines l"
                             + " JOIN journal_entries e ON e.id = l.entry_id"
                             + " JOIN accounts a ON a.id = l.account_id"
                             + " WHERE e.period_id = " + fy2026.id() + " AND e.posted = 1"
                             + " GROUP BY a.code")) {
            while (rs.next()) {
                fromJournal.put(rs.getString(1), new long[]{rs.getLong(2), rs.getLong(3)});
            }
        }

        assertEquals(fromJournal.keySet(), balancesFromCache(fy2026.id()).keySet(),
                "the cache covers exactly the accounts the journal touched");
        Map<String, long[]> cache = balancesFromCache(fy2026.id());
        fromJournal.forEach((code, totals) ->
                assertArrayEquals(totals, cache.get(code),
                        "the cache is exactly the posted journal for '" + code + "'"));
    }

    // ------------------------------------------------------------------
    // Snapshots
    // ------------------------------------------------------------------

    @Test
    void snapshotsFreezeTheTrialBalanceIntoTheAuditTrail() throws SQLException {
        posted(JAN_01, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 1_000_000L, null, null),
                new JournalService.NewLine(acct("4000"), null, 1_000_000L, null));

        long first = journal.snapshotTrialBalance(fy2026.id(), TbStage.UNADJUSTED);
        long second = journal.snapshotTrialBalance(fy2026.id(), TbStage.ADJUSTED);
        assertTrue(first > 0);
        assertTrue(second > first, "snapshots accumulate, never overwrite");

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT stage, payload FROM tb_snapshots ORDER BY id")) {
            assertTrue(rs.next());
            assertEquals("UNADJUSTED", rs.getString(1));
            String payload = rs.getString(2);
            assertTrue(payload.contains("\"stage\":\"UNADJUSTED\""));
            assertTrue(payload.contains("1010"));
            assertTrue(payload.contains("\"total_debit_cents\":1000000"));
            assertTrue(rs.next());
            assertEquals("ADJUSTED", rs.getString(1));
        }

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT action FROM audit_log WHERE action = 'SNAPSHOT_TB'")) {
            assertTrue(rs.next());
            assertTrue(rs.next());
            assertFalse(rs.next(), "one audit row per snapshot");
        }
    }

    // ------------------------------------------------------------------
    // Audit
    // ------------------------------------------------------------------

    @Test
    void everyJournalMutationIsAudited() throws SQLException {
        JournalEntry draft = journal.createDraft(entry(JAN_10, EntryType.NORMAL, null,
                new JournalService.NewLine(acct("1010"), 100L, null, null),
                new JournalService.NewLine(acct("4000"), null, 100L, null)));
        journal.post(draft.id());
        journal.voidEntry(draft.id(), "test void");

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT action, client_id FROM audit_log"
                             + " WHERE action IN ('CREATE_ENTRY','POST_ENTRY','VOID_ENTRY')"
                             + " ORDER BY id")) {
            assertTrue(rs.next());
            assertEquals("CREATE_ENTRY", rs.getString(1));
            assertEquals(clientId, rs.getLong(2));
            assertTrue(rs.next());
            assertEquals("POST_ENTRY", rs.getString(1));
            assertTrue(rs.next());
            assertEquals("VOID_ENTRY", rs.getString(1));
        }
    }
}
