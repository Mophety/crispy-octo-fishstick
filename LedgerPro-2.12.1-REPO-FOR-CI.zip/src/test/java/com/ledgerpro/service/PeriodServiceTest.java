package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Period;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-4 gate, part one: periods — the unit the journal lives in and the
 * unit that freezes at the end of the cycle.
 */
class PeriodServiceTest {

    private static final LocalDate JAN_1 = LocalDate.of(2026, 1, 1);
    private static final LocalDate DEC_31 = LocalDate.of(2026, 12, 31);

    @TempDir
    Path tmp;

    private Database database;
    private PeriodService service;
    private long clientId;
    private long otherClientId;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("periods.db").toString());
        database.migrate();
        service = new PeriodService(database);
        ClientService clients = new ClientService(database);
        clientId = clients.create("NRTH", "Norte Freight Systems, Inc.", "PHP").id();
        otherClientId = clients.create("GBLC", "Global Circuit Electronics, Inc.", "USD").id();
    }

    // ------------------------------------------------------------------
    // Create + list
    // ------------------------------------------------------------------

    @Test
    void createStoresThePeriodOpenAndListOrdersByStart() {
        Period fy2026 = service.create(clientId, "FY2026", JAN_1, DEC_31);
        service.create(clientId, "2027-01", LocalDate.of(2027, 1, 1),
                LocalDate.of(2027, 1, 31));

        List<Period> list = service.list(clientId);
        assertEquals(2, list.size());
        assertEquals("FY2026", list.getFirst().name(), "older start date first");
        assertEquals("2027-01", list.get(1).name());
        assertFalse(fy2026.closed(), "a fresh period is OPEN");
        assertTrue(fy2026.contains(LocalDate.of(2026, 6, 30)));
        assertFalse(fy2026.contains(LocalDate.of(2027, 1, 1)));
    }

    @Test
    void createValidatesShape() {
        assertThrows(IllegalArgumentException.class,
                () -> service.create(clientId, "  ", JAN_1, DEC_31));
        assertThrows(IllegalArgumentException.class,
                () -> service.create(clientId, "FY2026", null, DEC_31));
        assertThrows(IllegalArgumentException.class,
                () -> service.create(clientId, "FY2026", JAN_1, null));
        assertThrows(IllegalArgumentException.class,
                () -> service.create(clientId, "FY2026", DEC_31, JAN_1),
                "end before start");
        assertThrows(NoSuchElementException.class,
                () -> service.create(999L, "FY2026", JAN_1, DEC_31));
    }

    @Test
    void namesAreUniquePerClientButSharedAcrossClients() {
        service.create(clientId, "FY2026", JAN_1, DEC_31);
        // same name, different (non-overlapping) range: the name itself clashes
        assertThrows(DuplicatePeriodNameException.class,
                () -> service.create(clientId, " FY2026 ",
                        LocalDate.of(2027, 1, 1), LocalDate.of(2027, 12, 31)));

        Period other = service.create(otherClientId, "FY2026", JAN_1, DEC_31);
        assertEquals(otherClientId, other.clientId(), "same name, different client: fine");
    }

    @Test
    void overlappingPeriodsAreRejectedIncludingMereTouching() {
        service.create(clientId, "FY2026", JAN_1, DEC_31);

        IllegalArgumentException overlap = assertThrows(IllegalArgumentException.class,
                () -> service.create(clientId, "H2-2026",
                        LocalDate.of(2026, 7, 1), LocalDate.of(2027, 6, 30)));
        assertTrue(overlap.getMessage().contains("overlap"),
                "a date must belong to exactly one period");

        assertThrows(IllegalArgumentException.class,
                () -> service.create(clientId, "FY2027", DEC_31, DEC_31),
                "inclusive ends: even one shared day is an overlap");

        Period clean = service.create(clientId, "FY2027",
                LocalDate.of(2027, 1, 1), LocalDate.of(2027, 12, 31));
        assertFalse(clean.closed());
    }

    // ------------------------------------------------------------------
    // Close / reopen
    // ------------------------------------------------------------------

    @Test
    void closeFreezesAndReopenUnlocks() {
        Period period = service.create(clientId, "FY2026", JAN_1, DEC_31);

        service.close(period.id());
        assertTrue(service.find(period.id()).orElseThrow().closed());

        IllegalStateException closedAgain = assertThrows(IllegalStateException.class,
                () -> service.close(period.id()));
        assertTrue(closedAgain.getMessage().contains("closed already"));

        service.reopen(period.id());
        assertFalse(service.find(period.id()).orElseThrow().closed());

        IllegalStateException openAgain = assertThrows(IllegalStateException.class,
                () -> service.reopen(period.id()));
        assertTrue(openAgain.getMessage().contains("open already"));
    }

    @Test
    void everyMutationLeavesAnAuditRow() throws SQLException {
        Period period = service.create(clientId, "FY2026", JAN_1, DEC_31);
        service.close(period.id());
        service.reopen(period.id());

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT action FROM audit_log"
                             + " WHERE action IN ('CREATE_PERIOD','CLOSE_PERIOD','REOPEN_PERIOD')"
                             + " ORDER BY id")) {
            assertTrue(rs.next());
            assertEquals("CREATE_PERIOD", rs.getString(1));
            assertTrue(rs.next());
            assertEquals("CLOSE_PERIOD", rs.getString(1));
            assertTrue(rs.next());
            assertEquals("REOPEN_PERIOD", rs.getString(1));
            assertFalse(rs.next());
        }
    }
}
