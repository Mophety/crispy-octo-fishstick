package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.AccountType;
import com.ledgerpro.model.EntryType;
import com.ledgerpro.model.Side;
import com.ledgerpro.model.Period;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-5 gate: the worksheet and the financial statements.
 *
 * <p>The fixture walks one honest accounting cycle — a capitalized client,
 * revenue on account and in cash, purchases, prepaid expenses, paid
 * operating expenses, a dividend, then seven end-of-period adjustments
 * (supplies used, depreciation, insurance and rent expired, unearned revenue
 * earned, salaries accrued, and an allowance for doubtful accounts) — the
 * same shape as the firm's paper worksheets. Every expected figure below was
 * worked out by hand first, then asserted, so the arithmetic of the routing,
 * the special NET INCOME / ENDING CAPITAL rows and the three statements is
 * pinned to known-good numbers.</p>
 */
class WorksheetServiceTest {

    private static final LocalDate JAN_02 = LocalDate.of(2026, 1, 2);
    private static final LocalDate JAN_05 = LocalDate.of(2026, 1, 5);
    private static final LocalDate JAN_08 = LocalDate.of(2026, 1, 8);
    private static final LocalDate JAN_10 = LocalDate.of(2026, 1, 10);
    private static final LocalDate JAN_12 = LocalDate.of(2026, 1, 12);
    private static final LocalDate JAN_15 = LocalDate.of(2026, 1, 15);
    private static final LocalDate JAN_20 = LocalDate.of(2026, 1, 20);
    private static final LocalDate JAN_25 = LocalDate.of(2026, 1, 25);
    private static final LocalDate JAN_28 = LocalDate.of(2026, 1, 28);
    private static final LocalDate JAN_30 = LocalDate.of(2026, 1, 30);
    private static final LocalDate DEC_30 = LocalDate.of(2026, 12, 30);
    private static final LocalDate DEC_31 = LocalDate.of(2026, 12, 31);

    /** pesos → cents for the scenario's round numbers. */
    private static long cents(long pesos) {
        return pesos * 100;
    }

    @TempDir
    Path tmp;

    private Database database;
    private JournalService journal;
    private FxRateService fx;
    private AccountService accounts;
    private PeriodService periods;
    private ClientService clients;
    private WorksheetService worksheets;

    private long clientId;
    private Period fy2026;

    @BeforeEach
    void setUp() {
        database = new Database(tmp.resolve("worksheet.db").toString());
        database.migrate();
        clients = new ClientService(database);
        accounts = new AccountService(database);
        periods = new PeriodService(database);
        fx = new FxRateService(database);
        journal = new JournalService(database, fx);
        worksheets = new WorksheetService(database);

        clientId = clients.create("OWNS", "Owens Capital Services", "PHP").id();
        accounts.applyStandardChart(clientId);
        accounts.create(clientId, "2150", "Unearned Revenue",
                AccountType.LIABILITY, Side.CREDIT);
        fy2026 = periods.create(clientId, "FY2026", LocalDate.of(2026, 1, 1), DEC_31);

        // ---- the unadjusted journal ------------------------------------
        post(JAN_02, EntryType.NORMAL, "opening capitalization",
                line("1010", cents(54_750), null), line("3000", null, cents(54_750)));
        post(JAN_05, EntryType.NORMAL, "consulting revenue billed and collected",
                line("1010", cents(28_100), null), line("1100", cents(5_700), null),
                line("4000", null, cents(33_800)));
        post(JAN_08, EntryType.NORMAL, "purchased prepaid expenses on account",
                line("1300", cents(640), null), line("2000", null, cents(640)));
        post(JAN_10, EntryType.NORMAL, "prepaid insurance paid",
                line("1300", cents(240), null), line("1010", null, cents(240)));
        post(JAN_12, EntryType.NORMAL, "prepaid rent paid",
                line("1300", cents(360), null), line("1010", null, cents(360)));
        post(JAN_15, EntryType.NORMAL, "equipment, furniture and vehicles acquired",
                line("1500", cents(5_800), null),
                line("2000", null, cents(830)), line("2300", null, cents(2_000)),
                line("1010", null, cents(2_970)));
        post(JAN_20, EntryType.NORMAL, "operating expenses paid",
                line("6000", cents(1_680), null), line("6110", cents(125), null),
                line("6120", cents(220), null), line("6210", cents(170), null),
                line("6130", cents(50), null), line("6100", cents(100), null),
                line("6200", cents(200), null), line("6800", cents(40), null),
                line("1010", null, cents(2_585)));
        post(JAN_25, EntryType.NORMAL, "retainer collected in advance",
                line("1010", cents(400), null), line("2150", null, cents(400)));
        post(JAN_28, EntryType.NORMAL, "cash service revenue",
                line("1010", cents(1_200), null), line("4000", null, cents(1_200)));
        post(JAN_30, EntryType.NORMAL, "dividend declared and paid",
                line("3900", cents(350), null), line("1010", null, cents(350)));

        // ---- the adjustments --------------------------------------------
        post(DEC_30, EntryType.ADJUSTING, "prepaid expenses consumed",
                line("6150", cents(310), null), line("1300", null, cents(310)));
        post(DEC_30, EntryType.ADJUSTING, "depreciation for the year",
                line("6400", cents(450), null), line("1510", null, cents(450)));
        post(DEC_30, EntryType.ADJUSTING, "insurance expired",
                line("6200", cents(200), null), line("1300", null, cents(200)));
        post(DEC_30, EntryType.ADJUSTING, "rent expired",
                line("6100", cents(200), null), line("1300", null, cents(200)));
        post(DEC_30, EntryType.ADJUSTING, "unearned retainer earned",
                line("2150", cents(120), null), line("4000", null, cents(120)));
        post(DEC_30, EntryType.ADJUSTING, "salaries accrued",
                line("6000", cents(140), null), line("2100", null, cents(140)));
        post(DEC_30, EntryType.ADJUSTING, "allowance for doubtful accounts",
                line("6500", cents(57), null), line("1110", null, cents(57)));
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private long acct(String code) {
        return accounts.findByCode(clientId, code).orElseThrow().id();
    }

    private JournalService.NewLine line(String code, Long debit, Long credit) {
        return new JournalService.NewLine(acct(code), debit, credit, null);
    }

    private void post(LocalDate date, EntryType type, String memo,
                      JournalService.NewLine... lines) {
        journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, fy2026.id(), date, type, null, memo, null, null,
                List.of(lines))).id());
    }

    private WorksheetService.WorksheetRow row(String code) {
        return worksheets.worksheet(fy2026.id(),
                        WorksheetService.WorksheetFormat.COLUMNS_13).rows().stream()
                .filter(r -> r.account().code().equals(code))
                .findFirst().orElseThrow();
    }

    // ------------------------------------------------------------------
    // The 13-column worksheet
    // ------------------------------------------------------------------

    @Test
    void fullCycleWorksheetMatchesTheHandWorkedSheet() {
        WorksheetService.Worksheet w = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);

        // the three trial-balance column groups
        assertEquals(cents(93_620), w.totals().unadjDr());
        assertEquals(cents(93_620), w.totals().unadjCr());
        assertEquals(cents(1_477), w.totals().adjDr());
        assertEquals(cents(1_477), w.totals().adjCr());
        assertEquals(cents(94_267), w.totals().atbDr());
        assertEquals(cents(94_267), w.totals().atbCr());

        // the statement columns and the figures they produce
        assertEquals(cents(3_942), w.totals().isDr());
        assertEquals(cents(35_120), w.totals().isCr());
        assertEquals(cents(31_178), w.netIncome());
        assertEquals(cents(350), w.totals().soceDr());
        assertEquals(cents(54_750), w.totals().soceCr());
        assertEquals(cents(85_578), w.endingCapital());
        assertEquals(cents(89_975), w.totals().bsDr());
        assertEquals(cents(4_397), w.totals().bsCr());

        // the special rows make every column group balance, like the paper
        assertEquals(cents(35_120), w.isGrandDr());
        assertEquals(cents(35_120), w.isGrandCr());
        assertEquals(cents(85_928), w.soceGrandDr());
        assertEquals(cents(85_928), w.soceGrandCr());
        assertEquals(cents(89_975), w.bsGrandDr());
        assertEquals(cents(89_975), w.bsGrandCr());
        assertEquals(cents(211_023), w.grandDr());
        assertEquals(cents(211_023), w.grandCr());

        assertTrue(w.balanced(), "Dr = Cr must hold through every column group");
        assertEquals("OWNS", w.client().code());
        assertEquals("FY2026", w.period().name());
    }

    @Test
    void routingPutsEveryAdjustedBalanceInExactlyOneColumnPair() {
        // revenue flows to the income statement columns only
        WorksheetService.WorksheetRow revenue = row("4000");
        assertEquals(cents(35_000), revenue.unadjCr());
        assertEquals(cents(120), revenue.adjCr());
        assertEquals(cents(35_120), revenue.atbCr());
        assertEquals(cents(35_120), revenue.isCr());
        assertEquals(0, revenue.soceDr() + revenue.soceCr() + revenue.bsDr() + revenue.bsCr());

        // an account adjusted downward nets in the adjusted trial balance
        WorksheetService.WorksheetRow prepaid = row("1300");
        assertEquals(cents(1_240), prepaid.unadjDr());
        assertEquals(cents(710), prepaid.adjCr());
        assertEquals(cents(530), prepaid.atbDr());
        assertEquals(cents(530), prepaid.bsDr());

        // contra assets land on the balance sheet credit side
        WorksheetService.WorksheetRow accumDep = row("1510");
        assertEquals(cents(450), accumDep.adjCr());
        assertEquals(cents(450), accumDep.bsCr());
        WorksheetService.WorksheetRow allowance = row("1110");
        assertEquals(cents(57), allowance.bsCr());

        // contra equity lands in the changes-in-equity columns
        WorksheetService.WorksheetRow dividends = row("3900");
        assertEquals(cents(350), dividends.soceDr());
        assertEquals(0, dividends.bsDr());

        // capital carries its adjusted balance and its investment credit
        WorksheetService.WorksheetRow capital = row("3000");
        assertEquals(cents(54_750), capital.soceCr());
        assertEquals(cents(54_750), capital.investCr());

        // liabilities sit on the balance sheet credit side
        WorksheetService.WorksheetRow unearned = row("2150");
        assertEquals(cents(400), unearned.unadjCr());
        assertEquals(cents(120), unearned.adjDr());
        assertEquals(cents(280), unearned.bsCr());
    }

    // ------------------------------------------------------------------
    // The 10-column format
    // ------------------------------------------------------------------

    @Test
    void tenColumnFormatFoldsEquityIntoTheBalanceSheetColumns() {
        WorksheetService.Worksheet w = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_10);

        WorksheetService.WorksheetRow dividends = row13Dividends(w);
        assertEquals(cents(350), dividends.bsDr(), "drawing rides the debit side in 10-column");

        WorksheetService.WorksheetRow capital = w.rows().stream()
                .filter(r -> r.account().code().equals("3000")).findFirst().orElseThrow();
        assertEquals(cents(54_750), capital.bsCr());

        // the 10-column balance sheet: assets + drawing vs liabilities +
        // capital + net income — one grand pair, no equity columns
        assertEquals(cents(90_325), w.totals().bsDr());
        assertEquals(cents(59_147), w.totals().bsCr());
        assertEquals(cents(90_325), w.bsGrandDr());
        assertEquals(cents(90_325), w.bsGrandCr());
        assertEquals(cents(125_445), w.grandDr());
        assertEquals(cents(125_445), w.grandCr());
        assertTrue(w.balanced());

        // the figures that matter are identical in both formats
        assertEquals(cents(31_178), w.netIncome());
        assertEquals(cents(85_578), w.endingCapital());
    }

    @Test
    void tenColumnKeepsTheEquityCellsPopulated() {
        // the regression 2.4.0 fixed and this suite pins forever: in the
        // 10-column format the Changes in Equity columns stayed BLANK (the
        // routing zeroed the soce cells when the columns were hidden), so
        // re-showing the hidden pair from the table menu displayed an empty
        // grid even though equity had real movements
        WorksheetService.Worksheet w = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_10);

        WorksheetService.WorksheetRow dividends = row13Dividends(w);
        assertEquals(cents(350), dividends.soceDr(),
                "contra equity lands on the equity Dr cell in 10-column too");

        WorksheetService.WorksheetRow capital = w.rows().stream()
                .filter(r -> r.account().code().equals("3000")).findFirst().orElseThrow();
        assertEquals(cents(54_750), capital.soceCr(),
                "capital lands on the equity Cr cell in 10-column too");

        // the equity column totals are the account rows' own sums — the
        // special NET INCOME / ENDING CAPITAL rows print into the balance
        // sheet columns in this format, so the pair totals read as the
        // accounts' routing alone
        assertEquals(cents(350), w.totals().soceDr());
        assertEquals(cents(54_750), w.totals().soceCr());
        assertEquals(cents(350), w.soceGrandDr());
        assertEquals(cents(54_750), w.soceGrandCr());

        // and nothing that must stay in the balance sheet columns moved away
        assertEquals(cents(350), dividends.bsDr());
        assertEquals(cents(54_750), capital.bsCr());
        assertEquals(cents(90_325), w.bsGrandDr());
        assertEquals(cents(90_325), w.bsGrandCr());
        assertTrue(w.balanced());
    }

    private WorksheetService.WorksheetRow row13Dividends(WorksheetService.Worksheet w) {
        return w.rows().stream()
                .filter(r -> r.account().code().equals("3900")).findFirst().orElseThrow();
    }

    // ------------------------------------------------------------------
    // What the worksheet deliberately leaves out
    // ------------------------------------------------------------------

    @Test
    void closingEntriesStayOutOfTheWorksheet() {
        WorksheetService.Worksheet before = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);

        post(DEC_31, EntryType.CLOSING, "close revenue and expenses into capital",
                line("4000", cents(35_120), null),
                line("6000", null, cents(1_820)), line("6100", null, cents(300)),
                line("6110", null, cents(125)), line("6120", null, cents(220)),
                line("6130", null, cents(50)), line("6150", null, cents(310)),
                line("6200", null, cents(400)), line("6210", null, cents(170)),
                line("6400", null, cents(450)), line("6500", null, cents(57)),
                line("6800", null, cents(40)), line("3000", null, cents(31_178)));

        WorksheetService.Worksheet after = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);
        assertEquals(before.totals(), after.totals(), "closing must not bend the worksheet");
        assertEquals(before.netIncome(), after.netIncome());
        assertEquals(before.grandDr(), after.grandDr());
    }

    @Test
    void voidingMirrorsCancelInTheUnadjustedColumns() {
        WorksheetService.Worksheet before = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);

        var duplicate = journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, fy2026.id(), JAN_28, EntryType.NORMAL,
                null, "accidental duplicate revenue", null, null,
                List.of(line("1010", cents(1_200), null),
                        line("4000", null, cents(1_200))))).id());
        journal.voidEntry(duplicate.id(), "duplicate of the real cash revenue entry");

        // an account whose ONLY entry is voided leaves the sheet entirely —
        // a blank line on paper, no ghost "0.00" row here
        long ghost = accounts.create(clientId, "6900", "Ghost Expense",
                AccountType.EXPENSE, Side.DEBIT).id();
        var ghostEntry = journal.post(journal.createDraft(new JournalService.NewEntry(
                clientId, fy2026.id(), JAN_30, EntryType.NORMAL,
                null, "an entry that will be voided to nothing", null, null,
                List.of(new JournalService.NewLine(ghost, cents(500), null, null),
                        line("1010", null, cents(500))))).id());
        journal.voidEntry(ghostEntry.id(), "recorded against the wrong account");

        WorksheetService.Worksheet after = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);
        assertEquals(before.totals().unadjDr(), after.totals().unadjDr());
        assertEquals(before.totals().unadjCr(), after.totals().unadjCr());
        assertEquals(before.netIncome(), after.netIncome());
        assertEquals(before.endingCapital(), after.endingCapital());
        assertTrue(after.balanced());
        assertTrue(after.rows().stream().noneMatch(r -> r.account().code().equals("6900")),
                "a fully voided account reads as a blank line on the paper sheet");
        assertTrue(worksheets.incomeStatement(fy2026.id()).expenses().stream()
                .noneMatch(r -> r.code().equals("6900")));
    }

    @Test
    void draftEntriesNeverReachTheWorksheet() {
        WorksheetService.Worksheet before = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);

        journal.createDraft(new JournalService.NewEntry(
                clientId, fy2026.id(), JAN_30, EntryType.NORMAL,
                null, "still a draft — no ledger effect", null, null,
                List.of(line("1010", cents(500), null),
                        line("4000", null, cents(500)))));

        WorksheetService.Worksheet after = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);
        assertEquals(before.totals(), after.totals());
        assertEquals(before.rows().size(), after.rows().size());
    }

    @Test
    void emptyPeriodYieldsAnEmptyButBalancedWorksheet() {
        Period fresh = periods.create(clientId, "FY2027",
                LocalDate.of(2027, 1, 1), LocalDate.of(2027, 12, 31));
        WorksheetService.Worksheet w = worksheets.worksheet(
                fresh.id(), WorksheetService.WorksheetFormat.COLUMNS_13);

        assertTrue(w.rows().isEmpty());
        assertEquals(0, w.totals().unadjDr());
        assertEquals(0, w.netIncome());
        assertEquals(0, w.endingCapital());
        assertTrue(w.balanced());

        WorksheetService.IncomeStatement is = worksheets.incomeStatement(fresh.id());
        assertTrue(is.revenues().isEmpty());
        assertEquals(0, is.netIncome());
        WorksheetService.BalanceSheet bs = worksheets.balanceSheet(fresh.id());
        assertTrue(bs.balanced());
    }

    // ------------------------------------------------------------------
    // The statements
    // ------------------------------------------------------------------

    @Test
    void incomeStatementReadsLikeTheWorksheetColumns() {
        WorksheetService.IncomeStatement is = worksheets.incomeStatement(fy2026.id());

        assertEquals(1, is.revenues().size());
        assertEquals("4000", is.revenues().getFirst().code());
        assertEquals(cents(35_120), is.revenues().getFirst().amountCents());
        assertEquals(11, is.expenses().size());
        assertEquals(cents(35_120), is.totalRevenues());
        assertEquals(cents(3_942), is.totalExpenses());
        assertEquals(cents(31_178), is.netIncome());

        // the largest expense tells the same story as the journal
        WorksheetService.StatementRow salaries = is.expenses().stream()
                .filter(r -> r.code().equals("6000")).findFirst().orElseThrow();
        assertEquals(cents(1_820), salaries.amountCents());
    }

    @Test
    void equityChangeTellsTheCapitalStory() {
        WorksheetService.EquityChange soce = worksheets.equityChange(fy2026.id());

        assertEquals(0, soce.beginningCapital(),
                "a newly onboarded client starts from zero");
        assertEquals(1, soce.investments().size());
        assertEquals(cents(54_750), soce.investments().getFirst().amountCents());
        assertEquals(cents(31_178), soce.netIncome());
        assertEquals(1, soce.withdrawals().size());
        assertEquals("3900", soce.withdrawals().getFirst().code());
        assertEquals(cents(350), soce.withdrawals().getFirst().amountCents());
        assertEquals(cents(85_578), soce.endingCapital());
        assertTrue(soce.addsUp(), "beginning + investments + net income − withdrawals");
    }

    @Test
    void balanceSheetBalancesAssetsAgainstLiabilitiesAndEquity() {
        WorksheetService.BalanceSheet bs = worksheets.balanceSheet(fy2026.id());

        assertEquals(cents(89_468), bs.totalAssets());
        assertEquals(cents(3_890), bs.totalLiabilities());
        assertEquals(cents(85_578), bs.totalEquity());
        assertTrue(bs.balanced(), "assets = liabilities + ending equity, always");

        // contra assets read as the deduction lines they are
        WorksheetService.StatementRow accumDep = bs.assets().stream()
                .filter(r -> r.code().equals("1510")).findFirst().orElseThrow();
        assertEquals(-cents(450), accumDep.amountCents());
        WorksheetService.StatementRow allowance = bs.assets().stream()
                .filter(r -> r.code().equals("1110")).findFirst().orElseThrow();
        assertEquals(-cents(57), allowance.amountCents());

        assertEquals(4, bs.liabilities().size());
        assertEquals(List.of("2000", "2100", "2150", "2300"),
                bs.liabilities().stream()
                        .map(WorksheetService.StatementRow::code).sorted().toList());
    }

    // ------------------------------------------------------------------
    // Exports
    // ------------------------------------------------------------------

    @Test
    void csvRendersTheWholeGridWithTotals() {
        WorksheetService.Worksheet w = worksheets.worksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);
        String csv = worksheets.toCsv(w);

        assertTrue(csv.startsWith("Account,Unadjusted Dr,Unadjusted Cr,"));
        assertTrue(csv.contains("Account,Unadjusted Dr,Unadjusted Cr,Adjustments Dr,"
                + "Adjustments Cr,Adjusted TB Dr,Adjusted TB Cr,Income Stmt Dr,"
                + "Income Stmt Cr,Equity Dr,Equity Cr,Balance Sheet Dr,Balance Sheet Cr"));
        // a routed account row: revenue lands in the IS credit column only
        assertTrue(csv.contains("4000,Service Revenue,0.00,35000.00,0.00,120.00,"
                + "0.00,35120.00,0.00,35120.00,0.00,0.00,0.00,0.00"));
        // the special rows
        assertTrue(csv.contains("TOTAL Unadjusted,93620.00,93620.00,"));
        assertTrue(csv.contains("TOTAL Adjustments,0.00,0.00,1477.00,1477.00,"));
        assertTrue(csv.contains("NET INCOME,0.00,0.00,0.00,0.00,0.00,0.00,"
                + "31178.00,0.00,0.00,31178.00,0.00,0.00"));
        assertTrue(csv.contains("ENDING CAPITAL,0.00,0.00,0.00,0.00,0.00,0.00,"
                + "0.00,0.00,85578.00,0.00,0.00,85578.00"));
        assertTrue(csv.contains("TOTALS,93620.00,93620.00,1477.00,1477.00,"
                + "94267.00,94267.00,35120.00,35120.00,85928.00,"
                + "85928.00,89975.00,89975.00"));
        // names with commas are quoted properly
        assertFalse(csv.contains("SSS, Pag-IBIG"));
    }

    @Test
    void statementCsvsCarryTheHeadlines() {
        String is = worksheets.toCsv(worksheets.incomeStatement(fy2026.id()));
        assertTrue(is.startsWith("Income Statement,Amount"));
        assertTrue(is.contains("Total revenues,35120.00"));
        assertTrue(is.contains("Total expenses,3942.00"));
        assertTrue(is.contains("NET INCOME,31178.00"));

        String soce = worksheets.toCsv(worksheets.equityChange(fy2026.id()));
        assertTrue(soce.contains("\"Capital, beginning\",0.00"));
        assertTrue(soce.contains("Add: Ordinary Share Capital,54750.00"));
        assertTrue(soce.contains("Add: Net income,31178.00"));
        assertTrue(soce.contains("Less: Dividends Declared,350.00"));
        assertTrue(soce.contains("\"Capital, ending\",85578.00"));

        String bs = worksheets.toCsv(worksheets.balanceSheet(fy2026.id()));
        assertTrue(bs.contains("Total assets,89468.00"));
        assertTrue(bs.contains("(450.00)"));
        assertTrue(bs.contains("(57.00)"));
        assertTrue(bs.contains("Total liabilities,3890.00"));
        assertTrue(bs.contains("\"Total equity, ending\",85578.00"));
        assertTrue(bs.contains("TOTAL LIABILITIES AND EQUITY,89468.00"));
    }

    @Test
    void htmlCarriesAllThreeStatementsAndTheProof() {
        String html = worksheets.toHtml(
                worksheets.incomeStatement(fy2026.id()),
                worksheets.equityChange(fy2026.id()),
                worksheets.balanceSheet(fy2026.id()));

        assertTrue(html.startsWith("<!DOCTYPE html>"));
        assertTrue(html.contains("<title>Owens Capital Services"));
        assertTrue(html.contains("<h3>Income Statement</h3>"));
        assertTrue(html.contains("<h3>Statement of Changes in Owner's Equity</h3>"));
        assertTrue(html.contains("<h3>Balance Sheet</h3>"));
        assertTrue(html.contains("NET INCOME"));
        assertTrue(html.contains("31178.00"));
        assertTrue(html.contains("Capital, ending"));
        assertTrue(html.contains("TOTAL LIABILITIES AND EQUITY"));
        assertTrue(html.contains("89468.00"));
        assertTrue(html.contains("@media print"));
    }

    // ------------------------------------------------------------------
    // Snapshots — the immutable audit trail
    // ------------------------------------------------------------------

    @Test
    void snapshotsLandInTheAuditTrail() throws SQLException {
        long wsId = worksheets.snapshotWorksheet(
                fy2026.id(), WorksheetService.WorksheetFormat.COLUMNS_13);
        long isId = worksheets.snapshotStatement(
                fy2026.id(), WorksheetService.ReportKind.INCOME_STATEMENT);
        long soceId = worksheets.snapshotStatement(
                fy2026.id(), WorksheetService.ReportKind.SOCE);
        long bsId = worksheets.snapshotStatement(
                fy2026.id(), WorksheetService.ReportKind.BALANCE_SHEET);

        Map<String, String> kinds = new HashMap<>();
        Map<String, String> payloads = new HashMap<>();
        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, kind, payload FROM report_snapshots ORDER BY id")) {
            while (rs.next()) {
                kinds.put(rs.getString("kind"), String.valueOf(rs.getLong("id")));
                payloads.put(rs.getString("kind"), rs.getString("payload"));
            }
        }
        assertEquals(String.valueOf(wsId), kinds.get("WORKSHEET"));
        assertEquals(String.valueOf(isId), kinds.get("INCOME_STATEMENT"));
        assertEquals(String.valueOf(soceId), kinds.get("SOCE"));
        assertEquals(String.valueOf(bsId), kinds.get("BALANCE_SHEET"));

        assertTrue(payloads.get("WORKSHEET").contains("\"ending_capital_cents\":8557800"));
        assertTrue(payloads.get("WORKSHEET").contains("\"net_income_cents\":3117800"));
        assertTrue(payloads.get("INCOME_STATEMENT").contains("\"net_income_cents\":3117800"));
        assertTrue(payloads.get("SOCE").contains("\"beginning_capital_cents\":0"));
        assertTrue(payloads.get("BALANCE_SHEET").contains("\"total_assets_cents\":8946800"));

        try (Connection con = database.open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT COUNT(*) FROM audit_log WHERE action = 'SNAPSHOT_REPORT'")) {
            assertTrue(rs.next());
            assertEquals(4, rs.getInt(1), "every snapshot writes its audit row");
        }
    }

    // ------------------------------------------------------------------
    // Error paths
    // ------------------------------------------------------------------

    @Test
    void unknownPeriodIsRejected() {
        assertThrows(NoSuchElementException.class,
                () -> worksheets.worksheet(99_999L, WorksheetService.WorksheetFormat.COLUMNS_13));
        assertThrows(NoSuchElementException.class,
                () -> worksheets.incomeStatement(99_999L));
        assertThrows(NoSuchElementException.class,
                () -> worksheets.equityChange(99_999L));
        assertThrows(NoSuchElementException.class,
                () -> worksheets.balanceSheet(99_999L));
        assertThrows(NoSuchElementException.class,
                () -> worksheets.snapshotWorksheet(99_999L,
                        WorksheetService.WorksheetFormat.COLUMNS_13));
    }

    @Test
    void formatParsesTheDatabaseSpellings() {
        assertEquals(WorksheetService.WorksheetFormat.COLUMNS_10,
                WorksheetService.WorksheetFormat.parse("10-column"));
        assertEquals(WorksheetService.WorksheetFormat.COLUMNS_13,
                WorksheetService.WorksheetFormat.parse("COLUMNS_13"));
        assertThrows(IllegalArgumentException.class,
                () -> WorksheetService.WorksheetFormat.parse("A4"));
    }
}
