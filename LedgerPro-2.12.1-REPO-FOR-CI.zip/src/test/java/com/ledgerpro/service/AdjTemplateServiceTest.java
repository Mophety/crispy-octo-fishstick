package com.ledgerpro.service;

import com.ledgerpro.db.Database;
import com.ledgerpro.model.Account;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-gate for recurring adjustment templates: the same double-entry
 * discipline as the journal, plus the upsert/list/instantiate lifecycle the
 * New-entry form depends on.
 */
class AdjTemplateServiceTest {

    @TempDir
    Path tmp;

    private Database db;
    private AdjTemplateService templates;
    private AccountService accounts;
    private long clientId;

    @BeforeEach
    void setUp() {
        db = new Database(tmp.resolve("t.db").toString());
        db.migrate();
        templates = new AdjTemplateService(db);
        accounts = new AccountService(db);
        ClientService clients = new ClientService(db);
        clientId = clients.create("ACME", "Acme Trading Corp.", "PHP").id();
        accounts.applyStandardChart(clientId);
    }

    private static AdjTemplateService.TemplateLine dr(String code, long cents, String memo) {
        return new AdjTemplateService.TemplateLine(0, code, "DR",
                AdjTemplateService.FIXED, centsString(cents), memo);
    }

    private static AdjTemplateService.TemplateLine cr(String code, long cents, String memo) {
        return new AdjTemplateService.TemplateLine(0, code, "CR",
                AdjTemplateService.FIXED, centsString(cents), memo);
    }

    private static String centsString(long cents) {
        return java.math.BigDecimal.valueOf(cents, 2).toPlainString();
    }

    // ------------------------------------------------------------------
    // Save / list / upsert
    // ------------------------------------------------------------------

    @Test
    void saveStoresLinesAndListReadsThemBack() {
        templates.save(clientId, "DEP_SL", "Monthly depreciation — straight line",
                "",
            List.of(dr("6400", 125_000L, "monthly depreciation"),
                        cr("1510", 125_000L, "accumulated depreciation")));

        List<AdjTemplateService.Template> listed = templates.list(clientId, "ACME");
        assertEquals(1, listed.size());
        AdjTemplateService.Template template = listed.getFirst();
        assertEquals("DEP_SL", template.code());
        assertEquals("Monthly depreciation — straight line", template.name());
        assertEquals(2, template.lines().size());
        assertEquals(125_000L, template.totalCents());
        assertEquals(false, template.shared());
    }

    @Test
    void savingTheSameCodeReplacesTheLines() {
        templates.save(clientId, "ACC_SAL", "Accrue December salaries",
                "",
            List.of(dr("6000", 500_000L, null), cr("2100", 500_000L, null)));
        templates.save(clientId, "ACC_SAL", "Accrue January salaries",
                "",
            List.of(dr("6000", 610_000L, null), cr("2100", 610_000L, null)));

        List<AdjTemplateService.Template> listed = templates.list(clientId, "ACME");
        assertEquals(1, listed.size(), "same scope + code = one template, updated");
        assertEquals("Accrue January salaries", listed.getFirst().name());
        assertEquals(610_000L, listed.getFirst().totalCents());
    }

    @Test
    void clientTemplatesAndSharedTemplatesCoexist() {
        templates.save(clientId, "DEP_SL", "Acme depreciation",
                "",
            List.of(dr("6400", 1L, null), cr("1510", 1L, null)));
        templates.save(null, "DEP_SL", "Firm-wide depreciation",
                "",
            List.of(dr("6400", 2L, null), cr("1510", 2L, null)));

        List<AdjTemplateService.Template> listed = templates.list(clientId, "ACME");
        assertEquals(2, listed.size(), "the client's own and the shared one both show");
        assertEquals("Acme depreciation", listed.get(0).name(),
                "client-scoped templates list first");
        assertEquals(false, listed.get(0).shared());
        assertEquals("Firm-wide depreciation", listed.get(1).name());
        assertTrue(listed.get(1).shared());
    }

    // ------------------------------------------------------------------
    // Validation
    // ------------------------------------------------------------------

    @Test
    void templatesMustBalance() {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> templates.save(clientId, "BAD1", "Unbalanced", "",
                        List.of(dr("6400", 100L, null), cr("1510", 90L, null))));
        assertTrue(e.getMessage().contains("balance"));
    }

    @Test
    void templatesNeedAtLeastTwoLines() {
        assertThrows(IllegalArgumentException.class,
                () -> templates.save(clientId, "BAD2", "Lonely line", "",
                        List.of(dr("6400", 100L, null))));
    }

    @Test
    void linesNeedExactlyOnePositiveSide() {
        assertThrows(IllegalArgumentException.class,
                () -> templates.save(clientId, "BAD3", "Both sides", "",
                        List.of(dr("6400", 100L, null),
                                new AdjTemplateService.TemplateLine(0, "1510", "SIDE",
                                        AdjTemplateService.FIXED, "1.00", null))));
        assertThrows(IllegalArgumentException.class,
                () -> templates.save(clientId, "BAD4", "Zero amount", "",
                        List.of(dr("6400", 0L, null), cr("1510", 0L, null))));
    }

    @Test
    void codesAndNamesAreValidated() {
        assertThrows(IllegalArgumentException.class,
                () -> templates.save(clientId, "", "Blank code", "",
                        List.of(dr("6400", 1L, null), cr("1510", 1L, null))));
        assertThrows(IllegalArgumentException.class,
                () -> templates.save(clientId, "has space", "Bad code shape", "",
                        List.of(dr("6400", 1L, null), cr("1510", 1L, null))));
        assertThrows(IllegalArgumentException.class,
                () -> templates.save(clientId, "OKCODE", "  ", "",
                        List.of(dr("6400", 1L, null), cr("1510", 1L, null))));
    }

    // ------------------------------------------------------------------
    // Instantiate + delete
    // ------------------------------------------------------------------

    @Test
    void instantiateResolvesCodesAgainstTheClientChart() {
        AdjTemplateService.Template saved = templates.save(clientId, "DEP_SL",
                "Monthly depreciation",
                "",
            List.of(dr("6400", 125_000L, "depreciation for the month"),
                        cr("1510", 125_000L, null)));

        List<Account> chart = accounts.list(clientId, false);
        List<AdjTemplateService.AppliedLine> applied =
                templates.instantiate(saved.id(), chart);

        assertEquals(2, applied.size());
        assertEquals("6400", applied.get(0).account().code());
        assertEquals(125_000L, applied.get(0).debitCents());
        assertEquals("depreciation for the month", applied.get(0).memo());
        assertEquals("1510", applied.get(1).account().code());
        assertEquals(125_000L, applied.get(1).creditCents());
    }

    @Test
    void instantiateRefusesWhenCodesAreMissingFromTheChart() {
        AdjTemplateService.Template saved = templates.save(clientId, "ODD1",
                "References an account this client lacks",
                "",
            List.of(dr("6400", 1L, null), cr("9999", 1L, null)));

        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> templates.instantiate(saved.id(), accounts.list(clientId, false)));
        assertTrue(e.getMessage().contains("9999"),
                "the missing code is named: " + e.getMessage());
    }

    @Test
    void deleteRemovesTemplateAndLines() {
        AdjTemplateService.Template saved = templates.save(clientId, "GONE1", "Disposable",
                "",
            List.of(dr("6400", 1L, null), cr("1510", 1L, null)));
        templates.delete(saved.id());
        assertEquals(0, templates.list(clientId, "ACME").size());
    }

    // ------------------------------------------------------------------
    // Audit trail
    // ------------------------------------------------------------------

    @Test
    void savingAndDeletingAreAudited() throws Exception {
        AdjTemplateService.Template saved = templates.save(clientId, "AUD1", "Audited",
                "",
            List.of(dr("6400", 1L, null), cr("1510", 1L, null)));
        templates.delete(saved.id());

        try (var con = db.open();
             var ps = con.prepareStatement(
                     "SELECT COUNT(*) FROM audit_log WHERE client_id = ?"
                             + " AND action IN ('SAVE_ADJ_TEMPLATE', 'DELETE_ADJ_TEMPLATE')")) {
            ps.setLong(1, clientId);
            try (var rs = ps.executeQuery()) {
                assertTrue(rs.next());
                assertEquals(2, rs.getInt(1));
            }
        }
    }
}
