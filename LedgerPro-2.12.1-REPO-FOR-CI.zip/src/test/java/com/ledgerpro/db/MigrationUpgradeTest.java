package com.ledgerpro.db;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The upgrade gate: databases created by OLDER LedgerPro builds must open and
 * upgrade cleanly under the current one — never the Flyway "checksum
 * mismatch" wall the field reported.
 *
 * <p>Three scenarios, exactly mirroring real machines:</p>
 * <ol>
 *   <li>a database left at V1 by the previous release: V2 + V3 apply on top,
 *       user data survives;</li>
 *   <li>a database whose recorded V1 checksum was perturbed (the reported
 *       crash): {@link Database#migrate()} repairs the history and boots
 *       instead of throwing;</li>
 *   <li>a fresh database: V1→V3 in one go, with V1's checksum identical to
 *       the one real user databases carry (flyway 10.20.1 arithmetic).</li>
 * </ol>
 */
class MigrationUpgradeTest {

    @TempDir
    Path tmp;

    /** The V1 checksum recorded in real users' databases. */
    private static final int V1_CHECKSUM_IN_THE_WILD = -565803941;

    // ------------------------------------------------------------------
    // 1) old database at V1 upgrades cleanly, data intact
    // ------------------------------------------------------------------

    @Test
    void v1DatabaseUpgradesToTheLatestSchemaWithoutLosingData() throws Exception {
        Path db = tmp.resolve("old.db");
        createV1OnlyDatabase(db);
        seedRealisticOldData(db);

        new Database(db.toString()).migrate();   // the new build's start path

        try (Connection con = new Database(db.toString()).open();
             Statement st = con.createStatement()) {
            // the two new schema objects exist
            try (ResultSet rs = st.executeQuery(
                    "SELECT name, chart_template FROM clients WHERE code = 'ACME'")) {
                assertTrue(rs.next(), "the pre-upgrade client row must survive");
                assertEquals("Acme Trading Corp.", rs.getString("name"));
                assertEquals(null, rs.getString("chart_template"),
                        "V2's new column reads as NULL on pre-upgrade rows");
            }
            try (ResultSet rs = st.executeQuery(
                    "SELECT COUNT(*) FROM adj_template_lines")) {
                assertTrue(rs.next());
                assertEquals(0, rs.getInt(1));
            }
            // and the migration history is complete
            try (ResultSet rs = st.executeQuery(
                    "SELECT MAX(version) FROM flyway_schema_history")) {
                assertTrue(rs.next());
                assertEquals("6", rs.getString(1));
            }
        }
    }

    // ------------------------------------------------------------------
    // 2) perturbed checksum heals instead of crashing
    // ------------------------------------------------------------------

    @Test
    void perturbedChecksumIsRepairedAndMigrationSucceeds() throws Exception {
        Path db = tmp.resolve("tampered.db");
        createV1OnlyDatabase(db);
        seedRealisticOldData(db);
        // simulate the field report: history says a checksum the shipped V1
        // does not produce any more
        try (Connection con = java.sql.DriverManager.getConnection("jdbc:sqlite:" + db);
             Statement st = con.createStatement()) {
            st.executeUpdate("UPDATE flyway_schema_history SET checksum = 111222333"
                    + " WHERE version = '1'");
        }

        // the old build DIED here with FlywayValidateException; this one heals
        new Database(db.toString()).migrate();

        try (Connection con = new Database(db.toString()).open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT checksum FROM flyway_schema_history WHERE version = '1'")) {
            assertTrue(rs.next());
            assertEquals(V1_CHECKSUM_IN_THE_WILD, rs.getInt(1),
                    "repair must realign the checksum with the shipped V1");
        }
    }

    // ------------------------------------------------------------------
    // 3) fresh databases get the exact checksum real ones carry
    // ------------------------------------------------------------------

    @Test
    void freshDatabaseRecordsTheInTheWildV1Checksum() throws Exception {
        Path db = tmp.resolve("fresh.db");
        new Database(db.toString()).migrate();

        try (Connection con = new Database(db.toString()).open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT checksum FROM flyway_schema_history WHERE version = '1'")) {
            assertTrue(rs.next());
            assertEquals(V1_CHECKSUM_IN_THE_WILD, rs.getInt(1),
                    "the shipped V1 must stay byte-identical to the release that"
                            + " created existing user databases");
        }

        // and every migration this build ships is applied
        try (Connection con = new Database(db.toString()).open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT version FROM flyway_schema_history ORDER BY installed_rank")) {
            Set<String> versions = new HashSet<>();
            while (rs.next()) {
                versions.add(rs.getString(1));
            }
            assertEquals(Set.of("1", "2", "3", "4", "5", "6"), versions);
        }
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    /**
     * Builds the database exactly the way the PREVIOUS release did: Flyway
     * 10.20.1 (the version that shipped) against a folder holding only V1.
     */
    private void createV1OnlyDatabase(Path db) throws Exception {
        Path v1Dir = tmp.resolve("v1-only");
        Files.createDirectories(v1Dir);
        try (var stream = getClass().getClassLoader().getResourceAsStream(
                "db/migration/V1__init_schema.sql")) {
            assertNotNull(stream, "V1 must be on the test classpath");
            Files.copy(stream, v1Dir.resolve("V1__init_schema.sql"),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        Flyway.configure()
                .dataSource("jdbc:sqlite:" + db, null, null)
                .locations("filesystem:" + v1Dir)
                .load()
                .migrate();
    }

    /** One client + one account, the way real data looks before an upgrade. */
    private void seedRealisticOldData(Path db) throws Exception {
        try (Connection con = java.sql.DriverManager.getConnection("jdbc:sqlite:" + db);
             Statement st = con.createStatement()) {
            st.executeUpdate("INSERT INTO clients(code, name, base_currency)"
                    + " VALUES ('ACME', 'Acme Trading Corp.', 'PHP')");
            st.executeUpdate("INSERT INTO accounts(client_id, code, name, type,"
                    + " normal_side) VALUES (1, '1010', 'Cash in Bank', 'ASSET', 'DEBIT')");
        }
    }
}
