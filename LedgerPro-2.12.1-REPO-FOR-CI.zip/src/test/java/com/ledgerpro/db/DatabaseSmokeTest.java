package com.ledgerpro.db;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Phase-1 gate: the database foundation must be provably correct before
 * anything is built on top of it.
 *
 * <p>Every test uses its own throwaway SQLite file in a JUnit {@code @TempDir},
 * so the suite never touches a real {@code data/ledgerpro.db}.</p>
 */
class DatabaseSmokeTest {

    @TempDir
    Path tmp;

    // ------------------------------------------------------------------
    // Schema
    // ------------------------------------------------------------------

    @Test
    void migrationsCreateEveryExpectedTable() throws Exception {
        Database db = newDb();
        db.migrate();

        Set<String> tables = new HashSet<>();
        try (Connection con = db.open();
             ResultSet rs = con.createStatement().executeQuery(
                     "SELECT name FROM sqlite_master WHERE type='table'")) {
            while (rs.next()) {
                tables.add(rs.getString(1));
            }
        }

        for (String expected : new String[]{
                "clients", "periods", "accounts", "journal_entries", "journal_lines",
                "ledger_balances", "tb_snapshots", "report_snapshots",
                "adj_templates", "fx_rates", "audit_log"}) {
            assertTrue(tables.contains(expected),
                    "expected table '" + expected + "' is missing");
        }
    }

    @Test
    void runningMigrationsTwiceIsSafe() {
        Database db = newDb();
        db.migrate(); // first run applies V1
        db.migrate(); // second run must be a clean no-op, never an error
    }

    // ------------------------------------------------------------------
    // Connection settings
    // ------------------------------------------------------------------

    @Test
    void journalModeIsWal() throws Exception {
        Database db = newDb();
        db.migrate();
        try (Connection con = db.open();
             ResultSet rs = con.createStatement().executeQuery("PRAGMA journal_mode")) {
            assertTrue(rs.next());
            assertEquals("wal", rs.getString(1).toLowerCase(),
                    "WAL must be active on every connection");
        }
    }

    @Test
    void foreignKeysAreEnforced() throws Exception {
        Database db = newDb();
        db.migrate();
        try (Connection con = db.open();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO periods(client_id, name, start_date, end_date)"
                             + " VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, 999999);             // no such client exists
            ps.setString(2, "FY2026");
            ps.setString(3, "2026-01-01");
            ps.setString(4, "2026-12-31");
            assertThrows(SQLException.class, ps::executeUpdate,
                    "foreign_keys pragma must be ON on every connection");
        }
    }

    // ------------------------------------------------------------------
    // Structural guards on journal lines
    // ------------------------------------------------------------------

    @Test
    void journalLineCannotHaveNeitherDebitNorCredit() throws Exception {
        Database db = newDb();
        db.migrate();

        try (Connection con = db.open()) {
            long clientId = insert(con, "INSERT INTO clients(code, name)"
                    + " VALUES ('T1', 'Test Client')");
            long periodId = insert(con,
                    "INSERT INTO periods(client_id, name, start_date, end_date)"
                            + " VALUES (" + clientId + ", 'FY2026',"
                            + " '2026-01-01', '2026-12-31')");
            long accountId = insert(con,
                    "INSERT INTO accounts(client_id, code, name, type, normal_side)"
                            + " VALUES (" + clientId + ", '1010', 'Cash',"
                            + " 'ASSET', 'DEBIT')");
            long entryId = insert(con,
                    "INSERT INTO journal_entries(client_id, period_id, entry_no,"
                            + " entry_date) VALUES (" + clientId + ", " + periodId
                            + ", 1, '2026-01-05')");

            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO journal_lines(entry_id, account_id) VALUES (?, ?)")) {
                ps.setLong(1, entryId);
                ps.setLong(2, accountId);
                assertThrows(SQLException.class, ps::executeUpdate,
                        "a journal line must be a debit OR a credit - never neither");
            }
        }
    }

    // ------------------------------------------------------------------
    // Plain CRUD round trip
    // ------------------------------------------------------------------

    @Test
    void clientRoundTripWorks() throws Exception {
        Database db = newDb();
        db.migrate();
        try (Connection con = db.open()) {
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO clients(code, name) VALUES (?, ?)")) {
                ps.setString(1, "ACME");
                ps.setString(2, "Acme Trading Corp.");
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT name, base_currency FROM clients WHERE code = ?")) {
                ps.setString(1, "ACME");
                try (ResultSet rs = ps.executeQuery()) {
                    assertTrue(rs.next());
                    assertEquals("Acme Trading Corp.", rs.getString(1));
                    assertEquals("PHP", rs.getString(2)); // column default
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    /** Fresh Database pointing at a file inside this test's temp dir. */
    private Database newDb() {
        return new Database(tmp.resolve("test.db").toString());
    }

    /**
     * Executes an INSERT on the given connection and returns the generated
     * row id. Must run on the SAME connection as the insert, because
     * {@code last_insert_rowid()} is per-connection in SQLite.
     */
    private long insert(Connection con, String sql) throws SQLException {
        try (Statement st = con.createStatement()) {
            st.executeUpdate(sql);
            try (ResultSet rs = st.executeQuery("SELECT last_insert_rowid()")) {
                rs.next();
                return rs.getLong(1);
            }
        }
    }
}
