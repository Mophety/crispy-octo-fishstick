package com.ledgerpro.db;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 2.11.2: a packaged (jpackage) app must always keep its books under
 * {@code ~/.ledgerpro}, never in whatever writable working directory it
 * happened to be started from.
 */
class DatabaseDefaultPathTest {

    private String savedDb;
    private String savedPackaged;

    @BeforeEach
    void remember() {
        savedDb = System.getProperty("ledgerpro.db");
        savedPackaged = System.getProperty("jpackage.app-path");
        System.clearProperty("ledgerpro.db");
    }

    @AfterEach
    void restore() {
        restoreProperty("ledgerpro.db", savedDb);
        restoreProperty("jpackage.app-path", savedPackaged);
    }

    private static void restoreProperty(String key, String value) {
        if (value == null) {
            System.clearProperty(key);
        } else {
            System.setProperty(key, value);
        }
    }

    @Test
    void packagedAppAlwaysUsesTheUserHomeFolder() {
        // ignore the LEDGERPRO_DB env override: this test is about the default
        org.junit.jupiter.api.Assumptions.assumeTrue(
                System.getenv("LEDGERPRO_DB") == null
                        || System.getenv("LEDGERPRO_DB").isBlank());
        System.setProperty("jpackage.app-path", "/Applications/LedgerPro.app");
        String expected = Paths.get(System.getProperty("user.home"),
                ".ledgerpro", "ledgerpro.db").toString();
        assertEquals(expected, Database.defaultDbPath());
    }

    @Test
    void explicitPropertyStillWinsEvenWhenPackaged() {
        System.setProperty("jpackage.app-path", "/Applications/LedgerPro.app");
        System.setProperty("ledgerpro.db", "/tmp/custom-ledgerpro.db");
        assertEquals("/tmp/custom-ledgerpro.db", Database.defaultDbPath());
    }

    @Test
    void developmentRunsKeepThePortableDataFolder() {
        org.junit.jupiter.api.Assumptions.assumeTrue(
                System.getenv("LEDGERPRO_DB") == null
                        || System.getenv("LEDGERPRO_DB").isBlank());
        System.clearProperty("jpackage.app-path");
        String path = Database.defaultDbPath();
        // writable working dir -> data/ledgerpro.db; read-only -> user home
        assertTrue(path.endsWith("ledgerpro.db"), path);
    }
}
