package com.ledgerpro.db;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The regression gate for the field report this SchemaGuard exists for: a
 * database created by the OTHER 2.x build line — the one whose clients table
 * has {@code tax_id} and no {@code code} — crashed the app at startup with
 * {@code no such column: code} after Flyway's repair masked the lineage
 * difference. That database must now open with every row preserved.
 *
 * <p>Scenarios:</p>
 * <ol>
 *   <li><b>divergent lineage</b>: the old shape is created exactly the way
 *       the other build did (its own V1–V3 files), filled with realistic
 *       data including a flag-voided entry, then opened through
 *       {@link Database#migrate()} — data survives, mirrors are synthesized,
 *       the original file is kept as a backup;</li>
 *   <li><b>unrecognised lineage</b>: a clients table from no known build —
 *       the app still opens, starting clean with the original preserved;</li>
 *   <li><b>current lineage</b>: untouched by the guard (Flyway handles it).</li>
 * </ol>
 */
class SchemaGuardTest {

    @TempDir
    Path tmp;

    // ------------------------------------------------------------------
    // 1) the reported crash: divergent lineage opens with data intact
    // ------------------------------------------------------------------

    @Test
    void divergentLineageDatabaseOpensWithAllDataPreserved() throws Exception {
        Path db = tmp.resolve("field-report.db");
        createLegacyDatabase(db);
        seedLegacyData(db);

        new Database(db.toString()).migrate();

        assertNotNull(SchemaGuard.lastNotice(), "the reconciliation tells its story");
        assertTrue(Files.exists(backupOf(db)), "the original file is preserved");
        assertTrue(SchemaGuard.lastNotice().contains("preserved"));

        try (Connection con = new Database(db.toString()).open();
             Statement st = con.createStatement()) {

            // clients: derived code + carried tax id + base currency
            try (ResultSet rs = st.executeQuery(
                    "SELECT code, name, base_currency, tax_id, is_setup FROM clients")) {
                assertTrue(rs.next());
                assertEquals("NRT", rs.getString("code"), "code derived from the name");
                assertEquals("Northwind Retail Trading", rs.getString("name"));
                assertEquals("PHP", rs.getString("base_currency"));
                assertEquals("123-456-789-000", rs.getString("tax_id"));
                assertEquals(1, rs.getInt("is_setup"), "chart + period = set up");
            }

            // accounts: renamed classification columns mapped
            try (ResultSet rs = st.executeQuery(
                    "SELECT type, normal_side, is_permanent FROM accounts"
                            + " WHERE code = '1010'")) {
                assertTrue(rs.next());
                assertEquals("ASSET", rs.getString("type"));
                assertEquals("DEBIT", rs.getString("normal_side"));
                assertEquals(1, rs.getInt("is_permanent"));
            }

            // periods: CLOSED status and closed_at survive
            try (ResultSet rs = st.executeQuery(
                    "SELECT status, closed_at FROM periods WHERE name = 'FY 2026'")) {
                assertTrue(rs.next());
                assertEquals("CLOSED", rs.getString("status"));
                assertNotNull(rs.getString("closed_at"));
            }

            // journal entries: sequential numbers, reference, posted state
            try (ResultSet rs = st.executeQuery(
                    "SELECT entry_no, reference, posted, posted_at, type FROM journal_entries"
                            + " ORDER BY entry_no")) {
                List<Integer> numbers = new ArrayList<>();
                int normal = 0;
                while (rs.next()) {
                    numbers.add(rs.getInt("entry_no"));
                    if ("NORMAL".equals(rs.getString("type"))) {
                        normal++;
                        assertEquals(1, rs.getInt("posted"));
                        assertNotNull(rs.getString("posted_at"));
                        if (rs.getInt("entry_no") == 1) {
                            assertEquals("CAP-001", rs.getString("reference"));
                        }
                    }
                }
                assertEquals(List.of(1, 2, 3), numbers,
                        "1 capital + 1 prepaid + 1 synthesized void mirror");
                assertEquals(2, normal);
            }

            // the flag-voided entry now has a REVERSING mirror cancelling it
            try (ResultSet rs = st.executeQuery(
                    "SELECT COUNT(*) FROM journal_entries WHERE type = 'REVERSING'"
                            + " AND void_of_id = 2 AND posted = 1"
                            + " AND memo LIKE 'VOID of entry #%'")) {
                assertTrue(rs.next());
                assertEquals(1, rs.getInt(1));
            }

            // journal lines: transaction-currency trail carried over
            try (ResultSet rs = st.executeQuery(
                    "SELECT line_no, debit_cents, credit_cents, txn_currency,"
                            + " txn_debit_cents, txn_credit_cents, fx_rate"
                            + " FROM journal_lines WHERE entry_id = 1 ORDER BY line_no")) {
                assertTrue(rs.next());
                assertEquals(1, rs.getInt("line_no"));
                assertEquals(500_000_00L, rs.getLong("debit_cents"));
                assertEquals("USD", rs.getString("txn_currency"));
                assertEquals(10_000_00L, rs.getLong("txn_debit_cents"));
                assertEquals(50.0, rs.getDouble("fx_rate"), 1e-9);
            }

            // fx rates: pair shape with a note
            try (ResultSet rs = st.executeQuery(
                    "SELECT base_currency, quote_currency, rate_date, rate, note"
                            + " FROM fx_rates")) {
                assertTrue(rs.next());
                assertEquals("PHP", rs.getString("base_currency"));
                assertEquals("USD", rs.getString("quote_currency"));
                assertEquals("2026-01-02", rs.getString("rate_date"));
                assertEquals(50.0, rs.getDouble("rate"), 1e-9);
            }

            // adjustment templates: new line shape, formula preserved
            try (ResultSet rs = st.executeQuery(
                    "SELECT t.code, l.side, l.amount_source, l.value"
                            + " FROM adj_templates t JOIN adj_template_lines l"
                            + " ON l.template_id = t.id ORDER BY l.line_no")) {
                assertTrue(rs.next());
                assertEquals("MD", rs.getString("code"), "code derived from the template name");
                assertEquals("DR", rs.getString("side"));
                assertEquals("FORMULA", rs.getString("amount_source"));
                assertEquals("5% * BAL(1100)", rs.getString("value"));
            }

            // ledger balances recomputed from the migrated journal: account 3
            // (prepaid rent) carries the voided entry's debit AND the mirror's
            // credit, and both count as "regular" movement
            try (ResultSet rs = st.executeQuery(
                    "SELECT debit_total_cents, credit_total_cents, regular_dr, regular_cr"
                            + " FROM ledger_balances WHERE period_id = 1 AND account_id = 3")) {
                assertTrue(rs.next());
                assertEquals(120_000_00L, rs.getLong("debit_total_cents"));
                assertEquals(120_000_00L, rs.getLong("credit_total_cents"),
                        "the mirror cancels the voided debit exactly");
                assertEquals(120_000_00L, rs.getLong("regular_dr"));
                assertEquals(120_000_00L, rs.getLong("regular_cr"));
            }

            // the reconciliation itself is in the audit trail
            try (ResultSet rs = st.executeQuery(
                    "SELECT COUNT(*) FROM audit_log WHERE action = 'SCHEMA_RECONCILED'")) {
                assertTrue(rs.next());
                assertEquals(1, rs.getInt(1));
            }

            // and the schema history is genuine and complete
            try (ResultSet rs = st.executeQuery(
                    "SELECT MAX(version) FROM flyway_schema_history")) {
                assertTrue(rs.next());
                assertEquals("6", rs.getString(1));
            }
        }
    }

    // ------------------------------------------------------------------
    // 2) unrecognised lineage: opens clean, original preserved
    // ------------------------------------------------------------------

    @Test
    void unrecognisedLineageStartsCleanWithTheOriginalPreserved() throws Exception {
        Path db = tmp.resolve("alien.db");
        try (Connection con = DriverManager.getConnection("jdbc:sqlite:" + db);
             Statement st = con.createStatement()) {
            st.executeUpdate("CREATE TABLE clients (id INTEGER PRIMARY KEY, name TEXT)");
            st.executeUpdate("INSERT INTO clients(name) VALUES ('from no known build')");
        }

        new Database(db.toString()).migrate();

        assertNotNull(SchemaGuard.lastNotice());
        assertTrue(SchemaGuard.lastNotice().contains("preserved"),
                "the notice names the backup: " + SchemaGuard.lastNotice());
        assertTrue(Files.exists(backupOf(db)));
        try (Connection con = new Database(db.toString()).open();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM clients")) {
            assertTrue(rs.next());
            assertEquals(0, rs.getInt(1), "the fresh schema starts empty");
        }
    }

    // ------------------------------------------------------------------
    // 3) current lineage: the guard does not touch it
    // ------------------------------------------------------------------

    @Test
    void currentLineageIsLeftToFlyway() throws Exception {
        Path db = tmp.resolve("current.db");
        new Database(db.toString()).migrate();
        assertEquals(null, SchemaGuard.lastNotice());
        assertEquals(null, backupOf(db), "no backup is made for a current-lineage database");
    }

    // ------------------------------------------------------------------
    // helpers: build the OTHER build line's database exactly
    // ------------------------------------------------------------------

    private void createLegacyDatabase(Path db) throws Exception {
        Path legacyDir = tmp.resolve("legacy200");
        Files.createDirectories(legacyDir);
        for (String name : new String[]{
                "V1__init_schema.sql", "V2__chart_templates.sql", "V3__adj_templates.sql"}) {
            try (var stream = getClass().getClassLoader().getResourceAsStream(
                    "db/legacy200/" + name)) {
                assertNotNull(stream, name + " must be on the test classpath");
                Files.copy(stream, legacyDir.resolve(name),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        }
        Flyway.configure()
                .dataSource("jdbc:sqlite:" + db, null, null)
                .locations("filesystem:" + legacyDir)
                .load()
                .migrate();
    }

    /** The shape of the data the other build really wrote. */
    private void seedLegacyData(Path db) throws Exception {
        try (Connection con = DriverManager.getConnection("jdbc:sqlite:" + db);
             Statement st = con.createStatement()) {
            st.executeUpdate("INSERT INTO clients(name, tax_id, currency, chart_template_id)"
                    + " VALUES ('Northwind Retail Trading', '123-456-789-000', 'PHP', 1)");
            st.executeUpdate("INSERT INTO chart_templates(name, description)"
                    + " VALUES ('Standard chart', '54 accounts')");
            // two chart rows are enough to prove the mapping
            st.executeUpdate("INSERT INTO chart_template_accounts(template_id, code, name,"
                    + " account_type, normal_balance, is_permanent, line_no)"
                    + " VALUES (1, '1010', 'Cash', 'ASSET', 'DR', 1, 1),"
                    + " (1, '1020', 'Bank', 'ASSET', 'DR', 1, 2)");
            st.executeUpdate("INSERT INTO accounts(client_id, code, name, account_type,"
                    + " normal_balance, is_permanent, is_retained_earnings, parent_id,"
                    + " is_active, created_at) VALUES"
                    + " (1, '1010', 'Cash', 'ASSET', 'DR', 1, 0, NULL, 1, '2026-01-01 00:00:00'),"
                    + " (1, '3010', 'Capital', 'EQUITY', 'CR', 1, 0, NULL, 1, '2026-01-01 00:00:00'),"
                    + " (1, '1300', 'Prepaid rent', 'ASSET', 'DR', 1, 0, NULL, 1, '2026-01-01 00:00:00')");
            st.executeUpdate("INSERT INTO periods(client_id, label, start_date, end_date,"
                    + " status, created_at, closed_at) VALUES"
                    + " (1, 'FY 2026', '2026-01-01', '2026-12-31', 'CLOSED',"
                    + " '2026-01-01 00:00:00', '2027-01-09 00:00:00')");

            // a posted base-currency entry
            st.executeUpdate("INSERT INTO journal_entries(id, client_id, period_id, entry_date,"
                    + " reference, description, entry_type, status, void_of_id, created_at)"
                    + " VALUES (1, 1, 1, '2026-01-05', 'CAP-001', 'Initial investment',"
                    + " 'NORMAL', 'POSTED', NULL, '2026-01-05 00:00:00')");
            st.executeUpdate("INSERT INTO journal_lines(entry_id, line_no, account_id,"
                    + " currency, fx_rate, foreign_cents, debit_cents, credit_cents, memo)"
                    + " VALUES (1, 1, 1, 'USD', 50.0, 1000000, 50000000, 0, ''),"
                    + " (1, 2, 2, 'USD', 50.0, 1000000, 0, 50000000, '')");

            // a VOIDED entry with NO mirror — the other build voided by flag
            st.executeUpdate("INSERT INTO journal_entries(id, client_id, period_id, entry_date,"
                    + " reference, description, entry_type, status, void_of_id, created_at)"
                    + " VALUES (2, 1, 1, '2026-02-10', 'CHK-9', 'Duplicate payment',"
                    + " 'NORMAL', 'VOIDED', NULL, '2026-02-10 00:00:00')");
            st.executeUpdate("INSERT INTO journal_lines(entry_id, line_no, account_id,"
                    + " currency, fx_rate, foreign_cents, debit_cents, credit_cents, memo)"
                    + " VALUES (2, 1, 3, 'PHP', 1.0, 12000000, 12000000, 0, ''),"
                    + " (2, 2, 1, 'PHP', 1.0, 12000000, 0, 12000000, '')");

            st.executeUpdate("INSERT INTO fx_rates(client_id, currency, rate, source,"
                    + " rate_date, created_at) VALUES (1, 'USD', 50.0, 'MANUAL',"
                    + " '2026-01-02', '2026-01-02 00:00:00')");

            st.executeUpdate("INSERT INTO adj_templates(name, description, is_active)"
                    + " VALUES ('Monthly depreciation', '5 percent of AR', 1)");
            st.executeUpdate("INSERT INTO adj_template_lines(template_id, line_no,"
                    + " account_code, side, amount_source, value) VALUES"
                    + " (1, 1, '5400', 'DR', 'FORMULA', '5% * BAL(1100)'),"
                    + " (1, 2, '1110', 'CR', 'FORMULA', '5% * BAL(1100)')");

            st.executeUpdate("INSERT INTO ledger_balances(client_id, period_id, account_id,"
                    + " opening_cents, regular_dr, regular_cr, adjusting_dr, adjusting_cr,"
                    + " closing_dr, closing_cr, updated_at) VALUES"
                    + " (1, 1, 2, 0, 0, 0, 0, 0, 0, 0, '2026-01-05 00:00:00')");

            st.executeUpdate("INSERT INTO report_snapshots(client_id, period_id,"
                    + " report_type, data_json, generated_at) VALUES"
                    + " (1, 1, 'CHANGES_IN_EQUITY', '{}', '2026-06-30 00:00:00')");

            st.executeUpdate("INSERT INTO audit_log(client_id, period_id, action, entity_type,"
                    + " entity_id, details_json, created_at) VALUES"
                    + " (1, 1, 'CREATE_ENTRY', 'ENTRY', 1, '{}', '2026-01-05 00:00:00')");
        }
    }

    private Path backupOf(Path db) {
        try (var stream = Files.list(db.getParent())) {
            return stream.filter(p -> p.getFileName().toString().startsWith(
                            db.getFileName().toString() + ".backup-"))
                    .findFirst().orElse(null);
        } catch (Exception e) {
            return null;
        }
    }
}
