-- LedgerPro V2 — selectable chart-of-accounts templates

CREATE TABLE chart_templates (
  id           INTEGER PRIMARY KEY,
  name         TEXT NOT NULL UNIQUE,
  description  TEXT NOT NULL DEFAULT ''
);

CREATE TABLE chart_template_accounts (
  id             INTEGER PRIMARY KEY,
  template_id    INTEGER NOT NULL REFERENCES chart_templates(id) ON DELETE CASCADE,
  code           TEXT NOT NULL,
  name           TEXT NOT NULL,
  account_type   TEXT NOT NULL CHECK (account_type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE')),
  normal_balance TEXT NOT NULL CHECK (normal_balance IN ('DR','CR')),
  is_permanent   INTEGER NOT NULL DEFAULT 1,
  line_no        INTEGER NOT NULL DEFAULT 0,
  UNIQUE (template_id, code)
);

ALTER TABLE clients ADD COLUMN chart_template_id INTEGER REFERENCES chart_templates(id);
