-- LedgerPro V3 — recurring adjustment templates

CREATE TABLE adj_templates (
  id           INTEGER PRIMARY KEY,
  name         TEXT NOT NULL,
  description  TEXT NOT NULL DEFAULT '',
  is_active    INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE adj_template_lines (
  id             INTEGER PRIMARY KEY,
  template_id    INTEGER NOT NULL REFERENCES adj_templates(id) ON DELETE CASCADE,
  line_no        INTEGER NOT NULL,
  account_code   TEXT NOT NULL,
  side           TEXT NOT NULL CHECK (side IN ('DR','CR')),
  amount_source  TEXT NOT NULL CHECK (amount_source IN ('FIXED','FORMULA')),
  value          TEXT NOT NULL DEFAULT ''    -- "1250.00" for FIXED; "5% * BAL(1100)" for FORMULA
);

ALTER TABLE journal_entries ADD COLUMN adj_template_id INTEGER REFERENCES adj_templates(id);
