-- LedgerPro V1 — core accounting schema (11 tables)
-- All monetary amounts are integer cents. Dates are ISO-8601 TEXT.

CREATE TABLE clients (
  id          INTEGER PRIMARY KEY,
  name        TEXT NOT NULL UNIQUE,
  tax_id      TEXT NOT NULL DEFAULT '',
  currency    TEXT NOT NULL DEFAULT 'PHP',
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE accounts (
  id                  INTEGER PRIMARY KEY,
  client_id           INTEGER NOT NULL REFERENCES clients(id),
  code                TEXT NOT NULL,
  name                TEXT NOT NULL,
  account_type        TEXT NOT NULL CHECK (account_type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE')),
  normal_balance      TEXT NOT NULL CHECK (normal_balance IN ('DR','CR')),
  is_permanent        INTEGER NOT NULL DEFAULT 1,
  is_retained_earnings INTEGER NOT NULL DEFAULT 0,
  parent_id           INTEGER REFERENCES accounts(id),
  is_active           INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (client_id, code)
);

CREATE TABLE periods (
  id          INTEGER PRIMARY KEY,
  client_id   INTEGER NOT NULL REFERENCES clients(id),
  label       TEXT NOT NULL,
  start_date  TEXT NOT NULL,
  end_date    TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','POSTED','CLOSED')),
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  closed_at   TEXT
);

CREATE TABLE journal_entries (
  id           INTEGER PRIMARY KEY,
  client_id    INTEGER NOT NULL REFERENCES clients(id),
  period_id    INTEGER NOT NULL REFERENCES periods(id),
  entry_date   TEXT NOT NULL,
  reference    TEXT NOT NULL DEFAULT '',
  description  TEXT NOT NULL DEFAULT '',
  entry_type   TEXT NOT NULL CHECK (entry_type IN ('NORMAL','ADJUSTING','CLOSING','REVERSING')),
  status       TEXT NOT NULL DEFAULT 'POSTED' CHECK (status IN ('POSTED','VOIDED')),
  void_of_id   INTEGER REFERENCES journal_entries(id),
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_entries_period ON journal_entries(period_id);
CREATE INDEX idx_entries_client ON journal_entries(client_id);

CREATE TABLE journal_lines (
  id             INTEGER PRIMARY KEY,
  entry_id       INTEGER NOT NULL REFERENCES journal_entries(id),
  line_no        INTEGER NOT NULL,
  account_id     INTEGER NOT NULL REFERENCES accounts(id),
  currency       TEXT NOT NULL,
  fx_rate        REAL NOT NULL DEFAULT 1.0 CHECK (fx_rate > 0),
  foreign_cents  INTEGER NOT NULL DEFAULT 0,
  debit_cents    INTEGER NOT NULL DEFAULT 0,
  credit_cents   INTEGER NOT NULL DEFAULT 0,
  memo           TEXT NOT NULL DEFAULT '',
  UNIQUE (entry_id, line_no)
);
CREATE INDEX idx_lines_entry ON journal_lines(entry_id);
CREATE INDEX idx_lines_account ON journal_lines(account_id);

CREATE TABLE ledger_balances (
  id             INTEGER PRIMARY KEY,
  client_id      INTEGER NOT NULL REFERENCES clients(id),
  period_id      INTEGER NOT NULL REFERENCES periods(id),
  account_id     INTEGER NOT NULL REFERENCES accounts(id),
  opening_cents  INTEGER NOT NULL DEFAULT 0,
  regular_dr     INTEGER NOT NULL DEFAULT 0,
  regular_cr     INTEGER NOT NULL DEFAULT 0,
  adjusting_dr   INTEGER NOT NULL DEFAULT 0,
  adjusting_cr   INTEGER NOT NULL DEFAULT 0,
  closing_dr     INTEGER NOT NULL DEFAULT 0,
  closing_cr     INTEGER NOT NULL DEFAULT 0,
  updated_at     TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (period_id, account_id)
);
CREATE INDEX idx_ledger_balances_period ON ledger_balances(period_id);

CREATE TABLE tb_snapshots (
  id            INTEGER PRIMARY KEY,
  client_id     INTEGER NOT NULL REFERENCES clients(id),
  period_id     INTEGER NOT NULL REFERENCES periods(id),
  tb_type       TEXT NOT NULL CHECK (tb_type IN ('UNADJUSTED','ADJUSTED','POST_CLOSING')),
  total_debit   INTEGER NOT NULL,
  total_credit  INTEGER NOT NULL,
  is_balanced   INTEGER NOT NULL,
  generated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE tb_snapshot_lines (
  id            INTEGER PRIMARY KEY,
  snapshot_id   INTEGER NOT NULL REFERENCES tb_snapshots(id),
  account_id    INTEGER NOT NULL REFERENCES accounts(id),
  debit_cents   INTEGER NOT NULL DEFAULT 0,
  credit_cents  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE report_snapshots (
  id            INTEGER PRIMARY KEY,
  client_id     INTEGER NOT NULL REFERENCES clients(id),
  period_id     INTEGER NOT NULL REFERENCES periods(id),
  report_type   TEXT NOT NULL CHECK (report_type IN ('INCOME_STATEMENT','CHANGES_IN_EQUITY','BALANCE_SHEET')),
  data_json     TEXT NOT NULL,
  generated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE audit_log (
  id            INTEGER PRIMARY KEY,
  client_id     INTEGER NOT NULL,
  period_id     INTEGER,
  action        TEXT NOT NULL,
  entity_type   TEXT NOT NULL,
  entity_id     INTEGER,
  details_json  TEXT NOT NULL DEFAULT '{}',
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_audit_client ON audit_log(client_id);

-- Multi-currency support (retained per user requirement)
CREATE TABLE fx_rates (
  id          INTEGER PRIMARY KEY,
  client_id   INTEGER REFERENCES clients(id),   -- NULL = shared across clients
  currency    TEXT NOT NULL,
  rate        REAL NOT NULL CHECK (rate > 0),    -- base-currency units per 1 unit of `currency`
  source      TEXT NOT NULL CHECK (source IN ('MANUAL','FRANKFURTER')),
  rate_date   TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_fx_currency ON fx_rates(currency);
