# LedgerPro — run it on macOS and Windows

Two ways to get the app running. **Way 1 needs no Java installed at all** —
the bundles carry their own Java 21 runtime and all platform natives.

## Way 1 — run the ready-made bundle (fastest)

| Your machine                        | Download                     | Size  |
|-------------------------------------|------------------------------|-------|
| macOS 13+ on Intel x64 (your Mac)   | `LedgerPro-macOS-Intel.zip`  | ~68 MB |
| Windows 10/11 x64                   | `LedgerPro-Windows-x64.zip`  | ~84 MB |

### macOS (Ventura 13, Intel Core i5, 8 GB — your machine)

1. Unzip `LedgerPro-macOS-Intel.zip` (double-click; Archive Utility keeps
   the executable bits and symlinks intact).
2. Move `LedgerPro.app` wherever you like — `Applications`, `Desktop`, …
3. **First launch only:** right-click `LedgerPro.app` → **Open** →
   **Open**. Gatekeeper flags the app because it is unsigned (no Apple
   Developer ID was used to build it). Every launch after that is a
   plain double-click.
4. Optional sample data — client "NRTH" with a complete FY2026 journal,
   worksheet and statements:
   ```sh
   /Applications/LedgerPro.app/Contents/MacOS/LedgerPro --demo
   ```
   (adjust the path if you put the app elsewhere; it never overwrites an
   existing database)

If the right-click → Open dance ever fails, remove the quarantine flag
once and open normally:
```sh
xattr -dr com.apple.quarantine /Applications/LedgerPro.app
```

### Windows

1. Unzip `LedgerPro-Windows-x64.zip` (right-click → **Extract All**).
2. Open the `LedgerPro` folder it created.
3. Double-click **`LedgerPro.bat`**. SmartScreen may show "Windows
   protected your PC" — click **More info → Run anyway** (normal for
   unsigned `.bat` launchers).

Also in the folder:

| File                    | What it does                                        |
|-------------------------|-----------------------------------------------------|
| `LedgerPro-demo.bat`    | starts the app with the sample data ("NRTH", FY2026) |
| `LedgerPro-debug.bat`   | same app but with a console window showing the logs  |

### Where your data lives

- macOS: `~/.ledgerpro/ledgerpro.db`
- Windows: `%USERPROFILE%\.ledgerpro\ledgerpro.db`

Delete that file to start fresh. The packaged `.exe` / `.app` always uses
this location, however it was started. (Only a *development* run from a
writable terminal folder prefers `data/ledgerpro.db` in that folder.)
**Upgrading from 2.11.1 or earlier:** older packaged builds could create the
database in the folder they were launched from (`data\ledgerpro.db` next to the
app, or on the Desktop). If your books look empty after updating, copy that
`ledgerpro.db` (and `ledgerpro.db-wal` / `-shm` if present) to the folder above
while the app is closed. The app is otherwise fully
offline; only the FX view's "Fetch from Frankfurter" button uses the
internet.

## Way 2 — build the app yourself, from source

Apple and Microsoft don't allow building native app bundles for their
OSes *from another OS*, so each machine builds its own — it's one command:

```sh
# one-time prerequisites:
#   JDK 21+     https://adoptium.net/temurin/releases/?version=21
#               (macOS x64 .pkg on an Intel Mac; Windows x64 .msi)
#   Maven 3.9+  brew install maven   |   choco install maven

unzip LedgerPro-phase5-verified.zip && cd ledgerpro

./packaging/build-macos.sh             # → target/dist/LedgerPro.app
./packaging/build-macos.sh --dmg       # … plus a drag-install .dmg
```
```powershell
# Windows (PowerShell), after unzipping the source zip:
.\packaging\build-windows.ps1          # → target\dist\LedgerPro\LedgerPro.exe
.\packaging\build-windows.ps1 -Msi     # .msi installer (needs WiX on PATH)
```

Behind the wrappers: `mvn -Pdist package` — the full test suite runs
first, then jpackage wraps the app plus a trimmed Java 21 runtime into a
native application image (a real `.exe` launcher on Windows, a proper
`.app` bundle with `Info.plist` on macOS).

## Way 3 — let GitHub build the real `.exe` and Intel `.app` for you

No JDK or Maven on your machine: the workflow in
`.github/workflows/build-installers.yml` builds each app on its own operating
system and hands you the files.

1. Put the project in a GitHub repository (a private one works).
2. Open the repository's **Actions** tab → **Build installers** →
   **Run workflow**.
3. When it finishes (about 5-10 minutes), open the run and download from
   **Artifacts**: `LedgerPro-Windows-x64` (contains `LedgerPro.exe`),
   `LedgerPro-macOS-Intel` (contains `LedgerPro.app`) and, if those optional
   steps succeeded, `LedgerPro-Windows-msi` and `LedgerPro-macOS-dmg`.

The Mac job runs on GitHub's Intel runner (`macos-15-intel`), which GitHub plans
to retire in fall 2027; after that, build on your own Intel Mac with Way 2.

## Performance notes for the 1.6 GHz dual-core i5 / 8 GB Mac

- The app runs comfortably: local SQLite (WAL), no server, heap capped
  at 512 MB, all data operations are millisecond-scale.
- Expect **~3–6 s cold start** on the dual-core (JVM + JavaFX boot), then
  navigation is instant. Idle memory footprint ≈ 300–400 MB.
- Building from source (Way 2) takes roughly 5–10 minutes on that
  machine; close browsers/heavy apps during the build if it feels slow.
- Graphics: JavaFX 21 draws through its OpenGL pipeline on macOS (the Metal
  pipeline only arrived in later JavaFX releases), which works fine on the
  Intel UHD 617. If anything ever draws oddly, force software rendering —
  in `LedgerPro.app/Contents/MacOS/LedgerPro` add `-Dprism.order=sw`
  before `-cp` (self-built app: edit
  `LedgerPro.app/Contents/app/LedgerPro.cfg` → `[JavaOptions]` →
  `java-options=-Dprism.order=sw`).

## Troubleshooting

| Symptom                              | Fix                                                        |
|--------------------------------------|------------------------------------------------------------|
| "can't be opened / unidentified developer" (mac) | right-click → Open → Open; or the `xattr` command above |
| "app is damaged" (mac)               | same `xattr` command, then double-click                    |
| No window appears (win)              | run `LedgerPro-debug.bat` and read the console output      |
| Want logs on mac                     | run `LedgerPro.app/Contents/MacOS/LedgerPro` from Terminal |
| Demo data didn't appear              | it never overwrites — delete `~/.ledgerpro/ledgerpro.db` first |
| Reset everything                     | delete `~/.ledgerpro` (mac) / `%USERPROFILE%\.ledgerpro` (win) |
| JDK version errors when building     | check `java -version` says 21 or newer; see the Adoptium link above |

## What was verified (2026-11-15, on the Linux build host — 2.6.0)

- 149/149 tests green; full `mvn clean package` from a Java 21+ JDK.
- 2.6.0 specifics, all verified on this machine:
  - **The Settings dialog's layout** — captured headless and measured:
    544×745 px on a 1280×820 window (the 2.5.0 panel was tight and
    unpadded); its slider drag, live Reset and the dashboard-refresh
    setting are covered by 19 new unit tests.
  - **The live dashboard** — booted the app with the exact module-path
    recipe the bundles ship, waited through several refresh ticks, and
    took a thread dump: the `dashboard-live-refresh` daemon present and
    healthy, zero exceptions in the log. The period-selector row and the
    live header render in the captures at three window sizes.
  - **F5** re-reads the visible view (dashboard or any table) — wired
    through the same shortcut filter that guards text inputs.
- 2.5.0 specifics, all verified on this machine:
  - **Silent launch** — the app was booted with the exact module-path
    recipe the bundles ship (`--module-path <javafx> --add-modules
    javafx.controls` + app on the classpath): zero "unnamed module"
    lines in the startup output (2.4.0 printed one on every launch),
    and the bundle's own Linux launcher boots it end-to-end the same
    way.
  - **The client dashboard's charts** — headless captures at three
    window sizes show the trend chart, the expense pie and the balance
    bars rendering real data (colored-pixel ratios measured in the
    chart band); the responsive text measured 40 → 43 → 53 ink rows
    at 85% / 100% / 130%.
  - **The worksheet's 10-column Changes-in-Equity cells** carry their
    amounts (regression-tested at the service layer and captured
    headless); its sort cycle asc → desc → paper order is live in the
    running app.
- The **exact bundle recipe** used for the macOS/Windows zips (script
  launcher + official Temurin 21 JRE + app jars on the classpath +
  JavaFX on the module path + `Launcher` booting JavaFX) was executed
  on Linux: the app booted through that recipe's own runtime.
- 2.4.0/2.3.2/2.3.1 fixes carry on: ledger/trial-balance money columns
  render (screenshot-vs-service), maximized windows use the full space,
  the macOS launcher auto-detects both JRE layouts, the Add-client
  hints render verbatim in every theme.
- macOS/Windows bundle structure machine-checked: zip integrity,
  `Mach-O x86_64` / `PE32+ x86-64` runtime binaries, per-platform
  JavaFX natives present (and Linux natives absent), CRLF `.bat` files,
  executable launcher bit preserved.

## 2.12.1 — headless verification harness (dev)

The dev harness under `src/test/java/com/ledgerpro/dev/` renders the
real UI headless (Monocle, software pipeline) and is how every phase
was verified:

- `DashboardScaleSnapshots` — the dashboard at 100%/130% × four window
  sizes; PNG + scene-text dump per capture.
- `JournalScaleSnapshots` — the journal + sidebar at 100%/130% × three
  window sizes, with the full C1/C2 seed (including the user's own
  draft entries, untouched).
- `JournalToolbarProbe` — per-button width vs. text measurement (how the
  130% toolbar clipping was found).

Run them through the exec plugin (scope test), e.g.:

    mvn -o exec:java -Ddb.cli.class=com.ledgerpro.dev.JournalScaleSnapshots \
        -Dexec.classpathScope=test -Dexec.args="/tmp/probe.db /tmp/out" \
        -Dglass.platform=Monocle -Dmonocle.platform=Headless -Dprism.order=sw
