#!/usr/bin/env bash
# ============================================================================
#  LedgerPro 2.12.1 — macOS packaging (jpackage, bundled JDK 21 runtime +
#  JavaFX 21.0.5 modules). Run ON the Mac (Intel or Apple Silicon; the
#  CI runner is macos-15-intel — GitHub retired macos-13 on 2025-12-04).
#
#  What it builds (pick one):
#    app-image (default)  -> target/dist/LedgerPro.app   (double-clickable)
#    dmg                  -> target/dist/LedgerPro-2.12.1.dmg (disk image
#                            the user drags into /Applications)
#
#  Requirements on YOUR Mac:
#    1. JDK 21 (Temurin) installed and JAVA_HOME set.
#    2. Maven 3.9+ on PATH.
#    3. Xcode command-line tools (for hdiutil / codesign): run
#         xcode-select --install
#       once if needed. Nothing else — dmg needs no extra tool.
#
#  Usage:
#    ./build-macos.sh              (LedgerPro.app)
#    ./build-macos.sh dmg          (LedgerPro-2.12.1.dmg)
#
#  Unsigned-app note: Gatekeeper will quarantine the app on first launch
#  ("cannot be opened because the developer cannot be verified") —
#  right-click LedgerPro.app > Open > Open (or System Settings > Privacy &
#  Security > "Open Anyway"). Details in PACKAGING-NOTES.md.
# ============================================================================
set -euo pipefail

TYPE="${1:-app-image}"
case "$TYPE" in
  app-image|dmg) ;;
  *) echo "[error] unknown type '$TYPE' (use app-image or dmg)"; exit 2 ;;
esac

if [ -z "${JAVA_HOME:-}" ]; then
  echo "[error] JAVA_HOME is not set (install Temurin JDK 21 first)"; exit 2
fi
command -v mvn >/dev/null || { echo "[error] mvn not on PATH"; exit 2; }

echo "[1/2] building the jar and staging jpackage input..."
mvn -Pdist package -Djpackage.type="$TYPE" -DskipTests

echo "[2/2] result:"
ls -la target/dist/

cat <<'EOF'

Done. First launch of the unsigned app: right-click LedgerPro.app >
Open > Open (Gatekeeper; see PACKAGING-NOTES.md).
EOF
