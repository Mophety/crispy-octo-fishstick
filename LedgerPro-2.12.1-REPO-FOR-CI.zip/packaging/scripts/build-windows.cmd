@echo off
rem ============================================================================
rem  LedgerPro 2.12.1 — Windows packaging (jpackage, bundled JDK 21 runtime
rem  + JavaFX 21.0.5 modules). Plain .cmd, no PowerShell assumptions.
rem
rem  What it builds (pick one):
rem    app-image (default)  -> target\dist\LedgerPro\        (folder with
rem                             LedgerPro.exe + the runtime; zip it and ship)
rem    msi                   -> target\dist\LedgerPro-2.12.1.msi (installer;
rem                             needs the WiX toolset on PATH, see gotchas)
rem    exe                   -> target\dist\LedgerPro-2.12.1.exe (installer;
rem                             ALSO WiX-based: jpackage's only .exe flavor)
rem
rem  Requirements on YOUR Windows machine (or a windows-latest runner):
rem    1. JDK 21 (Temurin) installed and JAVA_HOME set to it.
rem    2. Maven 3.9+ on PATH (or edit MAVEN below to its full path).
rem    3. Nothing else for app-image. For msi/exe: WiX 3.14 installed and
rem       its bin folder on PATH (https://github.com/wixtoolset/wix3).
rem
rem  Usage:
rem    build-windows.cmd                (app-image)
rem    build-windows.cmd msi             (installer)
rem    build-windows.cmd exe             (installer)
rem
rem  Unsigned-app note: Windows SmartScreen will warn on first run of the
rem  .exe/.msi ("unknown publisher"). Click "More info" > "Run anyway".
rem Details in PACKAGING-NOTES.md.
rem ============================================================================
setlocal enabledelayedexpansion

set TYPE=%1
if "%TYPE%"=="" set TYPE=app-image
if "%TYPE%"=="msi" goto :check
if "%TYPE%"=="exe" goto :check
if "%TYPE%"=="app-image" goto :check
echo [error] unknown type "%TYPE%" (use app-image, msi or exe)
exit /b 2

:check
if "%JAVA_HOME%"=="" (
    echo [error] JAVA_HOME is not set ^(install Temurin JDK 21 first^)
    exit /b 2
)
where mvn >nul 2>nul
if errorlevel 1 (
    echo [error] mvn not on PATH ^(install Apache Maven 3.9+^)
    exit /b 2
)
if not "%TYPE%"=="app-image" (
    where light.exe >nul 2>nul
    if errorlevel 1 (
        echo [error] %TYPE% needs the WiX 3.14 toolset ^(light.exe^) on PATH
        exit /b 2
    )
)

echo [1/2] building jar + jpackage input + image (type "%TYPE%") ...
call mvn -Pdist package -Djpackage.type=%TYPE% -DskipTests
if errorlevel 1 goto :fail

echo [2/2] result:
dir target\dist

echo.
echo Done. Unsigned app: expect the SmartScreen "More info ^> Run anyway"
echo dance on first launch ^(see PACKAGING-NOTES.md^).
exit /b 0

:fail
echo [error] build failed — see the Maven/jpackage output above.
exit /b 1
