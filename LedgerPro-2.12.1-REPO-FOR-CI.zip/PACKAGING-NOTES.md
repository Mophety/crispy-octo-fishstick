# Packaging LedgerPro 2.12.1 — short guide for a first-time GitHub Actions user

## Can this be built in the dev sandbox? No.

The sandbox is Linux-only: jpackage exists (21.0.13) but it can only
bundle the platform it runs on — a Linux runtime, not a Windows .exe or
an Intel-Mac .app, and there is no WiX/hdiutil/codesign toolchain here.
So this package delivers **build scripts + CI workflow + instructions**
instead of built binaries; the CI build is where the real .exe and .app
come from.

## Repo build status (verified before shipping)

The full pipeline was re-run in the sandbox before this package was
assembled: `mvn -Pdist package` with tests — **190/190 green, 0
failures** — then a Linux app-image smoke-launch: the packaged
launcher starts, JavaFX initializes from the classpath jars, and it
stops only at "Unable to open DISPLAY" (headless sandbox, not a
defect). What GitHub's runners will execute is therefore the same
proven command, on real Windows/macOS hardware.

## What you got

```
packaging/
  icons/               icon.ico, icon.icns, icon.png (copied from src/main/resources/icons)
  scripts/
    build-windows.cmd   jpackage build for Windows: app-image (default) / msi / exe
    build-macos.sh      jpackage build for macOS:   .app (default) / .dmg
.github/workflows/
  package-desktop.yml  GitHub Actions: Windows app-image + Intel-mac .app/.dmg
PACKAGING-NOTES.md     this file
```

Both scripts call the existing `mvn -Pdist package` profile — the pom
already stages every runtime jar (JavaFX 21.0.5 natives included, they
are matched to the build platform automatically), copies the app jar,
and drives `jpackage` with the right icon, `-Xmx512m`, `-XX:+UseSerialGC`
and `--enable-native-access=ALL-UNNAMED`. The bundles therefore carry
the exact JDK 21 runtime of the machine that builds them, and JavaFX
21.0.5's platform-matching jars. Maven is preinstalled on GitHub's
runners, so the workflow only sets up the JDK. On the Mac the workflow
runs BOTH passes — `build-macos.sh app-image` (leaves `LedgerPro.app`
in `target/dist`) and `build-macos.sh dmg` — because a `.dmg`-type
jpackage run leaves only the `.dmg` in the output folder (the `.app`
sits in a staging dir); the app-image pass is what puts the
double-clickable `.app` next to it.

## Running it yourself on your own machine (no GitHub needed)

Windows (in the project folder, JDK 21 + Maven installed):

    packaging\scripts\build-windows.cmd             → target\dist\LedgerPro\
    packaging\scripts\build-windows.cmd msi         → target\dist\LedgerPro-2.12.1.msi (needs WiX 3.14 on PATH)

macOS (in Terminal, JDK 21 + Maven + command-line tools installed):

    ./packaging/scripts/build-macos.sh               → target/dist/LedgerPro.app
    ./packaging/scripts/build-macos.sh dmg           → target/dist/LedgerPro-2.12.1.dmg

## GitHub Actions, step by step (never used it before? this is all of it)

1. **Push the project to GitHub.** Create a repository (green "New"
   button on github.com), then — in the project folder —
   `git remote add origin <the URL git gives you>` and
   `git push -u origin main`. If you cloned from GitHub originally,
   this is already done.
2. **Put the files where GitHub sees them.** This package's files are
   already inside the repo working tree (`.github/workflows/…`,
   `packaging/…`), so a commit and push is enough:
   `git add .github packaging && git commit -m "packaging" && git push`.
   GitHub only runs workflows that are committed on the default branch.
3. **Open the Actions tab** on your repository page (top row,
   "Actions"). Left sidebar: "package-desktop". Click it, then the big
   **"Run workflow"** button → "Run workflow". That's the manual trigger
   (`workflow_dispatch`) — no tag needed. (Pushing a tag `v2.12.1`
   also triggers it: `git tag v2.12.1 && git push --tags`.)
4. **Watch the run.** A run appears with two jobs, `windows` and
   `macos-intel`. Click either to see its steps live. Green check =
   done (~10–15 min).
5. **Download the apps.** At the bottom of the finished run page,
   "Artifacts" lists `LedgerPro-2.12.1-windows-x64` and
   `LedgerPro-2.12.1-macos-intel`. Click either to download the zip.
   On the run page itself the artifacts stay downloadable for 90 days.
6. Notes on the runner: `windows-latest` = x64; `macos-15-intel` is
   GitHub's **Intel** runner — it replaced `macos-13`, which GitHub
   retired on 2025-12-04 (macos-14+ is ARM — do not switch, the
   artifact would not run on your Intel Mac).

## Known gotchas — unsigned apps (this build signs nothing)

**Windows SmartScreen** — the first launch of an unsigned `.exe` shows
"Windows protected your PC". Click **More info** → **Run anyway**.
For the `.msi` installer, the same, and it also needs WiX 3.14 on PATH
when building. The zip-unblocked note applies too: before extracting,
right-click the zip → Properties → check **Unblock** (or the .exe keeps
the mark-of-the-web and re-warns). These warnings repeat for each
machine/user that downloads the app fresh; they are cosmetic, not
malware. Real fix someday: a code-signing certificate (~$100+/yr, OV
still gets the initial warning; EV removes it) — not needed for a
class project.

**macOS Gatekeeper** — first launch of the unsigned `.app` shows
"LedgerPro cannot be opened because the developer cannot be
verified". Two ways past it:
- **Right-click** `LedgerPro.app` → **Open** → **Open** (the Open
  button appears only in the right-click menu, not in a normal
  double-click), or
- after a failed double-click: **System Settings → Privacy & Security
  → "Open Anyway"**. Once per Mac, then it remembers.
The `.dmg` itself may also be flagged — the same right-click dance on
the mounted installer if needed. On Sequoia+, the right-click option
sometimes doesn't appear: use the Privacy & Security route.

**Your Mac (1.6 GHz dual-core i5, 8 GB RAM)** — the app is already
tuned for it, nothing to change:
- `-Xmx512m` heap + `-XX:+UseSerialGC` (single-threaded GC — on 2 cores
  the parallel collector's threads cost more than they win) are baked
  into the jpackage launcher by the pom's dist profile.
- First launch takes 15–30 s (the runtime unpacks + first JavaFX
  paint on a slow CPU); later launches are quicker. Do not panic at
  the bouncing dock icon.
- JavaFX software pipeline: this app renders with the GPU-less-safe
  path on old Intel GPUs (Mac OS disables OpenGL acceleration for
  legacy Intel iGPUs on macOS 12+). It runs; it is not fast. If a
  window looks odd, the app's Settings → Interface has theme/density
  options that lighten the draw.
- 8 GB RAM is fine: the capped heap is 512 MB and the SQLite data is
  tiny. macOS itself will happily use the rest.
- If the .dmg mounts read-only "verification" slowly on that CPU,
  just copy the .app out of it once and keep it in /Applications.
