# Changelog

All notable changes to LedgerPro are documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/);
releases follow semantic versioning. 1.x releases predate this file.

## 2.12.1 — 2026-11-25

The layout truth pass: the dashboard, the journal and the shell verified
headless at real window sizes and text scales (100% and 130%), with the
defects that verification exposed fixed on the spot. Four phases (charts,
dashboard layout, journal/sidebar, docs). No schema change, no
accounting-logic change; 190/190 tests green (184 carried + 6 new/
updated contracts).

### Fixed — measurement and layout truths
- **UiSizing.em() ignored the text scale** (all phases): the em helper
  fell back to the JVM's 13 px platform default instead of the scene
  root's scaled font — every em-based breakpoint (combo caps, column
  bands) sat at the wrong size at 130%. Now it resolves the root's CSS
  font-size (14 px @100%, 18.2 px @130% verified).
- **Journal row factory dropped "table-row-cell"** (P4): setAll()
  removed the skin class, losing row height/padding/hover/selection.
  Zebra stripes restored; rows em-padded (readable at 130%).
- **Journal toolbar clipped at 130%** (P4): three rows now (create+period,
  entry+output, filters), verified unclipped at 1100x700..1680x1050.
- **The client switcher clipped at 130%** (P4): fixed 330 px pref →
  fitWidestItem (26 em cap).
- **Journal column bands sized at the wrong font** (P4): the em bands
  re-apply on scene-shown and scale change.
- **Empty-state hint clipped** (P4): wraps now.

### Added — the journal reads like a journal (P4)
- Status pills (Posted green / Draft amber / Voided red), amounts
  right-aligned with tabular digits, memo struck through on voided rows,
  full-text memo tooltips, em-sized Ref/Type/Period/FX bands.
- "New entry" is the single primary (accent) button; groups divided by
  thin rules; Paper explained by a tooltip.
- The formal banner ("Journal — CODE · Name · Reports in CUR") and a
  cleaner footer; the status-bar shortcut hint shortened behind a
  tooltip; No/Date sortable.
- The sidebar is a flat nav list with an accent-bar selected state.

### Packaging (final step)
- Windows/macOS packaging scripts (`packaging/scripts/build-windows.cmd`,
  `build-macos.sh`) over the existing `dist` profile, a GitHub Actions
  workflow (windows-latest + macos-15-intel; macos-13 was retired by
  GitHub on 2025-12-04) that builds and uploads
  app-images, and `PACKAGING-NOTES.md` — first-timer CI steps and the
  unsigned-app gotchas (SmartScreen, Gatekeeper). The dist profile was
  smoke-tested in-sandbox with a Linux app-image: the packaged launcher
  boots and JavaFX initializes from the classpath jars.

### Dashboard (P3)
- Header-row layout feedback loop removed (period combo sizes to its
  widest item, 22 em cap; labels never truncate).
- The page scrolls (fitToWidth ScrollPane); card rows re-flow
  (ResponsiveGrid) instead of squeezing; recent-entries table shows
  full dates/amounts, whole rows only.
- The four KPI cards share one height, one number size, two-line
  subtitle floor.

## 2.12.0 — 2026-11-24

The UI/UX overhaul: a design-token pass over every view and dialog, WCAG
AA fixes for the dark themes, keyboard-first quality-of-life features,
and the journal's reads moved off the JavaFX thread. No schema change, no
accounting-logic change; 184/184 tests green (181 carried over + 3 new).

### Added
- **Command palette (Ctrl/Cmd+K).** One searchable list over views,
  clients and actions (new entry, new client, backup, settings) —
  keyboard-first, flat-styled, inherits the live theme.
- **One-click backup / restore (Settings → Data).** `VACUUM INTO`
  snapshots (consistent under WAL) into ~/.ledgerpro/backups with
  timestamped names; restore verifies the file, replaces the live
  database and re-migrates older backups to the current schema. Covered
  by BackupServiceTest (3 tests).
- **Duplicate entry.** The journal's "Duplicate…" opens the New-entry
  dialog prefilled with the selected entry's type, memo, currency and
  lines (today's date, reference cleared).
- **CSV exports for the trial balance and the general ledger** — same
  cents-integer convention as the journal export, with totals rows.

### Changed — design system (Phase 1)
- One documented token set (spacing 4/8/12/16/20/24/32; radii 4/6/8; six
  type steps; semantic colors mapped onto the palette) in ledgerpro.css.
  JavaFX CSS lookups resolve only for Paint, so sizes/type are literals by
  convention, documented at the top of the stylesheet.
- All 16 leftover inline `setStyle` calls removed — status cells render
  through one shared `StatusText` factory and `lp-status-*` classes, so a
  theme switch can never leave stale colors. The db-status dot and the
  database-failure scene follow suit.
- Every view's empty state built by one `EmptyState` builder (glyph,
  title, hint) through the shared `lp-empty-*` classes.
- The status bar wears its own class with the hairline on TOP (it was the
  top bar's class, painting the border below it).
- The card focus ring is a 2px border, not a three-pass dropshadow
  (cheap on integrated GPUs). The duplicated journal hover rule removed.

### Changed — themes (Phase 2)
- **Nord Dark AA overlay**: muted ink lifted to #B7BFCC (Nord's own snow
  ramp) — the palette's 3.78:1 on the sidebar surface was below the WCAG
  AA 4.5:1 bar for real text. fg-subtle consumers migrated to fg-muted.
- New ThemeCycleCheck (dev tool) walks all six themes on a live scene and
  proves each repaints its own colors — no stale frames, no blanks.

### Changed — UX (Phase 3)
- Malformed amounts flagged inline (danger border on the offending field)
  in the entry dialog; dialogs land focus on their primary input; the
  Ctrl+N shortcut no longer double-refreshes the journal; the status bar
  hint advertises Ctrl/Cmd+K.

### Changed — performance (Phase 5)
- The journal's reads (register + ENTRY_LINES expansion) run on a single
  background reader (UiLoad) with an epoch guard: a client switch
  mid-read can never paint the previous client's rows, and the FX thread
  no longer blocks on the read. On a 2,000-entry year the read is ~80 ms
  off-thread; the synchronous refresh of every view stays under ~80 ms
  (ViewTimingProbe, 10 views).
- The FX-responsiveness check (dev tool) keeps a heartbeat on the FX
  thread while all ten views load; worst gap on software rendering is the
  first layout pulse, not data.

### Fixed
- `UiSnapshotSeed` wrote fx_rates rows with the date in base_currency and
  the currency in rate_date (dev-seed only, but it crashed
  FxRateService.mapRow on the FX view).
- Theme javadoc/declaration cleanup (stacked duplicate doc comment).

## 2.11.2 — 2026-11-22

The packaging release: real, branded desktop apps, one data-location fix,
and the demo books loadable from Settings. No schema or service changes.

### Added
- **Settings → Data → Load demo data.** The demo books (Northwind Retail
  Trading, FY2026) can now be loaded from the Settings dialog itself — no
  need to know the separate LedgerPro-demo launcher exists. The button is
  enabled only while the database has no clients AT ALL (the demo never
  mixes itself into real books), asks for confirmation first, and refreshes
  the client switcher, working client and every visible view immediately — no
  restart. Covered by the new headless `SettingsDemoDataCheck`.

### Fixed
- **Demo-data button could lie after a client was archived.** The button's
  enable guard keyed on ACTIVE clients only, while the seeding guard
  (`DemoData.seedIfEmpty`) keys on ANY client row — archived included, since
  an archived client still owns journal entries, FX snapshots and shared
  adjustment templates. Archiving the one and only client therefore left
  the button enabled; the seed silently skipped and the dialog reported
  "loaded" anyway. Both guards now share `DemoData.canSeed` (any client row,
  archived included), `seedIfEmpty` returns whether it actually seeded,
  and the dialog says "Demo skipped — move or rename
  ~/.ledgerpro/ledgerpro.db and start again" when the guard refuses. The
  `--demo` launcher flag reports the same skip honestly. The archived-only
  client scenario is pinned in `SettingsDemoDataCheck`.
- **Packaged app wrote its database to the launch folder.** `Database` preferred
  a writable `data/` folder in the working directory, which for a double-clicked
  `.exe` / `.app` is whichever folder it was started from (the app folder, the
  Desktop, a shortcut's "Start in"), so the same install could show different —
  apparently empty — books depending on how it was opened. jpackage launchers
  (detected via the `jpackage.app-path` property) now always use
  `~/.ledgerpro/ledgerpro.db`; development runs keep `data/`. Covered by the new
  `DatabaseDefaultPathTest` (3 tests). An existing database in an old launch
  folder is not moved automatically: see BUILD-AND-RUN.md.
- Docs: the JavaFX 21 renderer on macOS is OpenGL (not Metal); stale test counts
  removed from the build scripts and BUILD-AND-RUN.md.

### Changed — packaging (`mvn -Pdist package`)
- The Windows `.exe` and the macOS `.app` now carry the LedgerPro icon (`.ico`
  / `.icns` chosen by OS profile) and vendor/description metadata; before, they
  shipped the default Java icon.
- The packaged JVM runs with the serial GC and no perf-data file
  (`-XX:+UseSerialGC -XX:-UsePerfData`), better suited to 2-core machines.
- New GitHub Actions workflow (`.github/workflows/build-installers.yml`) builds
  the Windows `.exe` (+ optional `.msi`) and the macOS Intel `.app` (+ optional
  `.dmg`) on the target operating systems. See BUILD-AND-RUN.md, "Way 3".

## 2.11.1 — 2026-11-22

The ledgers-look release: the journal's register now wears the same design
language as the Ledgers tab (the look the user pointed at): the Amount
column renders bold success-green money figures — the exact treatment the
ledger's green running Balance column gets — through a new
`lp-col-money-strong` CSS class on the column, so every theme re-tints it
with its own success hue (measured: 2,107–2,406 visible green/teal figure
pixels across all six themes), and the Entry No column takes the ledger's
strong-ink treatment. Every 2.11.0 readability fix stays: theme-safe bold
status classes, the two-row never-truncating toolbar, capped and
proportioned dashboard charts. 178/178 tests green.

Context worth recording: the second screenshot batch (4:09–4:10 PM) showed
the same defects as the first because every shot carried the 2.10.0 build's
pixel fingerprint — a single-row toolbar, the wide blue element, uncapped
charts, and status strips pixel-identical to the first batch's. The 2.11.0
bundles delivered in `download/` were disassembled and verified to contain
all the fixes. This release adds the ledgers look on top.

## 2.11.0 — 2026-11-22

The readability release: every defect the user's four screenshots showed —
the journal status text turning near-invisible on dark themes, toolbar
buttons truncating their labels with an ellipsis, the balance bar chart
growing into a giant column, and the expense pie left tiny — is fixed at
root cause and verified with per-theme measurements. No schema, service or
data changes; a pure UI/UX release.

### Fixed — what the screenshots proved (each pixel-measured first)
- **Journal status text on dark themes**: the 2.10.0 inline `setStyle`
  colors resolved against the cell's own style and could ride near-background
  hues after a theme switch — the user's dark screenshot showed a 6-of-255
  luminance gap (mud-green on near-black). The register's status cells now
  use CSS classes (`lp-status-ok` / `-void` / `-draft`, scoped to table
  cells) with palette-variable colors and BOLD text: classes re-resolve
  through the scene's stylesheets on ThemeManager's re-pass, so a theme
  switch can never leave a stale color, and bold strokes no longer vanish.
  Verified per theme: all six themes now measure a text-vs-background
  luminance gap of 102–159 of 255 with thousands of visible status pixels.
- **Toolbar buttons truncating labels**: the 2.10.0 toolbar was one HBox
  row carrying eight buttons plus the search box, the status combo, a
  caption and the period combo (~1550 px at the design size) — on the
  user's window, three labels ended in literal ellipsis glyphs. The toolbar
  is now TWO rows (actions, then filters), every button and combo pinned to
  its computed size (min = computed, so a label can never be squeezed), the
  search box is the single flexible element, and the layout toggle
  shortens to Paper / Register with the full description in its tooltip.
  Re-tested with the same glyph detector that found the user's three
  truncations: zero true positives remain in any theme.
- **The giant bar chart**: the dashboard's bottom chart row held the only
  vertical growth, and the balance bar chart inside its card had no height
  cap — on the user's tall window it rendered 612 logical px tall while
  everything else stayed put. Every chart now carries a height cap
  (trend/pie 420, balance bars 360), and BOTH chart rows share the window's
  extra height.
- **The tiny pie**: the expense pie had a 280 px minimum and no growth
  share. It now measures 720×300 on the same window where it used to
  render small (minimum width 300, preferred width tracked to its card),
  and its slice labels print in the theme's default foreground so they stay
  readable on dark themes (the muted fill rendered them near-invisible).

### Verification
- 177/177 tests green (172 + 5 new: two-row toolbar structure, computed-size
  button invariants, status-class wiring through the real cell factory,
  chart caps and pie minimum via the live nodes).
- Headless captures: the journal in ALL SIX themes (contrast measured per
  theme), the dashboard on Primer Light and Primer Dark at the user's
  1680×1050 aspect (chart bounds read from the live scene graph:
  line 536×300, pie 720×300, bars 660×280), and the toolbar band run
  through the user's own ellipsis-glyph detector.

## 2.10.0 — 2026-11-22

The journal-restoration release: the journal tab returns to the 2.3.1
design — the flat, clean register — as the default, plus five performance
improvements in the journal's hot paths, four bug fixes (including a real
stale-period-filter defect the new test caught), and a set of daily-use
features: search, status filtering, a footer that describes exactly what is
on screen, CSV export, and keyboard navigation. One additive migration
(V6); no column changes.

### Changed — the 2.3.1 journal design restored as the default
- **The journal opens in REGISTER mode again**: one row per entry,
  uniform row backgrounds with the table skin's own hairline separators,
  and a status column of plain colored text (palette green for Posted, red
  for Voided, muted grey for Draft) — the exact look of the 2.3.1 register,
  verified pixel-for-pixel against a headless reference capture (one
  uniform row color, zero alternation, no badge fills in the status
  column). The 2.8.0 decorations are removed from the register: no zebra
  stripes, no hover fills, no status pills. The 2.7.0 voided dimming stays.
- The paper journal (Dr/Cr lines with the '# memo' rows) remains one
  toolbar toggle away and fully unchanged; the choice persists. Users who
  explicitly chose it keep their stored preference — only the factory
  default (and the parse fallback) changed.

### Fixed — the stale period filter (a real defect, caught by the new test)
- After switching working clients, the period combo kept the previous
  client's period as its VALUE even though that id no longer existed in
  the items: the combo rendered an empty selection while `getValue()`
  still returned the dead period, so the table filtered on an id that
  could not match anything until the user re-picked. The fix clears the
  value outright (`setValue(null)` — a ComboBox KEEPS its value after
  `clearSelection()`, which was the trap). Also fixed: the empty state no
  longer leaves the last client's banner and footer text behind; the
  amount column header initializes from the working client on first
  paint; the lines-mode context-menu actions route through the
  mode-aware selection so a selection left in the hidden register table
  can never act on the wrong entry.

### Performance — the journal's hot paths
- **O(1) row lookups**: a map of entry id → summary built once per reload
  replaces the linear scan that ran per style callback and per selection
  lookup (O(n²) on a full year).
- **One batched lines read**: `JournalService.linesForEntries(clientId)`
  loads every entry's lines in ONE SQL pass (joined to accounts, grouped
  by entry id) — the paper mode previously issued one query per entry,
  hundreds of round trips on a full year. The per-entry `lines()` remains
  for the single-entry detail dialog.
- **journal_lines entry index**: additive Flyway V6 creates
  `idx_journal_lines_entry` on `journal_lines(entry_id, line_no)` — the
  lines table had no entry_id index (V5 indexed journal_entries and
  ledger_balances only), so every lines read scanned the table. The
  migration is IF NOT EXISTS: idempotent, safe on every existing 2.x
  database.
- **ThreadLocal money formatters**: the visible-cell format path no
  longer constructs a fresh DecimalFormat per paint pass — one
  thread-confined instance per pattern serves the render thread.
- **Single-pass footer statistics**: counts and posted volume compute in
  the same pass over the filtered rows that paints the table (three
  separate stream passes before).

### Added — daily-use features in the journal
- **Search box** (memo text, reference text, entry-number prefix): live
  filtering over the cached rows — typing costs no database round trip.
- **Status filter** (All / Draft / Posted / Voided), composing with the
  period filter and the search box.
- **The footer describes what you see**: the statistics line counts the
  FILTERED set and appends the active period's name, so the numbers
  always match the table on screen.
- **Export CSV…**: writes the filtered register (entry number, date,
  type, reference, memo, period, currency and rate, base amount,
  status) to a user-chosen file, UTF-8, quoted fields, default name
  `journal-CODE-YYYYMMDD.csv`.
- **Enter** opens the selected entry's lines (matching double-click);
  **F5** forces a reload — the dashboard's own convention.

### Tests
- 172/172 green: the 164 existing plus 8 new — the batch loader's
  equivalence against the per-entry loader (rows, order, grouping,
  client scoping), the V6 index presence, the filter composition and
  footer math, the restored default and row classes, and the stale-period
  client switch. The suite now tolerates multiple FX-booting classes in
  one surefire fork (no `Platform.exit()` between classes).

## 2.9.0 — 2026-11-21

The feedback release: five fixes and upgrades that came straight out of
field-testing 2.8.0 — the journal opens in the professional paper-book
layout by default, switching themes no longer breaks the look, the
dashboard's charts clear when the working client changes, clients can be
edited, the dashboard's graphs carry their numbers on their face, and
the big dialogs (the entry window above all) are resizable. No database
change.

### Changed — the journal opens as the paper book (the layout request)
- **The journal's default layout is now ENTRY_LINES — the paper
  bookkeeping look** the user asked for: each entry unfolds into its
  debit and credit lines (account code — account name in the Account
  column, the amount in the Dr or the Cr column), and after the last line
  an indented '# memo' row carries the explanation, exactly the way a
  manual journal notes it. The register (one dense row per entry) is
  still there — **a toolbar toggle ("View as register" / "View as paper
  journal") swaps them in one click**, and the choice persists like
  every other setting. The paper mode also gained Type and Period
  columns on each entry's first line, so a group reads as a complete
  record without opening the detail dialog.
- Rationale: 2.8.0 shipped this layout but hid it in Settings →
  Workspace, so the default register looked "the same as before" and the
  redesign never surfaced. The 2.7.0 register users remembered liking
  was the same flat table as the 2.8.0 default — the paper book is what
  "the good one" was expected to be.

### Fixed — switching themes broke the app's appearance
- **Root cause**: swapping the AtlantaFX user-agent stylesheet re-styles
  controls in principle, but JavaFX keeps per-node resolved-style caches
  that a user-agent swap does not always invalidate — after a few
  switches, parts of the app wore stale colors, washed-out pills and
  dead hover states (worst on Alexia's overlay theme, which re-tints on
  top of the palette).
- **Fix**: `ThemeManager.apply` now walks EVERY live window after the
  swap — the argument scene first, then every showing stage — and calls
  `applyCss()` on each root, the documented idiom that clears the
  resolved-style caches and re-runs the whole CSS pass. The overlay
  list is re-asserted on every scene in the same pass. Result: every
  theme switch repaints every open window fully in the new palette,
  including the sidebar, the tables and the dialogs.

### Fixed — the line graph did not disappear when the client changed
- Two defects compounded: (1) when a live-refresh read was already in
  flight (the 15-second timer racing a client switch), the switch's own
  refresh was silently dropped — with live refresh Off it never re-ran,
  so the previous client's trend chart stayed on screen indefinitely;
  (2) nothing blanked the panels at switch time, so the old figures sat
  there while the new read was pending.
- Now: a dropped refresh is LATCHED and re-run the moment the in-flight
  read lands (a client switch always repaints, whatever the timer
  state), and the moment a new client becomes active the charts, the
  cards and the recent-entries table are blanked synchronously — the
  new client's own read paints over empty panels, never over the old
  client's ghost. The period selector resets too, so the read picks the
  new client's latest period instead of matching the old one's id.

### Added — editing a client (the Edit request)
- **Edit…** on the Clients toolbar, the row context menu, and a
  double-click: opens the client form PRE-FILLED (code, legal name, tax
  ID, base currency), title "Edit client NRTH", button "Save changes".
  The chart template picker is create-mode only — the chart is managed
  in Chart of Accounts, not by renaming.
- `ClientService.update(id, code, name, currency, taxId)` behind it:
  same validation as create (blank/length/character rules, ISO currency
  shape), UNIQUE code collisions surface as the same inline
  Duplicate-code error, and every edit writes an UPDATE_CLIENT row to
  the audit trail. Data is relational — journal entries, periods, the
  chart and the audit history stay attached by id; nothing re-creates.
- After a save the clients table, the top-bar switcher and the working
  client refresh together, so the new name/code shows everywhere at
  once.

### Added — the dashboard's graphs carry their numbers
- **Value labels on the trend chart**: every point prints its compact
  value (k/M formatting) right under its symbol — the revenue/expenses
  numbers read without hovering. Tooltips keep the exact figures.
- **Totals line under each chart caption**: the trend card shows total
  revenue · total expenses · margin (absolute + percent); the pie card
  shows total expenses across N accounts and the largest slice with its
  share; the balance card shows the equation itself — "Assets X =
  liabilities Y + equity Z · proof holds ✓". The captions stay blank
  when a period has no data, and never jump (reserved height).
- **Pie slice labels carry the share**: each visible slice reads
  "Rent · 24.6%" instead of a bare name; the trend chart's Y axis no
  longer forces zero into range, so month-to-month movement uses the
  actual band.

### Added — resizable windows (the resize request)
- **The New-entry dialog is resizable** (860×560 floor): grab any edge
  or corner and stretch — the LINES area absorbs every extra vertical
  pixel (its height cap grows with the window, re-fit live as you
  drag), so long entries show more rows before scrolling; the header,
  totals and save buttons stay pinned. Shrinking stays sane via the
  floor.
- The entry-detail viewer, the client create/edit form and the Settings
  panel are resizable too, each with a fitted minimum. Alert-style
  notices stay fixed-size (they're a sentence long).

## 2.8.0 — 2026-11-21

The packaging + presentation release: the launcher defect behind the
macOS console warning flood is fixed at root cause (JavaFX now rides the
module path in both platform bundles), the journal gets a professional
redesign and a second paper-style display mode, the worksheet's column
headers actually resize, and the dashboard's three charts become
animated and interactive. No database change; settings carry one new key
(journal display mode).

### Fixed — the launcher configuration defect
- **The "Unsupported JavaFX configuration: classes were loaded from
  'unnamed module'" warning + the CSS ClassCastException flood.** Both
  platform bundles launched the app with every jar — JavaFX included —
  on the CLASSPATH. In that configuration JavaFX's classes load into the
  unnamed module, the toolkit's runtime color-lookups
  (`-color-fg-default`, `-color-border-default`, …) fail to resolve,
  and every stylesheet rule using them is dropped mid-conversion with
  `ClassCastException: String → Paint`. Visibly: the journal table,
  combo-box popups and scrollbars lost their theming and rendered with
  fallback ink — the "weird and unprofessional" journal. The fix: the
  JavaFX jars (base, graphics, controls) now sit in their own
  `app/modules` directory and ride the MODULE path
  (`--module-path … --add-modules javafx.controls,javafx.graphics,
  javafx.base`); the app jar and its plain dependencies stay on the
  classpath. `javafx-swing` is dropped from the bundles entirely —
  nothing imports it, and it was a second unnamed-module source. Every
  theme now tints every control on both platforms.

### Fixed — the missing JavaFX natives (2.8.0-hotfix, same day)
- **The first 2.8.0 bundles crashed at startup on the user's Intel Mac
  with `Error initializing QuantumRenderer: no suitable pipeline found`.**
  Root cause: the JavaFX jars the bundles shipped were taken from the
  Gluon SDK zips, whose `lib/javafx.*.jar` carry NO platform natives
  (0 dylibs inside graphics on macOS; 0 dlls on Windows — both
  verified). Without the natives, neither the es2 nor the sw pipeline
  can initialize and the toolkit aborts. The old 2.6.0 bundle — which
  runs on the same Mac — had sourced its jars from Maven Central's
  platform-CLASSIFIER artifacts, whose jars DO bundle the natives
  (7 dylibs on mac graphics, 54 dlls on win). The hotfix rebuild sources
  every JavaFX jar from Maven Central with its `.sha1` verified, and the
  bundle scripts now carry a NATIVES GATE: the build FAILS if
  javafx-graphics doesn't list at least 5 dylibs (mac) / 30 dlls (win),
  so a native-less jar can never ship again. The exact launcher
  mechanism (module path + classifier jars) was boot-tested on this
  sandbox: the failure was reproduced with the old jars and the fixed
  jars run the app clean (0 warnings, 0 exceptions).

### Added — the journal's second display mode
- **ENTRY_LINES mode** (Settings → Workspace → Journal layout):
  the paper bookkeeping look. Each entry unfolds into its debit and
  credit lines — one row per line with the account's code and name,
  the amount in the Dr or the Cr column — followed by an indented
  `# memo` continuation row, the way a manual journal notes the
  explanation under the lines. Entries read as groups: No/Date/Status
  print on the group's first row, voided entries dim their whole group,
  and selecting any row of a group selects the entry (Post/Void/
  View-lines act on it). REGISTER (one line per entry) stays the
  default and the setting persists between launches.

### Fixed — the journal's professional look
- **The register now reads like a professional register**: zebra-striped
  rows (every other row tinted with the theme's subtle background),
  a status PILL per entry (green Posted / amber Draft / red Voided
  badge instead of plain text), and row hover highlighting. The pills
  and stripes key off AtlantaFX palette variables so all six themes
  tint them correctly.

### Fixed — the worksheet headers
- **Dragging a worksheet column header now resizes the column.** The
  13-column working paper's leaf columns sit inside group columns
  (Unadjusted TB, Adjustments, …), and the stock resize policy
  redistributes the drag proportionally across columns pinned by their
  minWidths — with the table wider than its columns' total pref width,
  the drag's delta never landed anywhere and nothing visibly changed.
  Drag deltas now commit directly to the dragged leaf's prefWidth
  (minimum honored), and the parent group's prefWidth tracks its
  children so the choice survives relayouts.

### Added — charts that respond and move
- **Every dashboard chart is animated** when the Animations preference
  is on: line points, pie slices and bars animate into place on every
  refresh, and the flag re-arms live when the setting flips (no
  restart). Motion off keeps the instant, flicker-free redraw the
  suite's tests expect.
- **Every dashboard chart is interactive**: hover a line symbol for
  its exact month and figure, a pie slice for the account, amount and
  its share of total expenses, a bar for its side of the proof —
  and click any of them to deep-link where the figures live (pie and
  line → the Journal, bars → the Reports view). Pie slices gently
  enlarge on hover so the hovered slice reads as selected.

### Quality of life
- The Journal re-renders instantly when the layout setting changes —
  no view switch needed.
- The Journal's Post/Void/View-lines act on the entry selected in
  EITHER mode, and the selection survives refreshes in both.
- Chart animation follows the Animations preference the moment it
  changes, not on next launch.

## 2.7.0 — 2026-11-15

The audit-driven release: the three reported defects are fixed at root
cause, the accounting cycle is COMPLETE (closing entries, post-closing
trial balance, reversals), and the fourth financial statement — cash
flows — joins the Reports view. One additive database migration (V5:
indexes only; no data change).

### Fixed — the three reported defects
- **The dashboard showed no figures even with the demo client loaded.**
  The live-refresh path read a field that was never assigned:
  `updateWorkingClient()` cleared `liveClient` when a client was dropped
  but never set it when one was selected, so every refresh pass exited
  before reading a single number. The client is now assigned before the
  first read, and a client switch drops the stale period so the new
  client's periods are re-read. A second, contributing defect: nothing
  selected a client at startup — the shell now restores the last working
  client (or picks the first active one on a fresh install).
- **Animations never played, even switched on.** The view-swap animation
  was guarded by a condition a resting node always satisfies
  (opacity 1, translateY 0), so it could never start — dead code since
  2.5.0. The guard now only checks motion-off/not-attached, and the entry
  state is set explicitly so every swap animates. The chart-reveal
  animation also skipped when the chart had not laid out yet; it now
  waits for the first layout pass and then draws.
- **The animation toggle lived on the main window.** The status bar's
  "Anim: On/Off" button is removed — Settings → Interface → Animations
  is the single control, as requested. The status bar keeps its readouts
  (shortcut hint, text scale).

### Added — the closing workflow (the cycle's missing step)
- **Closing-entry generator** (`ClosingService`): one click produces the
  classic four-step close — revenues and expenses zeroed into a new
  Income Summary account (3901), its net swept to Retained Earnings,
  dividends closed too. The set lands as DRAFTS for review, never
  auto-posted; posting is the journal's normal deliberate action.
- **The Close Period wizard** (Journal → "Close Period…"): the pre-close
  checklist (unposted drafts block, unbalanced trial balance blocks,
  a pending closing set blocks) → generate → review → post → lock, with
  the result dialog showing what closed and the net income carried.
- **Post-closing trial balance, reachable at last**: with closing entries
  in the journal, the TB's Post-closing stage now shows only permanent
  accounts — the stage existed since 2.4.0 but nothing could ever feed it.
- **Reversing entries**: the next period can reverse accrual-type
  adjustments ("accrued"/"accrual" memos) — every line swaps sides, dated
  to the new period's start, as a REVERSING draft. The type stays
  hand-unpickable in the entry dialog.
- **Period close is now a cycle step**, not just a lock: the wizard
  verifies the checklist before allowing the close.

### Added — the statement of cash flows
- **The fourth statement** (Reports → "Cash Flow" tab): the indirect
  method — net income plus non-cash add-backs (depreciation,
  amortization) and working-capital movements, then investing and
  financing sections classified from the chart — with the app's proof
  discipline: "Net movement = cash end − cash beginning ✓ reconciles to
  the cash accounts", verified to the penny in tests.

### Improved
- **The theme preference moved to the shared preferences node** — it
  used to persist under a different node than every other setting, so
  Settings' Reset could never reach it. Legacy values migrate once.
- **Preferences failures are surfaced** instead of silently swallowed —
  a locked-down store now says so (observable flag) instead of quietly
  resetting the experience.
- **Voided journal rows are dimmed** (muted ink, 62% opacity) — the
  mirrored reversal pair reads at a glance without relying on the Status
  column.
- **Hot-path indexes** (migration V5): journal_entries gets
  (period_id, posted) and (period_id, type) indexes — every TB stage,
  worksheet and dashboard query filtered by period with a table scan
  before — and ledger_balances gets (period_id).
- **Dashboard timer stands down** when the view leaves the scene — a
  late tick can no longer land a runLater on a dead view.

### Tests
- 164 green (149 before): Sprint0RegressionTest boots the real JavaFX
  toolkit headless and asserts each reported defect's fix (dashboard
  figures within two refresh cycles, an animation passing through
  non-identity intermediates, no control in the status bar, client
  remembered); ClosingServiceTest covers the full close, dividends,
  checklist blocking and reversals; CashFlowServiceTest proves the
  penny-exact reconciliation.

## 2.6.0 — 2026-11-15

The live release: the dashboard went real-time and interactable, the
Settings dialog got the layout it deserved, and a pass of fixes and
performance work landed. No database migration — existing data is
untouched.

### Fixed
- **The Settings dialog's cramped layout.** The 2.5.0 panel sat at one
  tight width with controls pressed against the pane's edge. It now opens
  generously sized (min 640×540, pref 700×620) with real padding (24 px
  sides) and 14 px row gaps — measured at 544×745 px on a 1280×820 window.
- **A text-size drag in Auto mode silently wrote a pinned value the UI
  ignored.** Dragging the slider now switches to Pinned at that size
  directly — the choice is both made and visible.
- **Reset did not apply to the running app.** It reverted the stored
  values but the open scene kept its theme/size/density until relaunch.
  Reset now re-applies everything live: theme returns to Primer Light,
  text to Auto, density to comfortable, while the panel is still open.

### Added — the live dashboard
- **Real-time refresh**: the client dashboard re-reads its figures on a
  background timer — Settings → Workspace → "Dashboard live refresh"
  (off / 5 s / 15 s default / 30 s). The reads run OFF the JavaFX thread
  (the UI never waits on SQLite), land on the FX thread in one pass, and
  a refresh-in-flight guard prevents pile-ups. A live stamp shows when
  the figures were last read; a Refresh button forces one now; **F5**
  re-reads the visible view anywhere in the app.
- **A period selector**: the dashboard describes the client's chosen
  period (default: the newest) — flip periods without leaving the view.
- **Clickable summary cards**: NET INCOME and ENTRIES jump to the
  Journal, ASSETS and EQUITY to the Reports view — hand cursor, hover
  border, keyboard-focusable (Space/Enter activate).

### Performance
- The live reads ride the same single-connection SQL pass as before, now
  on the background thread; the workspace-overview stat reads are skipped
  while the client dashboard is showing (they only matter to the
  no-client state); the timer only ticks while the dashboard is the
  visible view.

### Verified
- 149/149 tests green (130 carried over + 19: Prefs defaults/persistence/
  reset + DashboardRefresh parsing, Money display flags and parse
  round-trips, the dashboard roll-up arithmetic).
- Headless captures: the Settings dialog measured 544×745 px on a
  1280×820 window; the dashboard's period-selector row, live header and
  chart band render at three window sizes; text still scales
  (ink rows 43 → 43 → 53 at 85%/100%/130%).
- Runtime e2e: the app booted with the exact module-path recipe the
  bundles ship — zero "unnamed module" warnings, zero exceptions, and the
  dashboard-live-refresh daemon observed healthy in a thread dump.

## 2.5.0 — 2026-11-15

The settings release: a real Settings center, the terminal warning fixed
at the launcher level, the worksheet's stuck sorting repaired, a working
client's dashboard with graphs, and a performance pass. No database
migration — existing data is untouched.

### Fixed
- **The launch warning every terminal showed** — "Unsupported JavaFX
  configuration: classes were loaded from 'unnamed module @…'". The
  launchers now put the JavaFX jars on the `--module-path` (with
  `--add-modules javafx.controls`), so JavaFX loads as the real modules it
  is; the app starts silently on macOS, Windows and Linux, launcher and
  demo variant alike. The app jar and its libraries stay on the classpath,
  which is the supported combination.
- **The worksheet's sort never went back to the paper's order.** A column
  header click toggled ascending/descending forever; once sorted, clearing
  the arrow (via the table menu) left a scrambled grid that no click
  restored. Headers now cycle a third state — ascending → descending →
  UNSORTED — and the third click clears the arrow and returns the rows to
  the working paper's own layout: account rows by code, then the sheet's
  special rows (TOTAL…, NET INCOME, ENDING CAPITAL, TOTALS) below them,
  where they stay even under an active sort (they are the cross-foot, not
  account rows).

### Added — the Settings dialog
- **SETTINGS (sidebar)**: the app's control room — theme (six looks),
  text size (Auto responsive or pinned 85%–130%), compact density,
  animations, comma grouping of amounts, explicit zeros, the view the app
  opens on, window-geometry memory, and the void-entry confirmation.
  Every control applies LIVE (the open scene restyles/rescales as you
  choose), everything persists between launches, and a Reset button
  restores the factory defaults.
- **A status bar** joins it: the shortcut hint, the Anim toggle and the
  live text-scale readout.
- The journal's void flow honors the new preference: "Confirm before
  voiding" off means no reason prompt.

### Added — the working client's dashboard
- The dashboard is now scoped to the working client: **net income,
  assets, equity and entry-count cards** (with the balance-sheet proof
  noted on the assets card); a **monthly revenue-vs-expenses line
  chart**; an **expense-composition pie** (top eight accounts, "Other");
  the **balance-sheet proof drawn as bars** (assets vs liabilities +
  equity); and the **last eight journal entries**, double-click for the
  lines. With no working client it stays the old workspace overview.
- Performance: every aggregate rides ONE database connection per refresh
  (one SQL pass over the period's posted lines for the series, the
  routing and the composition; one grouped query for counts; one for the
  recents).

### Changed — motion
- **Animations are now OFF by default** (opt-in, remembered). More
  motion when on: dialogs settle in, charts draw left-to-right, view
  swaps glide, worksheet rows stagger.
- **Performance of the responsive text**: the scale quantizes to whole
  percent — a drag fires the 120 ms glide only on real steps, and when
  animations are off the scale is written directly (zero timelines
  during resize). This plus the single-connection dashboard addresses
  the 2.4.0 performance drop.

### Verified
- 130/130 tests green on the 2.5.0 tree (123 carried over + 7: the
  10-column equity-population regression and the UiScale contract).
- Headless captures at three window sizes: scales exactly
  0.850 / 1.000 / 1.300; the dashboard's chart band carries real chart
  pixels (colored-pixel ratios measured); text-ink rows grow 40 → 43 →
  53 across the sizes.
- The Linux bundle booted end-to-end through its own runtime with the
  module-path launchers: **zero** "unnamed module" lines in the output
  (2.4.0 printed one on every launch).

## 2.4.0 — 2026-11-15

The responsive-text release: the whole interface now re-fits the window,
the 10-column worksheet's hidden equity columns are fixed (they were
blank), and the app gained motion with a one-click off switch. No database
migration — existing data is untouched.

### Added — responsive text
- **Every text re-fits the window size.** All stylesheet font sizes are
  `em` against the scene root, whose size follows the window: the
  geometric mean of width and height against the 1280×820 design window's
  own mean (≈1024.5 px), clamped to 85%–130%. Real windows read as: the
  app's minimum 1024×660 at the 85% floor, a 1280×820 or 1366×768 laptop
  window at ~100%, a 1440×900 window at ~111%, a maximized 1920×1040 at
  the 130% ceiling. The scale glides over ~120 ms while a window is
  dragged, so the text breathes with the resize instead of snapping.
- **A TEXT SIZE slider in the sidebar** pins a fixed scale (85%–130%,
  remembered between launches); double-clicking the slider returns to
  Auto. The status bar shows the live percentage and mode.

### Fixed
- **The 10-column worksheet's Changes-in-Equity Dr/Cr columns were blank.**
  In that format the routing zeroed the equity cells (the columns were
  hidden, so the code never filled them) — re-showing the pair from the
  table menu's column list displayed an empty grid even though equity had
  real movements. Equity now always lands in those cells in BOTH formats:
  the 10-column sheet prints without the pair (its equity still folds
  into the balance sheet columns, unchanged) but keeps them live and
  populated, with the group caption marked so the kept columns read as a
  reference strip. Its TOTALS row and a TOTAL Changes in Owner's Equity
  row now populate the pair's totals too, and the balance proof runs per
  format.

### Added — motion & quality of life
- **Smooth animations, switchable**: view changes fade and slide in
  (~220 ms ease-out), the worksheet's freshly loaded rows settle with a
  short 40 ms stagger, the dashboard's cards fade in on first show.
- **Dialog keyboard accelerators**: Esc closes every dialog form, and
  Ctrl/Cmd+Enter fires the default (save/post) button — wired into all
  nine dialogs.
- **A status bar**: the keyboard-shortcut hint, the Anim toggle and the
  live text-scale readout.

### Verified
- 130/130 tests green on the 2.4.0 tree.
- Visual verification headless at three window sizes (1024×660, 1280×820,
  1920×1040): text measurably scales (85% floor / 100% / 130% ceiling);
  the 10-column worksheet shows populated Changes-in-Equity cells.

# Changelog

All notable changes to LedgerPro are documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/);
releases follow semantic versioning. 1.x releases predate this file.

## 2.3.2 — 2026-11-15

A patch release on top of 2.3.1: two rendering bugs, one layout overhaul
and a handful of quality-of-life improvements. No database migration —
existing data is untouched.

### Fixed
- **The general ledger's Debit, Credit and Balance columns were blank.**
  The three money columns had formatting cells but no value factories,
  so every row rendered empty amounts while the footer printed correct
  totals — the ledger looked "not outputting debit and credit properly"
  even though the data was recorded and balanced. Values now render per
  line (e.g. `2,500,000.00` debit, running balance bold in the same
  column style).
- **The trial balance's Debit and Credit columns were blank** for the
  same reason — every account row showed empty amounts with only the
  totals line populated. Both columns now render each account's movement.
- Memo cells no longer truncate ("OR-20…") mid-word: the money columns'
  fixed pref-widths were stealing space from Memo; with values rendered
  the constrained-resize policy distributes widths sanely.

### Changed — responsive windows
- **Maximized/fullscreen windows now use all of the space.** The six
  views that host their table inside a hidden-when-empty work area
  (Journal, Ledgers, Trial Balance, Worksheet, Reports, Chart of
  Accounts) never gave that area vertical growth, so a maximized window
  kept a ~400 px table pinned to the top with a huge dead band below —
  measured at 460–674 px on a 1920×1040 fullscreen. All six now stretch
  their tables to the window bottom (verified headless at 1920×1040:
  content now reaches the bottom padding edge; tables grew from 400 px
  to 765–887 px).
- **The dashboard fills the window too**: the checklist and roadmap
  cards grow to equal height instead of leaving two thirds of a
  maximized window empty.
- **The window remembers its geometry.** Size, position and maximized
  state are restored on the next launch; a remembered position that no
  longer fits any attached screen is discarded in favor of a centered
  default.

### Added — quality of life
- **Keyboard navigation**: Ctrl/Cmd+1…9 jump to the sidebar views in
  navigation order, Ctrl/Cmd+N opens the Journal's New-entry dialog.
  Shortcuts stay silent while typing in inputs.
- The 2.3.1 launcher hardening carries over (macOS `.jre` bundle
  auto-detection, plain-English recovery messages) — re-verified on
  this release's bundles.

### Performance
- The dashboard's refresh opened four SQLite connections (one per stat
  query); it now reads all four in one connection. Connection pragmas
  are unchanged (WAL, foreign keys, NORMAL sync, 5 s busy timeout).

### Verified
- 123/123 tests green on the 2.3.2 tree.
- Layout probe (headless, 1920×1040): every view's content bottom now
  lands within the 18 px content padding — was 460–674 px short.
- Screenshot-verified: ledger Debit/Credit/Balance per-row values match
  the service-layer output exactly; trial balance per-account values
  match and totals balance (3,640,130.60 Dr = Cr on the demo data).
- All three platform bundles rebuilt from the tested source with
  launcher JRE auto-detection intact.

## 2.3.1 — 2026-11-02

A patch release on top of 2.3.0: one startup fix, one form made
self-explaining. No database migration — existing data is untouched.

### Fixed
- **macOS launcher startup failure.** The bundled macOS JRE unpacks as a
  `.jre` bundle whose java binary lives at `runtime/Contents/Home/bin/java`,
  but the 2.3.0 launcher exec'd the flat Linux-style path
  (`runtime/bin/java`). The `exec` failed with ENOENT and the app died
  before showing any window — the "cannot execute: No such file or
  directory" seen when launching the 2.3.0 macOS zip. Every launcher
  (macOS `LedgerPro` and `LedgerPro-demo`, Linux `run.sh` and `run-demo.sh`,
  Windows `.bat` files) now auto-detects both runtime layouts, and if
  neither exists it prints a plain-English recovery message ("re-download
  the zip and extract it again") instead of a cryptic failure. Windows and
  Linux were never affected.

### Added
- **Add-client form field descriptions.** Every input in the New client
  dialog now carries a one-line muted description directly beneath it,
  telling a first-time user what the value is for, its allowed shape and
  where it shows up later:
  - *Client code* — "Short ID that identifies this client in lists, ledgers
    and reports. 1–12 characters — letters, digits, '.' and '-';
    saved as UPPERCASE."
  - *Legal name* — "The client's registered business name, exactly as it
    should appear on statements and reports."
  - *Tax ID* — "Optional — the client's tax identification number
    (e.g. TIN). Kept for the register; not validated."
  - *Base currency* — "The currency this client's books are kept in.
    Journal entries in other currencies convert into it at their FX rate.
    Any 3-letter ISO 4217 code (e.g. PHP) can be typed."
  - The hints are styled with a theme-aware class (`.lp-field-hint`, on
    AtlantaFX's `-color-fg-muted`) so they stay legible in all six looks.

### Changed
- The starting-chart picker in the New client dialog no longer has a fixed
  320 px width — it stretches with the field column like every other
  input, so the full option text ("Detailed — full corporate chart · 70
  accounts") is never ellipsized.

### Verified
- 123/123 tests green on the 2.3.1 tree.
- The launcher's JRE-layout auto-detection was verified against the real
  `.app` bundle layout (`runtime/Contents/Home/bin/java` resolves; the old
  flat path is absent by design).
- The Linux bundle booted the demo app end-to-end through its own runtime
  and re-seeded its database.
- The Add-client hints were screenshot-verified in Primer Light and
  Alexia's theme (all four hint texts render verbatim, no clipping).
- All three platform bundles (Windows x64, macOS Intel, Linux x64) plus
  the source zip were rebuilt from the fully-tested source; zip
  integrity, `Mach-O x86_64` / `PE32+ x86-64` runtime binaries,
  per-platform JavaFX natives, CRLF `.bat` files and executable launcher
  bits were machine-checked.

## 2.3.0 — 2026-11-02

### Added
- **Switchable themes** (`ui/Theme`, `ui/ThemeManager`, `css/theme-alexia.css`).
  The sidebar's new APPEARANCE picker re-skins the whole application live —
  no restart: Primer Light (the default look), Primer Dark, Nord Light,
  Nord Dark, Dracula, and **Alexia's theme** — the deep forest-green suite
  sampled from Alexia's screenshots (near-black-green sidebar with
  green-filled navigation pills, dark-green page, lighter green cards and
  tables, green primary buttons, green "Balanced" ink), implemented as a
  stylesheet layered over AtlantaFX PrimerDark. The choice is remembered
  per user and restored on the next launch.
- Theme coverage was screenshot-verified headless in all six looks
  (dashboard, journal register, new-entry dialog, clients, chart of
  accounts), and the runtime switch itself is proven by pixel checks.

### Changed
- **The journal-entry form answers as you type.** "Save & post" /
  "Save draft" previously re-evaluated only when the date, period or
  currency changed, so a fully typed, balanced entry kept its buttons dim
  until an unrelated field was touched. Enablement now tracks every
  keystroke, account pick, add and remove: the buttons light up the
  moment the entry balances and dim again the moment it doesn't. Two
  engine optimizations came along: validation is one parse per row (it
  used to re-parse every field three times per keystroke), and the
  foreign-currency rate is resolved once per date/currency change instead
  of hitting the SQLite FX cache on every keystroke.

### Known issues
- The macOS zip of this release shipped the broken launcher described
  above; upgrading to 2.3.1 fixes it (delete the old folder, unzip the
  2.3.1 build, launch — data is unaffected).

## 2.2.0

- Schema guard: reconciles databases created by either 2.x build line
  before Flyway migrations run; V4 `schema_alignment` migration.
- Audit trail: every posting, void and template application is recorded
  and browsable in the new Audit view (with entry detail dialog).
- Journal/adjustment template save & load dialogs; manual FX-rate entry
  dialog.
- Polished table rendering (dedicated money / signed-money cells) and
  refreshed view chrome.
- 118/118 tests green at release.

## 2.0.0

- LedgerPro v2: selectable chart-of-accounts templates (Minimal /
  Standard 54-account corporate chart / Detailed) applied when a client
  is created, and adjustment templates (entry-rule integration) that post
  recurring adjusting entries from a saved definition.
- Multi-currency posting retained from the 1.x line; dialog padding,
  journal scrolling and edit/remove button fixes across the UI.
- 72/72 tests green at release; verified bundles for macOS, Windows and
  Linux.
