# LedgerPro

A multi-client accounting-cycle desktop application for a corporate
accounting firm. Java 21 LTS, JavaFX 21, AtlantaFX, SQLite (WAL mode),
Flyway, Maven.

## Current status — 2.12.1 (the layout truth pass: charts in proportion, a dashboard that scrolls and re-flows, a journal that never truncates — all verified headless at 100%/130% text scale across four window sizes). Previously 2.12.0 (packaging release: branded .exe/.app, data always in ~/.ledgerpro, GitHub-built installers)

This tree is the **original LedgerPro** (multi-currency posting and the whole
accounting cycle intact) with these additions. V1's migration file is
byte-identical to the release that created existing user databases, and the
schema guard below reconciles even the OTHER 2.x build line's databases,

- **The journal wears the Ledgers tab's look** (2.11.1) — the register's
  Amount column renders bold success-green figures exactly like the ledger's
  green running Balance column (per-theme measured: 2,107-2,406 visible
  green/teal pixels in all six themes), and the Entry No column takes the
  ledger's strong-ink treatment.
- **Theme-safe journal status colors** (2.11.0) — the status text (Posted/
  Voided/Draft) renders through CSS classes with bold palette colors that
  re-resolve on every theme switch; all six themes now measure a 102-159/255
  text-vs-background luminance gap (the user's dark screenshot showed 6).
  The paper-mode pills gained emphasis borders and bold text so they read as
  badges, not mud, on dark backgrounds.
- **A toolbar that never truncates** (2.11.0) — the journal toolbar is two
  rows (actions, then filters) with every button pinned to its computed
  size; the search box is the only flexible control. The user's screenshots
  showed three labels ellipsized on one crowded row.
- **Dashboard charts in proportion** (2.11.0) — every chart capped (trend/
  pie 420 px, balance bars 360), both chart rows share the window's extra
  height, the expense pie measures 720x300 where it used to render tiny,
  and pie labels print in the theme default foreground.
- **The 2.3.1 journal design restored** (2.10.0) — the journal opens in the
  flat register again: one row per entry, uniform rows with hairline
  separators, plain colored status text (no zebra, no hover fills, no
  pills). Verified pixel-for-pixel against a headless reference capture of
  the 2.3.1 journal. The paper journal stays one toolbar toggle away;
  stored preferences are honored.
- **The stale period filter fixed** (2.10.0) — switching clients used to
  leave the previous client's period as the combo's value (invisible but
  live), filtering the journal on a dead id. The value now clears outright
  (a ComboBox keeps its value after `clearSelection()` — the trap).
- **Journal performance** (2.10.0) — O(1) row lookups (id → summary map),
  one batched lines read for the paper mode (was one query per entry),
  the new V6 index on `journal_lines(entry_id, line_no)`, ThreadLocal
  money formatters, and single-pass footer statistics.
- **Journal quality of life** (2.10.0) — a search box (memo/ref/entry-no
  prefix), a status filter (All/Draft/Posted/Voided), a footer that
  describes exactly the filtered rows on screen (with the active period),
  Export CSV of the filtered register, Enter to open the selected entry's
  lines, and F5 to reload.
- **Theme switching fixed at root cause** (2.9.0) — swapping themes no
  longer leaves stale colors on rendered controls: every live window gets a
  full CSS re-pass (`applyCss`) after the user-agent stylesheet swap, so all
  six themes repaint cleanly no matter how many times you switch.
- **The dashboard clears on client switches** (2.9.0) — the previous
  client's line chart no longer ghosts: panels blank synchronously at
  switch time, and a refresh dropped by an in-flight read is latched and
  re-run when that read lands (with live refresh Off it used to never
  re-run at all).
- **Editing a client** (2.9.0) — Edit… on the toolbar, the context menu or
  a double-click opens the client form pre-filled (code, name, tax ID,
  currency); `ClientService.update` writes an UPDATE_CLIENT audit row;
  journal, periods, chart and history stay attached by id. The switcher
  and working client refresh together after a save.
- **The dashboard's graphs carry their numbers** (2.9.0) — value labels
  under every trend-chart point (compact k/M), a totals line under each
  chart caption (revenue · expenses · margin; total expenses and the
  largest slice; the balance equation itself), pie-slice labels with
  shares, and the recent-entries count + posted volume.
- **Resizable windows** (2.9.0) — the New-entry dialog stretches by any
  edge or corner (860×560 floor): the lines area absorbs the extra height
  live. Entry detail, the client form and Settings are resizable too.
- **The 2.8.0 packaging fix** — the platform bundles put JavaFX on the
  module path (no more "unnamed module" warning or un-styled tables),
  the journal's two display modes, worksheet column resizing, and
  animated interactive charts; the 2.8.0-hotfix re-sourced the JavaFX
  jars from Maven Central with natives verified (the first bundles
  crashed with `no suitable pipeline found`).
- **The three 2.6.0 defects fixed at root cause** (2.7.0) — the dashboard
  fills with the working client's figures (the live-refresh path never
  received the selected client before, and no client was auto-selected at
  startup); animations actually play when enabled (the view-swap guard was
  unsatisfiable by design, dead code since 2.5.0; the chart reveal now waits
  for the first layout pass); the animation toggle lives ONLY in Settings —
  the status-bar copy is gone. The last working client is remembered and
  restored across launches.
- **The closing workflow** (2.7.0) — Journal → "Close Period…" runs the
  pre-close checklist (unposted drafts block, unbalanced trial balance
  blocks, a pending closing set blocks), generates the classic four-step
  closing entries as DRAFTS (revenues/expenses → Income Summary 3901 →
  Retained Earnings; dividends closed), posts them on confirmation and
  locks the period. The post-closing trial balance — a stage the schema
  knew about since 2.4.0 — is finally reachable. Accrual adjustments
  reverse into the next period from the same service.
- **The statement of cash flows** (2.7.0) — Reports' fourth tab: the
  indirect method (net income + non-cash add-backs + working-capital
  movements; investing and financing classified from the chart), with the
  proof line reconciling to the cash accounts' own movement, penny-exact.
- **Performance and polish** (2.7.0) — hot-path indexes (migration V5:
  journal_entries by (period_id, posted) and (period_id, type);
  ledger_balances by period_id), voided journal rows dimmed at a glance,
  the theme preference migrated to the shared preferences node (Reset
  reaches it now), preferences-store failures surfaced instead of
  swallowed, and the dashboard's background timer stands down when the
  view leaves the scene.
- **The live dashboard** (2.6.0) — real-time and interactable: figures
  re-read on a background timer (Settings → Workspace → Dashboard live
  refresh, 5/15/30 s or off; default 15 s), a live stamp shows the last
  read, F5 or the Refresh button forces one now; a period selector picks
  which period the cards and charts describe; every summary card is a
  deep link (NET INCOME / ENTRIES → Journal, ASSETS / EQUITY → Reports)
  with hand cursor and hover border. The reads run off the JavaFX thread
  and only while the dashboard is visible.
- **The Settings dialog's layout fixed** (2.6.0) — generous width/height
  (min 640×540) with real padding; a text-size drag now pins at that
  size directly; Reset re-applies the defaults to the running app (theme,
  text, density) instead of waiting for the next launch.
- **Silent launch** (2.5.0) — the launchers put JavaFX on the module path,
  which kills the "Unsupported JavaFX configuration: classes were loaded
  from 'unnamed module'" warning every terminal printed on startup.
  macOS, Windows, Linux, launcher and demo variant alike.
- **A Settings dialog** (2.5.0) — theme, text size (Auto or pinned),
  compact density, animations (OFF by default), comma-grouped amounts,
  explicit zeros, startup view, window-geometry memory, void-entry
  confirmation. Live apply, persisted, Reset to defaults.
- **The working client's dashboard** (2.5.0) — net income / assets /
  equity / entry-count cards, a monthly revenue-vs-expenses line chart,
  an expense-composition pie, the balance-sheet proof as bars, and the
  last eight journal entries (double-click for the lines). One database
  connection per refresh.
- **Worksheet sorting fixed** (2.5.0) — column headers cycle asc → desc →
  the paper's own order; the special rows stay below the account rows.
- **The live dashboard** (2.6.0) — real-time and interactable: figures
  re-read on a background timer (Settings → Workspace → Dashboard live
  refresh, 5/15/30 s or off; default 15 s), a live stamp shows the last
  read, F5 or the Refresh button forces one now; a period selector picks
  which period the cards and charts describe; every summary card is a
  deep link (NET INCOME / ENTRIES → Journal, ASSETS / EQUITY → Reports)
  with hand cursor and hover border. The reads run off the JavaFX thread
  and only while the dashboard is visible.
- **The Settings dialog's layout fixed** (2.6.0) — generous width/height
  (min 640×540) with real padding; a text-size drag now pins at that
  size directly; Reset re-applies the defaults to the running app (theme,
  text, density) instead of waiting for the next launch.
- **Silent launch** (2.5.0) — the launchers put JavaFX on the module path,
  which kills the "Unsupported JavaFX configuration: classes were loaded
  from 'unnamed module'" warning every terminal printed on startup.
  macOS, Windows, Linux, launcher and demo variant alike.
- **A Settings dialog** (2.5.0) — theme, text size (Auto or pinned),
  compact density, animations (OFF by default), comma-grouped amounts,
  explicit zeros, startup view, window-geometry memory, void-entry
  confirmation. Live apply, persisted, Reset to defaults.
- **The working client's dashboard** (2.5.0) — net income / assets /
  equity / entry-count cards, a monthly revenue-vs-expenses line chart,
  an expense-composition pie, the balance-sheet proof as bars, and the
  last eight journal entries (double-click for the lines). One database
  connection per refresh.
- **Worksheet sorting fixed** (2.5.0) — column headers cycle asc → desc →
  the paper's own order; the special rows stay below the account rows.
- **Responsive text** (2.4.0) — every label, cell, button and dialog re-fits
  the window: all stylesheet font sizes are `em` against a scene-root size
  that follows the window (85%–130% around the 14 px design size, geometric
  mean of width/height against the 1280×820 design window — the app's
  minimum 1024×660 window reads the 85% floor, a laptop window ~100%, a
  1440×900 window ~111%, a maximized 1920×1040 the 130% ceiling). A TEXT
  SIZE control in Settings pins a fixed size instead; the status bar shows
  the live percentage.
- **Fixed the 10-column worksheet's Changes-in-Equity columns** (2.4.0) —
  they were blank in that format (the routing zeroed the equity cells when
  the columns were hidden), so re-showing the pair from the table menu
  displayed an empty grid. Equity now always lands in those cells in BOTH
  formats — the 10-column sheet merely prints without them, and its pair
  stays live and marked "kept visible".
- **Dialog keyboard accelerators** (2.4.0) — Esc closes every dialog form,
  Ctrl/Cmd+Enter fires its default (save/post) button, wired into all nine
  dialogs.
- **Responsive windows** (2.3.2) — maximized/fullscreen windows use all of
  the space: every table stretches to the bottom of the window and the
  dashboard cards fill it. Verified headless at 1920×1040.
- **Fixed blank money columns** (2.3.2) — the general ledger's Debit/Credit/
  Balance columns and the trial balance's Debit/Credit columns rendered
  empty (formatting cells without value factories). Every row now shows
  its amounts.
- **Window geometry memory + shortcuts** (2.3.2) — size, position and
  maximized state restore on the next launch (a Settings toggle now);
  Ctrl/Cmd+K search · Ctrl/Cmd+1…9 jump between views and Ctrl/Cmd+N opens the New Entry
  dialog.
- **Fixed the macOS launcher** (2.3.1) — the bundled macOS JRE unpacks as a
  `.jre` bundle (`runtime/Contents/Home/bin/java`), but the 2.3.0 launcher
  exec'd the flat path (`runtime/bin/java`), so the app died with
  "cannot execute: No such file or directory" before any window appeared.
  Every launcher now auto-detects both layouts and prints a clear message
  if the runtime is missing. Windows and Linux were never affected.

- **Switchable themes** (`ui/Theme`, `ui/ThemeManager`) — the sidebar's new
  APPEARANCE picker re-skins the whole application live, no restart: **Primer
  Light** (the default), **Primer Dark**, **Nord Light**, **Nord Dark**,
  **Dracula**, and **Alexia's theme** — the deep forest-green look sampled
  from Alexia's screenshots (`css/theme-alexia.css` re-tints the AtlantaFX
  palette: green nav pills on a near-black sidebar, green cards and tables
  on a dark-green page, green primary buttons with white labels). The choice
  is remembered per user and restored on the next launch.
- **A journal-entry form that answers as you type** — the "Save & post" /
  "Save draft" buttons now unlock THE INSTANT the last digit balances the
  entry. Their enablement previously watched only the header fields (date,
  period, currency), so a fully typed, balanced entry kept its buttons dim
  until something unrelated was touched — the form felt broken. Enablement
  now tracks every keystroke, account pick, add and remove; validation is a
  single pass per row (the old path re-parsed each field three times), and
  the foreign-currency rate is resolved once per date/currency change
  instead of on every keystroke.
- **Selectable chart-of-accounts templates** (`ChartTemplates`, migration V2)
  — Minimal (16 accounts, small service businesses) / Standard (the firm's
  54-account corporate chart, delegating to `StandardChart`) / Detailed
  (70 accounts). Picked in the New client dialog and applied idempotently any
  time under Chart of Accounts → "Apply template…"; the chosen preset is
  recorded in `clients.chart_template` and shown in the view's banner.
- **Recurring adjustment templates** (`AdjTemplateService`, migration V3)
  — remember any balanced set of lines under a code, per client or shared
  firm-wide (lines reference account CODES, so they survive chart rebuilds).
  "Save as template…" on the new-entry form and on any entry's detail view;
  "Load template…" prefills a new ADJUSTING entry.
- **Form fixes from field testing** — every modal dialog breathes at its
  edges again (20px horizontal padding); the new-entry dialog's LINES area
  scrolls (totals, FX hint and buttons stay pinned) so "+ Add line" can never
  overflow the window; the per-line ✕ button works (enable state recomputed
  on every add and remove); the "···" button beside each line memo is a live
  overflow menu (duplicate / clear amounts / remove).
- **Self-healing schema history** (`Database.migrate()`) — a desktop app must
  never refuse to open the user's data over bookkeeping: on a validation
  failure (e.g. checksum drift after an update) Flyway `repair()` runs and
  the migration retries once; table data is never touched.
- **Schema alignment with the firm's reviewed ER design** (migration V4) —
  `clients.tax_id/is_setup`, `periods.closed_at/locked_at`,
  `journal_entries.reference/adj_template_id/posted_at`, the full
  transaction-currency trail on `journal_lines` (`line_no`, `txn_currency`,
  `txn_debit/credit_cents`, `fx_rate`, `fx_rate_id`), the currency-pair
  `fx_rates` table with a `note`, `accounts.is_permanent/
  is_retained_earnings/parent_id`, the split `ledger_balances` cache,
  `tb_snapshots` summary columns, `report_snapshots.export_format/export_path`,
  and structured `audit_log` entity links.
- **The SchemaGuard** (`db/SchemaGuard.java`) — the launch regression fix.
  Databases created by the other 2.x build line (whose `clients` table lacks
  `code`) are detected by introspection, backed up, migrated to this
  schema with every row preserved (flag-voided entries get their mirrored
  REVERSING entries synthesized), and opened; unrecognised lineages start
  clean with the original kept one rename away. The app never refuses to
  open the user's data.
- **Recurring templates with FORMULAS** — every template line picks its
  amount source: a fixed amount, or an expression over the period's
  adjusted ledger (`5% * BAL(1100)`, `BAL(1430) * 10% / 12`, percentages
  and + - * / arithmetic) evaluated at load time. Covered by the Formula
  parser's own tests.
- **Audit Log view** — the whole firm's trail, newest first, with the
  entity each row touched, linked by the V4 audit columns.
- **Client onboarding + housekeeping** — tax id on the New client form,
  the `is_setup` flag maintained by the account/period services, document
  `reference` on entries (shown in the register and detail), posted-at and
  closed-at timestamps, and export provenance (`export_format`/`export_path`)
  recorded on report snapshots.
- **The firm's logo** — the supplied artwork is the app icon (macOS .icns,
  Windows .ico, Linux .png), the window icon set and the sidebar mark
  (`scripts/make_icons.py` regenerates everything from the source PNG).
- **Demo seeding for this build** (`--demo`, `dev.DemoData`) — Northwind
  Retail Trading's full FY2026: multi-currency entries, a voided duplicate
  with mirrored reversal, formula templates posted against live balances,
  and the statements.

Build & test with the same stack the bundles ship (Temurin 21, JavaFX 21.0.5,
flyway 10.20.1): 149 tests green.

## Earlier phases (as shipped) — Phase 5 (worksheet, statements, exports)

- **The worksheet** — the firm's internal working paper, in both paper
  formats: the classic **10-column** sheet and the **13-column** sheet that
  carries Changes in Owner's Equity columns of its own (equity folds into
  the balance sheet columns in the 10-column form — drawing on the debit
  side, net income on the credit side, exactly like the paper). Every
  account carries its unadjusted balance (NORMAL entries plus REVERSING
  voiding mirrors — a voided entry cancels in every column), its
  adjustments, its adjusted balance, and its routed amount in exactly one
  statement column pair. Contra assets land on the balance sheet's credit
  side as the deduction lines they are; accounts that net to zero
  everywhere read as the blank lines the paper sheet leaves out
- **The paper sheet's own rows, each in its column group** — TOTAL
  Unadjusted, TOTAL Adjustments, TOTAL Adjusted TB, **NET INCOME** (it
  balances the income statement columns and lands in the equity columns),
  TOTAL Changes in Owner's Equity, **ENDING CAPITAL** (it balances the
  equity columns and becomes the balance sheet's equity figure), TOTAL
  Balance Sheet and the grand TOTALS. Closing entries deliberately stay
  out — the worksheet is the paper that precedes closing
- **The three statements** — single-step income statement; statement of
  changes in owner's equity (beginning capital, investments, net income,
  withdrawals, ending capital — a newly onboarded client honestly reads as
  beginning zero with its opening credit as the investment); and the
  balance sheet with assets, liabilities and ending equity. Every build
  asserts its own proof: net income reconciles, the equity story adds up,
  and assets equal liabilities plus equity — a theorem of Dr = Cr that a
  regression can never be allowed to quietly break
- **Exports** — CSV with exact ungrouped decimals (a spreadsheet ingests
  it losslessly) and one self-contained print-ready **HTML page of all
  three statements** — print to PDF from any browser and it is the
  client-ready document, no new dependencies, fully offline
- **report_snapshots** — the V1 schema anticipated this phase: worksheet
  and statement snapshots freeze as JSON into the table the schema was
  born with, each with its audit row. The dashboard's getting-started
  checklist counts them
- **WorksheetService** — pure derivation from the posted journal; the only
  writer of `report_snapshots`. Every figure it produces can be recomputed
  and checked against the ledger

### Phase 4 recap (journal, ledgers, trial balance)

- **Accounting periods** — the unit entries live in and the unit that
  freezes at the end of the cycle. Periods never overlap (a date belongs
  to exactly one period); closing locks a period against new entries,
  posting and voiding; reopening is deliberate and audited
- **The double-entry journal** — NORMAL, ADJUSTING and CLOSING entries
  with per-entry 'debits = credits' enforced on the typed amounts *before
  anything is stored* — even drafts must balance. Sequential entry
  numbers per client. Draft → posted is a one-way door: posted entries
  are immutable
- **Multi-currency entries read the Phase-3 FX cache** — type the
  amounts in the original currency (e.g. a USD 3,000 vendor invoice);
  the rate is resolved from the cache (newest on or before the entry
  date, inverse-pair fallback), snapshotted onto the entry, and the
  stored lines carry base-currency cents — converted half-up per line,
  with the rounding residual (a cent or two) absorbed by the largest
  line so debits equal credits *exactly* in the reporting currency.
  A missing rate refuses the entry with instructions, never guesses
- **Voiding by mirrored reversal — nothing is ever deleted** — voiding a
  posted entry records and auto-posts its REVERSING mirror (same
  accounts, Dr/Cr flipped), pointing back at the original through
  `void_of_id`. "Voided" is derived from the mirror's existence, so no
  flag can ever disagree with the entry that does the cancelling
- **General ledger per account** — every posted line, oldest first, with
  the running balance signed in the account's normal direction: contra
  accounts (Accumulated Depreciation, allowances) behave exactly as
  charted. Deactivated accounts keep their history visible
- **The three trial-balance checkpoints** — unadjusted, adjusted and
  post-closing, each filtering the posted journal by how far the cycle
  has come (voiding mirrors cancel in every stage). The grand-total line
  states plainly whether debits equal credits. "Snapshot…" freezes any
  trial balance into `tb_snapshots` as JSON — the immutable audit trail
  of every report the firm ever produced
- **JournalService** — the only writer of `journal_entries`,
  `journal_lines`, `ledger_balances` and `tb_snapshots`; every mutation
  is one transaction with one `audit_log` row (CREATE_ENTRY, POST_ENTRY,
  VOID_ENTRY, CLOSE_PERIOD, REOPEN_PERIOD, SNAPSHOT_TB, …)

### Phase 3 recap (chart of accounts + FX rates)

- Chart of accounts per client: searchable register, contra-account
  support, 54-account Philippine-style standard chart in one click
  (idempotent), structure freeze once an account carries journal lines
- FX-rate workstation: Frankfurter (ECB) reference rates cached in the
  database, manual rates that deliberately override the API for a date
  and pair, inverse-pair lookup fallback

### Phase 2 recap (application shell + clients)

- Application shell: sidebar navigation, top bar with the working-client
  switcher, AtlantaFX theming (Primer Light by default, switchable at
  runtime since 2.3 — see the APPEARANCE picker at the bottom of the
  sidebar)
- Client management: searchable register, new-client dialog with inline
  validation, archive/restore — never delete
- Dashboard: live stats, getting-started checklist, delivery roadmap

### Phase 1 recap (database foundation)

- Full SQLite schema with referential integrity and structural CHECK guards
  (`src/main/resources/db/migration/V1__init_schema.sql`)
- Flyway migrations applied programmatically on startup
- WAL journal mode + per-connection pragmas (`Database.java`)
- Smoke-test suite covering schema, WAL, FK enforcement and CHECK guards

## Quick commands

| Command              | What it does                                                  |
|----------------------|---------------------------------------------------------------|
| `mvn clean test`     | runs all tests (123: DB incl. the schema guard, clients, COA, |
|                      | FX, periods, journal, templates & formulas, worksheet,       |
|                      | theme catalog)                                                |
| `mvn javafx:run`     | launches the desktop application                              |
| `mvn exec:java`      | DbCli: creates `data/ledgerpro.db`, migrates it, prints counts |
| `mvn -Pdist package` | builds the native application (jpackage; see next section)    |

## Build a desktop application (Windows & macOS)

`mvn -Pdist package` wraps the app into a **native application image**
with jpackage: a double-clickable program that carries its own Java 21
runtime, so the machine it runs on needs **no Java installed**.

Ready-made, pre-verified bundles for macOS (Intel) and Windows plus full
instructions live in `BUILD-AND-RUN.md`; one-command wrappers are in
`packaging/` (`build-macos.sh`, `build-windows.ps1`).

| OS      | Result                             | How to run              |
|---------|------------------------------------|-------------------------|
| Windows | `target\dist\LedgerPro\LedgerPro.exe` | double-click            |
| macOS   | `target/dist/LedgerPro.app`       | double-click            |
| Linux   | `target/dist/LedgerPro/bin/LedgerPro` | run from a terminal     |

One-time setup on the build machine: **JDK 21+** (Adoptium Temurin, matching
your OS) and **Maven 3.9+**. Build **on the target OS** — jpackage bundles
that machine's Java runtime into the image.

Installers instead of an app folder:

- macOS: `mvn -Pdist package -Djpackage.type=dmg` — a drag-and-install
  `.dmg` built with the system's own tools, nothing extra to install.
- Windows: `mvn -Pdist package -Djpackage.type=msi` — needs the WiX
  toolset on `PATH`.

Notes for the packaged app:

- **First launch on macOS (Ventura):** Gatekeeper stops unsigned apps.
  Right-click `LedgerPro.app` → *Open* → *Open* (once), or System Settings
  → Privacy & Security → *Open Anyway*.
- **Windows SmartScreen:** click *More info* → *Run anyway*.
- The double-clicked app keeps its database in `~/.ledgerpro/ledgerpro.db`
  (its working directory is read-only); development runs keep using
  `data/ledgerpro.db` next to the project.
- **Intel Macs (e.g. Ventura on Core i5 with UHD 617):** fully supported —
  the bundled Java 21 + JavaFX 21 line ships macOS x64 builds, and its
  default renderer works on that GPU. If graphics ever glitch, open
  `LedgerPro.app/Contents/app/LedgerPro.cfg` (Windows:
  `LedgerPro\app\LedgerPro.cfg`) and add a line
  `java-options=-Dprism.order=es2` — or `sw` — under `[JavaOptions]`.
- Internet is only needed for the FX view's "Fetch from Frankfurter"
  button; the packaged app is otherwise fully offline.

## Requirements

- JDK 21 or newer (LTS) — the build targets Java 21, matching the JavaFX
  21.0.5 runtime the bundles ship. Get it from
  <https://adoptium.net/temurin/releases/?version=21>:
  Windows x64 `.msi`, macOS Intel `.pkg`, macOS Apple Silicon `.pkg`.
- Maven 3.9+ (or IntelliJ IDEA CE's bundled Maven).
- Internet access only for the FX view's "Fetch from Frankfurter" button;
  everything else works fully offline.

## Project layout

```
src/main/java/com/ledgerpro/   App.java          JavaFX entry point
                               Launcher.java     packaged-app main (jpackage)
                               DbCli.java        DB health check (CLI)
                               db/               Database: connections + Flyway
                               model/            Client, Account, Period,
                                                 JournalEntry, JournalLine,
                                                 EntryType, TbStage, FxRate
                               service/          ClientService, AccountService,
                                                 PeriodService, JournalService,
                                                 WorksheetService, FxRateService,
                                                 StandardChart, exceptions
                               ui/               AppShell, Dashboard, Clients,
                                                 Accounts (COA), FxView, Journal,
                                                 Ledgers, TrialBalance,
                                                 Worksheet, Reports, dialogs,
                                                 Theme + ThemeManager (the
                                                 switchable looks)
src/main/resources/            db/migration/     V1 schema
                               css/ledgerpro.css author stylesheet (on AtlantaFX)
                               css/theme-alexia.css Alexia's green palette
src/test/java/                 db/               Phase-1 smoke tests
                               service/          client / account / chart / FX /
                                                 period / journal / worksheet tests
                               dev/UiSnapshot    headless screenshot smoke check
```

## Where is my data?

- Development runs (`mvn javafx:run`, DbCli): `data/ledgerpro.db` next to
  the project, plus `-wal` / `-shm` sidecar files while the app runs — that
  is WAL mode working normally.
- The packaged application: `~/.ledgerpro/ledgerpro.db` (its working
  directory is read-only, so it falls back to your home folder).
- Override either with `-Dledgerpro.db=/any/path.db` or the
  `LEDGERPRO_DB` environment variable.

## Golden rules

1. Never edit a Flyway migration that already ran on a database; add
   `V2__…`, `V3__…` instead.
2. Money is stored as integer cents; FX *rates* are ratios (REAL), and the
   cents they produce when applied still land in the journal as integers.
3. Accounting rules (Dr = Cr, posting, closing) live in `service` classes
   only.
4. Nothing is ever deleted: clients and accounts are archived/deactivated,
   entries are voided by mirrored reversing entries.
5. Closed periods are frozen — corrections reopen them in daylight, with
   an audit row, never by silent back-dated edits.
